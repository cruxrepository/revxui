const endpoints = {
  baseUrl:
    process.env.NODE_ENV === "development"
      ? "https://apistore.revxenergy.com"
      : "https://apistore.revxenergy.com",
  //baseUrlLogin: process.env.NODE_ENV==="development"?"http://localhost:3000":"https://backend.solarnxt.com",
  //baseUrlLogin: process.env.NODE_ENV==="development"?"http://13.233.105.186:3000":"http://13.233.105.186:3000",
  googleMapsKey : "AIzaSyA16d9FJFh__vK04jU1P64vnEpPc3jenec",
  baseUrlLogin: process.env.REACT_APP_BASE_URL,
  //  tokenValidation: "/configurator/v1/auth/validate-token/",
  // userLogin: "/bo/api/auth/login",
  // googleLogin: "/bo/api/auth/login/google"
};

export default endpoints;