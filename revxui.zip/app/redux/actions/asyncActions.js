import axios from "axios";
import endpoints from "../../endpoints/endpoints";

export function userLogin(data) {
  return (dispatch) => {
    const url = endpoints.baseUrl + `/user/LoginView`;

    // dispatch({ type: 'USER_LOGIN_INITIATED' });
    axios
      .post(url, data)
      .then((response) => {
        const payloadData = response.data;
        dispatch({
          type: 'USER_LOGIN_SUCCESSFUL',
          payload: { ...payloadData },
          loginBy: 'mobile'
        });

        // dispatch({
        //     type: LOGIN,
        //     payload: {
        //         isLoggedIn: true
        //     }
        // });
      })
      .catch((error) => {
        let errorStr = null;
        if (!error.response) {
          errorStr = 'Sorry for the inconvenience, server not reachable. Please try again later';
        }
        if (error.response === 400) {
          errorStr = 'Invalid Email id or password';
        } else if (error.response === 401) {
          errorStr = 'Unauthorized access';
        } else {
          errorStr = 'Login failed';
        }
        // dispatch({
        //     type: 'USER_LOGIN_FAILED',
        //     payload: 'Invalid Email id or password',
        //     // payloadd: 'Unauthorized access',
        //     // payloaddd: 'Login failed',
        //     loginBy: 'mobile'
        // });

      });
  };
}

export function getCVBulk(id, uid, rid, page) {
  return (dispatch) => {
    let getCVUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?user_id=` + uid + `&role_id=` + rid + `&type=Commercial&page=` + page;
    let allCVFetchs = [];
    let finalCVCall = [];

    dispatch({ type: "GET_CV_LIST" });
    axios
      .get(getCVUrl)
      .then((response) => {
        allCVFetchs = response.data.data;

        allCVFetchs.map((en) => {
          let allData = [];
          // allData.push(en.vehicle_number);                      
          allData.push({
            "vehicle_number": en.vehicle_number, "type": en.type, "vehicle_model": en.vehicle_model,
            "vehicle_status": en.vehicle_status, "serial_number": en.serial_number, "vehicle_id": en.vehicle_id
          });
          allData.push({ "serial_number": en.serial_number, "created_at": en.created_at });
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.distance_to_empty);
          allData.push({
            "vehicle_id": en.vehicle_id, "driver_id": en.driver_id, "battery_id": en.battery_id, "vehicle_status": en.vehicle_status,
            "batteryassign_status": en.batteryassign_status, "driver_status": en.driver_status,
            "vehicle_battery_id": en.vehicle_battery_id, "assignment_id": en.assignment_id,
            "telematics_status": en.telematics_status, "asset_linkage_id": en.asset_linkage_id,
            "imei": en.imei, "driver_name": en.driver_name, "serial_number": en.serial_number, "type": en.type
          });
          allData.push(en.vehicle_number);
          allData.push(en.type);
          allData.push(en.vehicle_model);
          allData.push(en.vehicle_status);
          allData.push(en.serial_number);
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.distance_to_empty);
          allData.push(en.batteryassign_status);
          allData.push(en.driver_status);
          allData.push(en.telematics_status);
          allData.push(en.imei);
          allData.push(en.chassis_number);
          allData.push(en.engine_number);
          allData.push(en.asset.fleet_name);
          allData.push(en.user.operational_manager);

          finalCVCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalCVCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_CV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_CV_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getCommVBulk(id, uid, rid) {
  return (dispatch) => {
    let getCVUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?user_id=` + uid + `&role_id=` + rid + `&type=Commercial&page=`;
    let allCVFetchs = [];
    let finalCVCall = [];

    dispatch({ type: "GET_CV_LIST" });
    axios
      .get(getCVUrl)
      .then((response) => {
        allCVFetchs = response.data.data;

        allCVFetchs.map((en) => {
          let allData = [];
          allData.push({
            "vehicle_number": en.vehicle_number, "type": en.type, "vehicle_model": en.vehicle_model,
            "vehicle_status": en.vehicle_status, "serial_number": en.serial_number, "vehicle_id": en.vehicle_id
          });
          allData.push({ "serial_number": en.serial_number, "created_at": en.created_at });
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.distance_to_empty);
          allData.push({
            "vehicle_id": en.vehicle_id, "driver_id": en.driver_id, "battery_id": en.battery_id, "vehicle_status": en.vehicle_status,
            "batteryassign_status": en.batteryassign_status, "driver_status": en.driver_status,
            "vehicle_battery_id": en.vehicle_battery_id, "assignment_id": en.assignment_id,
            "telematics_status": en.telematics_status, "asset_linkage_id": en.asset_linkage_id,
            "imei": en.imei, "driver_name": en.driver_name, "serial_number": en.serial_number, "type": en.type
          });
          allData.push(en.vehicle_number);
          allData.push(en.type);
          allData.push(en.vehicle_model);
          allData.push(en.vehicle_status);
          allData.push(en.serial_number);
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.distance_to_empty);
          allData.push(en.batteryassign_status);
          allData.push(en.driver_status);
          allData.push(en.telematics_status);
          allData.push(en.imei);
          allData.push(en.chassis_number);
          allData.push(en.engine_number);
          allData.push(en.asset.fleet_name);
          allData.push(en.user.operational_manager);


          finalCVCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalCVCall,
          rawData: response.data.data,

        };
        dispatch({
          type: "GET_CV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_CV_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getCVLBulk(id, uid, rid) {
  return (dispatch) => {
    let getCVLUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?user_id=` + uid + `&role_id=` + rid + `&type=Commercial`;
    let allCVLFetchs = [];
    let finalCVLCall = [];

    dispatch({ type: "GET_CVL_LIST" });
    axios
      .get(getCVLUrl)
      .then((response) => {
        allCVLFetchs = response.data.data;

        allCVLFetchs.map((en) => {
          let allData = [];
          allData.push(en.vehicle_number);
          allData.push(en.type);
          allData.push(en.vehicle_status);
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.serial_number);
          allData.push(en.distance_to_empty);
          allData.push(en.batteryassign_status);
          allData.push(en.driver_status);
          allData.push(en.vehicle_model);
          allData.push(en.chassis_number);
          allData.push(en.engine_number);
          allData.push(en.asset.fleet_name);
          allData.push(en.user.operational_manager);
          allData.push(en.telematics_status);
          allData.push(en.imei);

          finalCVLCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalCVLCall,
          rawData: response.data.data,

        };
        dispatch({
          type: "GET_CVL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_CVL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getFleetBulk() {
  return (dispatch) => {
    let getFleetUrl = endpoints.baseUrl + `/vehicle/list/fleet`;
    let allFleetFetchs = [];
    let finalFleetCall = [];

    dispatch({ type: "GET_FLEET_LIST" });
    axios
      .get(getFleetUrl)
      .then((response) => {
        allFleetFetchs = response.data.data;

        allFleetFetchs.map((en) => {
          let allData = [];

          allData.push(en.fleet_name);
          allData.push(en.entity_id);


          finalFleetCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalFleetCall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_FLEET_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_FLEET_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getIVBulk(id) {
  return (dispatch) => {
    let getIVUrl = endpoints.baseUrl + `/vehicle/list/investor/` + id;
    let allIVFetchs = [];
    let finalIVCall = [];

    dispatch({ type: "GET_IV_LIST" });
    axios
      .get(getIVUrl)
      .then((response) => {
        allIVFetchs = response.data.data;

        allIVFetchs.map((en) => {
          let allData = [];

          allData.push(en.user_name);
          allData.push(en.user_id);


          finalIVCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalIVCall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_IV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_IV_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getIV2Bulk(id) {
  return (dispatch) => {
    let getIV2Url = endpoints.baseUrl + `/battery/investor/` + id;
    let allIV2Fetchs = [];
    let finalIV2Call = [];

    dispatch({ type: "GET_IV2_LIST" });
    axios
      .get(getIV2Url)
      .then((response) => {
        allIV2Fetchs = response.data.data;

        allIV2Fetchs.map((en) => {
          let allData = [];

          allData.push(en.user_name);
          allData.push(en.user_id);


          finalIV2Call.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalIV2Call,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_IV2_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_IV2_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getOMBulk(id) {
  return (dispatch) => {
    let getOMUrl = endpoints.baseUrl + `/vehicle/list/manager/` + id;
    let allOMFetchs = [];
    let finalOMCall = [];

    dispatch({ type: "GET_OM_LIST" });
    axios
      .get(getOMUrl)
      .then((response) => {
        allOMFetchs = response.data.data;

        allOMFetchs.map((en) => {
          let allData = [];

          allData.push(en.user_name);
          allData.push(en.user_id);


          finalOMCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalOMCall,
          rawData: response.data.data

        };
        // console.log("payload_data",payload_data);
        dispatch({
          type: "GET_OM_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_OM_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}

export function getEVBulk(id, uid, rid, page) {
  return (dispatch) => {
    let getEVUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?user_id=` + uid + `&role_id=` + rid + `&type=Erickshaw&page=` + page;
    let allEVFetchs = [];
    let finalEVCall = [];

    dispatch({ type: "GET_EV_LIST" });
    axios
      .get(getEVUrl)
      .then((response) => {
        allEVFetchs = response.data.data;

        allEVFetchs.map((en) => {
          let allData = [];
          allData.push({
            "vehicle_number": en.vehicle_number, "vehicle_status": en.vehicle_status,
            "vehicle_id": en.vehicle_id, "serial_number": en.serial_number
          });
          allData.push({ "serial_number": en.serial_number, "created_at": en.created_at });
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.soc);
          allData.push({
            "battery_status": en.battery_status, "vehicle_id": en.vehicle_id, "assignment_id": en.assignment_id,
            "driver_status": en.driver_status, "vehicle_status": en.vehicle_status, "asset_linkage_id": en.asset_linkage_id,
            "telematics_status": en.telematics_status, "imei": en.imei, "driver_name": en.driver_name,
            "serial_number": en.serial_number, "batteryassign_status": en.batteryassign_status, "vehicle_battery_id": en.vehicle_battery_id
          });
          allData.push(en.vehicle_number);
          allData.push(en.type);
          allData.push(en.vehicle_model);
          allData.push(en.vehicle_status);
          allData.push(en.serial_number);
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.distance_to_empty);
          allData.push(en.batteryassign_status);
          allData.push(en.driver_status);
          allData.push(en.telematics_status);
          allData.push(en.imei);
          allData.push(en.chassis_number);
          allData.push(en.engine_number);
          allData.push(en.asset.fleet_name);
          allData.push(en.user.operational_manager);
          finalEVCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalEVCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_EV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_EV_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getErickVBulk(id, uid, rid) {
  return (dispatch) => {
    let getEVUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?user_id=` + uid + `&role_id=` + rid + `&type=Erickshaw&page=`;
    let allEVFetchs = [];
    let finalEVCall = [];

    dispatch({ type: "GET_EV_LIST" });
    axios
      .get(getEVUrl)
      .then((response) => {
        allEVFetchs = response.data.data;

        allEVFetchs.map((en) => {
          let allData = [];
          allData.push({
            "vehicle_number": en.vehicle_number, "vehicle_status": en.vehicle_status,
            "vehicle_id": en.vehicle_id, "serial_number": en.serial_number
          });
          allData.push({ "serial_number": en.serial_number, "created_at": en.created_at });
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.soc);
          allData.push({
            "battery_status": en.battery_status, "vehicle_id": en.vehicle_id, "assignment_id": en.assignment_id,
            "driver_status": en.driver_status, "vehicle_status": en.vehicle_status, "asset_linkage_id": en.asset_linkage_id,
            "telematics_status": en.telematics_status, "imei": en.imei, "driver_name": en.driver_name,
            "serial_number": en.serial_number, "batteryassign_status": en.batteryassign_status, "vehicle_battery_id": en.vehicle_battery_id
          });
          allData.push(en.vehicle_number);
          allData.push(en.type);
          allData.push(en.vehicle_model);
          allData.push(en.vehicle_status);
          allData.push(en.serial_number);
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.distance_to_empty);
          allData.push(en.batteryassign_status);
          allData.push(en.driver_status);
          allData.push(en.telematics_status);
          allData.push(en.imei);
          allData.push(en.chassis_number);
          allData.push(en.engine_number);
          allData.push(en.asset.fleet_name);
          allData.push(en.user.operational_manager);
          finalEVCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalEVCall,
          rawData: response.data.data,
        };
        dispatch({
          type: "GET_EV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_EV_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getEVLBulk(id, uid, rid) {
  return (dispatch) => {
    let getEVLUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?user_id=` + uid + `&role_id=` + rid + `&type=Erickshaw`;
    let allEVLFetchs = [];
    let finalEVLCall = [];

    dispatch({ type: "GET_EVL_LIST" });
    axios
      .get(getEVLUrl)
      .then((response) => {
        allEVLFetchs = response.data.data;

        allEVLFetchs.map((en) => {
          let allData = [];
          allData.push(en.vehicle_number);
          allData.push(en.type);
          allData.push(en.vehicle_status);
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.serial_number);
          allData.push(en.distance_to_empty);
          allData.push(en.batteryassign_status);
          allData.push(en.driver_status);
          allData.push(en.vehicle_model);
          allData.push(en.chassis_number);
          allData.push(en.engine_number);
          allData.push(en.asset.fleet_name);
          allData.push(en.user.operational_manager);
          allData.push(en.telematics_status);
          allData.push(en.imei);
          finalEVLCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalEVLCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_EVL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_EVL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getVMBulk(page) {
  return (dispatch) => {
    let getVMUrl = endpoints.baseUrl + `/vehiclemodel/list?page=` + page;
    let allVMFetchs = [];
    let finalVMCall = [];

    dispatch({ type: "GET_VM_LIST" });
    axios
      .get(getVMUrl)
      .then((response) => {
        allVMFetchs = response.data.data;

        allVMFetchs.map((en) => {
          let allData = [];

          allData.push(en.model);
          allData.push(en.seating);
          allData.push(en.top_speed);
          allData.push(en.payload_weight);
          allData.push(en.typical_range);
          allData.push(en.model_id);
          allData.push(en.fuel);
          allData.push(en.gross_vehicle_weight);
          allData.push(en.width);
          allData.push(en.height);
          allData.push(en.length);
          allData.push(en.load_body_type);
          allData.push(en.manufacturer);
          allData.push(en.unladen_wt);
          allData.push(en.vehicle_type);

          finalVMCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalVMCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_VM_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_VM_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}

export function getBatteryModelBulk(page) {
  return (dispatch) => {
    // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
    let getBatteryModelUrl = endpoints.baseUrl + `/batterymodel/list?page=` + page;
    let allBatteryModelFetchs = [];
    let finalBatteryModelCall = [];

    dispatch({ type: "GET_BATTERYMODEL_LIST" });
    axios
      .get(getBatteryModelUrl)
      .then((response) => {
        allBatteryModelFetchs = response.data.data;

        allBatteryModelFetchs.map((en) => {
          let allData = [];

          allData.push(en.model_info);
          allData.push(en.nominal_voltage);
          allData.push(en.capacity_mah);
          allData.push(en.power);
          allData.push(en.cell_maufacturer);
          allData.push(en.battery_model_id);
          allData.push(en.battery_type);
          allData.push(en.cell_chemisty);
          allData.push(en.cell_type);
          allData.push(en.height);
          allData.push(en.width);
          allData.push(en.length);
          allData.push(en.number_of_cells_parallel);
          allData.push(en.number_of_cells_series);
          allData.push(en.oem);
          allData.push(en.thermistor);


          finalBatteryModelCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalBatteryModelCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_BATTERYMODEL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GETCBATTERYMODEL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBatteryModelLBulk() {
  return (dispatch) => {
    // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
    let getBatteryModelLUrl = endpoints.baseUrl + `/batterymodel/list`;
    let allBatteryModelLFetchs = [];
    let finalBatteryModelLCall = [];

    dispatch({ type: "GET_BATTERYMODELL_LIST" });
    axios
      .get(getBatteryModelLUrl)
      .then((response) => {
        allBatteryModelLFetchs = response.data.data;

        allBatteryModelLFetchs.map((en) => {
          let allData = [];

          allData.push(en.model_info);
          allData.push(en.nominal_voltage);
          allData.push(en.capacity_mah);
          allData.push(en.power);
          allData.push(en.cell_maufacturer);
          allData.push(en.battery_model_id);
          allData.push(en.battery_type);
          allData.push(en.cell_chemisty);
          allData.push(en.cell_type);
          allData.push(en.height);
          allData.push(en.width);
          allData.push(en.length);
          allData.push(en.number_of_cells_parallel);
          allData.push(en.number_of_cells_series);
          allData.push(en.oem);
          allData.push(en.thermistor);


          finalBatteryModelLCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalBatteryModelLCall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_BATTERYMODELL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GETCBATTERYMODELL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getMyBatteryBulk(id, uId, rId, page) {
  return (dispatch) => {
    let getMyBatteryUrl = endpoints.baseUrl + `/battery/get/` + id + `?user_id=` + uId + `&role_id=` + rId + `&page=` + page;
    let allMyBatteryFetchs = [];
    let finalMyBatteryCall = [];
    dispatch({ type: "GET_MYBATTERY_LIST" });
    axios
      .get(getMyBatteryUrl)
      .then((response) => {
        allMyBatteryFetchs = response.data.data;

        allMyBatteryFetchs.map((en) => {
          let allData = [];

          allData.push({
            "bms_id": en.bms_id, "serial_number": en.serial_number, "battery_model": en.battery_model,
            "vehicle_number": en.vehicle_number, "imei": en.imei, "battery_status": en.battery_status, "battery_type": en.battery_type
          });
          allData.push({ "vehicle_number": en.vehicle_number, "updated_at": en.updated_at });
          allData.push(en.investors.investor);
          allData.push(en.user.operational_manager);
          allData.push({ "imei": en.imei, "status": en.status });
          allData.push({
            "bms_id": en.bms_id, "serial_number": en.serial_number, "vehicle_id": en.vehicle_id,
            "vehicle_status": en.vehicle_status, "vehicle_number": en.vehicle_number,
            "vehicle_battery_id": en.vehicle_battery_id, "battery_id": en.battery_id, "battery_status": en.battery_status,
            "telematics_status": en.telematics_status, "asset_linkage_id": en.asset_linkage_id,
            "imei": en.imei, "battery_type": en.battery_type
          });
          allData.push(en.serial_number);
          allData.push(en.battery_model);
          allData.push(en.vehicle_number);
          allData.push(en.imei);
          allData.push(en.investors.investor);
          allData.push(en.user.operational_manager);
          allData.push(en.battery_status);
          allData.push(en.battery_type);
          allData.push(en.status);
          allData.push(en.vehicle_status);
          allData.push(en.telematics_status);
          allData.push(en.bms_unique_id);
          allData.push(en.sw_version);

          finalMyBatteryCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalMyBatteryCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_MYBATTERY_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_MYBATTERY_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function GetBBBulk(id, uId, rId) {
  return (dispatch) => {
    let getMyBatteryUrl = endpoints.baseUrl + `/battery/get/` + id + `?user_id=` + uId + `&role_id=` + rId + `&page=`;
    let allMyBatteryFetchs = [];
    let finalMyBatteryCall = [];
    dispatch({ type: "GET_MYBATTERY_LIST" });
    axios
      .get(getMyBatteryUrl)
      .then((response) => {
        allMyBatteryFetchs = response.data.data;

        allMyBatteryFetchs.map((en) => {
          let allData = [];

          // allData.push(en.serial_number);
          allData.push({
            "bms_id": en.bms_id, "serial_number": en.serial_number, "battery_model": en.battery_model,
            "vehicle_number": en.vehicle_number, "imei": en.imei, "battery_status": en.battery_status, "battery_type": en.battery_type
          });
          allData.push({ "vehicle_number": en.vehicle_number, "updated_at": en.updated_at });
          allData.push(en.investors.investor);
          allData.push(en.user.operational_manager);
          allData.push({ "imei": en.imei, "status": en.status });
          allData.push({
            "bms_id": en.bms_id, "serial_number": en.serial_number, "vehicle_id": en.vehicle_id,
            "vehicle_status": en.vehicle_status, "vehicle_number": en.vehicle_number,
            "vehicle_battery_id": en.vehicle_battery_id, "battery_id": en.battery_id, "battery_status": en.battery_status,
            "telematics_status": en.telematics_status, "asset_linkage_id": en.asset_linkage_id,
            "imei": en.imei, "battery_type": en.battery_type
          });
          allData.push(en.serial_number);
          allData.push(en.battery_model);
          allData.push(en.vehicle_number);
          allData.push(en.imei);
          allData.push(en.investors.investor);
          allData.push(en.user.operational_manager);
          allData.push(en.battery_status);
          allData.push(en.battery_type);
          allData.push(en.status);
          allData.push(en.vehicle_status);
          allData.push(en.telematics_status);
          allData.push(en.bms_unique_id);
          allData.push(en.sw_version);
          finalMyBatteryCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalMyBatteryCall,
          rawData: response.data.data,

        };
        dispatch({
          type: "GET_MYBATTERY_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_MYBATTERY_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBatteryTotal(id, uId, rId) {
  return (dispatch) => {
    let getMyBatteryUrl = endpoints.baseUrl + `/battery/get/` + id + `?user_id=` + uId + `&role_id=` + rId + `&page=`;
    let allMyBatteryFetchs = [];
    let finalMyBatteryCall = [];
    dispatch({ type: "GET_LIST" });
    axios
      .get(getMyBatteryUrl)
      .then((response) => {
        allMyBatteryFetchs = response.data.data;

        allMyBatteryFetchs.map((en) => {
          let allData = [];

          // allData.push(en.serial_number);
          allData.push(en.serial_number);
          allData.push(en.battery_model);
          allData.push(en.investors.investor);
          allData.push(en.user.operational_manager);
          allData.push(en.vehicle_number);
          allData.push(en.status);
          allData.push(en.vehicle_status);
          allData.push(en.battery_status);
          allData.push(en.bms_unique_id);
          allData.push(en.sw_version);
          allData.push(en.imei);
          allData.push(en.battery_type);
          allData.push(en.telematics_status);
          allData.push(en.bms_model_info);
          finalMyBatteryCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalMyBatteryCall,
          rawData: response.data.data,

        };
        dispatch({
          type: "GET_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBMSBulk(page) {
  return (dispatch) => {
    // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
    let getBMSUrl = endpoints.baseUrl + `/battery/bms/list?page=` + page;
    let allBMSFetchs = [];
    let finalBMSCall = [];

    dispatch({ type: "GET_BMS_LIST" });
    axios
      .get(getBMSUrl)
      .then((response) => {
        allBMSFetchs = response.data.data;

        allBMSFetchs.map((en) => {
          let allData = [];

          allData.push(en.model_info);
          allData.push(en.hw_version);
          allData.push(en.oem);
          allData.push(en.bms_model_id);


          finalBMSCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalBMSCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_BMS_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BMS_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBMSLBulk() {
  return (dispatch) => {
    // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
    let getBMSLUrl = endpoints.baseUrl + `/battery/bms/list`;
    let allBMSLFetchs = [];
    let finalBMSLCall = [];

    dispatch({ type: "GET_BMSL_LIST" });
    axios
      .get(getBMSLUrl)
      .then((response) => {
        allBMSLFetchs = response.data.data;

        allBMSLFetchs.map((en) => {
          let allData = [];

          allData.push(en.model_info);
          allData.push(en.hw_version);
          allData.push(en.oem);
          allData.push(en.bms_model_id);


          finalBMSLCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalBMSLCall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_BMSL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BMSL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBatteryProBulk(imei) {
  return (dispatch) => {
    let getBatteryProUrl = endpoints.baseUrl + `/battery/profile/` + imei;
    let allBatteryProFetchs = [];
    let finalBatteryProCall = [];

    dispatch({ type: "GET_BATTERY_PRO_LIST" });
    axios
      .get(getBatteryProUrl)
      .then((response) => {
        allBatteryProFetchs = response.data.data;
        const payload_data = {
          status: response.status,
          data: allBatteryProFetchs,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_BATTERY_PRO_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BATTERY_PRO_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBDashboardBulk(imei) {
  return (dispatch) => {
    let getBDashboardUrl = endpoints.baseUrl + `/battery/dashboard/` + imei;
    let allBDashboardFetchs = [];
    let finalBDashboardCall = [];

    dispatch({ type: "GET_BATTERY_DASHBOARD_LIST" });
    axios
      .get(getBDashboardUrl)
      .then((response) => {
        allBDashboardFetchs = response.data.data;
        const payload_data = {
          status: response.status,
          data: allBDashboardFetchs,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_BATTERY_DASHBOARD_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BATTERY_DASHBOARD_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getVDashboardBulk(vid) {
  return (dispatch) => {
    let getVDashboardUrl = endpoints.baseUrl + `/vehicle/dashboard/` + vid;
    let allVDashboardFetchs = [];
    let finalVDashboardCall = [];

    dispatch({ type: "GET_VEHICLE_DASHBOARD_LIST" });
    axios
      .get(getVDashboardUrl)
      .then((response) => {
        allVDashboardFetchs = response.data.data;
        const payload_data = {
          status: response.status,
          data: allVDashboardFetchs,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_VEHICLE_DASHBOARD_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_VEHICLE_DASHBOARD_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBatteryViewBulk(imei) {
  return (dispatch) => {
    let getBatteryViewUrl = endpoints.baseUrl + `/battery/data/` + imei;
    let allBatteryViewFetchs = [];
    let finalBatteryViewCall = [];

    dispatch({ type: "GET_BATTERY_VIEW_LIST" });
    axios
      .get(getBatteryViewUrl)
      .then((response) => {
        allBatteryViewFetchs = response.data.data;

        // allBatteryViewFetchs.map((en) => {
        //     let allData = [];

        //     allData.push(en.name);
        //     allData.push(en.value);
        //     finalBatteryViewCall.push(allData);
        // })
        const payload_data = {
          status: response.status,
          data: allBatteryViewFetchs,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_BATTERY_VIEW_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BATTERY_VIEW_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}

export function getBVABulk() {
  return (dispatch) => {
    let getBVAUrl = endpoints.baseUrl + `/battery/vehicle/list`;
    let allBVAFetchs = [];
    let finalBVACall = [];

    dispatch({ type: "GET_BVA_LIST" });
    axios
      .get(getBVAUrl)
      .then((response) => {
        allBVAFetchs = response.data.data;

        allBVAFetchs.map((en) => {
          let allData = [];

          allData.push(en.vehicle_number);
          allData.push(en.vehicle_id);


          finalBVACall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalBVACall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_BVA_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BVA_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getVDABulk(id, vtype) {
  return (dispatch) => {
    let getVDAUrl = endpoints.baseUrl + `/vehicle/driver/assign/` + id + `?type=` + vtype;
    let allVDAFetchs = [];
    let finalVDACall = [];

    dispatch({ type: "GET_VDA_LIST" });
    axios
      .get(getVDAUrl)
      .then((response) => {
        allVDAFetchs = response.data.data;

        allVDAFetchs.map((en) => {
          let allData = [];

          allData.push(en.name);
          allData.push(en.driver_id);


          finalVDACall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalVDACall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_VDA_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_VDA_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getEVDABulk(id) {
  return (dispatch) => {
    let getEVDAUrl = endpoints.baseUrl + `/vehicle/driver/erick/assign/` + id;
    let allEVDAFetchs = [];
    let finalEVDACall = [];

    dispatch({ type: "GET_EVDA_LIST" });
    axios
      .get(getEVDAUrl)
      .then((response) => {
        allEVDAFetchs = response.data.data;

        allEVDAFetchs.map((en) => {
          let allData = [];

          allData.push(en.name);
          allData.push(en.driver_id);


          finalEVDACall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalEVDACall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_EVDA_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_EVDA_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBABulk() {
  return (dispatch) => {
    let getBAUrl = endpoints.baseUrl + `/vehicle/battery/assign`;
    let allBAFetchs = [];
    let finalBACall = [];

    dispatch({ type: "GET_BA_LIST" });
    axios
      .get(getBAUrl)
      .then((response) => {
        allBAFetchs = response.data.data;

        allBAFetchs.map((en) => {
          let allData = [];

          allData.push(en.serial_number);
          allData.push(en.battery_id);


          finalBACall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalBACall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_BA_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BA_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getBatteryListBulk() {
  return (dispatch) => {
    let getBatteryListUrl = endpoints.baseUrl + `/battery/list/2`;
    let allBatteryListFetchs = [];
    let finalBatteryListCall = [];

    dispatch({ type: "GET_BATTERYLIST_LIST" });
    axios
      .get(getBatteryListUrl)
      .then((response) => {

        allBatteryListFetchs = response.data.data;
        // allBatteryListFetchs.map((en) => {
        let allData = [];

        allData.push(allBatteryListFetchs.battery_model);
        allData.push(allBatteryListFetchs.vehicle_type);
        allData.push(allBatteryListFetchs.vehicle_number);
        allData.push(allBatteryListFetchs.driver_name);
        allData.push(allBatteryListFetchs.battery_voltage);
        allData.push(allBatteryListFetchs.soc);
        allData.push(allBatteryListFetchs.current_state);
        allData.push(allBatteryListFetchs.soh);
        allData.push(allBatteryListFetchs.battery_health_status)

        finalBatteryListCall.push(allData);

        const payload_data = {
          status: response.status,
          data: finalBatteryListCall,
          rawData: response.data.data
        };
        dispatch({
          type: "GET_BATTERYLIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BATTERYLIST_FAILED",
          payload: { status, data },
        });
      });

  };
}

export function getUserBulk(id, page) {
  return (dispatch) => {
    let getUserUrl = endpoints.baseUrl + `/bo/list/` + id + `?page=` + page;
    let allUserFetchs = [];
    let finalUserCall = [];

    dispatch({ type: "GET_USER_LIST" });
    axios
      .get(getUserUrl)
      .then((response) => {
        allUserFetchs = response.data.data;
        allUserFetchs.map((en) => {
          let allData = [];

          allData.push(en.username);
          allData.push(en.email);
          allData.push(en.mobile_number);
          allData.push(en.role_name);
          allData.push(en.operator_name);
          allData.push(en.entity.asset_type)
          allData.push(en.user_id)
          allData.push(en.address);
          allData.push(en.entity_id)


          finalUserCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalUserCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record
        };
        dispatch({
          type: "GET_USER_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_USER_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getUserLBulk(id) {
  return (dispatch) => {
    let getUserLUrl = endpoints.baseUrl + `/bo/list/` + id;
    let allUserLFetchs = [];
    let finalUserLCall = [];

    dispatch({ type: "GET_USERL_LIST" });
    axios
      .get(getUserLUrl)
      .then((response) => {
        allUserLFetchs = response.data.data;
        allUserLFetchs.map((en) => {
          let allData = [];

          allData.push(en.username);
          allData.push(en.email);
          allData.push(en.mobile_number);
          allData.push(en.role_name);
          allData.push(en.operator_name);
          allData.push(en.entity.asset_type)
          allData.push(en.user_id)
          allData.push(en.address);
          allData.push(en.entity_id)


          finalUserLCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalUserLCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record
        };
        dispatch({
          type: "GET_USERL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_USERL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getRoleBulk(page) {
  return (dispatch) => {
    let getRoleUrl = endpoints.baseUrl + `/role/get?page=` + page;
    let allRoleFetchs = [];
    let finalRoleCall = [];

    dispatch({ type: "GET_ROLE_LIST" });
    axios
      .get(getRoleUrl)
      .then((response) => {
        allRoleFetchs = response.data.data;

        allRoleFetchs.map((en) => {
          let allData = [];

          allData.push(en.role_name);
          allData.push(en.role_id);
          finalRoleCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalRoleCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record
        };
        dispatch({
          type: "GET_ROLE_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_ROLE_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getRoleLBulk() {
  return (dispatch) => {
    let getRoleLUrl = endpoints.baseUrl + `/role/get`;
    let allRoleLFetchs = [];
    let finalRoleLCall = [];

    dispatch({ type: "GET_ROLEL_LIST" });
    axios
      .get(getRoleLUrl)
      .then((response) => {
        allRoleLFetchs = response.data.data;

        allRoleLFetchs.map((en) => {
          let allData = [];

          allData.push(en.role_name);
          allData.push(en.role_id);
          finalRoleLCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalRoleLCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record
        };
        dispatch({
          type: "GET_ROLEL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_ROLEL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getDriverBulk(id) {
  return (dispatch) => {
    let getDriverUrl = endpoints.baseUrl + `/driver/list/` + id + `?page=`;
    let allDriverFetchs = [];
    let finalDriverCall = [];

    dispatch({ type: "GET_DRIVER_LIST" });
    axios
      .get(getDriverUrl)
      .then((response) => {
        allDriverFetchs = response.data;


        const payload_data = {
          status: response.status,
          data: response.data,
          totalRecords: response.data.total_record.toString(),
          page_number: response.data.page_number,
          total_records: response.data.total_records
        };
        // console.log("payload_data",payload_data)

        dispatch({
          type: "GET_DRIVER_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_DRIVER_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}

export function getEntityBulk() {
  return (dispatch) => {
    let getEntityUrl = endpoints.baseUrl + `/entity/get?page=`;
    let allEntityFetchs = [];
    let finalEntityCall = [];
    dispatch({ type: "GET_ENTITY_LIST" });
    axios
      .get(getEntityUrl)
      .then((response) => {
        allEntityFetchs = response.data.data;

        allEntityFetchs.map((en) => {
          let allData = [];

          allData.push(en.operator_name);
          allData.push(en.contact_name);
          allData.push(en.primary_email_id);
          allData.push(en.primary_mobile_number);
          allData.push(en.region);
          allData.push(en.gst);
          allData.push(en.fleet_id);
          finalEntityCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalEntityCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_ENTITY_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_ENTITY_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}

export function getClientBulk() {
  return (dispatch) => {
    let getClientUrl = endpoints.baseUrl + `/client/get`;
    let allClientFetchs = [];
    let finalClientCall = [];
    dispatch({ type: "GET_CLIENT_LIST" });
    axios
      .get(getClientUrl)
      .then((response) => {
        allClientFetchs = response.data.data;

        allClientFetchs.map((en) => {
          let allData = [];

          allData.push(en.name);
          allData.push(en.buisness_name);
          allData.push(en.primary_mobile_number);
          allData.push(en.number_of_hubs);
          allData.push(en.location);
          allData.push(en.gst_number);
          allData.push(en.client_id);
          finalClientCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalClientCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_CLIENT_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_CLIENT_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}


export function getTelematicsBulk(page) {
  return (dispatch) => {
    // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
    let getTelematicsUrl = endpoints.baseUrl + `/telematics/get?page=` + page;
    let allTelematicsFetchs = [];
    let finalTelematicsCall = [];

    dispatch({ type: "GET_TELEMATICS_LIST" });
    axios
      .get(getTelematicsUrl)
      .then((response) => {
        allTelematicsFetchs = response.data.data;

        allTelematicsFetchs.map((en) => {
          let allData = [];

          allData.push(en.model_info);
          allData.push(en.oem);
          allData.push(en.sim_type);
          allData.push(en.protocal);
          allData.push(en.datasheet_attachment);
          allData.push(en.telematics_model_id);


          finalTelematicsCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalTelematicsCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_TELEMATICS_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_TELEMATICS_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getTMBulk() {
  return (dispatch) => {
    let getTMUrl = endpoints.baseUrl + `/telematics/get`;
    let allTMFetchs = [];
    let finalTMCall = [];

    dispatch({ type: "GET_TM_LIST" });
    axios
      .get(getTMUrl)
      .then((response) => {
        allTMFetchs = response.data.data;

        allTMFetchs.map((en) => {
          let allData = [];

          allData.push(en.model_info);
          allData.push(en.oem);
          allData.push(en.sim_type);
          allData.push(en.protocal);
          allData.push(en.datasheet_attachment);
          allData.push(en.telematics_model_id);


          finalTMCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalTMCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_TM_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_TM_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getTeleListBulk(id,uid,rid, page) {
  return (dispatch) => {
    // list/112?user_id=214&role_id=43&page=
    let getTeleListUrl = endpoints.baseUrl + `/telematicsnew/list/` + id + `?user_id=` + uid + `&role_id=` + rid + `&page=` + page;
    let allTeleListFetchs = [];
    let finalTeleListCall = [];

    dispatch({ type: "GET_TELELIST_LIST" });
    axios
      .get(getTeleListUrl)
      .then((response) => {
        allTeleListFetchs = response.data.data;

        allTeleListFetchs.map((en) => {
          let allData = [];

          allData.push(en.dbc_file_type);
          allData.push(en.model_info);
          allData.push(en.imei);
          allData.push(en.mobile_number);
          allData.push(en.sim_operator);
          allData.push({
            "telematics_id": en.telematics_id, "telematassign_status": en.telematassign_status,
            "vehicle_number": en.vehicle_number, "serial_number": en.serial_number
          });


          finalTeleListCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalTeleListCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_TELELIST_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_TELELIST_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getTeleListTotalBulk(id,uid,rid) {
  return (dispatch) => {
    // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
    let getTeleListTotalUrl = endpoints.baseUrl + `/telematicsnew/list/` + id + `?user_id=` + uid + `&role_id=` + rid;
    let allTeleListTotalFetchs = [];
    let finalTeleListTotalCall = [];

    dispatch({ type: "GET_TELELISTTOTAL_LIST" });
    axios
      .get(getTeleListTotalUrl)
      .then((response) => {
        allTeleListTotalFetchs = response.data.data;

        allTeleListTotalFetchs.map((en) => {
          let allData = [];

          allData.push(en.dbc_file_type);
          allData.push(en.model_info);
          allData.push(en.imei);
          allData.push(en.mobile_number);
          allData.push(en.sim_operator);
          allData.push({
            "telematics_id": en.telematics_id, "telematassign_status": en.telematassign_status,
            "vehicle_number": en.vehicle_number, "serial_number": en.serial_number
          });


          finalTeleListTotalCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalTeleListTotalCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_TELELISTTOTAL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_TELELISTTOTAL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getReportBulk(id, uid, rid, page) {
  return (dispatch) => {
    let getReportUrl = endpoints.baseUrl + `/battery/batteryreport/` + id + `?user_id=` + uid + `&role_id=` + rid + `&page=` + page;
    let allReportFetchs = [];
    let finalReportCall = [];

    dispatch({ type: "GET_REPORT_LIST" });
    axios
      .get(getReportUrl)
      .then((response) => {
        allReportFetchs = response.data.data;

        allReportFetchs.map((en) => {
          let allData = [];
          allData.push(en.serial_number);
          allData.push(en.bms_unique_id);
          allData.push(en.imei);
          allData.push({ "imei": en.imei, "bms_id": en.bms_id });


          finalReportCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalReportCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_REPORT_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_REPORT_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getReportFullBulk(id, uid, rid) {
  return (dispatch) => {
    let getReportFullUrl = endpoints.baseUrl + `/battery/batteryreport/` + id + `?user_id=` + uid + `&role_id=` + rid + `&page=`;
    let allReportFullFetchs = [];
    let finalReportFullCall = [];

    dispatch({ type: "GET_REPORTFULL_LIST" });
    axios
      .get(getReportFullUrl)
      .then((response) => {
        allReportFullFetchs = response.data.data;

        allReportFullFetchs.map((en) => {
          let allData = [];
          allData.push(en.serial_number);
          allData.push(en.bms_unique_id);
          allData.push(en.imei);
          allData.push({ "imei": en.imei, "bms_id": en.bms_id });


          finalReportFullCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalReportFullCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_REPORTFULL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_REPORTFULL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getVModelBulk() {
  return (dispatch) => {
    let getVModelUrl = endpoints.baseUrl + `/vehiclemodel/list`;
    let allVModelFetchs = [];
    let finalVModelCall = [];

    dispatch({ type: "GET_VMODEL_LIST" });
    axios
      .get(getVModelUrl)
      .then((response) => {
        allVModelFetchs = response.data.data;

        allVModelFetchs.map((en) => {
          let allData = [];

          allData.push(en.model);
          allData.push(en.seating);
          allData.push(en.top_speed);
          allData.push(en.payload_weight);
          allData.push(en.typical_range);
          allData.push(en.model_id);
          allData.push(en.fuel);
          allData.push(en.gross_vehicle_weight);
          allData.push(en.width);
          allData.push(en.height);
          allData.push(en.length);
          allData.push(en.load_body_type);
          allData.push(en.manufacturer);
          allData.push(en.unladen_wt);
          allData.push(en.vehicle_type);

          finalVModelCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalVModelCall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_VMODEL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_VMODEL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}

export function getTeleModelBulk() {
  return (dispatch) => {
    let getTeleModelUrl = endpoints.baseUrl + `/telematics/model`;
    let allTeleModelFetchs = [];
    let finalTeleModelCall = [];

    dispatch({ type: "GET_TELEMODEL_LIST" });
    axios
      .get(getTeleModelUrl)
      .then((response) => {
        allTeleModelFetchs = response.data.data;

        allTeleModelFetchs.map((en) => {
          let allData = [];

          allData.push(en.telematics_model_id);
          allData.push(en.model);


          finalTeleModelCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalTeleModelCall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_TELEMODEL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_TELEMODEL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}

export function TeleAssignBulk() {
  return (dispatch) => {
    let getTeleAssignUrl = endpoints.baseUrl + `/telematics/assign/get`;
    let allTeleAssignFetchs = [];
    let finalTeleAssignCall = [];

    dispatch({ type: "GET_TELE_ASSIGN_LIST" });
    axios
      .get(getTeleAssignUrl)
      .then((response) => {
        allTeleAssignFetchs = response.data.data;

        allTeleAssignFetchs.map((en) => {
          let allData = [];
          allData.push(en.telematics_id);
          allData.push(en.imei);
          finalTeleAssignCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalTeleAssignCall,
          rawData: response.data.data

        };
        dispatch({
          type: "GET_TELE_ASSIGN_LIST_FULFILLED",
          payload: payload_data,
        });
        console.log("payload_data", payload_data);
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_TELE_ASSIGN_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getInvestorBulk() {
  return (dispatch) => {
    let getInvestorUrl = endpoints.baseUrl + `/investor/get`;
    let allInvestorFetchs = [];
    let finalInvestorCall = [];

    dispatch({ type: "GET_INVESTOR_LIST" });
    axios
      .get(getInvestorUrl)
      .then((response) => {
        allInvestorFetchs = response.data.data;

        allInvestorFetchs.map((en) => {
          let allData = [];
          allData.push(en.investing_asset);
          allData.push(en.invest_company_name);
          allData.push(en.invest_operator_name);
          allData.push(en.primary_email_id);
          allData.push(en.primary_mobile_number);
          allData.push(en.gst);
          allData.push(en.investor_id);


          finalInvestorCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalInvestorCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_INVESTOR_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_INVESTOR_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getHypoBulk() {
  return (dispatch) => {
    let getHypoUrl = endpoints.baseUrl + `/hypo/get`;
    let allHypoFetchs = [];
    let finalHypoCall = [];

    dispatch({ type: "GET_HYPO_LIST" });
    axios
      .get(getHypoUrl)
      .then((response) => {
        allHypoFetchs = response.data.data;

        allHypoFetchs.map((en) => {
          let allData = [];
          allData.push(en.hypo_company_name);
          allData.push(en.hypo_operator_name);
          allData.push(en.primary_email_id);
          allData.push(en.secondary_email_id);
          allData.push(en.primary_mobile_number);
          allData.push(en.secondary_mobile_number);
          allData.push(en.gst);
          allData.push(en.hypo_id);
          allData.push(en.association.reference_id);
          allData.push(en.association.association_type);
          allData.push(en.association.association_name);


          finalHypoCall.push(allData);
        })
        const payload_data = {
          status: response.status,
          data: finalHypoCall,
          rawData: response.data.data,
          page_number: response.data.page_number,
          total_records: response.data.total_record

        };
        dispatch({
          type: "GET_HYPO_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_HYPO_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}