import axios from "axios";
import endpoints from "../../endpoints/endpoints";

export function userLogin(data) {
  return (dispatch) => {
      const url = endpoints.baseUrl + `/user/LoginView` ;

      // dispatch({ type: 'USER_LOGIN_INITIATED' });
      axios
          .post(url, data)
          .then((response) => {
              const payloadData = response.data;
              dispatch({
                  type: 'USER_LOGIN_SUCCESSFUL',
                  payload: { ...payloadData },
                  loginBy: 'mobile'
              });

              // dispatch({
              //     type: LOGIN,
              //     payload: {
              //         isLoggedIn: true
              //     }
              // });
          })
          .catch((error) => {
              let errorStr = null;
              if (!error.response) {
                  errorStr = 'Sorry for the inconvenience, server not reachable. Please try again later';
              }
              if (error.response === 400) {
                  errorStr = 'Invalid Email id or password';
              } else if (error.response === 401) {
                  errorStr = 'Unauthorized access';
              } else {
                  errorStr = 'Login failed';
              }
              // dispatch({
              //     type: 'USER_LOGIN_FAILED',
              //     payload: 'Invalid Email id or password',
              //     // payloadd: 'Unauthorized access',
              //     // payloaddd: 'Login failed',
              //     loginBy: 'mobile'
              // });
              
          });
  };
}

export function getCVBulk(id, page) {
  return (dispatch) => {
      let getCVUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?type=Commercial&page=` + page ;
      let allCVFetchs = [];
      let finalCVCall = [];
     
    dispatch({ type: "GET_CV_LIST" });
    axios
      .get(getCVUrl)
      .then((response) => {
          allCVFetchs = response.data.data;

                  allCVFetchs.map((en) => {
                      let allData = [];
                      allData.push(en.vehicle_number);                      
                      allData.push({"type" :en.type, "vehicle_status"  : en.vehicle_status});
                      allData.push(en.investor.investor);
                      allData.push(en.driver_name);
                      allData.push(en.serial_number);
                      allData.push(en.distance_to_empty);
                      allData.push({"vehicle_id" :en.vehicle_id,"driver_id" :en.driver_id,"battery_id" :en.battery_id,
                       "batteryassign_status"  : en.batteryassign_status, "driver_status"  : en.driver_status,
                       "vehicle_battery_id"  : en.vehicle_battery_id, "assignment_id"  : en.assignment_id});
                       allData.push(en.vehicle_model);
                       allData.push(en.chassis_number);
                       allData.push(en.engine_number);
                       allData.push(en.asset.fleet_name);
                       allData.push(en.user.operational_manager);
                       allData.push(en.type);
                       allData.push(en.batteryassign_status);
                       allData.push(en.driver_status);
                       allData.push(en.vehicle_status);
                   

                      finalCVCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalCVCall,
          rawData:response.data.data,
          page_number:response.data.page_number,
          total_records:response.data.total_record

        };
        dispatch({
          type: "GET_CV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_CV_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getCommVBulk(id) {
  return (dispatch) => {
      let getCVUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?type=Commercial&page=`;
      let allCVFetchs = [];
      let finalCVCall = [];
     
    dispatch({ type: "GET_CV_LIST" });
    axios
      .get(getCVUrl)
      .then((response) => {
          allCVFetchs = response.data.data;

                  allCVFetchs.map((en) => {
                      let allData = [];
                      allData.push(en.vehicle_number);                      
                      allData.push({"type" :en.type, "vehicle_status"  : en.vehicle_status});
                      allData.push(en.investor.investor);
                      allData.push(en.driver_name);
                      allData.push(en.serial_number);
                      allData.push(en.distance_to_empty);
                      allData.push({"vehicle_id" :en.vehicle_id,"driver_id" :en.driver_id,"battery_id" :en.battery_id,
                       "batteryassign_status"  : en.batteryassign_status, "driver_status"  : en.driver_status,
                       "vehicle_battery_id"  : en.vehicle_battery_id, "assignment_id"  : en.assignment_id});
                       allData.push(en.vehicle_model);
                       allData.push(en.chassis_number);
                       allData.push(en.engine_number);
                       allData.push(en.asset.fleet_name);
                       allData.push(en.user.operational_manager);
                       allData.push(en.type);
                       allData.push(en.batteryassign_status);
                       allData.push(en.driver_status);
                       allData.push(en.vehicle_status);
                   

                      finalCVCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalCVCall,
          rawData:response.data.data,

        };
        dispatch({
          type: "GET_CV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_CV_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getCVLBulk(id) {
  return (dispatch) => {
    let getCVLUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?type=Commercial`;
    let allCVLFetchs = [];
    let finalCVLCall = [];

    dispatch({ type: "GET_CVL_LIST" });
    axios
      .get(getCVLUrl)
      .then((response) => {
        allCVLFetchs = response.data.data;

        allCVLFetchs.map((en) => {
          let allData = [];
          allData.push(en.vehicle_number);
          allData.push(en.type);
          allData.push(en.vehicle_status);
          allData.push(en.investor.investor);
          allData.push(en.driver_name);
          allData.push(en.serial_number);
          allData.push(en.distance_to_empty);
          allData.push(en.batteryassign_status);
          allData.push(en.driver_status);
          allData.push(en.vehicle_model);
          allData.push(en.chassis_number);
          allData.push(en.engine_number);
          allData.push(en.asset.fleet_name);
          allData.push(en.user.operational_manager);


          finalCVLCall.push(allData);
        })

        const payload_data = {
          status: response.status,
          data: finalCVLCall,
          rawData: response.data.data,

        };
        dispatch({
          type: "GET_CVL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_CVL_LIST_FAILED",
          payload: { status, data },
        });
      });

  };
}
export function getFleetBulk() {
  return (dispatch) => {
      let getFleetUrl = endpoints.baseUrl + `/vehicle/list/fleet`;
      let allFleetFetchs = [];
      let finalFleetCall = [];
     
    dispatch({ type: "GET_FLEET_LIST" });
    axios
      .get(getFleetUrl)
      .then((response) => {
          allFleetFetchs = response.data.data;

                  allFleetFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.fleet_name);                      
                      allData.push(en.entity_id);
                   

                      finalFleetCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalFleetCall,
          rawData:response.data.data

        };
        // console.log("payload_data",payload_data);
        dispatch({
          type: "GET_FLEET_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_FLEET_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getIVBulk(id) {
  return (dispatch) => {
      let getIVUrl = endpoints.baseUrl + `/vehicle/list/investor/` + id ;
      let allIVFetchs = [];
      let finalIVCall = [];
     
    dispatch({ type: "GET_IV_LIST" });
    axios
      .get(getIVUrl)
      .then((response) => {
          allIVFetchs = response.data.data;

                  allIVFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.user_name);                      
                      allData.push(en.user_id);
                   

                      finalIVCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalIVCall,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_IV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_IV_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getIV2Bulk(id) {
  return (dispatch) => {
      let getIV2Url = endpoints.baseUrl + `/battery/investor/` + id ;
      let allIV2Fetchs = [];
      let finalIV2Call = [];
     
    dispatch({ type: "GET_IV2_LIST" });
    axios
      .get(getIV2Url)
      .then((response) => {
          allIV2Fetchs = response.data.data;

                  allIV2Fetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.user_name);                      
                      allData.push(en.user_id);
                   

                      finalIV2Call.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalIV2Call,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_IV2_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_IV2_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getOMBulk(id) {
  return (dispatch) => {
      let getOMUrl = endpoints.baseUrl + `/vehicle/list/manager/` + id ;
      let allOMFetchs = [];
      let finalOMCall = [];
     
    dispatch({ type: "GET_OM_LIST" });
    axios
      .get(getOMUrl)
      .then((response) => {
          allOMFetchs = response.data.data;

                  allOMFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.user_name);                      
                      allData.push(en.user_id);
                   

                      finalOMCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalOMCall,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_OM_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_OM_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}

export function getEVBulk(id, page) {
  return (dispatch) => {
      let getEVUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?type=Erickshaw&page=` + page ;
      let allEVFetchs = [];
      let finalEVCall = [];
     
    dispatch({ type: "GET_EV_LIST" });
    axios
      .get(getEVUrl)
      .then((response) => {
          allEVFetchs = response.data.data;

                  allEVFetchs.map((en) => {
                      let allData = [];
                      allData.push(en.vehicle_number);                      
                      allData.push(en.investor.investor);
                      allData.push(en.soc);
                      allData.push({"vehicle_id" :en.vehicle_id, "assignment_id"  : en.assignment_id, "vehicle_status"  : en.vehicle_status, "driver_status"  : en.driver_status});
                      allData.push(en.vehicle_model);
                      allData.push(en.chassis_number);
                      allData.push(en.engine_number);
                      allData.push(en.asset.fleet_name);
                      allData.push(en.user.operational_manager);
                      allData.push(en.type);
                      allData.push(en.vehicle_status);
                      allData.push(en.driver_status);
                      finalEVCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalEVCall,
          rawData:response.data.data,
          page_number:response.data.page_number,
          total_records:response.data.total_record

        };
        dispatch({
          type: "GET_EV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_EV_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getErickVBulk(id) {
  return (dispatch) => {
      let getEVUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?type=Erickshaw&page=`;
      let allEVFetchs = [];
      let finalEVCall = [];
     
    dispatch({ type: "GET_EV_LIST" });
    axios
      .get(getEVUrl)
      .then((response) => {
          allEVFetchs = response.data.data;

                  allEVFetchs.map((en) => {
                      let allData = [];
                      allData.push(en.vehicle_number);                      
                      allData.push(en.investor.investor);
                      allData.push(en.soc);
                      allData.push({"vehicle_id" :en.vehicle_id, "assignment_id"  : en.assignment_id, "vehicle_status"  : en.vehicle_status, "driver_status"  : en.driver_status});
                      allData.push(en.vehicle_model);
                      allData.push(en.chassis_number);
                      allData.push(en.engine_number);
                      allData.push(en.asset.fleet_name);
                      allData.push(en.user.operational_manager);
                      allData.push(en.type);
                      allData.push(en.vehicle_status);
                      allData.push(en.driver_status);
                      finalEVCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalEVCall,
          rawData:response.data.data,
        };
        dispatch({
          type: "GET_EV_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_EV_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getEVLBulk(id) {
  return (dispatch) => {
      let getEVLUrl = endpoints.baseUrl + `/vehicle/list/` + id + `?type=Erickshaw`;
      let allEVLFetchs = [];
      let finalEVLCall = [];
     
    dispatch({ type: "GET_EVL_LIST" });
    axios
      .get(getEVLUrl)
      .then((response) => {
          allEVLFetchs = response.data.data;

                  allEVLFetchs.map((en) => {
                      let allData = [];
                      allData.push(en.vehicle_number);                      
                      allData.push(en.investor.investor);
                      allData.push(en.soc);
                      allData.push(en.vehicle_model);
                      allData.push(en.chassis_number);
                      allData.push(en.engine_number);
                      allData.push(en.asset.fleet_name);
                      allData.push(en.user.operational_manager);
                      allData.push(en.type);
                      allData.push(en.vehicle_status);
                      allData.push(en.driver_status);
                      allData.push(en.driver_name);
                      allData.push(en.distance_to_empty);
                      finalEVLCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalEVLCall,
          rawData:response.data.data,
          page_number:response.data.page_number,
          total_records:response.data.total_record

        };
        dispatch({
          type: "GET_EVL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_EVL_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getVMBulk(page) {
  return (dispatch) => {
      let getVMUrl = endpoints.baseUrl + `/vehiclemodel/list?page=` + page ;
      let allVMFetchs = [];
      let finalVMCall = [];
     
    dispatch({ type: "GET_VM_LIST" });
    axios
      .get(getVMUrl)
      .then((response) => {
          allVMFetchs = response.data.data;

                  allVMFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.model);                      
                      allData.push(en.seating);  
                      allData.push(en.top_speed);  
                      allData.push(en.payload_weight);  
                      allData.push(en.typical_range);  
                      allData.push(en.model_id);  
                   

                      finalVMCall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalVMCall,
          rawData:response.data.data,
          page_number:response.data.page_number,
          total_records:response.data.total_record

        };
        dispatch({
          type: "GET_VM_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_VM_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}

export function getBatteryModelBulk(page) {
  return (dispatch) => {
      // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
      let getBatteryModelUrl = endpoints.baseUrl + `/batterymodel/list?page=` + page ;
      let allBatteryModelFetchs = [];
      let finalBatteryModelCall = [];
     
    dispatch({ type: "GET_BATTERYMODEL_LIST" });
    axios
      .get(getBatteryModelUrl)
      .then((response) => {
          allBatteryModelFetchs = response.data.data;

                  allBatteryModelFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.model_info);                      
                      allData.push(en.nominal_voltage);
                      allData.push(en.capacity_mah);
                      allData.push(en.power);
                      allData.push(en.cell_maufacturer);
                      allData.push(en.battery_model_id);
                   

                      finalBatteryModelCall.push(allData);
                  })
        const payload_data = {
          status: response.status,
          data: finalBatteryModelCall,
          rawData:response.data.data,
          page_number:response.data.page_number,
          total_records:response.data.total_record

        };
        dispatch({
          type: "GET_BATTERYMODEL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GETCBATTERYMODEL_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
export function getBatteryModelLBulk() {
  return (dispatch) => {
      // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
      let getBatteryModelLUrl = endpoints.baseUrl + `/batterymodel/list` ;
      let allBatteryModelLFetchs = [];
      let finalBatteryModelLCall = [];
     
    dispatch({ type: "GET_BATTERYMODELL_LIST" });
    axios
      .get(getBatteryModelLUrl)
      .then((response) => {
          allBatteryModelLFetchs = response.data.data;

                  allBatteryModelLFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.model_info);                      
                      allData.push(en.nominal_voltage);
                      allData.push(en.capacity_mah);
                      allData.push(en.power);
                      allData.push(en.cell_maufacturer);
                      allData.push(en.battery_model_id);
                   

                      finalBatteryModelLCall.push(allData);
                  })
        const payload_data = {
          status: response.status,
          data: finalBatteryModelLCall,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_BATTERYMODELL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GETCBATTERYMODELL_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
export function getMyBatteryBulk(id, uId,page) {
  return (dispatch) => {
    let getMyBatteryUrl = endpoints.baseUrl + `/battery/get/` + id + `?user_id=`+uId+`&page=`+ page;
    let allMyBatteryFetchs = [];
      let finalMyBatteryCall = [];
    dispatch({ type: "GET_MYBATTERY_LIST" });
    axios
      .get(getMyBatteryUrl)
      .then((response) => {
          allMyBatteryFetchs = response.data.data;

                  allMyBatteryFetchs.map((en) => {
                      let allData = [];
      
                      // allData.push(en.serial_number);
                      allData.push({"bms_id" :en.bms_id , "serial_number"  : en.serial_number,
                      "vehicle_number" :en.vehicle_number, "imei" : en.imei});
                      allData.push(en.battery_model);
                      allData.push(en.investors.investor);
                      allData.push(en.user.operational_manager);
                      allData.push({"vehicle_number" :en.vehicle_number, "serial_number"  : en.serial_number});
                      allData.push({"imei" :en.imei, "status"  : en.status});
                      allData.push({"bms_id" :en.bms_id, "serial_number"  : en.serial_number,"vehicle_id"  : en.vehicle_id,
                        "vehicle_status"  : en.vehicle_status,"vehicle_number" :en.vehicle_number,
                      "vehicle_battery_id" :en.vehicle_battery_id,"battery_id" :en.battery_id,"battery_status" :en.battery_status});
                      // allData.push(en.imei);
                      allData.push(en.serial_number);
                      allData.push(en.bms_unique_id);
                      allData.push(en.sw_version);
                      allData.push(en.status);
                      allData.push(en.vehicle_number);
                      allData.push(en.battery_status);
                      allData.push(en.vehicle_status);
                      finalMyBatteryCall.push(allData);
                  })
        const payload_data = {
          status: response.status,
          data: finalMyBatteryCall,
          rawData:response.data.data,
          page_number:response.data.page_number,
          total_records:response.data.total_record

        };
        dispatch({
          type: "GET_MYBATTERY_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_MYBATTERY_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
export function GetBBBulk(id) {
  return (dispatch) => {
      let getMyBatteryUrl = endpoints.baseUrl + `/battery/get/` + id;
      let allMyBatteryFetchs = [];
      let finalMyBatteryCall = [];
    dispatch({ type: "GET_MYBATTERY_LIST" });
    axios
      .get(getMyBatteryUrl)
      .then((response) => {
          allMyBatteryFetchs = response.data.data;

                  allMyBatteryFetchs.map((en) => {
                      let allData = [];
      
                      // allData.push(en.serial_number);
                      allData.push({"bms_id" :en.bms_id , "serial_number"  : en.serial_number,
                      "vehicle_number" :en.vehicle_number, "imei" : en.imei});
                      allData.push(en.battery_model);
                      allData.push(en.investors.investor);
                      allData.push(en.user.operational_manager);
                      allData.push({"vehicle_number" :en.vehicle_number, "serial_number"  : en.serial_number});
                      allData.push({"imei" :en.imei, "status"  : en.status});
                      allData.push({"bms_id" :en.bms_id, "serial_number"  : en.serial_number,"vehicle_id"  : en.vehicle_id,
                        "vehicle_status"  : en.vehicle_status,"vehicle_number" :en.vehicle_number,
                      "vehicle_battery_id" :en.vehicle_battery_id,"battery_id" :en.battery_id,"battery_status" :en.battery_status});
                      // allData.push(en.imei);
                      allData.push(en.serial_number);
                      allData.push(en.bms_unique_id);
                      allData.push(en.sw_version);
                      allData.push(en.status);
                      allData.push(en.vehicle_number);
                      allData.push(en.battery_status);
                      allData.push(en.vehicle_status);
                      finalMyBatteryCall.push(allData);
                  })
        const payload_data = {
          status: response.status,
          data: finalMyBatteryCall,
          rawData:response.data.data,

        };
        dispatch({
          type: "GET_MYBATTERY_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_MYBATTERY_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
export function getBatteryTotal(id) {
  return (dispatch) => {
      let getMyBatteryUrl = endpoints.baseUrl + `/battery/get/` + id;
      let allMyBatteryFetchs = [];
      let finalMyBatteryCall = [];
    dispatch({ type: "GET_LIST" });
    axios
      .get(getMyBatteryUrl)
      .then((response) => {
          allMyBatteryFetchs = response.data.data;

                  allMyBatteryFetchs.map((en) => {
                      let allData = [];
      
                      // allData.push(en.serial_number);
                      allData.push(en.serial_number);
                      allData.push(en.battery_model);
                      allData.push(en.investors.investor);
                      allData.push(en.user.operational_manager);
                      allData.push(en.vehicle_number);
                      allData.push(en.status);
                      allData.push(en.vehicle_status);
                      allData.push(en.battery_status);
                      allData.push(en.bms_unique_id);
                      allData.push(en.sw_version);
                      finalMyBatteryCall.push(allData);
                  })
        const payload_data = {
          status: response.status,
          data: finalMyBatteryCall,
          rawData:response.data.data,

        };
        dispatch({
          type: "GET_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
export function getBMSBulk(page) {
  return (dispatch) => {
      // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
      let getBMSUrl = endpoints.baseUrl + `/battery/bms/list?page=` + page ;
      let allBMSFetchs = [];
      let finalBMSCall = [];
     
    dispatch({ type: "GET_BMS_LIST" });
    axios
      .get(getBMSUrl)
      .then((response) => {
          allBMSFetchs = response.data.data;

                  allBMSFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.model_info);                      
                      allData.push(en.hw_version);
                      allData.push(en.oem);
                      allData.push(en.bms_model_id);
                   

                      finalBMSCall.push(allData);
                  })
        const payload_data = {
          status: response.status,
          data: finalBMSCall,
          rawData:response.data.data,
          page_number:response.data.page_number,
          total_records:response.data.total_record

        };
        dispatch({
          type: "GET_BMS_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BMS_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
export function getBMSLBulk() {
  return (dispatch) => {
      // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
      let getBMSLUrl = endpoints.baseUrl + `/battery/bms/list` ;
      let allBMSLFetchs = [];
      let finalBMSLCall = [];
     
    dispatch({ type: "GET_BMSL_LIST" });
    axios
      .get(getBMSLUrl)
      .then((response) => {
          allBMSLFetchs = response.data.data;

                  allBMSLFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.model_info);                      
                      allData.push(en.hw_version);
                      allData.push(en.oem);
                      allData.push(en.bms_model_id);
                   

                      finalBMSLCall.push(allData);
                  })
        const payload_data = {
          status: response.status,
          data: finalBMSLCall,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_BMSL_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BMSL_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
export function getBatteryProBulk(imei) { 
  return (dispatch) => {
      let getBatteryProUrl = endpoints.baseUrl + `/battery/profile/` + imei;
      let allBatteryProFetchs = [];
      let finalBatteryProCall = [];
     
    dispatch({ type: "GET_BATTERY_PRO_LIST" });
    axios
      .get(getBatteryProUrl)
      .then((response) => {
          allBatteryProFetchs = response.data.data;

                  // allBatteryProFetchs.map((en) => {
                  //     let allData = [];
      
                  //     allData.push(en.serial_number);
                  //     allData.push(en.operation_owner);
                  //     allData.push(en.software_version);
                  //     allData.push(en.created_at);
                  //     allData.push(en.battery_model);
                  //     allData.push(en.nominal_voltage);
                  //     allData.push(en.capacity_mah);
                  //     allData.push(en.cell_chemisty);
                  //     allData.push(en.hardware_version);
                  //     allData.push(en.current_state);
                  //     allData.push(en.battery_current);
                  //     allData.push(en.battery_voltage);
                  //     allData.push(en.soc);
                  //     allData.push(en.soh);
                  //     allData.push(en.max_temperature);
                  //     allData.push(en.min_temperature);
                  //     allData.push(en.max_voltage); 
                  //     allData.push(en.min_voltage); 
                  //     allData.push(en.bms_id);
                  //     finalBatteryProCall.push(allData);
                  // })
        const payload_data = {
          status: response.status,
          data: allBatteryProFetchs,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_BATTERY_PRO_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BATTERY_PRO_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
export function getBatteryViewBulk(imei) {
  return (dispatch) => {
      let getBatteryViewUrl = endpoints.baseUrl + `/battery/data/` + imei;
      let allBatteryViewFetchs = [];
      let finalBatteryViewCall = [];
     
    dispatch({ type: "GET_BATTERY_VIEW_LIST" });
    axios
      .get(getBatteryViewUrl)
      .then((response) => {
          allBatteryViewFetchs = response.data.data;

                  // allBatteryViewFetchs.map((en) => {
                  //     let allData = [];
      
                  //     allData.push(en.name);
                  //     allData.push(en.value);
                  //     finalBatteryViewCall.push(allData);
                  // })
        const payload_data = {
          status: response.status,
          data: allBatteryViewFetchs,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_BATTERY_VIEW_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BATTERY_VIEW_LIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}
 
export function getBVABulk() {
  return (dispatch) => {
      let getBVAUrl = endpoints.baseUrl + `/battery/vehicle/list` ;
      let allBVAFetchs = [];
      let finalBVACall = [];
     
    dispatch({ type: "GET_BVA_LIST" });
    axios
      .get(getBVAUrl)
      .then((response) => {
          allBVAFetchs = response.data.data;

                  allBVAFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.vehicle_number); 
                      allData.push(en.vehicle_id); 
                   

                      finalBVACall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalBVACall,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_BVA_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BVA_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getVDABulk(id) {
  return (dispatch) => {
      let getVDAUrl = endpoints.baseUrl + `/vehicle/driver/assign/` + id ;
      let allVDAFetchs = [];
      let finalVDACall = [];
     
    dispatch({ type: "GET_VDA_LIST" });
    axios
      .get(getVDAUrl)
      .then((response) => {
          allVDAFetchs = response.data.data;

                  allVDAFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.name); 
                      allData.push(en.driver_id); 
                   

                      finalVDACall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalVDACall,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_VDA_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_VDA_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getBABulk() {
  return (dispatch) => {
      let getBAUrl = endpoints.baseUrl + `/vehicle/battery/assign` ;
      let allBAFetchs = [];
      let finalBACall = [];
     
    dispatch({ type: "GET_BA_LIST" });
    axios
      .get(getBAUrl)
      .then((response) => {
          allBAFetchs = response.data.data;

                  allBAFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(en.serial_number); 
                      allData.push(en.battery_id); 
                   

                      finalBACall.push(allData);
                  })

        const payload_data = {
          status: response.status,
          data: finalBACall,
          rawData:response.data.data

        };
        dispatch({
          type: "GET_BA_LIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BA_LIST_FAILED", 
          payload: { status, data },
        });
      }); 

  };
}
export function getBatteryListBulk() {
  return (dispatch) => {
      let getBatteryListUrl = endpoints.baseUrl + `/battery/list/2`;
      let allBatteryListFetchs = [];
      let finalBatteryListCall = [];
     
    dispatch({ type: "GET_BATTERYLIST_LIST" });
    axios
      .get(getBatteryListUrl)
      .then((response) => {

          allBatteryListFetchs = response.data.data;
                  // allBatteryListFetchs.map((en) => {
                      let allData = [];
      
                      allData.push(allBatteryListFetchs.battery_model);
                      allData.push(allBatteryListFetchs.vehicle_type);
                      allData.push(allBatteryListFetchs.vehicle_number);
                      allData.push(allBatteryListFetchs.driver_name);
                      allData.push(allBatteryListFetchs.battery_voltage);
                      allData.push(allBatteryListFetchs.soc);
                      allData.push(allBatteryListFetchs.current_state);
                      allData.push(allBatteryListFetchs.soh);
                      allData.push(allBatteryListFetchs.battery_health_status)
                     
                      finalBatteryListCall.push(allData);

        const payload_data = {
          status: response.status,
          data: finalBatteryListCall,
          rawData:response.data.data
        };
        dispatch({
          type: "GET_BATTERYLIST_FULFILLED",
          payload: payload_data,
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        dispatch({
          type: "GET_BATTERYLIST_FAILED",
          payload: { status, data },
        });
      }); 

  };
}

export function getUserBulk(id, page) {
    return (dispatch) => {
        let getUserUrl = endpoints.baseUrl + `/bo/list/` + id + `?page=` + page;
        let allUserFetchs = [];
        let finalUserCall = [];
       
      dispatch({ type: "GET_USER_LIST" });
      axios
        .get(getUserUrl)
        .then((response) => {
            allUserFetchs = response.data.data;
                    allUserFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.username);
                        allData.push(en.email);
                        allData.push(en.mobile_number);
                        allData.push(en.role_name);
                        allData.push(en.operator_name);
                        allData.push(en.entity.asset_type)
                        allData.push(en.user_id)
                        allData.push(en.address);
                        allData.push(en.entity_id)

                       
                        finalUserCall.push(allData);
                    })
          const payload_data = {
            status: response.status,
            data: finalUserCall,
            rawData:response.data.data,
            page_number:response.data.page_number,
            total_records:response.data.total_record
          };
          dispatch({
            type: "GET_USER_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_USER_LIST_FAILED",
            payload: { status, data },
          });
        }); 

    };
  }
  export function getUserLBulk() {
    return (dispatch) => {
        let getUserLUrl = endpoints.baseUrl + `/userlogin/list`;
        let allUserLFetchs = [];
        let finalUserLCall = [];
       
      dispatch({ type: "GET_USERL_LIST" });
      axios
        .get(getUserLUrl)
        .then((response) => {
            allUserLFetchs = response.data.data;
                    allUserLFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.username);
                        allData.push(en.email);
                        allData.push(en.mobile_number);
                        allData.push(en.role_name);
                        allData.push(en.operator_name);
                        allData.push(en.entity.asset_type)
                        allData.push(en.user_id)
                        allData.push(en.address);
                        allData.push(en.entity_id)

                       
                        finalUserLCall.push(allData);
                    })
          const payload_data = {
            status: response.status,
            data: finalUserLCall,
            rawData:response.data.data,
            page_number:response.data.page_number,
            total_records:response.data.total_record
          };
          dispatch({
            type: "GET_USERL_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_USERL_LIST_FAILED",
            payload: { status, data },
          });
        }); 

    };
  }
  export function getRoleBulk(page) {
    return (dispatch) => {
        let getRoleUrl = endpoints.baseUrl + `/role/get?page=` + page;
        let allRoleFetchs = [];
        let finalRoleCall = [];
       
      dispatch({ type: "GET_ROLE_LIST" });
      axios
        .get(getRoleUrl)
        .then((response) => {
            allRoleFetchs = response.data.data;

                    allRoleFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.role_name);
                        allData.push(en.role_id);
                        finalRoleCall.push(allData);
                    })
          const payload_data = {
            status: response.status,
            data: finalRoleCall,
            rawData:response.data.data,
            page_number:response.data.page_number,
            total_records:response.data.total_record
          };
          dispatch({
            type: "GET_ROLE_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_ROLE_LIST_FAILED",
            payload: { status, data },
          });
        }); 

    };
  }
  export function getRoleLBulk() {
    return (dispatch) => {
        let getRoleLUrl = endpoints.baseUrl + `/role/get`;
        let allRoleLFetchs = [];
        let finalRoleLCall = [];
       
      dispatch({ type: "GET_ROLEL_LIST" });
      axios
        .get(getRoleLUrl)
        .then((response) => {
            allRoleLFetchs = response.data.data;

                    allRoleLFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.role_name);
                        allData.push(en.role_id);
                        finalRoleLCall.push(allData);
                    })
          const payload_data = {
            status: response.status,
            data: finalRoleLCall,
            rawData:response.data.data,
            page_number:response.data.page_number,
            total_records:response.data.total_record
          };
          dispatch({
            type: "GET_ROLEL_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_ROLEL_LIST_FAILED",
            payload: { status, data },
          });
        }); 

    };
  }
  export function getDriverBulk(id, page) {
    return (dispatch) => {
        let getDriverUrl = endpoints.baseUrl + `/driver/list/` +id + `?page=` + page;
        let allDriverFetchs = [];
        let finalDriverCall = [];
   
      dispatch({ type: "GET_DRIVER_LIST" });
      axios
        .get(getDriverUrl)
        .then((response) => {
          allDriverFetchs = response.data;

          
          const payload_data = {
            status: response.status,
            data: response.data,
            totalRecords:response.data.total_record.toString(),
            page_number:response.data.page_number,
            total_records:response.data.total_records
          };
    // console.log("payload_data",payload_data)

          dispatch({
            type: "GET_DRIVER_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_DRIVER_LIST_FAILED",
            payload: { status, data },
          });
        }); 

    };
  }

  export function getEntityBulk(page) {
    return (dispatch) => {
        let getEntityUrl = endpoints.baseUrl + `/entity/get?page=` + page;
        let allEntityFetchs = [];
        let finalEntityCall = [];
      dispatch({ type: "GET_ENTITY_LIST" });
      axios
        .get(getEntityUrl)
        .then((response) => {
            allEntityFetchs = response.data.data;
  
                    allEntityFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.operator_name);
                        allData.push(en.contact_name);
                        allData.push(en.primary_email_id);
                        allData.push(en.primary_mobile_number);
                        allData.push(en.region);
                        allData.push(en.gst);
                        allData.push(en.fleet_id);
                        finalEntityCall.push(allData);
                    })
          const payload_data = {
            status: response.status,
            data: finalEntityCall,
            rawData:response.data.data,
            page_number:response.data.page_number,
            total_records:response.data.total_record
  
          };
          dispatch({
            type: "GET_ENTITY_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_ENTITY_LIST_FAILED",
            payload: { status, data },
          });
        }); 
  
    };
  }
  
  export function getClientBulk(page) {
    return (dispatch) => {
        let getClientUrl = endpoints.baseUrl + `/client/get?page=` + page;
        let allClientFetchs = [];
        let finalClientCall = [];
      dispatch({ type: "GET_CLIENT_LIST" });
      axios
        .get(getClientUrl)
        .then((response) => {
            allClientFetchs = response.data.data;
  
                    allClientFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.name);
                        allData.push(en.buisness_name);
                        allData.push(en.primary_mobile_number);
                        allData.push(en.number_of_hubs);
                        allData.push(en.location);
                        allData.push(en.gst_number);
                        allData.push(en.client_id);
                        finalClientCall.push(allData);
                    })
          const payload_data = {
            status: response.status,
            data: finalClientCall,
            rawData:response.data.data,
            page_number:response.data.page_number,
            total_records:response.data.total_record
  
          };
          dispatch({
            type: "GET_CLIENT_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_CLIENT_LIST_FAILED",
            payload: { status, data },
          });
        }); 
  
    };
  }
 

  export function getTelematicsBulk(page) {
    return (dispatch) => {
        // let getEUrl = endpoints.baseUrl + `/battery?type=ebattery`;
        let getTelematicsUrl = endpoints.baseUrl + `/telematics/get?page=` + page;
        let allTelematicsFetchs = [];
        let finalTelematicsCall = [];
       
      dispatch({ type: "GET_TELEMATICS_LIST" });
      axios
        .get(getTelematicsUrl)
        .then((response) => {
            allTelematicsFetchs = response.data.data;
  
                    allTelematicsFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.model_info);                      
                        allData.push(en.oem);
                        allData.push(en.sim_type);
                        allData.push(en.protocal);
                        allData.push(en.datasheet_attachment);
                        allData.push(en.telematics_data_id);
                     
  
                        finalTelematicsCall.push(allData);
                    })
          const payload_data = {
            status: response.status,
            data: finalTelematicsCall,
            rawData:response.data.data,
            page_number:response.data.page_number,
            total_records:response.data.total_record
  
          };
          dispatch({
            type: "GET_TELEMATICS_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_TELEMATICS_LIST_FAILED",
            payload: { status, data },
          });
        }); 
  
    };
  }


  export function getReportBulk(id, page) {
    return (dispatch) => {
        let getReportUrl = endpoints.baseUrl + `/battery/batteryreport/` + id + `?page=` + page;
        let allReportFetchs = [];
        let finalReportCall = [];
       
      dispatch({ type: "GET_REPORT_LIST" });
      axios
        .get(getReportUrl)
        .then((response) => {
            allReportFetchs = response.data.data;
  
                    allReportFetchs.map((en) => {
                        let allData = [];
                        allData.push(en.serial_number);                      
                        allData.push(en.bms_unique_id);
                        allData.push({"imei" :en.imei ,"bms_id" :en.bms_id} );
                     
  
                        finalReportCall.push(allData);
                    })
          const payload_data = {
            status: response.status,
            data: finalReportCall,
            rawData:response.data.data,
            page_number:response.data.page_number,
            total_records:response.data.total_record
  
          };
          dispatch({
            type: "GET_REPORT_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_REPORT_LIST_FAILED",
            payload: { status, data },
          });
        }); 
  
    };
  }

  export function getVModelBulk() {
    return (dispatch) => {
        let getVModelUrl = endpoints.baseUrl + `/vehiclemodel/list` ;
        let allVModelFetchs = [];
        let finalVModelCall = [];
       
      dispatch({ type: "GET_VMODEL_LIST" });
      axios
        .get(getVModelUrl)
        .then((response) => {
            allVModelFetchs = response.data.data;
  
                    allVModelFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.model);                      
                        allData.push(en.model_id);  
                     
  
                        finalVModelCall.push(allData);
                    })
  
          const payload_data = {
            status: response.status,
            data: finalVModelCall,
            rawData:response.data.data
  
          };
          dispatch({
            type: "GET_VMODEL_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_VMODEL_LIST_FAILED", 
            payload: { status, data },
          });
        }); 
  
    };
  }

  export function getTeleModelBulk() {
    return (dispatch) => {
        let getTeleModelUrl = endpoints.baseUrl + `/telematics/model`;
        let allTeleModelFetchs = [];
        let finalTeleModelCall = [];
       
      dispatch({ type: "GET_TELEMODEL_LIST" });
      axios
        .get(getTeleModelUrl)
        .then((response) => {
            allTeleModelFetchs = response.data.data;
  
                    allTeleModelFetchs.map((en) => {
                        let allData = [];
        
                        allData.push(en.telematics_data_id);                      
                        allData.push(en.model);
                     
  
                        finalTeleModelCall.push(allData);
                    })
  
          const payload_data = {
            status: response.status,
            data: finalTeleModelCall,
            rawData:response.data.data
  
          };
          dispatch({
            type: "GET_TELEMODEL_LIST_FULFILLED",
            payload: payload_data,
          });
        })
        .catch((error) => {
          let status = null;
          let data = null;
          //If no response from server
          if (!error.response) {
            status = 500;
            data = "No response from server";
          } else {
            status = error.response.status;
            data = error.response.data;
          }
          dispatch({
            type: "GET_TELEMODEL_LIST_FAILED", 
            payload: { status, data },
          });
        }); 
  
    };
  }

 
