export function saveLoggeduser(data) {
    return { type:"USER_LOGIN_SUCCESSFUL",payload:data };
}
export function clearLoggeduser() {
    return { type:"DESTROY_CURRENT_USER_INFO" };
}
export function clearBattProfile(){
    return{ type:"CLEAR_GET_BATTERY_PRO_LIST"}
}

export function clearEntity(){
    return{ type:"CLEAR_GET_ENTITY_LIST"}
}
export function clearClient(){
    return{ type:"CLEAR_GET_CLIENT_LIST"}
}
export function clearBattView(){
    return{ type:"CLEAR_GET_BATTERY_VIEW_LIST"}
}
export function clearCV(){
    return{ type:"CLEAR_GET_CV_LIST"}
}
export function clearBVA(){
    return{ type:"CLEAR_GET_BVA_LIST"}
}
export function clearVDA(){
    return{ type:"CLEAR_GET_VDA_LIST"}
}
export function clearEV(){
    return{ type:"CLEAR_GET_EV_LIST"}
}
export function clearVM(){
    return{ type:"CLEAR_GET_VM_LIST"}
}
export function clearIV(){
    return{ type:"CLEAR_GET_IV_LIST"}
}
export function clearIV2(){
    return{ type:"CLEAR_GET_IV2_LIST"}
}
export function clearFleet(){
    return{ type:"CLEAR_GET_FLEET_LIST"}
}
export function clearTeleModel(){
    return{ type:"CLEAR_GET_TELEMODEL_LIST"}
}
export function clearOM(){
    return{ type:"GET_OM_LIST"}
}
export function clearDrivers(){
    return{ type:"CLEAR_GET_DRIVER_LIST"}
}
export function clearTelematics(){
    return{ type:"CLEAR_GET_TELEMATICS"}
}
export function clearUsersList(){
    return{ type:"CLEAR_GET_USER_LIST"}
}
export function clearReport(){
    return{ type:"GET_REPORT_LIST"}
}

export function setReportData(data){
    return { type:"REPORT",payload:data };
}
export function setCVData(data){
    return { type:"CV",payload:data };
}
export function setBVAData(data){
    return { type:"BVA",payload:data };
}
export function setVDAData(data){
    return { type:"VDA",payload:data };
}
export function setBAData(data){
    return { type:"BA",payload:data };
}
export function setIVData(data){
    return { type:"IV",payload:data };
}
export function setIV2Data(data){
    return { type:"IV2",payload:data };
}
export function setFleetData(data){
    return { type:"FLEET",payload:data };
}
export function setTeleModelData(data){
    return { type:"TELEMODEL",payload:data };
}
export function setOMData(data){
    return { type:"OM",payload:data };
}
export function setEVData(data){
    return { type:"EV",payload:data };
}
export function setVMData(data){
    return { type:"VM",payload:data };
}
export function setBatteryModelData(data){
    return { type:"BATTERYMODEL",payload:data };
}
export function setBatteryModelLData(data){
    return { type:"BATTERYMODELL",payload:data };
}
export function setBMSData(data){
    return { type:"BMS",payload:data };
}
export function setBMSLData(data){
    return { type:"BMSL",payload:data };
}
export function setMyBatteryData(data){
    return { type:"MYBATTERY",payload:data };
}

export function setBatteryViewData(data){
    return { type:"BATTERY_VIEW",payload:data };
}

export function setBatteryProData(data){
    return { type:"BATTERY_PRO",payload:data };
}

export function setBatteryListData(data){
    return { type:"BATTERYLIST",payload:data };
}

export function setUserData(data){
    return { type:"USER",payload:data };
}
export function setUserLData(data){
    return { type:"USERL",payload:data };
}

export function setRoleData(data){
    return { type:"ROLE",payload:data };
}
export function setRoleLData(data){
    return { type:"ROLEL",payload:data };
}
export function clearMyBattery(){
    return { type:"CLEAR_GET_MYBATTERY_LIST"}
}
 

export function setLiveTrackerList(data){
    return { type:"LOG_LIVETRACKER_LIST",payload:data };
}
export function setLiveTrackerSelected(data){
    return { type:"LOG_LIVETRACKER_SELECTED",payload:data };
}