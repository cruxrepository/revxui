/**
 * Combine all reducers in this file and export the combined reducers.
 */
import { reducer as form } from 'redux-form';
import { combineReducers } from 'redux';
import { connectRouter } from 'connected-react-router';
import history from 'utils/history';
import userReducer from './reducers/userReducer';
// Global Reducers
import languageProviderReducer from 'containers/LanguageProvider/reducer';
import authReducer from './modules/authReducer';
import uiReducer from './modules/uiReducer';
import initval from './modules/initFormReducer';
import liveTrackerReducer from './reducers/liveTrackerReducer';
import getEVReducer from './reducers/getEVReducer';
import getEVLReducer from './reducers/getEVLReducer';
import getCVReducer from './reducers/getCVReducer';
import getCVLReducer from './reducers/getCVLReducer';
import getBVAReducer from './reducers/getBVAReducer';
import getVDAReducer from './reducers/getVDAReducer';
import getEVDAReducer from './reducers/getEVDAReducer';
import getIVReducer from './reducers/getIVReducer';
import getIV2Reducer from './reducers/getIV2Reducer';
import getFleetReducer from './reducers/getFleetReducer';
import getOMReducer from './reducers/getOMReducer';
import getVMReducer from './reducers/getVMReducer';
import getBatteryModelReducer from './reducers/getBatteryModelReducer';
import getBatteryModelLReducer from './reducers/getBatteryModelLReducer';
import getBMSReducer from './reducers/getBMSReducer';
import getBMSLReducer from './reducers/getBMSLReducer';
import getMyBatteryReducer from './reducers/getMyBatteryReducer';
import getBatteryProReducer from './reducers/getBatteryProReducer';
import getBDashboard from './reducers/getBDashboard';
import getVDashboardy from './reducers/getVDashboardy';
import getBatteryViewReducer from './reducers/getBatteryViewReducer';
import getUserReducer from './reducers/getUserReducer';
import getUserLReducer from './reducers/getUserLReducer';
import getRoleReducer from './reducers/getRoleReducer';
import getRoleLReducer from './reducers/getRoleLReducer';
import getDriverReducer from './reducers/getDriverReducer';
import getEntityReducer from './reducers/getEntityReducer';
import getClientReducer from './reducers/getClientReducer';
import getTelematicsReducer from './reducers/getTelematicsReducer';
import getReportReducer from './reducers/getReportReducer';
import getVModelReducer from './reducers/getVModelReducer';
import getBAReducer from './reducers/getBAReducer';
import getTeleModelReducer from './reducers/getTeleModelReducer';
import loginReducer from './reducers/loginReducer';
import getBatteryTotalReducer from './reducers/getBatteryTotalReducer';
import getBBReducer from './reducers/getBBReducer';
import getCommVReducer from './reducers/getCommVReducer';
import getErickVReducer from './reducers/getErickVReducer';
import getTeleListReducer from './reducers/getTeleListReducer';
import getTeleAssignReducer from './reducers/getTeleAssignReducer';
import getInvestorReducer from './reducers/getInvestorReducer';
import getHypoReducer from './reducers/getHypoReducer';
import getTeleListTotalReducer from './reducers/getTeleListTotalReducer';
import getTMReducer from './reducers/getTMReducer';
import getReportFullReducer from './reducers/getReportFullReducer';

/**
 * Creates the main reducer with the dynamically injected ones
 */
export default function createReducer(injectedReducers = {}) {
  const appReducer = combineReducers({
    form,
    login:loginReducer,
    user:userReducer,
    batteryModel:getBatteryModelReducer,
    batteryModell:getBatteryModelLReducer,
    bmsAll:getBMSReducer,
    bmslAll:getBMSLReducer,
    investorAll:getInvestorReducer,
    hypoAll:getHypoReducer,
    myBattery:getMyBatteryReducer,
    batteryTotal:getBatteryTotalReducer,
    entityAll:getEntityReducer,
    clientAll:getClientReducer,
    batteryPro:getBatteryProReducer,
    batteryDash:getBDashboard,
    vehicleDash:getVDashboardy,
    evAll:getEVReducer,
    imeiAll:getTeleAssignReducer,
    cvAll:getCVReducer,
    cvTotal:getCVLReducer,
    evTotal:getEVLReducer,
    bvaAll:getBVAReducer,
    vdaAll:getVDAReducer,
    evdaAll:getEVDAReducer,
    bAAll:getBAReducer,
    iv2All:getIV2Reducer,
    ivAll:getIVReducer,
    fleetAll:getFleetReducer,
    teleModelAll:getTeleModelReducer,
    omAll:getOMReducer,
    vmAll:getVMReducer,
    telematicsAll:getTelematicsReducer,
    teleAll:getTeleListTotalReducer,
    tmAll:getTMReducer,
    tList:getTeleListReducer,
    reportAll:getReportReducer,
    reportTotal:getReportFullReducer,
    batteryView:getBatteryViewReducer,
    ui: uiReducer, 
    userAll:getUserReducer,
    userLAll:getUserLReducer,
    roleAll:getRoleReducer,
    roleLAll:getRoleLReducer,
    liveTrackerList:liveTrackerReducer,
    bbAll:getBBReducer,
    commV:getCommVReducer,
    erickV:getErickVReducer,
    initval,
    authReducer,
    driverAll:getDriverReducer,
    vModel:getVModelReducer,
    language: languageProviderReducer,
    router: connectRouter(history),
    ...injectedReducers,
  })
  
  const rootReducer = (state, action) => {
    return appReducer(state, action)
  }
 

  // Wrap the root reducer and return a new root reducer with router state
  const mergeWithRouterState = connectRouter(history);
  return mergeWithRouterState(rootReducer);
}
