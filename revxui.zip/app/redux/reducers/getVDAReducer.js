const getVDAReducer = (
    vDAData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newVDAData;
      switch (action.type) {
        case "GET_VDA_LIST":
            newVDAData = {
            ...vDAData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_VDA_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newVDAData = {
            ...vDAData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_VDA_LIST_FAILED":
            newVDAData = {
            ...vDAData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_VDA_LIST":
            newVDAData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newVDAData = vDAData;
          break;
      }
      return newVDAData;
    };
    export default getVDAReducer;
