const userReducer = (
    state = {
      loggeduser: {},
    },
    action
  ) => {
    let new_state;
    switch (action.type) {
      case "LOG_USER":
        new_state = {
            loggeduser : action.payload,
        };
        break;
        case "CLEAR_USER":
            new_state = {
                loggeduser : {},
            };
            break; 
      default:
        new_state = state;
        break;
    }
    return new_state;
  };
  
  export default userReducer;