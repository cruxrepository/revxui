const getClientReducer = (
    clientData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newClientData;
      switch (action.type) {
        case "GET_CLIENT_LIST":
            newClientData = {
            ...clientData,
            fetching: true,
            fetched: false,
        rawData:{}

          };
          break;
        case "GET_CLIENT_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newClientData = {
            ...clientData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            dataPresent,
        rawData:action.payload.rawData,
            responseStatus: action.payload.status
          };
          break;
        case "GET_CLIENT_LIST_FAILED":
            newClientData = {
            ...clientData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
        rawData:{},
          };
          break;
        case "CLEAR_GET_CLIENT_LIST":
            newClientData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            rawData:{},
            dataPresent: false
          };
          break;
        default:
          newClientData = clientData;
          break;
      }
      return newClientData;
    };
    export default getClientReducer;
