const getIVReducer = (
  iVData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newIVData;
      switch (action.type) {
        case "GET_IV_LIST":
            newIVData = {
            ...iVData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_IV_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newIVData = {
            ...iVData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_IV_LIST_FAILED":
            newIVData = {
            ...iVData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_IV_LIST":
            newIVData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newIVData = iVData;
          break;
      }
      return newIVData;
    };
    export default getIVReducer;
