const getBMSReducer = (
    bMSData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newBMSData;
      switch (action.type) {
        case "GET_BMS_LIST":
            newBMSData = {
            ...bMSData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_BMS_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBMSData = {
            ...bMSData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_BMS_LIST_FAILED":
            newBMSData = {
            ...bMSData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_BMS_LIST":
            newBMSData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newBMSData = bMSData;
          break;
      }
      return newBMSData;
    };
    export default getBMSReducer;
