const getTeleListReducer = (
    teleListData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newTeleListData;
      switch (action.type) {
        case "GET_TELELIST_LIST":
            newTeleListData = {
            ...teleListData,
            fetching: true,
            fetched: false,
        rawData:{}

          };
          break;
        case "GET_TELELIST_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newTeleListData = {
            ...teleListData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            dataPresent,
        rawData:action.payload.rawData,
            responseStatus: action.payload.status
          };
          break;
        case "GET_TELELIST_LIST_FAILED":
            newTeleListData = {
            ...teleListData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
        rawData:{},
          };
          break;
        case "CLEAR_GET_TELELIST_LIST":
            newTeleListData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            rawData:{},
            dataPresent: false
          };
          break;
        default:
          newTeleListData = teleListData;
          break;
      }
      return newTeleListData;
    };
    export default getTeleListReducer;
