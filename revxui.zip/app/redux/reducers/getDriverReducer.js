const getDriverReducer = (
  DriverData = {
      success: false,
      fetching: false,
      fetched: false,
      responseStatus: null,
      data: {},
      totalRecords:null,
      dataPresent: false
    },
    action
  ) => {
    let newDriverData;
    switch (action.type) {
      case "GET_DRIVER_LIST":
        newDriverData = {
          ...DriverData,
          fetching: true,
          fetched: false,
          totalRecords: null
        };
        break;
      case "GET_DRIVER_LIST_FULFILLED":
        const dataPresent =  Object.keys(action.payload.data).length !== 0;
        newDriverData = {
          ...DriverData,
          success: true,
          fetching: false,
          fetched: true,
          data: action.payload.data,
          totalRecords:action.payload.totalRecords,          
          total_records: action.payload.total_record,
          page_no: action.payload.page_number,
          dataPresent:dataPresent,
          responseStatus: action.payload.status
        };
        break;
      case "GET_DRIVER_LIST_FAILED":
        newDriverData = {
          ...DriverData,
          success: false,
          fetching: false,
          fetched: true,
          dataPresent: false,
          responseStatus: action.payload.status,
          totalRecords:null,

        };
        break;
      case "CLEAR_GET_DRIVER_LIST":
        newDriverData = {
          success: false,
          fetching: false,
          fetched: false,
          responseStatus: null,
          data: {},
          totalRecords:null,
          dataPresent: false
        };
        break;
      default:
        newDriverData = DriverData;
        break;
    }
    return newDriverData;
  };
  export default getDriverReducer;
