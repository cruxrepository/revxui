const getBDashboardReducer = (
    bDashboardData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false
      },
      action
    ) => {
      let newBDashboardData;
      switch (action.type) {
        case "GET_BATTERY_DASHBOARD_LIST":
            newBDashboardData = {
            ...bDashboardData,
            fetching: true,
            fetched: false
          };
          break;
        case "GET_BATTERY_DASHBOARD_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBDashboardData = {
            ...bDashboardData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_BATTERY_DASHBOARD_LIST_FAILED":
            newBDashboardData = {
            ...bDashboardData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status
          };
          break;
        case "CLEAR_GET_BATTERY_DASHBOARD_LIST":
            newBDashboardData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false
          };
          break;
        default:
          newBDashboardData = bDashboardData;
          break;
      }
      return newBDashboardData;
    };
    export default getBDashboardReducer;
