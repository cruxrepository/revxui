const getTelematicsReducer = (
    telematicsData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newTelematicsData;
      switch (action.type) {
        case "GET_TELEMATICS_LIST":
            newTelematicsData = {
            ...telematicsData,
            fetching: true,
            fetched: false,
        rawData:{}

          };
          break;
        case "GET_TELEMATICS_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newTelematicsData = {
            ...telematicsData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            dataPresent,
        rawData:action.payload.rawData,
            responseStatus: action.payload.status
          };
          break;
        case "GET_TELEMATICS_LIST_FAILED":
            newTelematicsData = {
            ...telematicsData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
        rawData:{},
          };
          break;
        case "CLEAR_GET_TELEMATICS_LIST":
            newTelematicsData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            rawData:{},
            dataPresent: false
          };
          break;
        default:
          newTelematicsData = telematicsData;
          break;
      }
      return newTelematicsData;
    };
    export default getTelematicsReducer;
