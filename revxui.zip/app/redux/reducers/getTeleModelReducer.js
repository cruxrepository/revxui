const getTeleModelReducer = (
  teleModelData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newTeleModelData;
      switch (action.type) {
        case "GET_TELEMODEL_LIST":
            newTeleModelData = {
            ...teleModelData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_TELEMODEL_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newTeleModelData = {
            ...teleModelData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_TELEMODEL_LIST_FAILED":
            newTeleModelData = {
            ...teleModelData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_TELEMODEL_LIST":
            newTeleModelData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newTeleModelData = teleModelData;
          break;
      }
      return newTeleModelData;
    };
    export default getTeleModelReducer;
