const getRoleReducer = (
    RoleData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false
      },
      action
    ) => {
      let newRoleData;
      switch (action.type) {
        case "GET_ROLE_LIST":
            newRoleData = {
            ...RoleData,
            fetching: true,
            fetched: false
          };
          break;
        case "GET_ROLE_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newRoleData = {
            ...RoleData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            rawData:action.payload.rawData,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_ROLE_LIST_FAILED":
          newRoleData = {
            ...RoleData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status
          };
          break;
        case "CLEAR_GET_ROLE_LIST":
          newRoleData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false
          };
          break;
        default:
          newRoleData = RoleData;
          break;
      }
      return newRoleData;
    };
    export default getRoleReducer;
