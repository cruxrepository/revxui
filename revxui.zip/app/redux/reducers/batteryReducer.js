// const batteryReducer = (
//     state = {
//      batteryEData:[],
//      batteryCData:[]
//     },
//     action
//   ) => {
//     let new_state;
//     switch (action.type) {
//       case "E_BATTERY":
//         new_state = {
//             ...state,
//             batteryEData : action.payload,
//         };
//         break;
//      case "C_BATTERY":
//         new_state = {
//             ...state,
//             batteryCData : action.payload,
//         };
//             break;
//       default:
//         new_state = state;
//         break;
//     }
//     return new_state;
//   };
  
//   export default batteryReducer;