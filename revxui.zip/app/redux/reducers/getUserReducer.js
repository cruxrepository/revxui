const getUserReducer = (
    UserData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        rawData: {},
        dataPresent: false
      },
      action
    ) => {
      let newUserData;
      switch (action.type) {
        case "GET_USER_LIST":
            newUserData = {
            ...UserData,
            fetching: true,
            fetched: false,
            rawData: {}
          };
          break;
        case "GET_USER_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newUserData = {
            ...UserData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            rawData:action.payload.rawData,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_USER_LIST_FAILED":
          newUserData = {
            ...UserData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:action.payload.rawData,

          };
          break;
        case "CLEAR_GET_USER_LIST":
          newUserData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            rawData:{},
            dataPresent: false
          };
          break;
        default:
          newUserData = UserData;
          break;
      }
      return newUserData;
    };
    export default getUserReducer;
