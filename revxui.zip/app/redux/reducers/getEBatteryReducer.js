// const getEBatteryReducer = (
//     eBatteryData = {
//         success: false,
//         fetching: false,
//         fetched: false,
//         responseStatus: null,
//         data: {},
//         dataPresent: false
//       },
//       action
//     ) => {
//       let newEBatteryData;
//       switch (action.type) {
//         case "GET_EBATTERY_LIST":
//             newEBatteryData = {
//             ...eBatteryData,
//             fetching: true,
//             fetched: false
//           };
//           break;
//         case "GET_EBATTERY_LIST_FULFILLED":
//           const dataPresent =  Object.keys(action.payload.data).length !== 0;
//           newEBatteryData = {
//             ...eBatteryData,
//             success: true,
//             fetching: false,
//             fetched: true,
//             data: action.payload.data,
//             dataPresent,
//             responseStatus: action.payload.status
//           };
//           break;
//         case "GET_EBATTERY_LIST_FAILED":
//             newEBatteryData = {
//             ...eBatteryData,
//             success: false,
//             fetching: false,
//             fetched: true,
//             dataPresent: false,
//             responseStatus: action.payload.status
//           };
//           break;
//         case "CLEAR_GET_EBATTERY_LIST":
//             newEBatteryData = {
//             success: false,
//             fetching: false,
//             fetched: false,
//             responseStatus: null,
//             data: {},
//             dataPresent: false
//           };
//           break;
//         default:
//             newEBatteryData = eBatteryData;
//           break;
//       }
//       return newEBatteryData;
//     };
//     export default getEBatteryReducer;
