const getBatteryModelLReducer = (
    batteryModelLData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newBatteryModelLData;
      switch (action.type) {
        case "GET_BATTERYMODELL_LIST":
            newBatteryModelLData = {
            ...batteryModelLData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_BATTERYMODELL_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBatteryModelLData = {
            ...batteryModelLData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_BATTERYMODELL_LIST_FAILED":
            newBatteryModelLData = {
            ...batteryModelLData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_BATTERYMODELL_LIST":
            newBatteryModelLData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newBatteryModelLData = batteryModelLData;
          break;
      }
      return newBatteryModelLData;
    };
    export default getBatteryModelLReducer;
