const loginReducer = (
    state = {
        validation_completed: false,
        // token: null,
        login_on_going: false,
        valid_user: false,
        error: null,
        login_by: null,
        result: [],
        loginBy: null
    },
    action
) => {
    let newState;
    switch (action.type) {
        case 'USER_LOGIN_INITIATED':
            newState = {
                ...state,
                login_on_going: true,
                validation_completed: false
            };
            break;
        case 'USER_LOGIN_SUCCESSFUL':
            const payload = action.payload;
            // const token = payload.btoken;
            // const user = payload.user;
            const loginBy = action.loginBy;
            const result = action.payload.data;
            newState = {
                ...state,
                login_on_going: false,
                valid_user: true,
                // token,
                error: null,
                validation_completed: true,
                loginBy,
                result
            };
            break;
        case 'USER_LOGIN_FAILED':
            newState = {
                ...state,
                error: action.payload,
                valid_user: false,
                login_on_going: false,
                // token: null,
                validation_completed: true,
                login_by: null,
                loginBy: null,
                result: []
            };
            break;
        case 'CLEAR_LOGIN_FAILED_ERROR':
            newState = {
                ...state,
                error: null
            };
            break;
        case 'DESTROY_CURRENT_USER_INFO':
            newState = {
                // token: null,
                login_on_going: true,
                valid_user: false,
                validation_completed: false,
                error: null,
                loginBy: null,
                result: []
            };
            break;

        default:
            newState = state;
            break;
    }

    return newState;
};

export default loginReducer;
