const getBatteryViewReducer = (
    batteryViewData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false
      },
      action
    ) => {
      let newBatteryViewData;
      switch (action.type) {
        case "GET_BATTERY_VIEW_LIST":
            newBatteryViewData = {
            ...batteryViewData,
            fetching: true,
            fetched: false
          };
          break;
        case "GET_BATTERY_VIEW_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBatteryViewData = {
            ...batteryViewData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_BATTERY_VIEW_LIST_FAILED":
            newBatteryViewData = {
            ...batteryViewData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status
          };
          break;
        case "CLEAR_GET_BATTERY_VIEW_LIST":
            newBatteryViewData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false
          };
          break;
        default:
          newBatteryViewData = batteryViewData;
          break;
      }
      return newBatteryViewData;
    };
    export default getBatteryViewReducer;
