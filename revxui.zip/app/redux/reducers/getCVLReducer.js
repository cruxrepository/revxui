const getCVLReducer = (
    cVLData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newCVLData;
      switch (action.type) {
        case "GET_CVL_LIST":
            newCVLData = {
            ...cVLData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_CVL_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newCVLData = {
            ...cVLData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_CVL_LIST_FAILED":
            newCVLData = {
            ...cVLData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_CVL_LIST":
            newCVLData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newCVLData = cVLData;
          break;
      }
      return newCVLData;
    };
    export default getCVLReducer;
