const getBatteryProReducer = (
    batteryProData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false
      },
      action
    ) => {
      let newBatteryProData;
      switch (action.type) {
        case "GET_BATTERY_PRO_LIST":
            newBatteryProData = {
            ...batteryProData,
            fetching: true,
            fetched: false
          };
          break;
        case "GET_BATTERY_PRO_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBatteryProData = {
            ...batteryProData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_BATTERY_PRO_LIST_FAILED":
            newBatteryProData = {
            ...batteryProData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status
          };
          break;
        case "CLEAR_GET_BATTERY_PRO_LIST":
            newBatteryProData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false
          };
          break;
        default:
          newBatteryProData = batteryProData;
          break;
      }
      return newBatteryProData;
    };
    export default getBatteryProReducer;
