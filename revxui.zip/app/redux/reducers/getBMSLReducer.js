const getBMSLReducer = (
    bMSLData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newBMSLData;
      switch (action.type) {
        case "GET_BMSL_LIST":
            newBMSLData = {
            ...bMSLData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_BMSL_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBMSLData = {
            ...bMSLData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_BMSL_LIST_FAILED":
            newBMSLData = {
            ...bMSLData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_BMSL_LIST":
            newBMSLData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newBMSLData = bMSLData;
          break;
      }
      return newBMSLData;
    };
    export default getBMSLReducer;
