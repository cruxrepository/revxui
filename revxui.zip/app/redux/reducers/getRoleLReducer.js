const getRoleLReducer = (
    RoleLData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false
      },
      action
    ) => {
      let newRoleLData;
      switch (action.type) {
        case "GET_ROLEL_LIST":
            newRoleLData = {
            ...RoleLData,
            fetching: true,
            fetched: false
          };
          break;
        case "GET_ROLEL_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newRoleLData = {
            ...RoleLData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            rawData:action.payload.rawData,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_ROLEL_LIST_FAILED":
          newRoleLData = {
            ...RoleLData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status
          };
          break;
        case "CLEAR_GET_ROLEL_LIST":
          newRoleLData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false
          };
          break;
        default:
          newRoleLData = RoleLData;
          break;
      }
      return newRoleLData;
    };
    export default getRoleLReducer;
