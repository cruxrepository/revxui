const getVModelReducer = (
  vModelData = {
      success: false,
      fetching: false,
      fetched: false,
      responseStatus: null,
      data: {},
      dataPresent: false,
      rawData:{}
    },
    action
  ) => {
    let newVModelData;
    switch (action.type) {
      case "GET_VMODEL_LIST":
          newVModelData = {
          ...vModelData,
          fetching: true,
          fetched: false,
      rawData:{}

        };
        break;
      case "GET_VMODEL_LIST_FULFILLED":
        const dataPresent =  Object.keys(action.payload.data).length !== 0;
        newVModelData = {
          ...vModelData,
          success: true,
          fetching: false,
          fetched: true,
          data: action.payload.data,
          dataPresent,
      rawData:action.payload.rawData,
          responseStatus: action.payload.status
        };
        break;
      case "GET_VMODEL_LIST_FAILED":
          newVModelData = {
          ...vModelData,
          success: false,
          fetching: false,
          fetched: true,
          dataPresent: false,
          responseStatus: action.payload.status,
      rawData:{},
        };
        break;
      case "CLEAR_GET_VMODEL_LIST":
          newVModelData = {
          success: false,
          fetching: false,
          fetched: false,
          responseStatus: null,
          data: {},
          rawData:{},
          dataPresent: false
        };
        break;
      default:
        newVModelData = vModelData;
        break;
    }
    return newVModelData;
  };
  export default getVModelReducer;
