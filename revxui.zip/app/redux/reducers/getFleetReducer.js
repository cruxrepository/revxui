const getFleetReducer = (
  fleetData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newFleetData;
      switch (action.type) {
        case "GET_FLEET_LIST":
            newFleetData = {
            ...fleetData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_FLEET_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newFleetData = {
            ...fleetData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_FLEET_LIST_FAILED":
            newFleetData = {
            ...fleetData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_FLEET_LIST":
            newFleetData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newFleetData = fleetData;
          break;
      }
      return newFleetData;
    };
    export default getFleetReducer;
