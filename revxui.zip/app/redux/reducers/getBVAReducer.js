const getBVAReducer = (
    bVAData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newBVAData;
      switch (action.type) {
        case "GET_BVA_LIST":
            newBVAData = {
            ...bVAData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_BVA_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBVAData = {
            ...bVAData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_BVA_LIST_FAILED":
            newBVAData = {
            ...bVAData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_BVA_LIST":
            newBVAData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newBVAData = bVAData;
          break;
      }
      return newBVAData;
    };
    export default getBVAReducer;
