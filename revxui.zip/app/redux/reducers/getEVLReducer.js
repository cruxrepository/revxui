const getEVLReducer = (
    eVLData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newEVLData;
      switch (action.type) {
        case "GET_EVL_LIST":
            newEVLData = {
            ...eVLData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_EVL_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newEVLData = {
            ...eVLData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_EVL_LIST_FAILED":
            newEVLData = {
            ...eVLData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_EVL_LIST":
            newEVLData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newEVLData = eVLData;
          break;
      }
      return newEVLData;
    };
    export default getEVLReducer;
