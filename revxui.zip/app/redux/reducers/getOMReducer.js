const getOMReducer = (
  oMData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newOMData;
      switch (action.type) {
        case "GET_OM_LIST":
            newOMData = {
            ...oMData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_OM_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newOMData = {
            ...oMData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
            rawData:action.payload.rawData,
            responseStatus: action.payload.status
          };
          break;
        case "GET_OM_LIST_FAILED":
            newOMData = {
            ...oMData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            // responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_OM_LIST":
            newOMData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newOMData = oMData;
          break;
      }
      return newOMData;
    };
    export default getOMReducer;
