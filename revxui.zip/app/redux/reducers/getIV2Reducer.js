const getIV2Reducer = (
  iV2Data = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newIV2Data;
      switch (action.type) {
        case "GET_IV2_LIST":
            newIV2Data = {
            ...iV2Data,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_IV2_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newIV2Data = {
            ...iV2Data,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_IV2_LIST_FAILED":
            newIV2Data = {
            ...iV2Data,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_IV2_LIST":
            newIV2Data = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newIV2Data = iV2Data;
          break;
      }
      return newIV2Data;
    };
    export default getIV2Reducer;
