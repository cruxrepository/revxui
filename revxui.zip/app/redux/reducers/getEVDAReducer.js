const getEVDAReducer = (
    eVDAData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newEVDAData;
      switch (action.type) {
        case "GET_EVDA_LIST":
            newEVDAData = {
            ...eVDAData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_EVDA_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newEVDAData = {
            ...eVDAData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_EVDA_LIST_FAILED":
            newEVDAData = {
            ...eVDAData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_EVDA_LIST":
            newEVDAData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newEVDAData = eVDAData;
          break;
      }
      return newEVDAData;
    };
    export default getEVDAReducer;
