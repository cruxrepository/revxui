const getVDashboardReducer = (
    vDashboardData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false
      },
      action
    ) => {
      let newVDashboardData;
      switch (action.type) {
        case "GET_VEHICLE_DASHBOARD_LIST":
            newVDashboardData = {
            ...vDashboardData,
            fetching: true,
            fetched: false
          };
          break;
        case "GET_VEHICLE_DASHBOARD_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newVDashboardData = {
            ...vDashboardData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_VEHICLE_DASHBOARD_LIST_FAILED":
            newVDashboardData = {
            ...vDashboardData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status
          };
          break;
        case "CLEAR_GET_VEHICLE_DASHBOARD_LIST":
            newVDashboardData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false
          };
          break;
        default:
          newVDashboardData = vDashboardData;
          break;
      }
      return newVDashboardData;
    };
    export default getVDashboardReducer;
