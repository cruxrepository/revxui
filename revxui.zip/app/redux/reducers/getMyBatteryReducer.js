const getMyBatteryReducer = (
  myBatteryData = {
    success: false,
    fetching: false,
    fetched: false,
    responseStatus: null,
    data: {},
    dataPresent: false,
    rawData: {}
  },
  action
) => {
  let newMyBatteryData;
  switch (action.type) {
    case "GET_MYBATTERY_LIST":
      newMyBatteryData = {
        ...myBatteryData,
        fetching: true,
        fetched: false,
        rawData: {}

      };
      break;
    case "GET_MYBATTERY_LIST_FULFILLED":
      const dataPresent = Object.keys(action.payload.data).length !== 0;
      newMyBatteryData = {
        ...myBatteryData,
        success: true,
        fetching: false,
        fetched: true,
        data: action.payload.data,
        total_records: action.payload.total_records,
        page_no: action.payload.page_number,
        dataPresent,
        rawData: action.payload.rawData,
        responseStatus: action.payload.status
      };
      break;
    case "GET_MYBATTERY_LIST_FAILED":
      newMyBatteryData = {
        ...myBatteryData,
        success: false,
        fetching: false,
        fetched: true,
        dataPresent: false,
        responseStatus: action.payload.status,
        rawData: {},
      };
      break;
    case "CLEAR_GET_MYBATTERY_LIST":
      newMyBatteryData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        rawData: {},
        dataPresent: false
      };
      break;
    default:
      newMyBatteryData = myBatteryData;
      break;
  }
  return newMyBatteryData;
};
export default getMyBatteryReducer;
