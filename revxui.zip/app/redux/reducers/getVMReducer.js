const getVMReducer = (
    vMData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newVMData;
      switch (action.type) {
        case "GET_VM_LIST":
            newVMData = {
            ...vMData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_VM_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newVMData = {
            ...vMData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_VM_LIST_FAILED":
            newVMData = {
            ...vMData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_VM_LIST":
            newVMData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newVMData = vMData;
          break;
      }
      return newVMData;
    };
    export default getVMReducer;
