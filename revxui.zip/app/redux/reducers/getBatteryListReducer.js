const getBatteryListReducer = (
  BatteryListData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        rawData: {},
        dataPresent: false
      },
      action
    ) => {
      let newBatteryListData;
      switch (action.type) {
        case "GET_BATTERYLIST_LIST":
            newBatteryListData = {
            ...BatteryListData,
            fetching: true,
            fetched: false,
            rawData: {}
          };
          break;
        case "GET_BATTERYLIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBatteryListData = {
            ...BatteryListData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            rawData:action.payload.rawData,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_BATTERYLIST_FAILED":
          newBatteryListData = {
            ...BatteryListData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:action.payload.rawData,

          };
          break;
        case "CLEAR_GET_BATTERYLIST":
          newBatteryListData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            rawData:{},
            dataPresent: false
          };
          break;
        default:
          newBatteryListData = BatteryListData;
          break;
      }
      return newBatteryListData;
    };
    export default getBatteryListReducer;
