const getBAReducer = (
    bAData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        dataPresent: false,
        rawData:{}
      },
      action
    ) => {
      let newBAData;
      switch (action.type) {
        case "GET_BA_LIST":
            newBAData = {
            ...bAData,
            fetching: true,
            fetched: false,
            rawData:{}
          };
          break;
        case "GET_BA_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newBAData = {
            ...bAData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            dataPresent,
        rawData:action.payload.rawData,
        responseStatus: action.payload.status
          };
          break;
        case "GET_BA_LIST_FAILED":
            newBAData = {
            ...bAData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:{},
          };
          break;
        case "CLEAR_GET_BA_LIST":
            newBAData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            dataPresent: false,
            rawData:{},
          };
          break;
        default:
          newBAData = bAData;
          break;
      }
      return newBAData;
    };
    export default getBAReducer;
