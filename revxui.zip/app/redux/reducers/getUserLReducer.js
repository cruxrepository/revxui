const getUserLReducer = (
    UserLData = {
        success: false,
        fetching: false,
        fetched: false,
        responseStatus: null,
        data: {},
        rawData: {},
        dataPresent: false
      },
      action
    ) => {
      let newUserLData;
      switch (action.type) {
        case "GET_USERL_LIST":
            newUserLData = {
            ...UserLData,
            fetching: true,
            fetched: false,
            rawData: {}
          };
          break;
        case "GET_USERL_LIST_FULFILLED":
          const dataPresent =  Object.keys(action.payload.data).length !== 0;
          newUserLData = {
            ...UserLData,
            success: true,
            fetching: false,
            fetched: true,
            data: action.payload.data,
            total_records: action.payload.total_records,
            page_no: action.payload.page_number,
            rawData:action.payload.rawData,
            dataPresent,
            responseStatus: action.payload.status
          };
          break;
        case "GET_USERL_LIST_FAILED":
          newUserLData = {
            ...UserLData,
            success: false,
            fetching: false,
            fetched: true,
            dataPresent: false,
            responseStatus: action.payload.status,
            rawData:action.payload.rawData,

          };
          break;
        case "CLEAR_GET_USERL_LIST":
          newUserLData = {
            success: false,
            fetching: false,
            fetched: false,
            responseStatus: null,
            data: {},
            rawData:{},
            dataPresent: false
          };
          break;
        default:
          newUserLData = UserLData;
          break;
      }
      return newUserLData;
    };
    export default getUserLReducer;
