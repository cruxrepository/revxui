const liveTrackerReducer = (
    state = {
     liveTrackerList:[],
     liveTrackerSelected:[]
    },
    action
  ) => {
    let new_state;
    switch (action.type) {
      case "LOG_LIVETRACKER_LIST":
        new_state = {
            ...state,
            liveTrackerList : action.payload,
        };
        break;
     case "LOG_LIVETRACKER_SELECTED":
        new_state = {
            ...state,
            liveTrackerSelected : action.payload,
        };
            break;
      default:
        new_state = state;
        break;
    }
    return new_state;
  };
  
  export default liveTrackerReducer;