import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles, useTheme, styled, withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import SimpleMap from "./SimpleMap";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import Slider from '@material-ui/core/Slider';
import { Icon } from '@iconify/react';
import BasicTable from './BasicTable';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import './App1.css';
import PaymentPie from "./PaymentPie";
import PaymentPieMobile from "./PaymentPieMobile";
const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'left',
    color: theme.palette.text.secondary,
}));
const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.secondary.dark,
        backgroundColor: theme.palette.secondary.light,
    },
    map: {
        height: 350, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    turingX: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#009688', letterSpacing: '0.03em'
    },
    box: {
        border: '1px solid #009688', height: '130px', borderRadius: '40px', backgroundColor: '#F8F8F8'

    },
    box1: {
        height: '160px', borderRadius: '23px', backgroundColor: '#E5E5E5', marginTop: 25, margin: 20

    },
    copyRight: {
        fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    drive: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: theme.palette.secondary.dark, margin: 45
    },
    paperH: {
        height: '350px', border: '1px solid #D8D8D8'
    },
    paperH1: {
        height: '200px', border: '1px solid #D8D8D8'
    },
    paperH2: {
        height: '300px', border: '1px solid #D8D8D8'
    },
    paperH3: {
        height: '300px', border: '1px solid #D8D8D8'
    },
    slide: {
        margin: 30
    },
    slider: {
        '& > .MuiSlider-thumbColorPrimary': { opacity: '0 !important' },
        color: '#009688', borderRadius: '0px',
        '& > .MuiSlider-rail': { height: '5px', color: '#C4C4C4' }, '& > .MuiSlider-track': { height: '5px' },
        marginTop: '-5px'
    },
    sliderTxt: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 600
    },
    sliderTxt2: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 500, color: '#5F6368', marginLeft: '125px', marginTop: '-30px'
    },
    icon: {
        marginLeft: 45
    },
    iconS: {
        marginLeft: 20
    },
    iconSM: {
        marginLeft: 20
    },
    boxGreen: {
        border: '5px solid #68A724', width: 45, height: 45, borderRadius: '25px', marginTop: '-65px', marginLeft: '-38px'
    },
    boxYellow: {
        border: '5px solid #BCBC26', width: 45, height: 45, borderRadius: '25px', marginTop: '20px', marginLeft: '-40px'
    },
    boxRed: {
        border: '5px solid #C4C4C4', width: 45, height: 45, borderRadius: '25px', marginTop: '20px', marginLeft: '-40px'
    },
    txt1: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 400, color: '#000000'
    },
    txt2: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 700, color: '#000000'
    },
    txt3: {
        fontFamily: 'Maven Pro', fontSize: '18px', fontWeight: 700, color: '#000000'
    },
    txt1M: {
        fontFamily: 'Maven Pro', fontSize: '15px', fontWeight: 400, color: '#000000'
    },
    txt2M: {
        fontFamily: 'Maven Pro', fontSize: '12px', fontWeight: 700, color: '#000000'
    },
    txt3M: {
        fontFamily: 'Maven Pro', fontSize: '10px', fontWeight: 700, color: '#000000'
    },
    boxtxt: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#000000', marginTop: '5px'
    },
    boxtxtM: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#000000', marginTop: '10px'
    },
    boxGreenM: {
        border: '5px solid #68A724', width: 45, height: 45, borderRadius: '25px' 
      },
      boxYellowM: {
        border: '5px solid #BCBC26', width: 45, height: 45, borderRadius: '25px' 
      },
      boxRedM: {
        border: '5px solid #C4C4C4', width: 45, height: 45, borderRadius: '25px' 
      },



}));
const PrettoSlider = withStyles({
    root: {
        color: '#68A724B2',
        height: 8,
    },
    thumb: {
        height: 24,
        width: 24,
        backgroundColor: '#fff',
        border: '2px solid currentColor',
        marginTop: -8,
        marginLeft: -12,
        '&:focus,&:hover,&$active': {
            boxShadow: 'inherit',
        },
    },
    active: {},
    valueLabel: {
        left: 'calc(-50% + 4px)',
    },
    track: {
        height: 8,
        borderRadius: 4,
        color: '#68A724B2'
    },
    rail: {
        height: 8,
        borderRadius: 4,
        color: '#FFFFFF'
    },
})(Slider);

export default function RevxAdmin() {


    const [trackerSearch, setTrackerSearch] = React.useState("");
    const [zoomVar, setZoomVar] = React.useState(0);
    const theme = useTheme();
    const classes = useStyles();
    const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

    return (
        <>

            <div className={classes.root}>
                <Grid container spacing={2}>
                    <Grid item xs={12} lg={8}>
                        <Paper className={classes.map} variant="outlined" >
                            <SimpleMap
                                zoom={zoomVar}
                            />

                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={4}>
                        <Paper className={classes.paperH}><br />
                            <Typography align="center" className={classes.turingX}>Drivers using TuringX</Typography>
                            <div style={{ margin: 50 }}>
                                <Box className={classes.box}>
                                    <Typography align="center" className={classes.drive}>20-Drivers</Typography></Box></div></Paper>
                    </Grid>


                    <Grid item xs={12} lg={7}>
                        <Paper >
                            <BasicTable />
                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={5}>
                        <Paper >
                           <Typography align="center" className={classes.turingX}> Combined Fleet Efficiency</Typography> 
                            {isMdUp ? <PaymentPie /> : <PaymentPieMobile />}
                        </Paper>
                    </Grid> 
                    
                    {/* <Grid item xs={12} lg={5}>
                        <Paper className={isMdUp === true ? classes.paperH3 : classes.paperH2}>
                        <Typography align="center" className={classes.turingX}>Vehicle Assignment</Typography> 
                            <Box className={classes.slide}>
                                <Typography className={classes.sliderTxt}>2 W
                                    <Icon className={classes.icon} icon="mdi:motorbike" color="#009688" width="30" height="30" hFlip={true} />
                                    <Typography className={classes.sliderTxt2}>30/70</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={60} />
                                <br /> <br />
                                <Typography className={classes.sliderTxt}>3 W
                                    <Icon className={classes.icon} icon="mdi:rickshaw" color="#000000" width="30" height="30" hFlip={true} />
                                    <Typography className={classes.sliderTxt2}>20/180</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={90} />
                                <br /> <br />
                                <Typography className={classes.sliderTxt}>Battery
                                    <Icon className={isMdUp === true ? classes.iconS : classes.iconSM} icon="mdi:car-battery" color="#009688" width="30" height="30" hFlip={true} />
                                    <Typography className={classes.sliderTxt2}>50/298</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={95} /></Box>
                        </Paper>
                    </Grid> */}
                     <Grid item xs={12} lg={5}>
                        <Paper 
                        // className={isMdUp === true ? classes.paperH1 : classes.paperH2}
                        >
                            <Typography align="center" className={classes.turingX}>Vehicle Assignment</Typography> 
                            <br/>
                            <Box className={classes.slide}>
                                <Typography className={classes.sliderTxt}>EVIFY
                                    {/* <Icon className={classes.icon} icon="mdi:motorbike" color="#009688" width="30" height="30" hFlip={true} /> */}
                                    <Typography className={classes.sliderTxt2}>30/100</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={30} />
                                <br /> 
                                <Typography className={classes.sliderTxt}>Moeving
                                    {/* <Icon className={classes.icon} icon="mdi:rickshaw" color="#000000" width="30" height="30" hFlip={true} /> */}
                                    <Typography className={classes.sliderTxt2}>90/200</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={45} />
                                <br /> 
                                <Typography className={classes.sliderTxt}>E20
                                    {/* <Icon className={isMdUp === true ? classes.iconS : classes.iconSM} icon="mdi:car-battery" color="#009688" width="30" height="30" hFlip={true} /> */}
                                    <Typography className={classes.sliderTxt2}>300/700</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={43} />
                                <br /> 
                                <Typography className={classes.sliderTxt}>Grevol
                                    {/* <Icon className={classes.icon} icon="mdi:rickshaw" color="#000000" width="30" height="30" hFlip={true} /> */}
                                    <Typography className={classes.sliderTxt2}>1000/3500</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={28} />
                                <br /> 
                                <Typography className={classes.sliderTxt}>Mahindra
                                    {/* <Icon className={classes.icon} icon="mdi:rickshaw" color="#000000" width="30" height="30" hFlip={true} /> */}
                                    <Typography className={classes.sliderTxt2}>10000/100000</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={10} />
                                <br /><br /></Box>
                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={7}>
                        <Paper 
                        // className={classes.paperH3}
                        >
                        <Typography align="center" className={classes.turingX}>Health Card</Typography> 
                            {isMdUp === true ?
                                <Table className={classes.rootTable}>
                                    <TableBody>
                                        <TableRow>
                                            <TableCell className={classes.txt1}>2 W<Typography className={classes.txt2}>100</Typography></TableCell>
                                            <TableCell><Icon icon="mdi:motorbike" color="#009688" width="30" height="30" hFlip={true} /></TableCell>
                                            <TableCell className={classes.txt3}>Healthy<Icon icon="mdi:minus" color="#68a724" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxGreen} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>50</Box>

                                            <TableCell className={classes.txt3}>UnHealthy<Icon icon="mdi:minus" color="#BCBC26" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxYellow} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>30</Box>

                                            <TableCell className={classes.txt3}>Deactivated<Icon icon="mdi:minus" color="#C4C4C4" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxRed} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>30</Box>
                                        </TableRow>
                                        <br/>
                                        <TableRow>
                                            <TableCell className={classes.txt1}>3 W<Typography className={classes.txt2}>150</Typography></TableCell>
                                            <TableCell><Icon icon="mdi:rickshaw" color="#009688" width="30" height="30" hFlip={true} /></TableCell>
                                            <TableCell className={classes.txt3}>Healthy<Icon icon="mdi:minus" color="#68a724" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxGreen} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>20</Box>

                                            <TableCell className={classes.txt3}>UnHealthy<Icon icon="mdi:minus" color="#BCBC26" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxYellow} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>50</Box>

                                            <TableCell className={classes.txt3}>Deactivated<Icon icon="mdi:minus" color="#C4C4C4" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxRed} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>70</Box>
                                        </TableRow>
                                        <br/>
                                        <TableRow>
                                            <TableCell className={classes.txt1}>Battery<Typography className={classes.txt2}>200</Typography></TableCell>
                                            <TableCell><Icon icon="mdi:car-battery" color="#009688" width="30" height="30" hFlip={true} /></TableCell>
                                            <TableCell className={classes.txt3}>Healthy<Icon icon="mdi:minus" color="#68a724" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxGreen} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>80</Box>

                                            <TableCell className={classes.txt3}>UnHealthy<Icon icon="mdi:minus" color="#BCBC26" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxYellow} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>90</Box>

                                            <TableCell className={classes.txt3}>Deactivated<Icon icon="mdi:minus" color="#C4C4C4" width="40" height="45" /></TableCell>
                                            <Box className={classes.boxRed} align="center">
                                                <Typography align="center" className={classes.boxtxt}></Typography>100</Box>
                                        </TableRow>
                                    </TableBody>
                                </Table> :

                                <Table className={classes.rootTable}>
                                    <TableBody>
                                        <TableRow>
                                            <TableCell className={classes.txt1M}>2 W<Typography className={classes.txt2M}>100</Typography></TableCell>
                                            <TableCell><Icon icon="mdi:motorbike" color="#009688" width="30" height="30" hFlip={true} /></TableCell>
                                            <TableCell className={classes.txt3M}>Healthy
                                                <Box className={classes.boxGreenM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>50</Box></TableCell>

                                            <TableCell className={classes.txt3M}>UnHealthy
                                                <Box className={classes.boxYellowM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>30</Box></TableCell>

                                            <TableCell className={classes.txt3M}>Deactivated
                                                <Box className={classes.boxRedM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>30</Box></TableCell>
                                        </TableRow>

                                        <TableRow>
                                            <TableCell className={classes.txt1M}>3 W<Typography className={classes.txt2M}>150</Typography></TableCell>
                                            <TableCell><Icon icon="mdi:rickshaw" color="#009688" width="30" height="30" hFlip={true} /></TableCell>
                                            <TableCell className={classes.txt3M}>Healthy
                                                <Box className={classes.boxGreenM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>20</Box></TableCell>

                                            <TableCell className={classes.txt3M}>UnHealthy
                                                <Box className={classes.boxYellowM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>50</Box></TableCell>

                                            <TableCell className={classes.txt3M}>Deactivated
                                                <Box className={classes.boxRedM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>70</Box></TableCell>
                                        </TableRow>

                                        <TableRow>
                                            <TableCell className={classes.txt1M}>Battery<Typography className={classes.txt2M}>200</Typography></TableCell>
                                            <TableCell><Icon icon="mdi:car-battery" color="#009688" width="30" height="30" hFlip={true} /></TableCell>
                                            <TableCell className={classes.txt3M}>Healthy
                                                <Box className={classes.boxGreenM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>80</Box></TableCell>

                                            <TableCell className={classes.txt3M}>UnHealthy
                                                <Box className={classes.boxYellowM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>90</Box></TableCell>

                                            <TableCell className={classes.txt3M}>Deactivated
                                                <Box className={classes.boxRedM} align="center">
                                                    <Typography align="center" className={classes.boxtxtM}></Typography>100</Box></TableCell>
                                        </TableRow>
                                    </TableBody>
                                </Table>}

                        </Paper>
                    </Grid>

                </Grid>
            </div>
            <br />
            <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt.Ltd. </Typography>
        </>
    )
};
