import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import Button from "@material-ui/core/Button";
import './style.css';
import Paper from "@material-ui/core/Paper";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import SimpleSnackbar from '../Users/SimpleSnackbar';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import { useDispatch, useSelector } from 'react-redux';
import { getReportBulk, getReportFullBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';
import Pagination from '@material-ui/lab/Pagination';
import endpoints from '../../../endpoints/endpoints';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import { Box, CircularProgress, FormControl, InputLabel, ListItemText, MenuItem, Select, Tooltip } from "@material-ui/core";
import { CloudDownload } from "@material-ui/icons";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  gst: {
    color: '#4CAF50'
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  tabHelp: {
    fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
  },
  formControl: {
    width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
  },
  textField: {
    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
  },
  autoComplete: {
    '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
  },
  dialog: {
    position: 'relative', marginLeft: '630px'
  },
  BNsecondaryTextG: { color: '#00FF00' },

}));



/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function Report() {
  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const classes = useStyles();
  const validateKeyData = (key) => {
    return key ? key : "-";
  };
  const [open, setOpen] = React.useState(false)
  const [imei, setImei] = React.useState(false)
  const [bmsid, setBmsid] = React.useState(false)

  const [open1, setOpen1] = React.useState(false);
  const [ddd1, setDdd1] = React.useState(false);

  const handleClick1 = () => {
    setOpen1(true);
  };

  const handleClose1 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen1(false);
  };
  const [open2, setOpen2] = React.useState(false);
  const [ddd2, setDdd2] = React.useState(false);

  const handleClick2 = () => {
    setOpen2(true);
  };

  const handleClose2 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen2(false);
  };

  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [addResponse, setAddResponce] = React.useState("")
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)

  const [selectedBms, setSelectedBms] = React.useState("");
  const [page, setPage] = React.useState(1);

  const changePage = (event, newValue) => {
    setPage(newValue);
  };
  const ReportData = useSelector((store) => store.reportAll)
  const ReportDataRaw = useSelector((store) => store.reportAll.rawData)
  let ReportMeta = {};
  ReportMeta.data = [];
  let ReportMetaa = useSelector((store) => store.reportAll)
  if (ReportMetaa.data.length >= 1) {
    ReportMeta.data = ReportMetaa.data;
  }
  const MyReportPage = useSelector((store) => store.reportAll.page_number)
  const MyReportCount = Math.ceil(useSelector((store) => store.reportAll.total_records) / 10)
  let ReportFetching = useSelector((store) => store.reportAll.fetching)
  let ReportResponsecode = useSelector((store) => store.reportAll.responseStatus)
  let ReportMetaPresent = useSelector((store) => store.reportAll.dataPresent)

  const ReportFullData = useSelector((store) => store.reportTotal)
  const ReportFullDataRaw = useSelector((store) => store.reportTotal.rawData)
  let ReportFullMeta = {};
  ReportFullMeta.data = [];
  let ReportFullMetaa = useSelector((store) => store.reportTotal)
  if (ReportFullMetaa.data.length >= 1) {
    ReportFullMeta.data = ReportFullMetaa.data;
  }
  let ReportFullFetching = useSelector((store) => store.reportTotal.fetching)
  let ReportFullResponsecode = useSelector((store) => store.reportTotal.responseStatus)
  let ReportFullMetaPresent = useSelector((store) => store.reportTotal.dataPresent)

  let ReportSerial = ReportFullMeta.data.map(function (el) { return el[0]; });
  let ReportBMS_Unique = ReportFullMeta.data.map(function (el) { return el[1]; });
  let ReportIMEI = ReportFullMeta.data.map(function (el) { return el[2]; });

  const logged_user = useSelector((store) => store.login.result);
  console.log("logged_userlogged_user",logged_user)
  let enty = logged_user.entity_id
  let roid = logged_user.role_id
  let Urid = logged_user.user_id

  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(
      getReportBulk(enty,Urid,roid, page)
    );
    dispatch(
      getReportFullBulk(enty,Urid,roid)
    );

  }, [ReportMetaPresent, page, ReportFullMetaPresent]);

  React.useEffect(() => {
    setDownload({
      fromDate: "",
      toDate: "",
      imei: ""
    })

  }, [selectedBms]);



  const [download, setDownload] = React.useState({
    fromDate: "",
    toDate: "",
    imei: ""
  })


  const downloadReport = (value) => {
    let imei = value;
    // console.log("value",value)
    if (download.fromDate && download.toDate) {
      let fromDate = download.fromDate;
      let toDate = download.toDate;

      // if (download.fromDate && download.toDate) {
      let getReport = endpoints.baseUrl + `/battery/datadownload/` + imei + `?fromDate=` + fromDate + `&toDate=` + toDate;
      // console.log("getReport",getReport)
      const a = document.createElement('a')
      a.setAttribute('href', getReport)
      // a.setAttribute('download', true)
      a.click()
      // setAddBatteryErrors(true);
      setNotificationTimeOut(70000)
      handleClick2(true);
      setDdd2("Preparing Your csv for Download, Please wait..")
      axios
        .get(getReport, download)
        .then((response) => {
          handleClick1(true);
          response.status === 200 ? setDdd1("Downloaded successfully") : setDdd1(response.message)
          // location.reload();
        });
    }
    else {
      handleClick2(true);
      setDdd2("Please Fill Required Fields")
    }



  }

  const setDRArray = (e, key) => {
    setDownload((state) => ({ ...state, [key]: e.target.value }));

  }
  const [dataOn, setDataOn] = React.useState(false);
  const [clear1, setClear1] = React.useState("");
  const [clear2, setClear2] = React.useState("");
  const [clear3, setClear3] = React.useState("");

  const ReportColumn = [

    {
      label: "Serial Number", name: "name",
      options: {
        filter: true,
        filterList: clear1,
        filterType: 'custom',
        filterOptions: {
          logic: (serial_number, filters, row) => {
            if (filters.length) return !filters.includes(serial_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = ReportSerial.filter((item,
              index) => ReportSerial.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Serial Number</InputLabel>
                <Select

                  multiple
                  value={clear1.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear1(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getReportFullBulk(enty,Urid,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Battery Unique Identifier", name: "unique",
      options: {
        filter: true,
        filterList: clear3,
        filterType: 'custom',
        filterOptions: {
          logic: (bms_unique_id, filters, row) => {
            if (filters.length) return !filters.includes(bms_unique_id);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = ReportBMS_Unique.filter((item,
              index) => ReportBMS_Unique.indexOf(item) === index);
            return (
              <FormControl style={{ width: '200px' }}>
                <InputLabel htmlFor="select-multiple-chip">Battery Unique Identifier</InputLabel>
                <Select

                  multiple
                  value={clear3.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear3(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getReportFullBulk(enty,Urid,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "IMEI", name: "unique",
      options: {
        filter: true,
        display: false,
        filterList: clear2,
        filterType: 'custom',
        filterOptions: {
          logic: (imei, filters, row) => {
            if (filters.length) return !filters.includes(imei);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = ReportIMEI.filter((item,
              index) => ReportIMEI.indexOf(item) === index);
            return (
              <FormControl style={{ width: '200px' }}>
                <InputLabel htmlFor="select-multiple-chip">IMEI</InputLabel>
                <Select

                  multiple
                  value={clear2.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear2(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getReportFullBulk(enty,Urid,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Download", name: "download",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <IconButton
            onClick={() => {
              if (value.imei === '') {
                handleClick2(true);
                setDdd2("No IMEI")
              }
              else {
                setOpen(true)
                setImei(value.imei)
                setBmsid(value.bms_id)
              }
            }}
          ><Icon icon="fa:cloud-download" color="#77b93e" width="22" height="22" />
          </IconButton>
        ),
      },
    },


  ];

  const data = [

    { name: "ABC-123", unique: "5645645" },
    { name: "XYZ-963", unique: "455245645" },
    { name: "test123", unique: "45452524" },
  ];

  const onDownload = () => {
    const headerRow = ["Serial Number", "Battery Unique ID", "IMEI"];
    const bodyRows = ReportFullMeta.data.length && ReportFullMeta.data.map((col) => {
      return [
        col[0],
        col[1],
        col[2]
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }
  const options = {
    filter: true,
    download: false,
    print: false,
    viewColumns: false,
    search: false,
    selectableRows: "none",
    customToolbar: () => {
      return (<>
        <Tooltip style={{ flex: 'left' }} title={"Download CSV"}>
          <IconButton style={{ transform: "translateX(-4em)" }} onClick={() => {
            onDownload()
          }}>
            <CloudDownload />
          </IconButton></Tooltip>
        {clear1 != '' || clear2 != '' || clear3 != '' ?
          <Button style={{ width: '100px' }}
            onClick={() => {
              setDataOn(false)
              setClear1([])
              setClear2([])
              setClear3([])
              dispatch(getReportBulk(enty,Urid,roid, page));
            }}>RESET</Button> : null}</>);
    },
  };




  return (
    <div className={classes.table}>

      <Paper square className={classes.root} />
      {/* <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} /> */}
      <Snackbar open={open1} autoHideDuration={3000} onClose={handleClose1} notificationTimeOut={notificationTimeOut}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        style={{ marginTop: '300px', marginLeft: '450px' }}
      >
        <Alert onClose={handleClose1} severity="success">
          {ddd1}
        </Alert>
      </Snackbar>
      <Snackbar open={open2} autoHideDuration={3000} onClose={handleClose2} notificationTimeOut={notificationTimeOut}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        style={{ marginTop: '550px', marginLeft: '450px' }}
      >
        <Alert onClose={handleClose2} severity="warning">
          {ddd2}
        </Alert>
      </Snackbar>
      {ReportFetching === true ?
        <><br /><br /><br /><br /><Box sx={{ display: 'flex', justifyContent: 'space-around' }}>
          <CircularProgress style={{ height: '100px', width: '100px' }} />
        </Box></> :
        <>
          <MUIDataTable
            checkboxSelection={false}
            title="Report"
            data={dataOn === true ? ReportFullMeta.data : ReportMeta.data}
            columns={ReportColumn}
            options={options}
            selectableRows={1}
            selectableRowsHideCheckboxes
          /><br />
          <Pagination color="secondary" count={MyReportCount} page={page} onChange={changePage} /><br /></>
      }

      <Typography align="center" className={classes.copyRight}>
        Copyright© 2023 ReVx Energy Pvt.Ltd.
      </Typography>
      <Dialog
        fullScreen={fullScreen}
        open={open}
        maxWidth={"lg"}
        onClose={() => setOpen(false)}
        aria-labelledby="responsive-dialog-title"
        style={{ width: '1200px', position: 'relative', marginLeft: '680px', marginTop: '250px' }}
      >
        <DialogTitle id="responsive-dialog-title">{"Report Download"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item lg={6} xs={12}>
                <Typography>From</Typography>
                <TextField
                  onChange={(e) => {
                    setDRArray(e, 'fromDate')
                  }}
                  value={selectedBms === bmsid ? download && download.fromDate : null}
                  type="date"
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography>To</Typography><TextField
                  type="date"
                  onChange={(e) => {
                    setDRArray(e, 'toDate')
                  }}
                  value={selectedBms === bmsid ? download && download.toDate : null}
                />
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpen(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            onClick={() => {
              downloadReport(imei)
            }}
            color="secondary">
            Download
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
