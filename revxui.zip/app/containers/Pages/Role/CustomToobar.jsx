import React from "react";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import { withStyles, makeStyles, useTheme, styled, useStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import { Icon } from '@iconify/react';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import classNames from 'classnames';
import './style.css';

import Checkbox from '@material-ui/core/Checkbox';
import Box from '@material-ui/core/Box';
import FavoriteBorder from '@material-ui/icons/FavoriteBorder';
import FormControlLabel from '@material-ui/core/FormControlLabel';

export default function CustomToolbar(props) {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const [openAddRole, setOpenAddRole] = React.useState(false);

  const handleClick = () => {
  }
  const useStyles = makeStyles((theme) => ({
    Box: {
      border: '1px solid #000000'
    },
    IconButton: {
      '&:hover': {
        color: '#9ccc65'
      },
      
    },
    tabHelp: {
      fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
    },
    formControl: {
      width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
    },
    textField: {
      width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
      'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    autoComplete: {
      '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
  },
  dialog: {
    position:'relative'
  }
  }));

  //   const theme = useTheme();
  const classes = useStyles();
  const [status, setStatus] = React.useState('');
  const [action, setAction] = React.useState('');
  const [addrole, setAddRole] = React.useState('');

  const handleChange1 = (event) => {
    setStatus(event.target.value);
};
const handleChange2 = (event) => {
  setAction(event.target.value);
};
const handleChangeAddRole = (event) => {
  setAddRole(event.target.value);
};
  return (
    <React.Fragment>
      <Tooltip style={{ flex: 'left' }} title={"Add Role"}>
        <IconButton
          className={classes.IconButton}
          onClick={() => setOpenAddRole(true)}
        >
          <Icon icon="mdi:account-plus" width="30" height="30" hFlip={true} />
        </IconButton>
      </Tooltip>

      <Dialog
        fullScreen={fullScreen}
        open={openAddRole}
        maxWidth={"lg"}
        onClose={() => setOpenAddRole(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Add Role"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
             <Grid container spacing={2}>
              <Grid item xs={12} lg={2}>
                <Typography className={classes.tabHelp}>Role Name</Typography>
                <TextField size="small" id="outlined" placeholder="eg: Admin" className={classes.textField} />
              
              </Grid>
              <Grid item xs={12} lg={5} className={classes.tabHelp}>
                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography>Role Permission</Typography></Grid>
                        <Grid item xs={4} lg={2}><Typography>View</Typography></Grid>
                        <Grid item xs={4} lg={2}><Typography>Edit</Typography></Grid>
                      </Grid><br />

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography>Dashboard</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Live Tracker</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Drivers</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                       <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Vehicle</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Battery</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Charging</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Telematics</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      
                    </Grid>


                    <Grid item xs={12} lg={5} className={classes.tabHelp}>
                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography>Role Permission</Typography></Grid>
                        <Grid item xs={4} lg={2}><Typography>View</Typography></Grid>
                        <Grid item xs={4} lg={2}><Typography>Edit</Typography></Grid>
                      </Grid><br />

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Client</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Accounts</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Reports</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                       <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Users</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Role</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      <Grid container spacing={2}>
                        <Grid item xs={4} lg={4}><Typography >Settings</Typography></Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                        <Grid item xs={4} lg={2}>
                        <FormControlLabel
                          control={
                            <Checkbox icon={<Icon icon="akar-icons:circle-fill" color="#c4c4c4" width="26" height="26" />}
                              checkedIcon={<Icon icon="akar-icons:circle-check-fill" color="#68a724" width="26" height="26" />}
                              value="checkedH" />
                          }
                        />
                        </Grid>
                      </Grid>

                      
                    </Grid>
            </Grid>  
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenAddRole(false)}
            color="secondary">
            Cancel
          </Button>
          <Button
            onClick={() => setOpenAddRole(false)}
            color="primary" autoFocus>
            Submit
          </Button>
        </DialogActions>
      </Dialog>  

    </React.Fragment>

  );


}

// export default withStyles(CustomToolbar, defaultToolbarStyles, { name: "CustomToolbar" });
