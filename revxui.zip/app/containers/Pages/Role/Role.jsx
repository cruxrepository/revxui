import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import PropTypes from "prop-types";
import Chip from "@material-ui/core/Chip";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import Tooltip from "@material-ui/core/Tooltip";
import NotificationImportantIcon from "@material-ui/icons/NotificationImportant";
import Paper from "@material-ui/core/Paper";
import "./style.css";
import CustomToolbar from "./CustomToobar";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Grid from "@material-ui/core/Grid";
import IconButton from "@material-ui/core/IconButton";
import TextField from "@material-ui/core/TextField";
import FormControl from "@material-ui/core/FormControl";
import classNames from "classnames";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import { Icon } from "@iconify/react";

import Checkbox from "@material-ui/core/Checkbox";
import Box from "@material-ui/core/Box";
import FavoriteBorder from "@material-ui/icons/FavoriteBorder";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import SimpleSnackbar from '../Users/SimpleSnackbar';

import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  setRoleData,
  setRolePermissionData,
} from "../../../redux/actions/normalActions";
import Loading from "../../../components/Loading";
import ErrorWrap from "../../../components/Error/ErrorWrap";
import { getRoleBulk, getRoleLBulk } from "../../../redux/actions/asyncActions";
import Pagination from "@material-ui/lab/Pagination";
import endpoints from "../../../endpoints/endpoints";
import { CircularProgress, InputLabel, ListItemText } from "@material-ui/core";
import { CloudDownload } from "@material-ui/icons";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  gst: {
    color: "#4CAF50",
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  tabHelp: {
    fontSize: "17px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#A7A7A7",
  },
  formControl: {
    width: "100%",
    borderRadius: "9px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#7A7A7D  !important",
    },
  },
  textField: {
    width: "100%",
    color: "#7A7A7D",
    borderRadius: "9px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#C4C4C4  !important",
    },
    "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
  },
  autoComplete: {
    ".MuiPaper-root": { width: "80% !important", marginLeft: "60px" },
  },
  dialog: {
    position: "relative",
    marginLeft: "680px",
  },
}));

/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function Role() {
  const RoleData = useSelector((store) => store.roleAll);
  const RoleDataRaw = useSelector((store) => store.roleAll.rawData);
  let RoleMeta = useSelector((store) => store.roleAll);
  const MyRolePage = useSelector((store) => store.roleAll.page_number);
  const MyRoleCount = Math.ceil(
    useSelector((store) => store.roleAll.total_records) / 10
  );
  let RoleFetching = useSelector((store) => store.roleAll.fetching);
  let RoleResponsecode = useSelector((store) => store.roleAll.responseStatus);
  let RoleMetaPresent = useSelector((store) => store.roleAll.dataPresent);
  let allRoles = RoleMeta.data;
  const logged_user = useSelector((store) => store.login.result);
  const ppp = useSelector((store) => store.login.result.password);
  let roleEditAccess = logged_user.role === "edit"
  const [page, setPage] = React.useState(1);
  const UserName = useSelector((store) => store.login.result.username);

  const changePage = (event, newValue) => {
    setPage(newValue);
  };

  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getRoleBulk(page));
    dispatch(getRoleLBulk());
  }, [dispatch, RoleMetaPresent, page, RoleLMetaPresent]);
  let RoleLFetching = useSelector((store) => store.roleLAll.fetching)
  let RoleLResponsecode = useSelector((store) => store.roleLAll.responseStatus)
  let RoleLMetaPresent = useSelector((store) => store.roleLAll.dataPresent)
  const RoleLData = useSelector((store) => store.roleLAll)
  let RoleLMeta = useSelector((store) => store.roleLAll)
  let RoleList = RoleLMeta.data.length && RoleLMeta.data.map(function (el) { return el[0]; });

  const [dataOn, setDataOn] = React.useState(false);
  const [clear1, setClear1] = React.useState("");

  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("sm"));
  const classes = useStyles();
  const [screen, setScreen] = React.useState(false);
  const [value, setValue] = React.useState(0);
  const [index, setIndex] = React.useState(0);
  const [editrole, setEditRole] = React.useState("");
  const [openAddRole, setOpenAddRole] = React.useState(false);
  const [openEditRole, setOpenEditRole] = React.useState(false);
  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [addResponse, setAddResponce] = React.useState("")
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)
  const [typeVar, setTypeVar] = React.useState([]);

  const [rolePAddForm, setRolePAddForm] = React.useState({
    role_id: "",
    created_by: UserName,
    updated_by: "",
    roles: {
      dashboard: ["view", "edit"],
      live_tracker: [],
      drivers: [],
      vehicle: [],
      battery: [],
      telematics: [],
      assignment: [],
      client: [],
      reports: [],
      users: [],
      role: [],
      settings: [],
    },
  });
  const [rolePEditForm, setRolePEditForm] = React.useState({
    role_id: "",
    roles: {
      dashboard: ["view", "edit"],
      live_tracker: [],
      drivers: [],
      vehicle: [],
      battery: [],
      telematics: [],
      assignment: [],
      client: [],
      reports: [],
      users: [],
      role: [],
      settings: [],
    },
  });
  const submitRoleP = () => {
    const postRoleP = endpoints.baseUrl + `/rolepermission/add`;
    axios.post(postRoleP, rolePAddForm).then((response) => {
      dispatch(getRoleBulk(page));
    });
  };
  const setRolePAddFormArray = (e, key) => {
    setRolePAddForm((state) => ({ ...state, [key]: e.target.value }));
  };

  const [roleAddForm, setRoleAddForm] = React.useState({
    role_name: "",
  });
  const submitRole = () => {
    if (roleAddForm.role_name) {
      const postRole = endpoints.baseUrl + `/role/add`;
      axios.post(postRole, roleAddForm).then((response) => {
        setAddBatteryErrors(true);
        response.status === 201 ? setAddResponce("Role onboarding successfully") : setAddResponce(response.message)
        setOpenAddRole(false);
        let roleId = response.data.role_id;
        let newVar = rolePAddForm;
        newVar.role_id = roleId;
        setRolePAddForm((state) => ({ ...state }));

        submitRoleP();

        dispatch(getRoleBulk(page));
      });
    }
    else {
      setAddBatteryErrors(true);
      setAddResponce("Fill Required Field")
    }

  };
  const setRoleAddFormArray = (e, key) => {
    setRoleAddForm((state) => ({ ...state, [key]: e.target.value }));
  };
  const validateKeyData = (key) => {
    return key ? key : "-";
  };
  const RoleColumn = [
    {
      label: "Role Name",
      name: "role",
      options: {
        filter: true,
        filterList: clear1,
        filterType: 'custom',
        filterOptions: {
          logic: (role_name, filters, row) => {
            if (filters.length) return !filters.includes(role_name);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = RoleList.filter((item,
              index) => RoleList.indexOf(item) === index);
            return (
              <FormControl style={{ width: '200px' }}>
                <InputLabel htmlFor="select-multiple-chip">Role Name</InputLabel>
                <Select

                  multiple
                  value={clear1.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear1(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getRoleLBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Action Button",
      name: "action",
      options: {
        filter: false,
        customBodyRender: (value) => {
          return (
            <>
              <IconButton
                onClick={() => {
                  setOpenEditRole(true);
                  setRoleEditArray(value);
                }}
              >
                <Icon
                  icon="bxs:edit-alt"
                  color="#33a6ff"
                  width="22"
                  height="22"
                />
              </IconButton>
              <IconButton
                onClick={() => {
                  deleteRole(value);
                }}
              >
                <Icon
                  icon="ic:baseline-delete"
                  color="#fa5d41"
                  width="22"
                  height="22"
                />
              </IconButton>

            </>
          );
        },
      },
    },
  ];
  const RoleColumn1 = [
    {
      label: "Role Name",
      name: "role",
      options: {
        filter: true,
        filterList: clear1,
        filterType: 'custom',
        filterOptions: {
          logic: (role_name, filters, row) => {
            if (filters.length) return !filters.includes(role_name);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = RoleList.filter((item,
              index) => RoleList.indexOf(item) === index);
            return (
              <FormControl style={{ width: '200px' }}>
                <InputLabel htmlFor="select-multiple-chip">Role Name</InputLabel>
                <Select

                  multiple
                  value={clear1.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear1(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getRoleLBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },

  ];
  const [editArray, setEditArray] = React.useState({
    rolename: "",

  });
  const setRoleEditFormArray = (e, key) => {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));
  };

  const submitRoleEdit = () => {
    if (editArray.updated_by = UserName) {
      const putRole = endpoints.baseUrl + `/role/edit/` + editArray.role_id;
      axios.put(putRole, editArray).then((response) => {
        const deleteRoleP = endpoints.baseUrl + `/rolepermission/delete/` + editArray.role_id;
        axios
          .delete(deleteRoleP)
          .then((response) => {

            const postRoleP = endpoints.baseUrl + `/rolepermission/add`;
            let newVar = rolePEditForm;
            newVar.role_id = editArray.role_id
            setRolePEditForm((state) => ({ ...state }));
            axios.post(postRoleP, rolePEditForm).then((response) => {
              setAddBatteryErrors(true);
              response.status === 200 ? setAddResponce("Role detail edited successfully") : setAddResponce(response.message)
              dispatch(getRoleBulk(page));
            });
          });
      });
    }
    else {
      setAddBatteryErrors(true);
      setAddResponce("Please fill require fields")
    }


  };
  const setRoleEditArray = (role_id) => {
    let allRole = RoleDataRaw;
    let findArray = allRole.find((el) => el.role_id === role_id);
    const putRole = endpoints.baseUrl + `/rolepermission/get/` + role_id;
    axios.get(putRole).then((response) => {
      // console.log("==========",response);
      let newVar = rolePEditForm;
      newVar.roles = response.data.data.roles
      setRolePEditForm((state) => ({ ...state }));

    });
    setEditArray(findArray);
  };
  const deleteRole = (role_id) => {
    const deleteRole = endpoints.baseUrl + `/role/roleSoftDelete/` + role_id;
    axios.delete(deleteRole).then((response) => {
      setAddBatteryErrors(true);
      response.status === 200 ? setAddResponce("Role offboarding") : setAddResponce(response.message)
      dispatch(getRoleBulk(page));
    });
  };
  const changeRoleP = (check, pageName, perm) => {
    let newVar = rolePAddForm;

    if (check) {
      newVar.roles[pageName].push(perm);
    } else {
      let index = newVar.roles[pageName].indexOf(perm);
      if (index > -1) {
        newVar.roles[pageName].splice(index, 1);
      }
    }
    setRolePAddForm((state) => ({ ...state }));
  };
  const changeRolePEdit = (check, pageName, perm) => {
    let newVar = rolePEditForm;
    if (check) {
      if (newVar.roles[pageName]) {
        newVar.roles[pageName].push(perm);

      } else {
        newVar.roles[pageName] = [];
        newVar.roles[pageName].push(perm);

      }


    } else {
      let index = newVar.roles[pageName].indexOf(perm);
      if (index > -1) {
        newVar.roles[pageName].splice(index, 1);
      }
    }
    setRolePEditForm((state) => ({ ...state }));
  };
  const data = [
    { name: "Nithish", role: "Admin", action: "Edit" },
    { name: "Dinesh", role: "Fleet Manager", action: "Delete" },
    { name: "Boopathi", role: "Operation Manager", action: "Edit" },
    { name: "Dinesh", role: "Vehicle Investor", action: "Delete" },
    { name: "Boopathi", role: "Battery Investor", action: "Edit" },
  ];

  const onDownload = () => {
    const headerRow = ["Role Name"];
    const bodyRows = RoleLMeta.data.length && RoleLMeta.data.map((col) => {
      return [
        col[0]
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }

  const options = {
    filter: true,
    download: false,
    print: false,
    viewColumns: false,
    search: false,
    selectableRows: "none",
    customToolbar: () => {
      if (roleEditAccess === true) {
        return (
          <><Tooltip style={{ flex: 'left', transform: "translateX(-6em)" }} title={"Onboard Role"}><IconButton
            className={classes.IconButton}
            onClick={() => setOpenAddRole(true)}
          >
            <Icon icon="mdi:account-plus" width="26" height="26" hFlip={true} />
          </IconButton></Tooltip>
            <Tooltip style={{ flex: 'left' }} title={"Download CSV"}>
              <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                onDownload()
              }}>
                <CloudDownload />
              </IconButton></Tooltip>
            {clear1 != '' ?
              <Button style={{ width: '100px' }}
                onClick={() => {
                  setDataOn(false)
                  setClear1([])
                  dispatch(getRoleBulk(page));
                }}>RESET</Button> : null}</>

        );
      }
      else (
        <>
          {clear1 != '' ?
            <Button style={{ width: '100px' }}
              onClick={() => {
                setDataOn(false)
                setClear1([])
                dispatch(getRoleBulk(page));
              }}>RESET</Button> : null}</>
      )
    },
  };

  const [frame, setFrame] = React.useState(false);
  // const refreshPage = () => {
  //   window.location.reload(false);
  // };
  // console.log("rolePAddForm", rolePAddForm);
  // console.log("rolePEditForm", rolePEditForm);
  return (
    <div onMouseEnter={() => setFrame(true)} className={classes.table}>
      <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />
      <Paper square className={classes.root} />
      {openEditRole === true ? (
        <>
          <DialogTitle id="responsive-dialog-title">{"Edit Role"}</DialogTitle>
          <Grid container spacing={2}>
            <Grid item xs={12} lg={2}>
              <div style={{ display: "flex" }}>
                <Typography className={classes.tabHelp}>Role Name</Typography>
                &nbsp;
                <Typography style={{ color: "red", fontSize: "20px" }}>
                  *
                </Typography>
              </div>
              <TextField
                onChange={(e) => {
                  setRoleEditFormArray(e, "role_name");
                }}
                size="small"
                id="outlined"
                value={editArray.role_name}
                className={classes.textField}
              />
            </Grid>

            {/* dv */}
            <Grid item xs={12} lg={5} className={classes.tabHelp}>
              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Role Permission</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <Typography>View</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <Typography>Edit</Typography>
                </Grid>
              </Grid>
              <br />

              {/* <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Dashboard</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.dashboard && rolePEditForm.roles.dashboard.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "dashboard", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.dashboard && rolePEditForm.roles.dashboard.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "dashboard", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid> */}

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Live Tracker</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.live_tracker && rolePEditForm.roles.live_tracker.includes(
                          "view"
                        )}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "live_tracker", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.live_tracker && rolePEditForm.roles.live_tracker.includes(
                          "edit"
                        )}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "live_tracker", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Drivers</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.drivers && rolePEditForm.roles.drivers.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "drivers", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.drivers && rolePEditForm.roles.drivers.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "drivers", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Vehicle</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.vehicle && rolePEditForm.roles.vehicle.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "vehicle", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.vehicle && rolePEditForm.roles.vehicle.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "vehicle", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Battery</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.battery && rolePEditForm.roles.battery.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "battery", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.battery && rolePEditForm.roles.battery.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "battery", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Assignment</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.assignment && rolePEditForm.roles.assignment.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "assignment", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.assignment && rolePEditForm.roles.assignment.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "assignment", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>
            </Grid>

            <Grid item xs={12} lg={5} className={classes.tabHelp}>
              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Role Permission</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <Typography>View</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <Typography>Edit</Typography>
                </Grid>
              </Grid>
              <br />
              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Telematics</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.telematics && rolePEditForm.roles.telematics.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "telematics", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.telematics && rolePEditForm.roles.telematics.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "telematics", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Association</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.client && rolePEditForm.roles.client.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "client", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.client && rolePEditForm.roles.client.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "client", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Reports</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.reports && rolePEditForm.roles.reports.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "reports", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.reports && rolePEditForm.roles.reports.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "reports", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Users</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.users && rolePEditForm.roles.users.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "users", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.users && rolePEditForm.roles.users.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "users", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }

                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Role</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.role && rolePEditForm.roles.role.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "role", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.role && rolePEditForm.roles.role.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "role", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Settings</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.settings && rolePEditForm.roles.settings.includes("view")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "settings", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePEditForm.roles.settings && rolePEditForm.roles.settings.includes("edit")}
                        onChange={(e) => {
                          changeRolePEdit(e.target.checked, "settings", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenEditRole(false)}
              color="secondary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                setOpenEditRole(false);
                submitRoleEdit();
              }}
              color="primary"
              autoFocus
            >
              Submit
            </Button>
          </DialogActions>
        </>
      ) : openAddRole === true ? (
        <>
          <DialogTitle id="responsive-dialog-title">{"Add Role"}</DialogTitle>
          <Grid container spacing={2}>
            <Grid item xs={12} lg={2}>
              <div style={{ display: "flex" }}>
                <Typography className={classes.tabHelp}>Role Name</Typography>
                &nbsp;
                <Typography style={{ color: "red", fontSize: "20px" }}>
                  *
                </Typography>
              </div>
              <TextField
                onChange={(e) => {
                  setRoleAddFormArray(e, "role_name");
                }}
                size="small"
                id="outlined"
                placeholder="eg: Admin"
                value={roleAddForm.role_name}
                className={classes.textField}
              />
            </Grid>
            <Grid item xs={12} lg={5} className={classes.tabHelp}>
              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Role Permission</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <Typography>View</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <Typography>Edit</Typography>
                </Grid>
              </Grid>
              <br />

              {/* <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Dashboard</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.dashboard.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "dashboard", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.dashboard.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "dashboard", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid> */}

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Live Tracker</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.live_tracker.includes(
                          "view"
                        )}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "live_tracker", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.live_tracker.includes(
                          "edit"
                        )}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "live_tracker", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Drivers</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.drivers.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "drivers", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.drivers.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "drivers", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Vehicle</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.vehicle.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "vehicle", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.vehicle.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "vehicle", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Battery</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.battery.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "battery", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.battery.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "battery", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Assignment</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.assignment.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "assignment", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.assignment.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "assignment", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>
            </Grid>

            <Grid item xs={12} lg={5} className={classes.tabHelp}>
              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Role Permission</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <Typography>View</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <Typography>Edit</Typography>
                </Grid>
              </Grid>
              <br />
              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Telematics</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.telematics.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "telematics", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.telematics.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "telematics", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Association</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.client.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "client", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.client.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "client", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Reports</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.reports.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "reports", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.reports.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "reports", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Users</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.users.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "users", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.users.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "users", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Role</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.role.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "role", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.role.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "role", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item xs={4} lg={4}>
                  <Typography>Settings</Typography>
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.settings.includes("view")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "settings", "view");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
                <Grid item xs={4} lg={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={rolePAddForm.roles.settings.includes("edit")}
                        onChange={(e) => {
                          changeRoleP(e.target.checked, "settings", "edit");
                        }}
                        icon={
                          <Icon
                            icon="akar-icons:circle-fill"
                            color="#c4c4c4"
                            width="26"
                            height="26"
                          />
                        }
                        checkedIcon={
                          <Icon
                            icon="akar-icons:circle-check-fill"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        }
                      />
                    }
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenAddRole(false)}
              color="secondary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                submitRole();
                submitRoleP();
              }}
              color="primary"
              autoFocus
            >
              Submit
            </Button>
          </DialogActions>
        </>
      ) : RoleMetaPresent === true ? (
        <>
          {RoleFetching === true ?
            <><br /><br /><br /><br /><Box sx={{ display: 'flex', justifyContent: 'space-around' }}>
              <CircularProgress style={{ height: '100px', width: '100px' }} />
            </Box></>
            : <><MUIDataTable
              checkboxSelection={false}
              title="Role"
              data={dataOn === true ? RoleLMeta.data : RoleMeta.data}
              columns={roleEditAccess === true ? RoleColumn : RoleColumn1}
              options={options}
              selectableRows={1}
              selectableRowsHideCheckboxes
            />
              <br />
              <Pagination color="secondary"
                count={MyRoleCount}
                page={page}
                onChange={changePage}
              /></>}
        </>
      ) : RoleFetching ? (
        <Loading />
      ) : RoleResponsecode === 500 ? (
        <ErrorWrap />
      ) : null}
      <br />
      <Typography align="center" className={classes.copyRight}>

        Copyright© 2023 ReVx Energy Pvt.Ltd.
      </Typography>
    </div>
  );
}
