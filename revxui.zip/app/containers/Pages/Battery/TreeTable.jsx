import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
import Collapse from '@material-ui/core/Collapse';
import IconButton from '@material-ui/core/IconButton';
import Grid from '@material-ui/core/Grid';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import { getBatteryViewBulk } from '../../../redux/actions/asyncActions';
import { useDispatch, useSelector } from 'react-redux';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';

import './styles.css';


const useRowStyles = makeStyles({
  root: {
    '& > *': {
      borderBottom: 'unset', fontSize: '14px', fontWeight: 600, border: '1px solid #68A72450 !important'
    },
  },
  style: {
    fontSize: '14px', fontWeight: 600, width: '200px'
  }
});

function createData(name) {
  return {
    name,
    view: [
      { dkey: 'Cell Voltage', dvalue: '38.0 V' },
      { dkey: 'Cell Voltage', dvalue: '38.0 V' },
    ],
  };
}

function Row(props) {
  const { row } = props;
  const [open, setOpen] = React.useState(false);
  const classes = useRowStyles();

  return (



    <React.Fragment>
      <TableRow  onClick={() => setOpen(!open)}>
        <TableCell style={{border : '1px solid #fff'}}>
          <IconButton aria-label="expand row" size="small" >
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell component="th" scope="row" align="left" style={{
          fontWeight: 600, color: '#68A724', border : '1px solid #fff'
        }} >
          {"Systems"}
        </TableCell>
      </TableRow>
      <TableRow >
        <TableCell style={{ paddingBottom: 0, paddingTop: 0, border : '1px solid #fff' }} colSpan={6}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box margin={1}>
              <Table size="small" aria-label="purchases">

                <TableBody>
                  {
                    row && row.map((rows) => {
                      if (rows !== null && isNaN(rows.name)) {
                        return (
                          <TableRow key={rows.name} className={classes.root}>


                            <Grid container>
                              <Grid item xs={12} lg={6} style={{ borderRight: '1px solid #68A72450', fontSize: '14px', fontWeight: 600 }}>
                                <Grid container>
                                  <Grid item xs={12} lg={4}></Grid>
                                  <Grid item xs={12} lg={4}>
                                    <TableCell style={{
                                      fontWeight: 600, border : '1px solid #fff'
                                    }}
                                      component="th" scope="row" >
                                      {
                                      rows.name === 'Battery Level' ? "TU Battery SOC" :
                                      rows.name}
                                    </TableCell></Grid>
                                  <Grid item xs={12} lg={4}></Grid></Grid></Grid>
                              <Grid item xs={12} lg={1}></Grid>
                              <Grid item xs={12} lg={5}>
                                <TableCell
                                  component="th" scope="row"
                                  style={{
                                    fontWeight: 600, color: '#68A724', border : '1px solid #fff'
                                  }}>{rows.value}
                                  { rows.name === 'Battery Level' ? "%" : null }</TableCell>
                              </Grid>


                            </Grid>




                          </TableRow>)
                      }
                    })
                  }


                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}
function RowArray(props) {
  const { row, name } = props;
  const [open, setOpen] = React.useState(false);
  const classes = useRowStyles();
  let sortedcellVoltage = row && row.sort(function(a, b) {
    return a.name.replace ( /[^\d.]/g, '' ) - b.name.replace ( /[^\d.]/g, '' );;
  });
  
  
  return (



    <React.Fragment>
      <TableRow buttonBase onClick={() => setOpen(!open)}  >
        <TableCell  style={{border : '1px solid #fff'}}>
          <IconButton aria-label="expand row" size="small" onClick={() => setOpen(!open)}>
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell component="th" scope="row" align="left" style={{
          fontWeight: 600, color: '#68A724', border : '1px solid #fff'
        }}>
          {name}
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0, border : '1px solid #fff' }} colSpan={6}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box margin={1}>
              <Table size="small" aria-label="purchases">

                <TableBody>
                  {
                    sortedcellVoltage && sortedcellVoltage.map((one) => {
                      return (
                        <TableRow key={one.name} className={classes.root}>
                          <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>

                            <Grid container>
                              <Grid item xs={12} lg={6} style={{ borderRight: '1px solid #68A72450', fontSize: '14px', fontWeight: 600 }}>
                                <Grid container>
                                  <Grid item xs={12} lg={4}></Grid>
                                  <Grid item xs={12} lg={4}>
                                    <TableCell
                                      component="th" scope="row"
                                      style={{
                                        fontWeight: 600, border : '1px solid #fff'
                                      }}
                                    >
                                      {one.name}
                                    </TableCell></Grid>
                                  <Grid item xs={12} lg={4}></Grid></Grid></Grid>
                              <Grid item xs={12} lg={1}></Grid>
                              <Grid item xs={12} lg={5}>
                                <TableCell
                                  component="th" scope="row" style={{
                                    fontWeight: 600, color: '#68A724', border : '1px solid #fff'
                                  }}
                                >{one.value}{name === "Cell Temperature" ? "ºC" : null}</TableCell>
                              </Grid>


                            </Grid>


                          </div>
                        </TableRow>
                      )
                    })
                  }


                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}
Row.propTypes = {
  row: PropTypes.shape({
    view: PropTypes.arrayOf(
      PropTypes.shape({
        dvalue: PropTypes.string.isRequired,
        dkey: PropTypes.string.isRequired,
      }),
    ).isRequired,
    name: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    protein: PropTypes.number.isRequired,
  }).isRequired,
};

const rows = [
  createData('Cell Voltage'),
  createData('Cell Temperature'),
  createData('Battery Current'),
  createData('Battery Level'),
  createData('Battery Voltage'),
];

export default function CollapsibleTable(props) {
  const { imei } = props;
  const classes = useRowStyles();

  const BatteryViewData = useSelector((store) => store.batteryView)
  const BatteryViewPresent = useSelector((store) => store.batteryView.dataPresent)
  const BatteryViewDataRaw = useSelector((store) => store.batteryView.rawData)
  const dispatch = useDispatch();
  React.useEffect(() => {
    dispatch(getBatteryViewBulk(imei));
  }, [dispatch, BatteryViewPresent]);
  let BatteryViewMeta = [];
  BatteryViewMeta[22] = [];
  BatteryViewMeta[22]['created_at'] = '';
  // if (BatteryViewPresent) {

  let BatteryViewMetaa = useSelector((store) => store.batteryView.data)

  if (BatteryViewMetaa.length >= 1) {
    BatteryViewMeta = BatteryViewMetaa;
  }
  if (typeof BatteryViewMeta[22] == "undefined") {
    BatteryViewMeta[22] = [];
    BatteryViewMeta[22]['created_at'] = '';
  }
  let BatteryViewFetching = useSelector((store) => store.batteryView.fetching)
  let BatteryViewResponsecode = useSelector((store) => store.batteryView.responseStatus)
  let BatteryViewMetaPresent = useSelector((store) => store.batteryView.dataPresent)


  let BatteryData = BatteryViewMeta;
  let singleArrays = BatteryData && BatteryData.map((el) => {
    return el && !el.name ? null : (el)
  })
  if(BatteryData){ 
  return (
    <TableContainer component={Paper}>
      <Table aria-label="collapsible table">
        <TableHead>
          <TableRow >
            <TableCell  style={{border : '1px solid #fff'}}/>
            {/* <TableCell align="left">Parameters</TableCell> */}
            {/* <TableCell align="left">Timestamp - {BatteryViewMeta[22]["created_at"]}</TableCell> */}
          </TableRow>
        </TableHead>
        <TableBody align="center">

          {BatteryData.map((row) => (
            row && row.name ? null :
            row && row.cell_temperature && row.cell_temperature ? <RowArray name="Cell Temperature" className={classes.root} row={row.cell_temperature} /> : row  && row.cell_voltage ? <RowArray className={classes.root} name="Cell Voltage" row={row && row.cell_voltage} /> : null
          ))}
          <Row row={singleArrays && singleArrays} />
        </TableBody>
      </Table>
    </TableContainer>
  );
          
  } else {
    return (<Loading />)
  }
}
