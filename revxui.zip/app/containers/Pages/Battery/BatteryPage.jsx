import React, { useState } from 'react';
import axios from 'axios';
import { withStyles, makeStyles, useTheme, styled, alpha, darken } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import LinearProgress from '@material-ui/core/LinearProgress';
import Chip from '@material-ui/core/Chip';
import MUIDataTable from 'mui-datatables';
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import Grid from '@material-ui/core/Grid';
import Switch from '@material-ui/core/Switch';
import Typography from '@material-ui/core/Typography';
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import Tooltip from '@material-ui/core/Tooltip';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import TabIcon from '@material-ui/icons/Tab';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import BatteryCharging30Icon from '@material-ui/icons/BatteryCharging30';
import endpoints from '../../../endpoints/endpoints';
import Divider from '@material-ui/core/Divider';
import SimpleSnackbar from '../Users/SimpleSnackbar';
// import LinearProgress from '@material-ui/core/LinearProgress';
import './styles.css';
import AcUnit from '@material-ui/icons/AcUnit';
import Adb from '@material-ui/icons/Adb';
import AllInclusive from '@material-ui/icons/AllInclusive';
import AssistantPhoto from '@material-ui/icons/AssistantPhoto';
import AppBar from '@material-ui/core/AppBar';
import PhotoLibrary from '@material-ui/icons/PhotoLibrary';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import FormControl from '@material-ui/core/FormControl';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import SimpleMap from "./SimpleMap";
import SimpleMap2 from "./SimpleMap2";
import TreeTable from "./TreeTable";
import Pagination from '@material-ui/lab/Pagination';
import Generic from '../Analytic/Generic';
import Mobility from './imgs/mobility.svg';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
    GetBBBulk, getBatteryTotal,
    getMyBatteryBulk, getBatteryModelBulk, getBatteryModelLBulk, getBatteryProBulk, getBMSBulk, getBMSLBulk,
    getIV2Bulk, getOMBulk, getFleetBulk, getBVABulk, getTeleModelBulk, getBDashboardBulk
} from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';
import clearMyBattery from '../../../redux/actions/normalActions';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import nodata from './imgs/nodata.jpg';
import { CircularProgress, StepButton } from "@material-ui/core";
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import BatteryCurrent from './current-time';
import BatteryVoltage from './voltage-time';
import CellVolt from './cell-voltage-time';
import CellTemp from './cell-temperature-time';
import { CloudDownload } from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
    tableborder: { display: 'none' },
    root: {
        margin: 10
    },
    textField: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
        'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    dialogPaper: {
        height: "85%",
        width: "50%",
        marginLeft: '700px'
    },
    table: {

        '& > div': {

            '& > .MuiToolbar-regular': {
                backgroundColor: '#68A72480  !important',
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0
            },
            // overflow: 'auto',
            // textAlign:'center'
        },

        '& table': {
            '& td': {
                wordBreak: 'keep-all',
                textAlign: 'center'
            },

            [theme.breakpoints.down('md')]: {
                '& td': {
                    height: 60,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                },
                '& tr:nth-child(odd)': {
                    backgroundColor: '#cfcfcf40'
                },
                '& tr:nth-child(even)': {
                    backgroundColor: '#cfcfcf20'
                },
            }
        }
    },
    graphText: {
        fontSize: 12,
        position: 'absolute',
        transform: 'rotate(270deg)',
        left: '-40px',
        top: 370,
        color: 'primary',
        fontWeight: 600
    },
    graphSelect: {
        minWidth: 150, left: '20em', marginBottom: 20
    },
    tabsSection: {
        [theme.breakpoints.up('lg')]: {
            // borderRadius:0,position:'sticky',top:0 ,width:500
            borderRadius: 0, top: 0, width: 500

        },
    },
    tabsSectionrr: {
        [theme.breakpoints.up('lg')]: {
            // borderRadius:0,position:'sticky',top:0 ,width:500
            borderRadius: 0, top: 0, width: 150

        },
    },
    primaryText: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
    }, primaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '300px'
    },
    secondaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '12px', fontWeight: 600, color: '#68A724', width: '100%'
    },
    voltageG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724'
    },
    voltageY: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FFBF00'
    },
    voltageR: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FF0000'
    },
    chart1: {
        marginLeft: '-20px', width: '120px', height: '50px', '.MuiPaper-root .MuiMenu-paper .MuiPopover-paper': { width: '120px !important' }
    },
    copyRight: {
        position: 'absolute', bottom: 0, right: 0, left: 0, fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    dialog: {
        // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
        position: 'relative', marginLeft: '680px'
    },
    healthy: {
        color: '#82E219', width: '5rem', fontSize: '20px'
    },
    Unhealthy: {
        color: '#FFFF00'
    },
    chart: {
        padding: theme.spacing(2)
    },
    dataView: {
        height: '300px',
    },
    BNavatar: { height: '56px', width: '56px', border: '1px solid #fff', backgroundColor: "#77b93e" },
    BNavatar1: { backgroundColor: '#f3efef' },
    BNgrid: { marginLeft: 20 },
    BNprimaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary', width: '200px',
    },
    BNstateText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '18px', fontWeight: 500, color: '#fff', width: '250px',
    },
    BNsecondaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary',
    },
    BNsecondaryTextG: { color: '#00FF00' },
    BNsecondaryText1: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary', width: '150px',
    },
    BNIcon: {
        marginRight: 10, marginTop: 10
    },
    BNtitle: {},
    BNsubtitle: {},

    BNchip: { backgroundColor: '#4caf50b5' },
    BNchip2: { backgroundColor: '#FFBF00' },
    BNchip3: { backgroundColor: '#FF0000' },
    BNstyledPaper: {
        backgroundColor: '#a2c97d',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper2: {
        backgroundColor: '#FFBF00',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper3: {
        backgroundColor: '#FF0000',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNprogressWidget: {
        marginTop: 20,
        background: theme.palette.secondary.dark,
        '& div': {
            background: theme.palette.primary.light,
        }
    },
    BNmap: {
        height: 323, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    BNcover: {
        '& $name, & $subheading': {
            color: theme.palette.common.white
        },
        position: 'relative',
        width: '100%',
        overflow: 'hidden',
        height: 200,
        backgroundColor: "#77b93e"
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        ,
        // backgroundColor:
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        // ,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundSize: 'cover',
        textAlign: 'center',
        boxShadow: theme.shadows[7],
        backgroundPosition: 'bottom center',
        borderRadius: '10px 10px 0px 0px',
    },
    BNname: {
        fontSize: '20px', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400, color: '#fff'
    },
    BNopt: {
        position: 'absolute',
        top: 0,
        right: 10,
        '& button': {
            color: theme.palette.common.white
        }
    },
    BNprofileTab: {
        marginTop: 0,
        [theme.breakpoints.down('sm')]: {
            marginTop: 0,
        },
        borderRadius: '0px 0px 10px 10px',
        background:
            // alpha(theme.palette.background.paper, 0.8)
            "#dcead7",
        position: 'relative'
    },
    BNaboutTxt: {
        fontSize: '16px', fontWeight: 600, color: '#000000'
    },

    BNaboutTxt1: {
        fontSize: '14px', fontWeight: 400, color: '#000000'
    },
    BNdriving: {
        color: '#82E219', marginLeft: '-90px'
    },
    BNdrivingR: {
        color: '#ff0000', marginLeft: '-90px'
    },
    BNorangeAvatar: {
        backgroundColor: '#ff5722',
    },
    BNpurpleAvatar: {
        backgroundColor: '#673ab7',
    },
    BNpinkAvatar: {
        backgroundColor: '#e91e63',
    },
    BNgreenAvatar: {
        backgroundColor: '#4caf50',
    },
    BNdivider: {
        width: '92%', marginLeft: '20px'
    },
    addTab: { backgroundColor: '#b3d391', color: "#fff" },
    pageTitle: {
        textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600
    }
}));
function TabContainer(props) {
    const { children } = props;
    return (
        <div style={{ paddingTop: 8 * 3 }}>
            {children}
        </div>
    );
}

TabContainer.propTypes = {
    children: PropTypes.node.isRequired,
};


export default function BatteryPage() {
    function Alert(props) {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
    }
    const BBData = useSelector((store) => store.bbAll)
    const BBDataRaw = useSelector((store) => store.bbAll.rawData)
    let BBMeta = useSelector((store) => store.bbAll)
    let BBFetching = useSelector((store) => store.bbAll.fetching)
    let BBResponsecode = useSelector((store) => store.bbAll.responseStatus)
    let BBMetaPresent = useSelector((store) => store.bbAll.dataPresent)

    const MyBatteryData = useSelector((store) => store.myBattery)
    const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
    const MyBatteryPage = useSelector((store) => store.myBattery.page_number)
    const MyBatteryPageCount = Math.ceil(useSelector((store) => store.myBattery.total_records) / 10)
    //   let MyBatteryMeta = useSelector((store) => store.myBattery)
    // let MyBatteryMeta =  getBatteryModelBulk()
    let MyBatteryMeta = {};
    MyBatteryMeta.data = [];
    let MyBatteryMetaa = useSelector((store) => store.myBattery)
    if (MyBatteryMetaa.data.length >= 1) {
        MyBatteryMeta.data = MyBatteryMetaa.data;
    }
    let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
    let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
    let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)

    const BatteryTotalData = useSelector((store) => store.batteryTotal)
    const BatteryTotalDataRaw = useSelector((store) => store.batteryTotal.rawData)
    let BatteryTotalMeta = {};
    BatteryTotalMeta.data = [];
    let BatteryTotalMetaa = useSelector((store) => store.batteryTotal)
    if (BatteryTotalMetaa.data.length >= 1) {
        BatteryTotalMeta.data = BatteryTotalMetaa.data;
    }
    let BatteryTotalFetching = useSelector((store) => store.batteryTotal.fetching)
    let BatteryTotalResponsecode = useSelector((store) => store.batteryTotal.responseStatus)
    let BatteryTotalMetaPresent = useSelector((store) => store.batteryTotal.dataPresent)


    let SerialNumber = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[0]; });
    let BatteryModel = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[1]; });
    let BatteryInvestor = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[2]; });
    let BatteryOperation = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[3]; });
    let BatteryVehicleNumber = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[4]; });
    let BatteryIdle = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[5]; });
    let BatteryVehicleStatus = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[6]; });
    let BatteryStatus = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[7]; });
    let BatteryBMS = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[8]; });
    let BatterySW = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[9]; });
    let BatteryIMEI = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[10]; });
    let BatteryType = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[11]; });
    let TelematicsStatus = BatteryTotalMeta.data && BatteryTotalMeta.data.map(function (el) { return el[12]; });

    const BatteryProData = useSelector((store) => store.batteryPro)
    const BatteryProRaw = useSelector((store) => store.batteryPro.rawData)
    let BatteryProMeta = useSelector((store) => store.batteryPro)
    let BatteryProFetching = useSelector((store) => store.batteryPro.fetching)
    let BatteryProResponsecode = useSelector((store) => store.batteryPro.responseStatus)
    let BatteryProMetaPresent = useSelector((store) => store.batteryPro.dataPresent)

    const BDashboardData = useSelector((store) => store.batteryDash)
    const BDashboardRaw = useSelector((store) => store.batteryDash.rawData)
    let BDashboardMeta = useSelector((store) => store.batteryDash)
    let BDashboardFetching = useSelector((store) => store.batteryDash.fetching)
    let BDashboardResponsecode = useSelector((store) => store.batteryDash.responseStatus)
    let BDashboardMetaPresent = useSelector((store) => store.batteryDash.dataPresent)
    // console.log("BDashboardMetaBDashboardMeta", BDashboardMeta)
    const BatteryModelData = useSelector((store) => store.batteryModel)
    const MyBatteryMPage = useSelector((store) => store.batteryModel.page_number)
    const MyBatteryPageMCount = Math.ceil(useSelector((store) => store.batteryModel.total_records) / 10)

    const BatteryModelDataRaw = useSelector((store) => store.batteryModel.rawData)
    let BatteryModelMeta = useSelector((store) => store.batteryModel)
    let BatteryModelFetching = useSelector((store) => store.batteryModel.fetching)
    let BatteryModelResponsecode = useSelector((store) => store.batteryModel.responseStatus)
    let BatteryModelMetaPresent = useSelector((store) => store.batteryModel.dataPresent)

    const BatteryModelLData = useSelector((store) => store.batteryModell)
    const BatteryModelLDataRaw = useSelector((store) => store.batteryModell.rawData)
    let BatteryModelLMeta = useSelector((store) => store.batteryModell)
    let BatteryModelLFetching = useSelector((store) => store.batteryModell.fetching)
    let BatteryModelLResponsecode = useSelector((store) => store.batteryModell.responseStatus)
    let BatteryModelLMetaPresent = useSelector((store) => store.batteryModell.dataPresent)

    const BMSData = useSelector((store) => store.bmsAll)
    const BMSDataRaw = useSelector((store) => store.bmsAll.rawData)
    const MyBatteryBMPage = useSelector((store) => store.bmsAll.page_number)
    const MyBatteryPageBMCount = Math.ceil(useSelector((store) => store.bmsAll.total_records) / 10)
    let BMSMeta = useSelector((store) => store.bmsAll)
    let BMSFetching = useSelector((store) => store.bmsAll.fetching)
    let BMSResponsecode = useSelector((store) => store.bmsAll.responseStatus)
    let BMSMetaPresent = useSelector((store) => store.bmsAll.dataPresent)

    const BMSLData = useSelector((store) => store.bmslAll)
    const BMSLDataRaw = useSelector((store) => store.bmslAll.rawData)
    let BMSLMeta = useSelector((store) => store.bmslAll)
    let BMSLFetching = useSelector((store) => store.bmslAll.fetching)
    let BMSLResponsecode = useSelector((store) => store.bmslAll.responseStatus)
    let BMSLMetaPresent = useSelector((store) => store.bmslAll.dataPresent)

    const IV2Data = useSelector((store) => store.iv2All)
    const IV2DataRaw = useSelector((store) => store.iv2All.rawData)
    let IV2Meta = useSelector((store) => store.iv2All)
    let IV2Fetching = useSelector((store) => store.iv2All.fetching)
    let IV2Responsecode = useSelector((store) => store.iv2All.responseStatus)
    let IV2MetaPresent = useSelector((store) => store.iv2All.dataPresent)
    //  Operation
    const OMData = useSelector((store) => store.omAll)
    const OMDataRaw = useSelector((store) => store.omAll.rawData)
    let OMMeta = useSelector((store) => store.omAll.data)
    let OMFetching = useSelector((store) => store.omAll.fetching)
    let OMResponsecode = useSelector((store) => store.omAll.responseStatus)
    let OMMetaPresent = useSelector((store) => store.omAll.dataPresent)


    //Fleet
    const FleetData = useSelector((store) => store.fleetAll)
    const FleetDataRaw = useSelector((store) => store.fleetAll.rawData)

    let FleetMeta = useSelector((store) => store.fleetAll)
    let FleetFetching = useSelector((store) => store.fleetAll.fetching)
    let FleetResponsecode = useSelector((store) => store.fleetAll.responseStatus)
    let FleetMetaPresent = useSelector((store) => store.fleetAll.dataPresent)

    //Vehicle Assign
    const BVAData = useSelector((store) => store.bvaAll)
    const BVADataRaw = useSelector((store) => store.bvaAll.rawData)
    let BVAMeta = useSelector((store) => store.bvaAll)
    let BVAFetching = useSelector((store) => store.bvaAll.fetching)
    let BVAResponsecode = useSelector((store) => store.bvaAll.responseStatus)
    let BVAMetaPresent = useSelector((store) => store.bvaAll.dataPresent)

    //Telematics Model
    const TeleModelData = useSelector((store) => store.teleModelAll)
    const TeleModelDataRaw = useSelector((store) => store.teleModelAll.rawData)
    let TeleModelMeta = useSelector((store) => store.teleModelAll)
    let TeleModelFetching = useSelector((store) => store.teleModelAll.fetching)
    let TeleModelResponsecode = useSelector((store) => store.teleModelAll.responseStatus)
    let TeleModelMetaPresent = useSelector((store) => store.teleModelAll.dataPresent)
    const logged_user = useSelector((store) => store.login.result);
    // console.log(logged_user)
    let enty1 = logged_user.entity_id === "1"
    let enty = logged_user.entity_id
    let UserIdd = logged_user.user_id
    let uName = logged_user.username
    let pWord = logged_user.password
    let roid = logged_user.role_id
    let batteryEditAccess = logged_user.battery === "edit"
    const dispatch = useDispatch();
    const [batPage, setBatPage] = React.useState(1);
    const [modelPage, setModelPage] = React.useState(1);
    const [bmsPage, setBmsPage] = React.useState(1);
    const changePageBat = (event, newValue) => {
        //MyBatteryPage
        // console.log("newValue",newValue)
        setBatPage(newValue);
    };
    const changePageBatModel = (event, newValue) => {
        setModelPage(newValue);
    };
    const changePageBMS = (event, newValue) => {
        setBmsPage(newValue);
    };

    let batteryPageNum = 0;
    const [openEditModel, setOpenEditModel] = React.useState(false);
    const [openEditBattery, setOpenEditBattery] = React.useState(false);
    const [zoomVar, setZoomVar] = React.useState(0);

    const theme = useTheme();
    const classes = useStyles();
    const [screen, setScreen] = React.useState(false);
    const [batDashboard, setBatDashboard] = React.useState(false);
    const [idleMode, setIdleMode] = React.useState(false);
    const [openAddBattery, setOpenAddBattery] = React.useState(false);
    const [openAddModel, setOpenAddModel] = React.useState(false);
    const [openAddBMS, setOpenAddBMS] = React.useState(false);
    const [openEditBMS, setOpenEditBMS] = React.useState(false);
    const [openVehicleActive, setOpenVehicleActive] = React.useState(false);
    const [openBatteryActive, setOpenBatteryActive] = React.useState(false);
    const [notificationTimeOut, setNotificationTimeOut] = React.useState(3000)

    const [openDeActiveV, setOpenDeActiveV] = React.useState(false);
    const [openDeActiveB, setOpenDeActiveB] = React.useState(false);

    const [dataOn, setDataOn] = React.useState(false);
    const [dataOnD, setDataOnD] = React.useState(false);
    const [pro, setPro] = React.useState(false);

    const [openPass, setOpenPass] = React.useState(false);
    const [openOn, setOpenOn] = React.useState(false);
    const [openOff, setOpenOff] = React.useState(false);


    const [open, setOpen] = React.useState(false);
    const [ddd, setDdd] = React.useState(false);

    const handleClick = () => {
        setOpen(true);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };
    const [open1, setOpen1] = React.useState(false);
    const [ddd1, setDdd1] = React.useState(false);

    const handleClick1 = () => {
        setOpen1(true);
    };

    const handleClose1 = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen1(false);
    };
    const [open2, setOpen2] = React.useState(false);
    const [ddd2, setDdd2] = React.useState(false);

    const handleClick2 = () => {
        setOpen2(true);
    };

    const handleClose2 = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen2(false);
    };
    const [open3, setOpen3] = React.useState(false);
    const [ddd3, setDdd3] = React.useState("");

    const handleClick3 = () => {
        setOpen3(true);
    };

    const handleClose3 = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen3(false);
    };
    const [open4, setOpen4] = React.useState(false);
    const [ddd4, setDdd4] = React.useState("");

    const handleClick4 = () => {
        setOpen4(true);
    };

    const handleClose4 = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen4(false);
    };


    const [getImei, setGetImei] = React.useState({});
    React.useEffect(() => {
        const get = endpoints.baseUrl + `/telematics/assign/get`;
        const cinemaCatGet = axios
            .get(get)
            .then((response) => {
                setGetImei(response.data.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);

    const [openTele, setOpenTele] = React.useState(false);
    const [openTeleD, setOpenTeleD] = React.useState(false);
    const [assetLink, setAssetLink] = React.useState(0);

    const [password1, setPassword1] = React.useState("");
    const [password2, setPassword2] = React.useState("");
    const [password3, setPassword3] = React.useState("");
    const [delete1, setDelete1] = React.useState("");
    const [delete2, setDelete2] = React.useState("");
    const [delete3, setDelete3] = React.useState("");
    const [selectedId1, setSelectedId1] = React.useState("");
    const [selectedId2, setSelectedId2] = React.useState("");
    const [selectedId3, setSelectedId3] = React.useState("");

    const [idleOn, setIdleOn] = React.useState({
        status: "true",
        imei: ""
    })

    const On = () => {
        if (idleOn.status && idleOn.imei) {
            const postOn = endpoints.baseUrl + `/battery/onoff`;

            axios
                .post(postOn, idleOn)
                .then((response) => {

                    handleClick3(true);
                    response.status === 200 ? setDdd3("Idle on") : setDdd3(response.message)
                    // dispatch(getMyBatteryBulk(enty, batPage));

                }).catch((err) => {
                    handleClick4(true);
                    setDdd4("connection error.")

                });
            setOpenOn(false)

        }
        else {
            handleClick4(true);
            setDdd4("Something went wrong..")

        }

    }

    const [idleOff, setIdleOff] = React.useState({
        status: "false",
        imei: ""
    })

    const Off = () => {

        if (idleOff.status && idleOff.imei) {
            const postOff = endpoints.baseUrl + `/battery/onoff`;

            axios
                .post(postOff, idleOff)
                .then((response) => {
                    handleClick3(true);
                    response.status === 200 ? setDdd3("Idle off") : setDdd3(response.message)
                    // dispatch(getMyBatteryBulk(enty, batPage));
                }).catch((err) => {
                    handleClick4(true);
                    setDdd4("connection error.")

                });
            setOpenOff(false)

        } else {
            handleClick4(true);
            setDdd4("Something went wrong..")

        }

    }

    const [assignVech, setAssignVech] = React.useState({
        vehicle_id: "",
        battery_id: ""
    })

    const assVehicle = () => {

        if (assignVech.vehicle_id && assignVech.battery_id) {
            const postVeh = endpoints.baseUrl + `/battery/vehicle/add`;

            axios
                .post(postVeh, assignVech)
                .then((response) => {
                    handleClick3(true);
                    response.status === 200 ? setDdd3("Vehicle assigned successfully!") : setDdd3(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                    dispatch(getBVABulk());
                    dispatch(getTeleModelBulk());
                });
            setOpenVehicleActive(false)

        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }
    const [assignBat, setAssignBat] = React.useState({
        battery_status: "enabled"
    })

    const assBat = () => {

        if (assignBat.battery_status) {
            const putBat = endpoints.baseUrl + `/battery/status/` + bid;

            axios
                .put(putBat, assignBat)
                .then((response) => {
                    handleClick3(true);
                    response.status === 200 ? setDdd3("Battery enabled") : setDdd3(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                    dispatch(getBVABulk());
                    dispatch(getTeleModelBulk());
                });
            setOpenBatteryActive(false)

        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }

    const [assignDBat, setAssignDBat] = React.useState({
        battery_status: "disabled"
    })

    const assBatD = () => {

        if (assignDBat.battery_status) {
            const putBatD = endpoints.baseUrl + `/battery/status/` + bid;

            axios
                .put(putBatD, assignDBat)
                .then((response) => {
                    handleClick3(true);
                    response.status === 200 ? setDdd3("Battery disbled") : setDdd3(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                    dispatch(getBVABulk());
                    dispatch(getTeleModelBulk());
                });
            setOpenDeActiveB(false)

        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }

    const [modelAddForm, setModelAddForm] = React.useState(
        {
            model_info: "",
            nominal_voltage: "",
            capacity_mah: "",
            power: "",
            cell_maufacturer: "",
            oem: "",
            number_of_cells_series: "",
            number_of_cells_parallel: "",
            cell_chemisty: "",
            cell_type: "",
            length: "",
            width: "",
            height: "",
            thermistor: "",
            battery_type: "",
            created_by: uName,
            updated_by: uName
            // bms_model_id:""

        }
    )
    const [batteryAddForm, setBatteryAddForm] = React.useState(
        {
            serial_number: "",
            created_by: uName,
            updated_by: "",
            bms_unique_id: "",
            battery_model_id: "",
            sw_version: "",
            bms_model_id: "",
            asset: {
                asset_type: "battery",
                entity_id: "",
                created_by: uName,
                updated_by: ""
            },
            investors: {
                asset_type: "battery",
                entity_id: enty,
                user_id: "0",
                created_by: uName,
                updated_by: ""
            },
            user: {
                asset_type: "battery",
                entity_id: enty,
                user_id: "0",
                created_by: uName,
                updated_by: ""
            },
            telematics: {
                telematics_data_id: "",
                imei: "",
                sim_operator: "",
                mobile_number: "",
                dbc_file_type: "",
                created_by: uName,
                updated_by: ""
            }
        }
    )
    const submitBattery = () => {

        if (batteryAddForm.battery_model_id && batteryAddForm.serial_number) {
            const postBattery = endpoints.baseUrl + `/battery/post`;
            axios
                .post(postBattery, batteryAddForm)
                .then((response) => {
                    handleClick3(true);
                    response.status === 201 ? setDdd3("Battery onboarded successfully!") : setDdd3(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                    setOpenAddBattery(false)
                    setBatteryAddForm({})
                    handleReset()
                });

        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }
    const setBatteryAddFormArray = (e, key, array) => {
        if (array) {
            setBatteryAddForm((state) => ({
                ...state, [array]: {
                    ...state[array],
                    [key]: e.target.value
                }
            }));
        } else {
            setBatteryAddForm((state) => ({ ...state, [key]: e.target.value }));

        }

    }

    const [editBatArray, setEditBatArray] = React.useState(
        {}
    )
    const deleteBattery = (bms_id) => {
        const deleteB = endpoints.baseUrl + `/battery/softdelete/` + bms_id;
        axios
            .delete(deleteB)
            .then((response) => {
                handleClick3(true);
                response.status === 200 ? setDdd3("Battery offboarded successfully!") : setDdd3(response.message)
                setDelete1(false)
                setPassword1()
                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
            });
    }
    const [bmsAddForm, setBmsAddForm] = React.useState(
        {
            model_info: "",
            hw_version: "",
            oem: "",
            created_by: uName,
            updated_by: ""
        }
    )
    const [editBMSArray, setEditBMSArray] = React.useState(
        {}
    )
    const submitBMS = () => {

        if (bmsAddForm.model_info && bmsAddForm.hw_version && bmsAddForm.oem) {
            const postBMS = endpoints.baseUrl + `/battery/bms/add`;
            axios
                .post(postBMS, bmsAddForm)
                .then((response) => {
                    handleClick3(true);
                    response.status === 201 ? setDdd3("BMS onboarded successfully!") : null
                    dispatch(getBMSBulk(bmsPage));
                    setOpenAddBMS(false)
                    setBmsAddForm({})
                }).catch((err) => {
                    setAddResponce("This details already exists")
                });


        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }
    const setBMSAddFormArray = (e, key) => {
        setBmsAddForm((state) => ({ ...state, [key]: e.target.value }));

    }

    const setEditBmsFormArray = (e, key) => {
        setEditBMSArray((state) => ({ ...state, [key]: e.target.value }));

    }


    const submitEditBMS = () => {
        if (editBMSArray.model_info && editBMSArray.hw_version && editBMSArray.oem && (editBMSArray.updated_by = uName)) {
            const putBMS = endpoints.baseUrl + `/battery/bms/edit/` + editBMSArray.bms_model_id;
            let newEditBMSArray = editBMSArray;
            axios
                .put(putBMS, newEditBMSArray)
                .then((response) => {
                    handleClick3(true);
                    response.status === 200 ? setDdd3("Battery details edited successfully!") : setDdd3(response.message)
                    dispatch(getBMSBulk(bmsPage));
                    setOpenEditBMS(false)
                    setEditBMSArray({})
                });
            setOpenEditBMS(false)

        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }

    const setEditBMSSArray = (bms_model_id) => {

        let allBMS = BMSDataRaw;
        let findEditBMSArray = allBMS.find(el => el.bms_model_id === bms_model_id);
        setEditBMSArray(findEditBMSArray);
    }
    const deleteBMS = (bms_model_id) => {
        const deleteBMSM = endpoints.baseUrl + `/battery/bms/delete/` + bms_model_id;
        axios
            .delete(deleteBMSM)
            .then((response) => {
                handleClick3(true);
                response.status === 200 ? setDdd3("BMS model offboarded successfully!") : setDdd3(response.message)
                setDelete3(false)
                setPassword3();
                dispatch(getBMSBulk(bmsPage))
            });
    }
    const [value, setValue] = React.useState(0);
    const [bmsmodel, setBmsmodel] = React.useState(0);
    const [bmsid, setBmsId] = React.useState(0);
    const [bid, setBId] = React.useState(0);
    const [imei, setImei] = React.useState(0);
    const [serial, setSerial] = React.useState(0);
    const [vn, setVn] = React.useState(0);
    const [vehBatID, setVehBatID] = React.useState(0);
    const [model, setModel] = React.useState(0);

    const [tableMode, setTableMode] = React.useState("ericksaw");


    const [csvDownload, setCsvDownload] = React.useState(1);
    const [chartOneVal, setChartOneVal] = React.useState("day");

    const [onOffPassword, setOnOffPassword] = React.useState("")
    const [onOffPassword1, setOnOffPassword1] = React.useState("")
    const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
    const [addResponse, setAddResponce] = React.useState("")


    const [editArray, setEditArray] = React.useState({

    })
    const [state, setState] = React.useState({
        checkedA: false,
    });
    const [state1, setState1] = React.useState({
        checkedB: false,
    });
    const [cacheBuster, setCacheBuster] = useState(Date.now());
    const clearCache = () => {
        setCacheBuster(Date.now());
        console.log("clearCacheclearCache",Date)
      };
       React.useEffect(() => {
        setEditArray(modelPage ? modelPage : 1)
        typeof enty && roid != "undefined" ? dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage)) : null;
        clearCache();
        dispatch(
            getBatteryModelBulk(modelPage)
        );
        dispatch(
            getBatteryTotal(enty, UserIdd, roid)
        );
    }, [MyBatteryMetaPresent, batPage, BatteryTotalMetaPresent, modelPage]);

    React.useEffect(() => {
        dispatch(getBMSBulk(bmsPage));
        dispatch(getBatteryModelLBulk());
        dispatch(getBMSLBulk());
        dispatch(getFleetBulk());
        dispatch(getBVABulk());
        dispatch(getTeleModelBulk());
    }, [BatteryModelLMetaPresent, BMSMetaPresent, BMSLMetaPresent, bmsPage, FleetMetaPresent, BVAMetaPresent, TeleModelMetaPresent]);


    let allModels = BatteryModelMeta.data
    let allBMSData = BMSLMeta.data




    const submitModel = () => {

        if (
            // modelAddForm.capacity_mah && 
            modelAddForm.model_info
            // && modelAddForm.nominal_voltage &
            // modelAddForm.power && modelAddForm.thermistor
        ) {
            const postModel = endpoints.baseUrl + `/batterymodel/add`;
            axios
                .post(postModel, modelAddForm)
                .then((response) => {
                    handleClick3(true);
                    response.status === 201 ? setDdd3("Battery model onboarded successfully!") : setDdd3(response.message)
                    dispatch(getBatteryModelBulk(modelPage));
                    setModelAddForm({})
                    handleReset4()
                });
            setOpenAddModel(false)

        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }
    const setModelAddFormArray = (e, key, array) => {
        if (array) {
            setModelAddForm((state) => ({
                ...state, bms: {
                    ...state.bms,
                    [key]: e.target.value
                }
            }));
        } else {
            setModelAddForm((state) => ({ ...state, [key]: e.target.value }));

        }


    }

    const setModelEditFormArray = (e, key, array) => {
        if (array) {
            setEditArray((state) => ({
                ...state, bms: {
                    ...state.bms,
                    [key]: e.target.value
                }
            }));
        } else {
            setEditArray((state) => ({ ...state, [key]: e.target.value }));

        }


    }
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
    const handleChange = (event, newValue) => {
        setValue(newValue);
        setOpenEditModel(false)
        setOpenEditBattery(false)
        setOpenAddBattery(false)
        setOpenAddModel(false)
        setOpenAddBMS(false)
        setOpenEditBMS(false)
        handleReset()
        handleReset1()
        handleReset2()
        handleReset3()
    };

    const handleChangeT = (event, val) => {
        setValue(val);
    };


    let allEditModel = BatteryModelMeta.data
    {/* Battery*/ }

    const setEditBatteryFormArray = (e, key, array) => {
        if (array) {
            setEditBatArray((state) => ({
                ...state, [array]: {
                    ...state[array],
                    [key]: e.target.value
                }
            }));
        } else {
            setEditBatArray((state) => ({ ...state, [key]: e.target.value }));

        }

    }


    const submitEditBattery = () => {
        if (editBatArray.bms_unique_id && editBatArray.serial_number && (editBatArray.updated_by = uName)) {
            const putBattery = endpoints.baseUrl + `/battery/update/` + editBatArray.bms_id;
            axios
                .put(putBattery, editBatArray)
                .then((response) => {
                    handleClick3(true);
                    response.status === 200 ? setDdd3("Battery details edited successfully!") : setDdd3(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                    setOpenEditBattery(false)
                    handleReset1()
                });

        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }

    const setEditBatteryArray = (bms_id) => {
        let allBattery = MyBatteryDataRaw;
        let findEditArray = allBattery.length && allBattery.find(el => el.bms_id === bms_id);
        setEditBatArray(findEditArray);
    }

    {/* Model*/ }

    const setModelEditArray = (battery_model_id) => {
        let allModel = BatteryModelDataRaw;
        let findArray = allModel.find(el => el.battery_model_id === battery_model_id);
        setEditArray(findArray);
    }
    const submitModelEdit = () => {

        if (
            editArray.capacity_mah && editArray.model_info && editArray.nominal_voltage && editArray.number_of_cells_parallel && editArray.number_of_cells_series
            && editArray.power && editArray.thermistor && (editArray.updated_by = uName)
            //  && editArray.bms_model_info
        ) {


            const putModel = endpoints.baseUrl + `/batterymodel/edit/` + editArray.battery_model_id;
            axios
                .put(putModel, editArray)
                .then((response) => {
                    handleClick3(true);
                    response.status === 200 ? setDdd3("Model details edited successfully!") : setDdd3(response.message)
                    dispatch(getBatteryModelBulk(modelPage));
                    setEditArray({

                    })
                });
            setOpenEditModel(false)
            handleReset5()

        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields")

        }

    }

    const deleteModel = (battery_model_id) => {
        const deleteModel = endpoints.baseUrl + `/batterymodel/softdelete/` + battery_model_id;
        axios
            .delete(deleteModel)
            .then((response) => {
                handleClick3(true);
                response.status === 200 ? setDdd3("Battery model offboarded successfully!") : setDdd3(response.message)
                setDelete2(false)
                setPassword2()
                dispatch(getBatteryModelBulk(modelPage));
            });
    }
    const Item = styled(Paper)(({ theme }) => ({
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'left',
        color: theme.palette.text.secondary,
    }));

    const validateKeyData = (key) => {
        return key ? key : "-";
    };
    const validateKeyData1 = (key) => {
        return key ? key : "-";
    };

    const handleTableChange = (event) => {
        if (tableMode === 'erickshaw') {
            setTableMode('comm');
        } else {
            setTableMode('erickshaw');
        }
    };
    const batteryProfile = (imei) => {
        dispatch(getBatteryProBulk(imei));
        setCsvDownload(1)
    }
    const DashboardList = (imei) => {
        dispatch(getBDashboardBulk(imei));
    }
    const downloadCsv = () => {
        let getCsvUrl = endpoints.baseUrl + `/battery/datadownload/` + imei;
        const a = document.createElement('a')
        a.setAttribute('href', getCsvUrl)
        // a.setAttribute('download', 'download.csv');
        a.click()
        handleClick4(true);
        setNotificationTimeOut(60000)
        setDdd4("Preparing Your csv for Download, Please wait..")

        axios
            .get(getCsvUrl)
            .then((response) => {
                // setFinalCsv(response);
                setCsvDownload(1)
                // const blob = new Blob([response.data], { type: 'text/csv' });
                // const url = window.URL.createObjectURL(blob)


                //  input.current.click()
                setNotificationTimeOut(6000)
                //  input.current.click()
                handleClick3(true);
                setDdd3("Downloaded successfully!")

            })
            .catch((error) => {

                let status = null;
                let data = null;
                setCsvDownload(4)
                handleClick4(true);
                setDdd4("Try again")

                //If no response from server
                if (!error.response) {
                    status = 500;
                    data = "No response from server";
                } else {
                    status = error.response.status;
                    data = error.response.data;
                }

            });

    }
    const handleSubmiAddBattery = () => {
        submitBattery()
    }
    const handleSubmitEditBattery = () => {
        submitEditBattery()
    }

    const DeactiveV = (vehicle_battery_id) => {
        const DeactiveVeh = endpoints.baseUrl + `/battery/vehicle/deactivate/` + vehicle_battery_id;
        axios
            .delete(DeactiveVeh)
            .then((response) => {
                handleClick3(true);
                setDdd3("Vehicle deactivated")
                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                dispatch(getBVABulk());
                dispatch(getTeleModelBulk());
                setOpenDeActiveV(false)
            });
    }
    const eIdles = React.useState(MyBatteryMeta.data);

    let allIdles = [];
    if (MyBatteryMetaPresent && BBMetaPresent) {
        allIdles = MyBatteryMeta.data
        // .map((ob) => {
        //     ob.idleMode = false;
        //     return ob;
        // })
    }
    const [selectedItem, setSelectedItem] = React.useState({ newmode: true })

    const checkPassword = () => {

        if (onOffPassword === pWord) {
            On()
        }
        else if (onOffPassword1 === pWord) {
            Off()
        }
        else {
            return null;
        }
    }

    const handleIdleMode = (dialog, imei, mode) => {
        setOpenPass(true)
        setSelectedItem((state) => ({
            ...state,
            imei: imei,
            mode: mode
        }))

    }
    let BModel = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[0]; });
    let BModelVoltage = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[1]; });
    let BModelCapacity = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[2]; });
    let BModelPower = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[3]; });
    let BModelCell_Man = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[4]; });
    let BModelType = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[6]; });
    let BModelCellChem = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[7]; });
    let BModelCellType = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[8]; });
    let BModelHeight = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[9]; });
    let BModelWidth = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[10]; });
    let BModelLength = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[11]; });
    let BModel_cells_parallel = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[12]; });
    let BModel_cells_series = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[13]; });
    let BModel_OEM = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[14]; });
    let BModelThermistor = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map(function (el) { return el[15]; });

    const columsModel = [
        {
            name: 'Battery Model',
            options: {
                filter: true,
                filterList: clear,
                filterType: 'custom',
                filterOptions: {
                    logic: (model_info, filters, row) => {
                        if (filters.length) return !filters.includes(model_info);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModel.filter((item,
                            index) => BModel.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Model</InputLabel>
                                <Select

                                    multiple
                                    value={clear.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Nominal Voltage (V)',
            options: {
                filter: true,
                filterList: clear1,
                filterType: 'custom',
                filterOptions: {
                    logic: (nominal_voltage, filters, row) => {
                        if (filters.length) return !filters.includes(nominal_voltage);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelVoltage.filter((item,
                            index) => BModelVoltage.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Nominal Voltage</InputLabel>
                                <Select

                                    multiple
                                    value={clear1.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear1(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Capacity (Ah)',
            options: {
                filter: true,
                filterList: clear2,
                filterType: 'custom',
                filterOptions: {
                    logic: (capacity_mah, filters, row) => {
                        if (filters.length) return !filters.includes(capacity_mah);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelCapacity.filter((item,
                            index) => BModelCapacity.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Capacity</InputLabel>
                                <Select

                                    multiple
                                    value={clear2.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear2(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Power (Wh)',
            options: {
                filter: true,
                filterList: clear3,
                filterType: 'custom',
                filterOptions: {
                    logic: (power, filters, row) => {
                        if (filters.length) return !filters.includes(power);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelPower.filter((item,
                            index) => BModelPower.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Power</InputLabel>
                                <Select

                                    multiple
                                    value={clear3.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear3(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Manufacturer',
            options: {
                filter: true,
                filterList: clear4,
                filterType: 'custom',
                filterOptions: {
                    logic: (cell_maufacturer, filters, row) => {
                        if (filters.length) return !filters.includes(cell_maufacturer);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelCell_Man.filter((item,
                            index) => BModelCell_Man.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Manufacturer</InputLabel>
                                <Select

                                    multiple
                                    value={clear4.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear4(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Action',
            options: {
                filter: false,
                customBodyRender: (value) => {
                    return (
                        <><IconButton
                            onClick={() => {
                                setOpenEditModel(true)
                                setModelEditArray(value)
                            }}
                        ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
                            <IconButton
                                onClick={() => {
                                    setDelete2(true);
                                    setSelectedId2(value);
                                }}
                            ><Icon icon="ic:baseline-delete"
                                color="#fa5d41"
                                width="22"
                                height="22" /> </IconButton>
                        </>
                    )
                }
            }
        },
        {
            name: 'battery_type',
            options: {
                filter: true,
                display: false,
                filterList: clear5,
                filterType: 'custom',
                filterOptions: {
                    logic: (battery_type, filters, row) => {
                        if (filters.length) return !filters.includes(battery_type);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelType.filter((item,
                            index) => BModelType.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Type</InputLabel>
                                <Select

                                    multiple
                                    value={clear5.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear5(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'cell_chemisty',
            options: {
                filter: true,
                display: false,
                filterList: clear6,
                filterType: 'custom',
                filterOptions: {
                    logic: (cell_chemisty, filters, row) => {
                        if (filters.length) return !filters.includes(cell_chemisty);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelCellChem.filter((item,
                            index) => BModelCellChem.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Cell Chemisty</InputLabel>
                                <Select

                                    multiple
                                    value={clear6.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear6(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'cell_type',
            options: {
                filter: true,
                display: false,
                filterList: clear7,
                filterType: 'custom',
                filterOptions: {
                    logic: (cell_type, filters, row) => {
                        if (filters.length) return !filters.includes(cell_type);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelCellType.filter((item,
                            index) => BModelCellType.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Cell Type</InputLabel>
                                <Select

                                    multiple
                                    value={clear7.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear7(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'height',
            options: {
                filter: true,
                display: false,
                filterList: clear8,
                filterType: 'custom',
                filterOptions: {
                    logic: (height, filters, row) => {
                        if (filters.length) return !filters.includes(height);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelHeight.filter((item,
                            index) => BModelHeight.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Height</InputLabel>
                                <Select

                                    multiple
                                    value={clear8.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear8(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'width',
            options: {
                filter: true,
                display: false,
                filterList: clear9,
                filterType: 'custom',
                filterOptions: {
                    logic: (width, filters, row) => {
                        if (filters.length) return !filters.includes(width);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelWidth.filter((item,
                            index) => BModelWidth.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Width</InputLabel>
                                <Select

                                    multiple
                                    value={clear9.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear9(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'length',
            options: {
                filter: true,
                display: false,
                filterList: clear10,
                filterType: 'custom',
                filterOptions: {
                    logic: (length, filters, row) => {
                        if (filters.length) return !filters.includes(length);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelLength.filter((item,
                            index) => BModelLength.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Length</InputLabel>
                                <Select

                                    multiple
                                    value={clear10.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear10(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'number_of_cells_parallel',
            options: {
                filter: true,
                display: false,
                filterList: clear11,
                filterType: 'custom',
                filterOptions: {
                    logic: (number_of_cells_parallel, filters, row) => {
                        if (filters.length) return !filters.includes(number_of_cells_parallel);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModel_cells_parallel.filter((item,
                            index) => BModel_cells_parallel.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Cells Parallel</InputLabel>
                                <Select

                                    multiple
                                    value={clear11.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear11(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'number_of_cells_series',
            options: {
                filter: true,
                display: false,
                filterList: clear12,
                filterType: 'custom',
                filterOptions: {
                    logic: (number_of_cells_series, filters, row) => {
                        if (filters.length) return !filters.includes(number_of_cells_series);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModel_cells_series.filter((item,
                            index) => BModel_cells_series.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Cells Series</InputLabel>
                                <Select

                                    multiple
                                    value={clear12.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear12(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'oem',
            options: {
                filter: true,
                display: false,
                filterList: clear13,
                filterType: 'custom',
                filterOptions: {
                    logic: (oem, filters, row) => {
                        if (filters.length) return !filters.includes(oem);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModel_OEM.filter((item,
                            index) => BModel_OEM.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">OEM</InputLabel>
                                <Select
                                    multiple
                                    value={clear13.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear13(filterList[index], index, column);
                                    }}
                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'thermistor',
            options: {
                filter: true,
                display: false,
                filterList: clear14,
                filterType: 'custom',
                filterOptions: {
                    logic: (thermistor, filters, row) => {
                        if (filters.length) return !filters.includes(thermistor);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelThermistor.filter((item,
                            index) => BModelThermistor.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Thermistor</InputLabel>
                                <Select
                                    multiple
                                    value={clear14.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear14(filterList[index], index, column);
                                    }}
                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
    ]
    const columsModel1 = [
        {
            name: 'Battery Model',
            options: {
                filter: true,
                filterList: clear,
                filterType: 'custom',
                filterOptions: {
                    logic: (model_info, filters, row) => {
                        if (filters.length) return !filters.includes(model_info);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModel.filter((item,
                            index) => BModel.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Model</InputLabel>
                                <Select

                                    multiple
                                    value={clear.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Nominal Voltage (V)',
            options: {
                filter: true,
                filterList: clear1,
                filterType: 'custom',
                filterOptions: {
                    logic: (nominal_voltage, filters, row) => {
                        if (filters.length) return !filters.includes(nominal_voltage);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelVoltage.filter((item,
                            index) => BModelVoltage.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Nominal Voltage</InputLabel>
                                <Select

                                    multiple
                                    value={clear1.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear1(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Capacity (Ah)',
            options: {
                filter: true,
                filterList: clear2,
                filterType: 'custom',
                filterOptions: {
                    logic: (capacity_mah, filters, row) => {
                        if (filters.length) return !filters.includes(capacity_mah);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelCapacity.filter((item,
                            index) => BModelCapacity.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Capacity</InputLabel>
                                <Select

                                    multiple
                                    value={clear2.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear2(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Power (Wh)',
            options: {
                filter: true,
                filterList: clear3,
                filterType: 'custom',
                filterOptions: {
                    logic: (power, filters, row) => {
                        if (filters.length) return !filters.includes(power);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelPower.filter((item,
                            index) => BModelPower.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Power</InputLabel>
                                <Select

                                    multiple
                                    value={clear3.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear3(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Manufacturer',
            options: {
                filter: true,
                filterList: clear4,
                filterType: 'custom',
                filterOptions: {
                    logic: (cell_maufacturer, filters, row) => {
                        if (filters.length) return !filters.includes(cell_maufacturer);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelCell_Man.filter((item,
                            index) => BModelCell_Man.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Manufacturer</InputLabel>
                                <Select

                                    multiple
                                    value={clear4.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear4(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Action',
            options: {
                filter: false,
                display: false,
                customBodyRender: (value) => {
                    return (
                        <><IconButton
                            onClick={() => {
                                setOpenEditModel(true)
                                setModelEditArray(value)
                            }}
                        ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
                            <IconButton
                                onClick={() => {
                                    setDelete2(true);
                                    setSelectedId2(value);
                                }}
                            ><Icon icon="ic:baseline-delete"
                                color="#fa5d41"
                                width="22"
                                height="22" /> </IconButton>
                        </>
                    )
                }
            }
        },
        {
            name: 'battery_type',
            options: {
                filter: true,
                display: false,
                filterList: clear5,
                filterType: 'custom',
                filterOptions: {
                    logic: (battery_type, filters, row) => {
                        if (filters.length) return !filters.includes(battery_type);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelType.filter((item,
                            index) => BModelType.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Type</InputLabel>
                                <Select

                                    multiple
                                    value={clear5.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear5(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'cell_chemisty',
            options: {
                filter: true,
                display: false,
                filterList: clear6,
                filterType: 'custom',
                filterOptions: {
                    logic: (cell_chemisty, filters, row) => {
                        if (filters.length) return !filters.includes(cell_chemisty);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelCellChem.filter((item,
                            index) => BModelCellChem.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Cell Chemisty</InputLabel>
                                <Select

                                    multiple
                                    value={clear6.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear6(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'cell_type',
            options: {
                filter: true,
                display: false,
                filterList: clear7,
                filterType: 'custom',
                filterOptions: {
                    logic: (cell_type, filters, row) => {
                        if (filters.length) return !filters.includes(cell_type);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelCellType.filter((item,
                            index) => BModelCellType.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Cell Type</InputLabel>
                                <Select

                                    multiple
                                    value={clear7.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear7(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'height',
            options: {
                filter: true,
                display: false,
                filterList: clear8,
                filterType: 'custom',
                filterOptions: {
                    logic: (height, filters, row) => {
                        if (filters.length) return !filters.includes(height);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelHeight.filter((item,
                            index) => BModelHeight.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Height</InputLabel>
                                <Select

                                    multiple
                                    value={clear8.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear8(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'width',
            options: {
                filter: true,
                display: false,
                filterList: clear9,
                filterType: 'custom',
                filterOptions: {
                    logic: (width, filters, row) => {
                        if (filters.length) return !filters.includes(width);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelWidth.filter((item,
                            index) => BModelWidth.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Width</InputLabel>
                                <Select

                                    multiple
                                    value={clear9.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear9(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'length',
            options: {
                filter: true,
                display: false,
                filterList: clear10,
                filterType: 'custom',
                filterOptions: {
                    logic: (length, filters, row) => {
                        if (filters.length) return !filters.includes(length);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelLength.filter((item,
                            index) => BModelLength.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Length</InputLabel>
                                <Select

                                    multiple
                                    value={clear10.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear10(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'number_of_cells_parallel',
            options: {
                filter: true,
                display: false,
                filterList: clear11,
                filterType: 'custom',
                filterOptions: {
                    logic: (number_of_cells_parallel, filters, row) => {
                        if (filters.length) return !filters.includes(number_of_cells_parallel);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModel_cells_parallel.filter((item,
                            index) => BModel_cells_parallel.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Cells Parallel</InputLabel>
                                <Select

                                    multiple
                                    value={clear11.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear11(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'number_of_cells_series',
            options: {
                filter: true,
                display: false,
                filterList: clear12,
                filterType: 'custom',
                filterOptions: {
                    logic: (number_of_cells_series, filters, row) => {
                        if (filters.length) return !filters.includes(number_of_cells_series);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModel_cells_series.filter((item,
                            index) => BModel_cells_series.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Cells Series</InputLabel>
                                <Select

                                    multiple
                                    value={clear12.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear12(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'oem',
            options: {
                filter: true,
                display: false,
                filterList: clear13,
                filterType: 'custom',
                filterOptions: {
                    logic: (oem, filters, row) => {
                        if (filters.length) return !filters.includes(oem);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModel_OEM.filter((item,
                            index) => BModel_OEM.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">OEM</InputLabel>
                                <Select
                                    multiple
                                    value={clear13.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear13(filterList[index], index, column);
                                    }}
                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'thermistor',
            options: {
                filter: true,
                display: false,
                filterList: clear14,
                filterType: 'custom',
                filterOptions: {
                    logic: (thermistor, filters, row) => {
                        if (filters.length) return !filters.includes(thermistor);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BModelThermistor.filter((item,
                            index) => BModelThermistor.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Thermistor</InputLabel>
                                <Select
                                    multiple
                                    value={clear14.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear14(filterList[index], index, column);
                                    }}
                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBatteryModelLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
    ]

    const [clear, setClear] = React.useState([]);
    const [clear1, setClear1] = React.useState([]);
    const [clear2, setClear2] = React.useState([]);
    const [clear3, setClear3] = React.useState([]);
    const [clear4, setClear4] = React.useState([]);
    const [clear5, setClear5] = React.useState([]);
    const [clear6, setClear6] = React.useState([]);
    const [clear7, setClear7] = React.useState([]);
    const [clear8, setClear8] = React.useState([]);
    const [clear9, setClear9] = React.useState([]);
    const [clear10, setClear10] = React.useState([]);
    const [clear11, setClear11] = React.useState([]);
    const [clear12, setClear12] = React.useState([]);
    const [clear13, setClear13] = React.useState([]);
    const [clear14, setClear14] = React.useState([]);


    const [selectedImei, setSelectedImei] = React.useState("");
    React.useEffect(() => {
        setAssignTele({
            battery_id: "",
            telematics_id: "",
        });
    }, [selectedImei]);

    const [assignTele, setAssignTele] = React.useState({
        battery_id: "",
        telematics_id: "",
    });

    const AssignTelematics = () => {
        if (assignTele.battery_id && assignTele.telematics_id) {
            const postImei = endpoints.baseUrl + `/telematics/assign/battery`;

            axios.post(postImei, assignTele).then((response) => {
                handleClick3(true);
                response.status === 200
                    ? setDdd3("Telematics assigned successfully!")
                    : setDdd3(response.message);
                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage))
                dispatch(getBVABulk());
                dispatch(getTeleModelBulk());
                setOpenTele(false);
            });
            setOpenTele(false);
        } else {
            handleClick4(true);
            setDdd4("Please fill the required fields");
        }
    };
    const ReassignImei = (asset_linkage_id) => {
        const Dimei = endpoints.baseUrl + `/telematics/deactivate/` + asset_linkage_id;
        axios.delete(Dimei).then((response) => {
            handleClick3(true);
            response.status === 200
                ? setDdd3("Imei deactivated")
                : setDdd3(response.message);
            dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage))
            dispatch(getBVABulk());
            dispatch(getTeleModelBulk());
            setOpenTeleD(false);
        });
    };

    const columnsBattery = [

        {
            name: 'Battery',
            options: {
                filter: false,
                field: value.serial_number,
                customBodyRender: (value) => (
                    <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-start', marginLeft: '60px' }}>
                        <><Tooltip style={{ flex: "left" }} title={value.battery_status === 'enabled' ? "Enabled" : "Disabled"}>
                            <Avatar style={{
                                backgroundColor: value.battery_status === 'enabled' ? '#ffcb0d' : '#c4c4c4',
                                marginLeft: '-15px'
                            }}>
                                {value.battery_type === "Storage Battery" ?
                                    <img src={Mobility} style={{ width: '30px', height: '30px', marginTop: '5px' }} /> :
                                    <Icon
                                        icon="mdi:car-battery"
                                        color="#fff"
                                        width="22"
                                        height="22"
                                    />}
                            </Avatar>
                        </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                            <Typography onClick={() => {
                                setBatDashboard(true)
                                DashboardList(value.imei)
                                setBmsId(validateKeyData(value.bms_id))
                                setImei(validateKeyData(value.imei))
                                setSerial(validateKeyData(value.serial_number))
                            }}
                                style={{ cursor: "pointer", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}>
                                &nbsp;&nbsp;{value.serial_number}
                            </Typography>
                            <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>
                                &nbsp;&nbsp;{value.battery_model}
                            </Typography>
                        </div>
                    </div>

                )
            }
        },
        {
            name: 'Vehicle',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', marginLeft: '30px' }}>
                        <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}>{validateKeyData(value.vehicle_number)}</Typography>
                        <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>{validateKeyData(value.updated_at)}</Typography></div>
                )
            }
        },
        {
            name: 'Investor',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-25px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Operation Manager',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-25px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Active',
            options: {
                filter: false,  //setImei(validateKeyData(value.imei))
                customBodyRender: (value) => {
                    if (value.status === "true") {
                        return (<Switch checked={true}
                            onClick={() => {
                                setImei(validateKeyData(value.imei))
                                setOpenOff(true)
                                setIdleOff((state) => ({
                                    ...state,
                                    "imei": value.imei
                                }))
                            }} />)
                    }
                    else {
                        return (<Switch checked={false} onClick={() => {
                            setImei(validateKeyData(value.imei))
                            setOpenOn(true)
                            setIdleOn((state) => ({
                                ...state,
                                "imei": value.imei
                            }))
                        }} />)
                    }
                }

            }
        },
        {
            name: 'Assignment',
            display: true,
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <>
                        <IconButton
                            onClick={() => {
                                setOpenEditBattery(true)
                                setEditBatteryArray(value.bms_id)
                            }}
                        ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                        </IconButton>
                        <IconButton
                            onClick={() => {
                                if (value.battery_type === "Storage Battery") {
                                    null
                                }
                                else {
                                    if (value.vehicle_status === "assign") {
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setSerial(validateKeyData(value.serial_number))
                                        setOpenDeActiveV(true)
                                        setVehBatID(validateKeyData(value.vehicle_battery_id))
                                    }
                                    else {
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setOpenVehicleActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setAssignVech((state) => ({
                                            ...state,
                                            "battery_id": value.bms_id
                                        }))
                                    }
                                }
                            }}>
                            {value.battery_type === "Storage Battery" ? <Icon icon="codicon:blank" width="22" height="22" />
                                : <Icon icon="mdi:motorbike" color={value.vehicle_status === "assign" ? "#68a724" : "C4C4C4"} width="22" height="22" />}
                        </IconButton>
                        <IconButton
                            onClick={() => {
                                if (value.battery_status === "enabled") {
                                    setSerial(validateKeyData(value.serial_number))
                                    setOpenDeActiveB(true)
                                    setBId(validateKeyData(value.battery_id))
                                }
                                else {
                                    setOpenBatteryActive(true)
                                    setSerial(validateKeyData(value.serial_number))
                                    setBId(validateKeyData(value.battery_id))
                                }

                            }}><Icon icon="mdi:car-battery" color={value.battery_status === "enabled" ? "#68a724" : 'C4C4C4'}
                                width="22" height="22" />
                        </IconButton>
                        <IconButton
                            onClick={() => {
                                if (value.telematics_status === "assign") {
                                    setSelectedImei(value.imei)
                                    setEditBatteryArray(value.bms_id)
                                    setAssetLink(value.asset_linkage_id);
                                    setOpenTeleD(true)
                                }
                                else {
                                    setAssignTele((state) => ({
                                        ...state,
                                        battery_id: value.battery_id,
                                    }));
                                    setOpenTele(true)
                                }
                            }}
                        >
                            <Icon
                                icon="material-symbols:wifi"
                                color={value.telematics_status === "assign" ? "#68a724" : "C4C4C4"}
                                width="20"
                                height="20"
                            />
                        </IconButton>
                        <IconButton
                            onClick={() => {
                                if (value.vehicle_status === "assign") {
                                    handleClick(true);
                                    setDdd(value.vehicle_number)
                                }
                                else if (value.battery_status === "enabled") {
                                    handleClick1(true);
                                    setDdd1(value.battery_status)
                                }
                                else if (value.telematics_status === "assign") {
                                    handleClick2(true);
                                    setDdd2(value.imei)
                                }
                                else {
                                    setDelete1(true);
                                    setSelectedId1(value.bms_id);
                                }
                            }}
                        >
                            <Icon
                                icon="ic:baseline-delete"
                                color="#fa5d41"
                                width="22"
                                height="22"
                            />
                        </IconButton>
                    </>
                ),


            },

        },
        {
            name: 'Serial Number',
            options: {
                filter: true,
                display: false,
                filterList: clear,
                filterType: 'custom',
                filterOptions: {
                    logic: (serial_number, filters, row) => {
                        if (filters.length) return !filters.includes(serial_number);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = SerialNumber.filter((item,
                            index) => SerialNumber.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Serial Number</InputLabel>
                                <Select

                                    multiple
                                    value={clear.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Battery Model',
            options: {
                filter: true,
                display: false,
                filterList: clear1,
                filterType: 'custom',
                filterOptions: {
                    logic: (battery_model, filters, row) => {
                        if (filters.length) return !filters.includes(battery_model);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryModel.filter((item,
                            index) => BatteryModel.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Model</InputLabel>
                                <Select

                                    multiple
                                    value={clear1.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear1(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Vehicle Number',
            options: {
                filter: true,
                display: false,
                filterList: clear2,
                filterType: 'custom',
                filterOptions: {
                    logic: (vehicle_number, filters, row) => {
                        if (filters.length) return !filters.includes(vehicle_number);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryVehicleNumber.filter((item,
                            index) => BatteryVehicleNumber.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Vehicle Number</InputLabel>
                                <Select

                                    multiple
                                    value={clear2.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear2(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'IMEI',
            options: {
                filter: true,
                display: false,
                filterList: clear3,
                filterType: 'custom',
                filterOptions: {
                    logic: (imei, filters, row) => {
                        if (filters.length) return !filters.includes(imei);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryIMEI.filter((item,
                            index) => BatteryIMEI.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">IMEI</InputLabel>
                                <Select

                                    multiple
                                    value={clear3.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear3(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Investors',
            options: {
                filter: true,
                display: false,
                filterList: clear4,
                filterType: 'custom',
                filterOptions: {
                    logic: (investors, filters, row) => {
                        if (filters.length) return !filters.includes(investors);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryInvestor.filter((item,
                            index) => BatteryInvestor.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Investor</InputLabel>
                                <Select

                                    multiple
                                    value={clear4.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear4(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Operation Manager',
            options: {
                filter: true,
                display: false,
                filterList: clear5,
                filterType: 'custom',
                filterOptions: {
                    logic: (operational_manager, filters, row) => {
                        if (filters.length) return !filters.includes(operational_manager);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryOperation.filter((item,
                            index) => BatteryOperation.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Operation Manager</InputLabel>
                                <Select

                                    multiple
                                    value={clear5.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear5(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Battery Status',
            options: {
                filter: true,
                display: false,
                filterList: clear6,
                filterType: 'custom',
                filterOptions: {
                    logic: (battery_status, filters, row) => {
                        if (filters.length) return !filters.includes(battery_status);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryStatus.filter((item,
                            index) => BatteryStatus.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Status</InputLabel>
                                <Select

                                    multiple
                                    value={clear6.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear6(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Battery Type',
            options: {
                filter: true,
                display: false,
                filterList: clear7,
                filterType: 'custom',
                filterOptions: {
                    logic: (battery_type, filters, row) => {
                        if (filters.length) return !filters.includes(battery_type);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryType.filter((item,
                            index) => BatteryType.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Type</InputLabel>
                                <Select

                                    multiple
                                    value={clear7.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear7(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Idle Status',
            options: {
                filter: true,
                display: false,
                filterList: clear8,
                filterType: 'custom',
                filterOptions: {
                    logic: (status, filters, row) => {
                        if (filters.length) return !filters.includes(status);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryIdle.filter((item,
                            index) => BatteryIdle.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Idle Status</InputLabel>
                                <Select

                                    multiple
                                    value={clear8.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear8(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Vehicle Status',
            options: {
                filter: true,
                display: false,
                filterList: clear8,
                filterType: 'custom',
                filterOptions: {
                    logic: (vehicle_status, filters, row) => {
                        if (filters.length) return !filters.includes(vehicle_status);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryVehicleStatus.filter((item,
                            index) => BatteryVehicleStatus.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Vehicle Status</InputLabel>
                                <Select

                                    multiple
                                    value={clear8.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear8(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Telematics Status',
            options: {
                filter: true,
                display: false,
                filterList: clear9,
                filterType: 'custom',
                filterOptions: {
                    logic: (telematics_status, filters, row) => {
                        if (filters.length) return !filters.includes(telematics_status);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = TelematicsStatus.filter((item,
                            index) => TelematicsStatus.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Telematics Status</InputLabel>
                                <Select

                                    multiple
                                    value={clear9.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear9(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'BMS Unique Id',
            options: {
                filter: true,
                display: false,
                filterList: clear10,
                filterType: 'custom',
                filterOptions: {
                    logic: (bms_unique_id, filters, row) => {
                        if (filters.length) return !filters.includes(bms_unique_id);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryBMS.filter((item,
                            index) => BatteryBMS.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">BMS Unique Id</InputLabel>
                                <Select

                                    multiple
                                    value={clear10.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear10(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'SW Version',
            options: {
                filter: true,
                display: false,
                filterList: clear11,
                filterType: 'custom',
                filterOptions: {
                    logic: (sw_version, filters, row) => {
                        if (filters.length) return !filters.includes(sw_version);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatterySW.filter((item,
                            index) => BatterySW.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">SW Version</InputLabel>
                                <Select

                                    multiple
                                    value={clear11.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear11(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
    ]
    const columnsBattery1 = [

        {
            name: 'Battery',
            options: {
                filter: false,
                field: value.serial_number,
                customBodyRender: (value) => (
                    <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-start', marginLeft: '60px' }}>
                        {value.battery_status === 'enabled' ? <><Tooltip style={{ flex: "left" }} title={"Enabled"}>
                            <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px' }}>
                                <Icon
                                    icon="mdi:car-battery"
                                    color="#fff"
                                    width="22"
                                    height="22"
                                />
                            </Avatar>
                        </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                            <><Tooltip style={{ flex: "left" }} title={"Disabled"}>
                                <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                                    <Icon
                                        icon="mdi:car-battery"
                                        color="#fff"
                                        width="22"
                                        height="22"
                                    />
                                </Avatar>
                            </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></>}
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                            <Typography onClick={() => {
                                setBatDashboard(true)
                                setBmsId(validateKeyData(value.bms_id))
                                setImei(validateKeyData(value.imei))
                                setSerial(validateKeyData(value.serial_number))
                            }}
                                style={{ cursor: "pointer", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}>
                                &nbsp;&nbsp;{value.serial_number}
                            </Typography>
                            <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>
                                &nbsp;&nbsp;{value.battery_model}
                            </Typography>
                        </div>
                    </div>

                )
            }
        },
        {
            name: 'Vehicle',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', marginLeft: '30px' }}>
                        <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}>{validateKeyData(value)}</Typography>
                        <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>{validateKeyData(value.updated_at)} </Typography></div>
                )
            }
        },
        {
            name: 'Investor',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-25px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Operation Manager',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-25px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Assignment',
            display: true,
            options: {
                customBodyRender: (value) => (
                    <>
                        <IconButton>
                            {value.battery_type === "Storage Battery" ? <Icon icon="codicon:blank" width="22" height="22" />
                                : <Icon icon="mdi:motorbike" color={value.vehicle_status === "assign" ? "#68a724" : "C4C4C4"} width="22" height="22" />}
                        </IconButton>
                        <IconButton>
                            <Icon icon="mdi:car-battery" color={value.battery_status === "enabled" ? "#68a724" : 'C4C4C4'}
                                width="22" height="22" />
                        </IconButton>
                        <IconButton>
                            <Icon
                                icon="material-symbols:wifi"
                                color={value.telematics_status === "assign" ? "#68a724" : "C4C4C4"}
                                width="20"
                                height="20"
                            />
                        </IconButton>
                    </>
                ),


            },

        },
        {
            name: 'Serial Number',
            options: {
                filter: true,
                display: false,
                filterList: clear,
                filterType: 'custom',
                filterOptions: {
                    logic: (serial_number, filters, row) => {
                        if (filters.length) return !filters.includes(serial_number);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = SerialNumber.filter((item,
                            index) => SerialNumber.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Serial Number</InputLabel>
                                <Select

                                    multiple
                                    value={clear.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Battery Model',
            options: {
                filter: true,
                display: false,
                filterList: clear1,
                filterType: 'custom',
                filterOptions: {
                    logic: (battery_model, filters, row) => {
                        if (filters.length) return !filters.includes(battery_model);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryModel.filter((item,
                            index) => BatteryModel.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Model</InputLabel>
                                <Select

                                    multiple
                                    value={clear1.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear1(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Vehicle Number',
            options: {
                filter: true,
                display: false,
                filterList: clear2,
                filterType: 'custom',
                filterOptions: {
                    logic: (vehicle_number, filters, row) => {
                        if (filters.length) return !filters.includes(vehicle_number);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryVehicleNumber.filter((item,
                            index) => BatteryVehicleNumber.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Vehicle Number</InputLabel>
                                <Select

                                    multiple
                                    value={clear2.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear2(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'IMEI',
            options: {
                filter: true,
                display: false,
                filterList: clear3,
                filterType: 'custom',
                filterOptions: {
                    logic: (imei, filters, row) => {
                        if (filters.length) return !filters.includes(imei);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryIMEI.filter((item,
                            index) => BatteryIMEI.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">IMEI</InputLabel>
                                <Select

                                    multiple
                                    value={clear3.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear3(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Investors',
            options: {
                filter: true,
                display: false,
                filterList: clear4,
                filterType: 'custom',
                filterOptions: {
                    logic: (investors, filters, row) => {
                        if (filters.length) return !filters.includes(investors);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryInvestor.filter((item,
                            index) => BatteryInvestor.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Investor</InputLabel>
                                <Select

                                    multiple
                                    value={clear4.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear4(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Operation Manager',
            options: {
                filter: true,
                display: false,
                filterList: clear5,
                filterType: 'custom',
                filterOptions: {
                    logic: (operational_manager, filters, row) => {
                        if (filters.length) return !filters.includes(operational_manager);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryOperation.filter((item,
                            index) => BatteryOperation.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Operation Manager</InputLabel>
                                <Select

                                    multiple
                                    value={clear5.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear5(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Battery Status',
            options: {
                filter: true,
                display: false,
                filterList: clear6,
                filterType: 'custom',
                filterOptions: {
                    logic: (battery_status, filters, row) => {
                        if (filters.length) return !filters.includes(battery_status);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryStatus.filter((item,
                            index) => BatteryStatus.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Status</InputLabel>
                                <Select

                                    multiple
                                    value={clear6.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear6(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Battery Type',
            options: {
                filter: true,
                display: false,
                filterList: clear7,
                filterType: 'custom',
                filterOptions: {
                    logic: (battery_type, filters, row) => {
                        if (filters.length) return !filters.includes(battery_type);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryType.filter((item,
                            index) => BatteryType.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Battery Type</InputLabel>
                                <Select

                                    multiple
                                    value={clear7.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear7(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Idle Status',
            options: {
                filter: true,
                display: false,
                filterList: clear8,
                filterType: 'custom',
                filterOptions: {
                    logic: (status, filters, row) => {
                        if (filters.length) return !filters.includes(status);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryIdle.filter((item,
                            index) => BatteryIdle.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Idle Status</InputLabel>
                                <Select

                                    multiple
                                    value={clear8.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear8(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Vehicle Status',
            options: {
                filter: true,
                display: false,
                filterList: clear8,
                filterType: 'custom',
                filterOptions: {
                    logic: (vehicle_status, filters, row) => {
                        if (filters.length) return !filters.includes(vehicle_status);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryVehicleStatus.filter((item,
                            index) => BatteryVehicleStatus.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Vehicle Status</InputLabel>
                                <Select

                                    multiple
                                    value={clear8.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear8(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'Telematics Status',
            options: {
                filter: true,
                display: false,
                filterList: clear9,
                filterType: 'custom',
                filterOptions: {
                    logic: (telematics_status, filters, row) => {
                        if (filters.length) return !filters.includes(telematics_status);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = TelematicsStatus.filter((item,
                            index) => TelematicsStatus.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">Telematics Status</InputLabel>
                                <Select

                                    multiple
                                    value={clear9.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear9(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'BMS Unique Id',
            options: {
                filter: true,
                display: false,
                filterList: clear10,
                filterType: 'custom',
                filterOptions: {
                    logic: (bms_unique_id, filters, row) => {
                        if (filters.length) return !filters.includes(bms_unique_id);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatteryBMS.filter((item,
                            index) => BatteryBMS.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">BMS Unique Id</InputLabel>
                                <Select

                                    multiple
                                    value={clear10.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear10(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
        {
            name: 'SW Version',
            options: {
                filter: true,
                display: false,
                filterList: clear11,
                filterType: 'custom',
                filterOptions: {
                    logic: (sw_version, filters, row) => {
                        if (filters.length) return !filters.includes(sw_version);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BatterySW.filter((item,
                            index) => BatterySW.indexOf(item) === index);
                        return (
                            <FormControl >
                                <InputLabel htmlFor="select-multiple-chip">SW Version</InputLabel>
                                <Select

                                    multiple
                                    value={clear11.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear11(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(GetBBBulk(enty, UserIdd, roid));
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            }
        },
    ]

    let BMSModel = BMSLMeta.data.length && BMSLMeta.data.map(function (el) { return el[0]; });
    let BMSModelH_V = BMSLMeta.data.length && BMSLMeta.data.map(function (el) { return el[1]; });
    let BMSModel_oem = BMSLMeta.data.length && BMSLMeta.data.map(function (el) { return el[2]; });

    const columsBMS = [
        {
            name: 'BMS Model',
            options: {
                filter: true,
                filterList: clear,
                filterType: 'custom',
                filterOptions: {
                    logic: (model_info, filters, row) => {
                        if (filters.length) return !filters.includes(model_info);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BMSModel.filter((item,
                            index) => BMSModel.indexOf(item) === index);
                        return (
                            <FormControl style={{ width: '200px' }}>
                                <InputLabel htmlFor="select-multiple-chip">BMS Model</InputLabel>
                                <Select

                                    multiple
                                    value={clear.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBMSLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Hardware',
            options: {
                filter: true,
                filterList: clear1,
                filterType: 'custom',
                filterOptions: {
                    logic: (hw_version, filters, row) => {
                        if (filters.length) return !filters.includes(hw_version);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BMSModelH_V.filter((item,
                            index) => BMSModelH_V.indexOf(item) === index);
                        return (
                            <FormControl style={{ width: '200px' }}>
                                <InputLabel htmlFor="select-multiple-chip">BMS Hardware</InputLabel>
                                <Select

                                    multiple
                                    value={clear1.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear1(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBMSLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        }, {
            name: 'OEM',
            options: {
                filter: true,
                filterList: clear2,
                filterType: 'custom',
                filterOptions: {
                    logic: (oem, filters, row) => {
                        if (filters.length) return !filters.includes(oem);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BMSModel_oem.filter((item,
                            index) => BMSModel_oem.indexOf(item) === index);
                        return (
                            <FormControl style={{ width: '200px' }}>
                                <InputLabel htmlFor="select-multiple-chip">BMS OEM</InputLabel>
                                <Select

                                    multiple
                                    value={clear2.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear2(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBMSLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Action',
            options: {
                filter: false,
                customBodyRender: (value) => {
                    // if (value === 'assign') {
                    return (
                        <><IconButton
                            onClick={() => {
                                setOpenEditBMS(true)
                                setEditBMSSArray(value)
                            }}
                        ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
                            <IconButton
                                onClick={() => {
                                    setDelete3(true);
                                    setSelectedId3(value);
                                }}
                            ><Icon icon="ic:baseline-delete"
                                color="#fa5d41"
                                width="22"
                                height="22" /> </IconButton></>

                    )
                }
            }
        },
    ]
    const columsBMS1 = [
        {
            name: 'BMS Model',
            options: {
                filter: true,
                filterList: clear,
                filterType: 'custom',
                filterOptions: {
                    logic: (model_info, filters, row) => {
                        if (filters.length) return !filters.includes(model_info);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BMSModel.filter((item,
                            index) => BMSModel.indexOf(item) === index);
                        return (
                            <FormControl style={{ width: '200px' }}>
                                <InputLabel htmlFor="select-multiple-chip">BMS Model</InputLabel>
                                <Select

                                    multiple
                                    value={clear.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBMSLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
        {
            name: 'Hardware',
            options: {
                filter: true,
                filterList: clear1,
                filterType: 'custom',
                filterOptions: {
                    logic: (hw_version, filters, row) => {
                        if (filters.length) return !filters.includes(hw_version);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BMSModelH_V.filter((item,
                            index) => BMSModelH_V.indexOf(item) === index);
                        return (
                            <FormControl style={{ width: '200px' }}>
                                <InputLabel htmlFor="select-multiple-chip">BMS Hardware</InputLabel>
                                <Select

                                    multiple
                                    value={clear1.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear1(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBMSLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        }, {
            name: 'OEM',
            options: {
                filter: true,
                filterList: clear2,
                filterType: 'custom',
                filterOptions: {
                    logic: (oem, filters, row) => {
                        if (filters.length) return !filters.includes(oem);
                        return false;
                    },
                    display: (filterList, onChange, index, column) => {
                        const optionValues = BMSModel_oem.filter((item,
                            index) => BMSModel_oem.indexOf(item) === index);
                        return (
                            <FormControl style={{ width: '200px' }}>
                                <InputLabel htmlFor="select-multiple-chip">BMS OEM</InputLabel>
                                <Select

                                    multiple
                                    value={clear2.length === 0 ? [] : filterList[index]}
                                    renderValue={selected => selected.join(', ')}
                                    onChange={event => {
                                        filterList[index] = event.target.value;
                                        onChange(filterList[index], index, column);
                                        setClear2(filterList[index], index, column);
                                    }}

                                >
                                    {optionValues.map(item => (
                                        <MenuItem key={item} value={item}
                                            onClick={() => {
                                                setDataOn(true)
                                                dispatch(getBMSLBulk());
                                            }}
                                        >
                                            <ListItemText primary={item}

                                            />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        );
                    }
                },
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                    }}
                        style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}
                        variant='subtitle2'>
                        {validateKeyData(value)}
                    </Typography>

                )
            },
        },
    ]
    const onDownload = () => {
        const headerRow = ["Serial Number", "Model", "Vehicle Number", "Investor", "Operational Manager", "Active",
            "Vehicle Status", "Battery Status", "BMS Unique Id", "Software Version", "IMEI", "Battery Type", "Telematics Status",
            "BMS Model"];
        const bodyRows = BatteryTotalMeta.data.length && BatteryTotalMeta.data.map((col) => {
            return [
                col[0],
                col[1],
                col[4],
                col[2],
                col[3],
                col[5],
                col[6],
                col[7],
                col[8],
                col[9],
                col[10],
                col[11],
                col[12],
                col[13]
            ];
        });

        const csvRows = [headerRow, ...bodyRows];
        const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", "data.csv");
            link.style.visibility = "hidden";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

    }

    const onDownloadModel = () => {
        const headerRow = ["Battery Model", "Nominal Voltage", "Capacity", "Power", "Manufacturer", "Battery Type",
            "Cell Chemisty", "Cell Type", "Height", "Width", "Length", "Number Of Cells Parallel", "Number Of Cells Series",
            "OEM", "Thermistor"];
        const bodyRows = BatteryModelLMeta.data.length && BatteryModelLMeta.data.map((col) => {
            return [
                col[0],
                col[1],
                col[2],
                col[3],
                col[4],
                col[6],
                col[7],
                col[8],
                col[9],
                col[10],
                col[11],
                col[12],
                col[13],
                col[14],
                col[15]
            ];
        });

        const csvRows = [headerRow, ...bodyRows];
        const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", "data.csv");
            link.style.visibility = "hidden";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

    }
    const onDownloadBMS = () => {
        const headerRow = ["BMS Model", "Hardware", "OEM"];
        const bodyRows = BMSLMeta.data.length && BMSLMeta.data.map((col) => {
            return [
                col[0],
                col[1],
                col[2]
            ];
        });

        const csvRows = [headerRow, ...bodyRows];
        const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", "data.csv");
            link.style.visibility = "hidden";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

    }
    const options = {
        filter: true,
        filterType: 'dropdown',
        responsive: 'vertical',
        viewColumns: false,
        filterList: false,
        print: false,
        download: false,
        search: false,
        rowsPerPage: 100,
        selectableRows: "none",
        // onFilterReset: () => {
        //     return dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage))
        // },
        customToolbar: () => {
            if (batteryEditAccess === true) {
                return (
                    <><Tooltip style={{ flex: 'left' }} title={"Onboarding Battery"}>
                        <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                            setOpenAddBattery(true)
                        }}>
                            <Icon icon="fluent:phone-add-24-regular" height="22" width="22" />
                        </IconButton></Tooltip>
                        <Tooltip style={{ flex: 'left' }} title={"Download CSV"}>
                            <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                                onDownload()
                            }}>
                                <CloudDownload />
                            </IconButton></Tooltip>

                        {dataOn === true ? <Button style={{ width: '100px' }}
                            onClick={() => {
                                setDataOn(false)
                                setClear([])
                                setClear1([])
                                setClear2([])
                                setClear3([])
                                setClear4([])
                                setClear5([])
                                setClear6([])
                                setClear7([])
                                setClear8([])
                                setClear9([])
                                setClear10([])
                                setClear11([])
                                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                            }}>RESET</Button> : null}</>

                );
            }
            else {
                <>{dataOn === true ? <Button style={{ width: '100px' }}
                    onClick={() => {
                        setDataOn(false)
                        setClear([])
                        setClear1([])
                        setClear2([])
                        setClear3([])
                        setClear4([])
                        setClear5([])
                        setClear6([])
                        setClear7([])
                        setClear8([])
                        setClear9([])
                        setClear10([])
                        setClear11([])
                        dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                    }}>RESET</Button> : null}</>
            }

        }

    };

    const options1 = {
        filter: true,
        filterType: 'dropdown',
        responsive: 'vertical',
        viewColumns: false,
        print: false,
        search: false,
        selectableRows: "none",
        customToolbar: () => {
            if (batteryEditAccess === true) {
                return (
                    value === 1 ? <><Tooltip style={{ flex: 'left' }} title={"Onboarding Model"}>
                        <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                            setOpenAddModel(true)
                        }}>
                            <Icon icon="fluent:tab-add-24-filled" height="22" width="22" />
                        </IconButton></Tooltip>
                        <Tooltip style={{ flex: 'left' }} title={"Download CSV"}>
                            <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                                onDownloadModel()
                            }}>
                                <CloudDownload />
                            </IconButton></Tooltip>
                        {dataOn === true ?
                            <Button style={{ width: '100px' }}
                                onClick={() => {
                                    setDataOn(false)
                                    setClear([])
                                    setClear1([])
                                    setClear2([])
                                    setClear3([])
                                    setClear4([])
                                    setClear5([])
                                    setClear6([])
                                    setClear7([])
                                    setClear8([])
                                    setClear9([])
                                    setClear10([])
                                    setClear11([])
                                    setClear12([])
                                    setClear13([])
                                    setClear14([])
                                    dispatch(getBatteryModelBulk(modelPage));
                                }}>RESET</Button> : null}
                    </>
                        : <><Tooltip style={{ flex: 'left' }} title={"Onboarding Model"}>
                            <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                                setOpenAddBMS(true)
                            }}>
                                <Icon icon="carbon:gui-management" height="22" width="22" />
                            </IconButton></Tooltip>
                            <Tooltip style={{ flex: 'left' }} title={"Download CSV"}>
                                <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                                    onDownloadBMS()
                                }}>
                                    <CloudDownload />
                                </IconButton></Tooltip>
                            {dataOn === true ?
                                <Button style={{ width: '100px' }}
                                    onClick={() => {
                                        setDataOn(false)
                                        setClear([])
                                        setClear1([])
                                        setClear2([])
                                        dispatch(getBMSBulk(bmsPage))
                                    }}>RESET</Button> : null}</>
                );
            }
            else {
                return (
                    value === 1 ? <>
                        {dataOn === true ?
                            <Button style={{ width: '100px' }}
                                onClick={() => {
                                    setDataOn(false)
                                    setClear([])
                                    setClear1([])
                                    setClear2([])
                                    setClear3([])
                                    setClear4([])
                                    setClear5([])
                                    setClear6([])
                                    setClear7([])
                                    setClear8([])
                                    setClear9([])
                                    setClear10([])
                                    setClear11([])
                                    setClear12([])
                                    setClear13([])
                                    setClear14([])
                                    dispatch(getBatteryModelBulk(modelPage));
                                }}>RESET</Button> : null}
                    </>
                        : <>
                            {dataOn === true ?
                                <Button style={{ width: '100px' }}
                                    onClick={() => {
                                        setDataOn(false)
                                        setClear([])
                                        setClear1([])
                                        setClear2([])
                                        dispatch(getBMSBulk(bmsPage))
                                    }}>RESET</Button> : null}</>
                );
            }

        }

    };


    const handleChangeC = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked });
    };
    const handleChangeD = (event) => {
        setState1({ ...state, [event.target.name]: event.target.checked });
    };


    //Add Battery

    function getSteps() {
        return ['Identifiction', 'Association', 'Mobilize'];
    }

    function getStepContent(step) {
        switch (step) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>BMS Model</Typography>
                        <Select
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'bms_model_id')

                            }}
                            value={batteryAddForm.bms_model_id}
                            className={classes.textField}>

                            <MenuItem value="">Select BMS Model</MenuItem>
                            {BMSLMeta.data.length && BMSLMeta.data.map((bms) => {
                                return (
                                    <MenuItem
                                        // onClick={() => {
                                        //    bms[0] !== 0 ? allHV(bms[0]) :null
                                        // }} 
                                        value={bms[3]}>{bms[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Model</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <Select onChange={(e) => {
                            setBatteryAddFormArray(e, 'battery_model_id')
                        }}
                            error={addBatteryErrors && batteryAddForm.battery_model_id === ""}
                            value={batteryAddForm.battery_model_id}
                            className={classes.textField}>

                            <MenuItem value="">Select Battery Model</MenuItem>
                            {BatteryModelLMeta.data.length && BatteryModelLMeta.data.map((model) => {
                                return (
                                    <MenuItem value={model[5]}>{model[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Serial Number</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField error={addBatteryErrors && batteryAddForm.serial_number === ""}
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'serial_number')
                            }}
                            helperText={'Enter valid alphanumeric Serial Number without space'}
                            size="small" id="outlined" value={batteryAddForm.serial_number && batteryAddForm.serial_number.toUpperCase() && batteryAddForm.serial_number.toUpperCase().trim()} placeholder="eg: Serial Number" className={classes.textField} />
                    </Grid>

                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField error={addBatteryErrors && batteryAddForm.bms_unique_id === ""}
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'bms_unique_id')
                            }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={batteryAddForm.bms_unique_id && batteryAddForm.bms_unique_id.trim()} placeholder="eg: Unique Identifier" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>BMS Software Version</Typography>
                        <TextField
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'sw_version')
                            }}
                            size="small" id="outlined"
                            value={batteryAddForm.sw_version && batteryAddForm.sw_version.toUpperCase() && batteryAddForm.sw_version.toUpperCase().trim()}
                            placeholder="eg: BMS Software Version" className={classes.textField} />
                    </Grid></Grid>;
            case 1:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.styleL}>Fleet Name</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography> </div>
                        {enty1 === true ?
                            <Select
                                onChange={(e) => {
                                    setBatteryAddFormArray(e, 'entity_id', 'asset')
                                    setBatteryAddFormArray(e, 'entity_id', 'investors')
                                    setBatteryAddFormArray(e, 'entity_id', 'user')
                                    dispatch(getOMBulk(e.target.value));
                                    dispatch(getIV2Bulk(e.target.value));
                                }}
                                error={addBatteryErrors && (batteryAddForm.asset && batteryAddForm.asset.entity_id === "")}
                                value={batteryAddForm.asset && batteryAddForm.asset.entity_id &&
                                    batteryAddForm.investors && batteryAddForm.investors.entity_id && batteryAddForm.user && batteryAddForm.user.entity_id}
                                className={classes.textField}
                            >
                                <MenuItem value="">Select your Fleet First </MenuItem>
                                {FleetMeta.data.length && FleetMeta.data.map((fleet) => {
                                    return (
                                        <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>

                                    )
                                }
                                )}
                            </Select> :
                            <TextField
                                size="small" id="outlined" value={uName} className={classes.textField} />}
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Operation Manager</Typography>
                        {batteryAddForm.asset.entity_id === '' ? <Select
                            className={classes.textField}
                        >
                            <MenuItem value="">Select your Fleet</MenuItem>
                        </Select> :
                            OMMetaPresent === false ?
                                <Select
                                    className={classes.textField}
                                >
                                    <MenuItem value="">No Data</MenuItem>
                                </Select> : <Select
                                    onChange={(e) => { setBatteryAddFormArray(e, 'user_id', 'user') }}
                                    value={batteryAddForm.user && batteryAddForm.user.user_id}
                                    className={classes.textField}
                                >
                                    <MenuItem value="">Select your Manager</MenuItem>
                                    {OMMeta.length && OMMeta.map((om) => {
                                        return (
                                            <MenuItem value={om[1]}>{om[0]}</MenuItem>

                                        )
                                    }
                                    )}
                                </Select>}
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Investor</Typography>
                        {IV2MetaPresent === false ?
                            <Select
                                className={classes.textField}
                            >
                                <MenuItem value="">No Data</MenuItem>
                            </Select> :
                            <Select
                                onChange={(e) => { setBatteryAddFormArray(e, 'user_id', 'investors') }}
                                value={batteryAddForm.investors && batteryAddForm.investors.user_id}
                                className={classes.textField}
                            >
                                <MenuItem value="">Select your Investor</MenuItem>
                                {IV2Meta.data.length && IV2Meta.data.map((ivv) => {
                                    return (
                                        <MenuItem value={ivv[1]}>{ivv[0]}</MenuItem>

                                    )
                                }
                                )}
                            </Select>}
                    </Grid>
                </Grid>;
            case 2:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>
                            IMEI Number
                        </Typography>
                        <TextField
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'imei', 'telematics')
                            }}
                            size="small" id="outlined"
                            value={batteryAddForm.telematics && batteryAddForm.telematics.imei && batteryAddForm.telematics.imei.trim()}
                            className={classes.textField}
                            placeholder="eg:  imei"
                        />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>
                            Model Info
                        </Typography>
                        <Select onChange={(e) => {
                            setBatteryAddFormArray(e, 'telematics_data_id', 'telematics')
                        }}
                            // error={addBatteryErrors && batteryAddForm.model_info === ""}
                            value={batteryAddForm.telematics && batteryAddForm.telematics.telematics_data_id}
                            className={classes.textField}>

                            <MenuItem value="">Select Telematics Model</MenuItem>
                            {TeleModelMeta.data.length && TeleModelMeta.data.map((telem) => {
                                return (
                                    <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>SIM Operator</Typography>
                        <Select className={classes.textField}
                            onChange={(e) => { setBatteryAddFormArray(e, 'sim_operator', 'telematics') }}
                            // error={addBatteryErrors && cVAddForm.model_id === ""}
                            value={batteryAddForm.telematics && batteryAddForm.telematics.sim_operator}
                        >
                            <MenuItem value="">Select your Model</MenuItem>
                            <MenuItem value="Airtel">Airtel</MenuItem>
                            <MenuItem value="Jio">Jio</MenuItem>
                            <MenuItem value="VI">VI</MenuItem>
                        </Select>
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Mobile Number</Typography>
                        <TextField type="number"
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'mobile_number', 'telematics')
                            }}
                            value={batteryAddForm.telematics && batteryAddForm.telematics.mobile_number && batteryAddForm.telematics.mobile_number.trim()}
                            helperText={batteryAddForm.telematics && batteryAddForm.telematics.mobile_number != '' &&
                                !/^[0-9]{10}$/.test(batteryAddForm.telematics && batteryAddForm.telematics.mobile_number) ?
                                'Mobile number must be 10 digits' : null}
                            className={classes.textField}
                            placeholder="eg:  9876678666"
                        />
                    </Grid>

                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>DBC File Type</Typography>
                        <Select className={classes.textField}
                            onChange={(e) => { setBatteryAddFormArray(e, 'dbc_file_type', 'telematics') }}
                            value={batteryAddForm.telematics && batteryAddForm.telematics.dbc_file_type}
                        >
                            <MenuItem value="">Select your DBC</MenuItem>
                            <MenuItem value="REVX">REVX</MenuItem>
                            <MenuItem value="GREVOL">GREVOL</MenuItem>

                        </Select>
                    </Grid>

                </Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep, setActiveStep] = React.useState(0);
    const [completed, setCompleted] = React.useState({});
    const steps = getSteps();

    const totalSteps = () => steps.length;

    const completedSteps = () => Object.keys(completed).length;

    const isLastStep = () => activeStep === totalSteps() - 1;

    const allStepsCompleted = () => completedSteps() === totalSteps();

    const handleNext = () => {
        const newActiveStep = isLastStep() && !allStepsCompleted() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps.findIndex((step, i) => !(i in completed))
            : activeStep + 1;
        setActiveStep(newActiveStep);
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleStep = (step) => () => {
        setActiveStep(step);
    };

    const handleComplete = () => {
        const newCompleted = completed;
        newCompleted[activeStep] = true;
        setCompleted(newCompleted);
        handleNext();
    };

    const handleReset = () => {
        setActiveStep(0);
        setCompleted({});
    };

    //Edit Battery

    function getSteps1() {
        return ['Identifiction', 'Association', 'Mobilize'];
    }

    function getStepContent1(step1) {
        switch (step1) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>BMS Model</Typography>
                        <TextField disabled size="small" id="outlined" value={editBatArray.bms_model_info}
                            // onChange={(e) => { setEditBatteryFormArray(e, 'bms_model_id') }}
                            className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Model</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField disabled size="small" id="outlined" value={editBatArray.battery_model}
                            // onChange={(e) => { setEditBatteryFormArray(e, 'battery_model') }}
                            className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Serial Number</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                            helperText={'Enter valid alphanumeric Serial Number without space'}
                            size="small" id="outlined" value={editBatArray.serial_number && editBatArray.serial_number.toUpperCase() && editBatArray.serial_number.toUpperCase().trim()}
                            onChange={(e) => { setEditBatteryFormArray(e, 'serial_number') }}
                            className={classes.textField} />
                    </Grid>

                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField type="number"
                            // error={addBatteryErrors && editBatArray.bms_unique_id === ""} 
                            size="small" id="outlined" value={editBatArray.bms_unique_id && editBatArray.bms_unique_id.trim()}
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            onChange={(e) => { setEditBatteryFormArray(e, 'bms_unique_id') }} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>BMS Software Version</Typography>
                        <TextField size="small" id="outlined" value={editBatArray.sw_version && editBatArray.sw_version.trim()}
                            // error={addBatteryErrors && editBatArray.sw_version === ""}
                            onChange={(e) => { setEditBatteryFormArray(e, 'sw_version') }} className={classes.textField} />
                    </Grid></Grid>;
            case 1:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.styleL}>Fleet Name</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography> </div>
                        {/* {enty1 === true ? <Select
                            onChange={(e) => {
                                setEditBatteryFormArray(e, 'entity_id', 'asset')
                                dispatch(getOMBulk(e.target.value));
                            }}
                            value={editBatArray.asset && editBatArray.asset.entity_id}
                            className={classes.textField}
                        >
                            {FleetMeta.data.length && FleetMeta.data.map((fleet) => {
                                return (
                                    <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select> :
                            <TextField
                                size="small" id="outlined" value={uName} className={classes.textField} />} */}
                        <Select
                            onChange={(e) => {
                                setEditBatteryFormArray(e, 'entity_id', 'asset')
                                setEditBatteryFormArray(e, 'entity_id', 'investors')
                                setEditBatteryFormArray(e, 'entity_id', 'user')
                                dispatch(getOMBulk(e.target.value));
                                dispatch(getIV2Bulk(e.target.value));
                            }}
                            value={editBatArray.asset && editBatArray.asset.entity_id &&
                                editBatArray.investors && editBatArray.investors.entity_id && editBatArray.user && editBatArray.user.entity_id}
                            className={classes.textField}
                        >
                            {FleetMeta.data.length && FleetMeta.data.map((fleet) => {
                                return (
                                    <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Operation Manager</Typography>
                        {OMMetaPresent === false ?
                            <Select
                                className={classes.textField}
                            >
                                <MenuItem value="">No Data</MenuItem>
                            </Select> : <Select
                                onChange={(e) => { setEditBatteryFormArray(e, 'user_id', 'user') }}
                                value={editBatArray.user && editBatArray.user.user_id}
                                className={classes.textField}
                            >
                                {OMMeta.length && OMMeta.map((om) => {
                                    return (
                                        <MenuItem value={om[1]}>{om[0]}</MenuItem>

                                    )
                                }
                                )}
                            </Select>}

                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Investor</Typography>
                        {IV2MetaPresent === false ?
                            <Select
                                className={classes.textField}
                            >
                                <MenuItem value="">No Data</MenuItem>
                            </Select> : <Select
                                onChange={(e) => { setEditBatteryFormArray(e, 'user_id', 'investors') }}
                                value={editBatArray.investors && editBatArray.investors.user_id}
                                className={classes.textField}
                            >
                                {IV2Meta.data.length && IV2Meta.data.map((ivv) => {
                                    return (
                                        <MenuItem value={ivv[1]}>{ivv[0]}</MenuItem>

                                    )
                                }
                                )}
                            </Select>}
                    </Grid>
                </Grid>;
            case 2:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>
                            IMEI Number
                        </Typography>
                        <TextField
                            onChange={(e) => {
                                setEditBatteryFormArray(e, 'imei', 'telematics')
                            }}
                            size="small" id="outlined"
                            value={editBatArray.telematics && editBatArray.telematics.imei && editBatArray.telematics.imei.trim()}
                            className={classes.textField}
                        />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>
                            Model Info
                        </Typography>
                        <Select onChange={(e) => {
                            setEditBatteryFormArray(e, 'telematics_data_id', 'telematics')
                        }}
                            value={editBatArray.telematics && editBatArray.telematics.telematics_data_id}
                            className={classes.textField}>

                            {TeleModelMeta.data.length && TeleModelMeta.data.map((telem) => {
                                return (
                                    <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>SIM Operator</Typography>
                        <Select className={classes.textField}
                            onChange={(e) => { setEditBatteryFormArray(e, 'sim_operator', 'telematics') }}
                            value={editBatArray.telematics && editBatArray.telematics.sim_operator}
                        >
                            <MenuItem value="">Select your Model</MenuItem>
                            <MenuItem value="Airtel">Airtel</MenuItem>
                            <MenuItem value="Jio">Jio</MenuItem>
                            <MenuItem value="VI">VI</MenuItem>

                        </Select>
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Mobile Number</Typography>
                        <TextField
                            type="number"
                            onChange={(e) => {
                                setEditBatteryFormArray(e, 'mobile_number', 'telematics')
                            }}
                            value={editBatArray.telematics && editBatArray.telematics.mobile_number && editBatArray.telematics.mobile_number.trim()}
                            helperText={editBatArray.telematics && editBatArray.telematics.mobile_number != '' &&
                                !/^[0-9]{10}$/.test(editBatArray.telematics && editBatArray.telematics.mobile_number) ?
                                'Mobile number must be 10 digits' : null}
                            className={classes.textField}
                        />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>DBC File Type</Typography>
                        <Select className={classes.textField}
                            onChange={(e) => { setEditBatteryFormArray(e, 'dbc_file_type', 'telematics') }}
                            value={editBatArray.telematics && editBatArray.telematics.dbc_file_type}
                        >
                            <MenuItem value="">Select your Model</MenuItem>
                            <MenuItem value="REVX">REVX</MenuItem>
                            <MenuItem value="GREVOL">GREVOL</MenuItem>

                        </Select>
                    </Grid>

                </Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep1, setActiveStep1] = React.useState(0);
    const [completed1, setCompleted1] = React.useState({});
    const steps1 = getSteps1();

    const totalSteps1 = () => steps1.length;

    const completedSteps1 = () => Object.keys(completed1).length;

    const isLastStep1 = () => activeStep1 === totalSteps1() - 1;

    const allStepsCompleted1 = () => completedSteps1() === totalSteps1();

    const handleNext1 = () => {
        const newActiveStep1 = isLastStep1() && !allStepsCompleted1() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps1.findIndex((step1, i) => !(i in completed1))
            : activeStep1 + 1;
        setActiveStep1(newActiveStep1);
    };

    const handleBack1 = () => {
        setActiveStep1((prevActiveStep1) => prevActiveStep1 - 1);
    };

    const handleStep1 = (step1) => () => {
        setActiveStep1(step1);
    };

    const handleComplete1 = () => {
        const newCompleted1 = completed1;
        newCompleted1[activeStep1] = true;
        setCompleted1(newCompleted1);
        handleNext1();
    };

    const handleReset1 = () => {
        setActiveStep1(0);
        setCompleted1({});
    };
    //Add BMS
    function getSteps2() {
        return ['Identifiction'];
    }

    function getStepContent2(step2) {
        switch (step2) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>BMS Model Info</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setBMSAddFormArray(e, 'model_info')
                            }} error={addBatteryErrors && bmsAddForm.model_info === ""}
                            size="small" id="outlined"
                            value={bmsAddForm.model_info && bmsAddForm.model_info.toUpperCase() && bmsAddForm.model_info.toUpperCase().trim()}
                            placeholder="eg: BMS Model" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Hardware Version</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setBMSAddFormArray(e, 'hw_version')
                            }} error={addBatteryErrors && bmsAddForm.hw_version === ""}
                            size="small" id="outlined"
                            value={bmsAddForm.hw_version && bmsAddForm.hw_version.toUpperCase() && bmsAddForm.hw_version.toUpperCase().trim()}
                            placeholder="eg: Version" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>OEM</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setBMSAddFormArray(e, 'oem')
                            }} error={addBatteryErrors && bmsAddForm.oem === ""}
                            size="small" id="outlined"
                            value={bmsAddForm.oem && bmsAddForm.oem.toUpperCase() && bmsAddForm.oem.toUpperCase().trim()}
                            placeholder="eg: OEM" className={classes.textField} />
                    </Grid></Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep2, setActiveStep2] = React.useState(0);
    const [completed2, setCompleted2] = React.useState({});
    const steps2 = getSteps2();

    const totalSteps2 = () => steps2.length;

    const completedSteps2 = () => Object.keys(completed2).length;

    const isLastStep2 = () => activeStep2 === totalSteps2() - 1;

    const allStepsCompleted2 = () => completedSteps2() === totalSteps2();

    const handleNext2 = () => {
        const newActiveStep2 = isLastStep2() && !allStepsCompleted2() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps2.findIndex((step2, i) => !(i in completed2))
            : activeStep2 + 1;
        setActiveStep2(newActiveStep2);
    };

    const handleBack2 = () => {
        setActiveStep2((prevActiveStep2) => prevActiveStep2 - 1);
    };

    const handleStep2 = (step2) => () => {
        setActiveStep2(step2);
    };

    const handleComplete2 = () => {
        const newCompleted2 = completed2;
        newCompleted2[activeStep2] = true;
        setCompleted2(newCompleted2);
        handleNext2();
    };

    const handleReset2 = () => {
        setActiveStep2(0);
        setCompleted2({});
    };

    //Edit BMS
    function getSteps3() {
        return ['Identifiction'];
    }

    function getStepContent3(step) {
        switch (step) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>BMS Model Info</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setEditBmsFormArray(e, 'model_info')
                            }} error={addBatteryErrors && editBMSArray.model_info === ""}
                            size="small" id="outlined"
                            value={editBMSArray.model_info && editBMSArray.model_info.toUpperCase() && editBMSArray.model_info.toUpperCase().trim()}
                            placeholder="eg: BMS Model" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Hardware Version</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setEditBmsFormArray(e, 'hw_version')
                            }} error={addBatteryErrors && editBMSArray.hw_version === ""}
                            size="small" id="outlined"
                            value={editBMSArray.hw_version && editBMSArray.hw_version.toUpperCase() && editBMSArray.hw_version.toUpperCase().trim()}
                            placeholder="eg: Version" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>OEM</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setEditBmsFormArray(e, 'oem')
                            }} error={addBatteryErrors && editBMSArray.oem === ""}
                            size="small" id="outlined"
                            value={editBMSArray.oem && editBMSArray.oem.toUpperCase() && editBMSArray.oem.toUpperCase().trim()}
                            placeholder="eg: OEM" className={classes.textField} />
                    </Grid></Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep3, setActiveStep3] = React.useState(0);
    const [completed3, setCompleted3] = React.useState({});
    const steps3 = getSteps3();

    const totalSteps3 = () => steps3.length;

    const completedSteps3 = () => Object.keys(completed3).length;

    const isLastStep3 = () => activeStep3 === totalSteps3() - 1;

    const allStepsCompleted3 = () => completedSteps3() === totalSteps3();

    const handleNext3 = () => {
        const newActiveStep3 = isLastStep3() && !allStepsCompleted3() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps3.findIndex((step3, i) => !(i in completed3))
            : activeStep3 + 1;
        setActiveStep3(newActiveStep3);
    };

    const handleBack3 = () => {
        setActiveStep3((prevActiveStep3) => prevActiveStep3 - 1);
    };

    const handleStep3 = (step3) => () => {
        setActiveStep3(step3);
    };

    const handleComplete3 = () => {
        const newCompleted3 = completed3;
        newCompleted3[activeStep3] = true;
        setCompleted3(newCompleted3);
        handleNext3();
    };

    const handleReset3 = () => {
        setActiveStep3(0);
        setCompleted3({});
    };

    //Add battery Model

    function getSteps4() {
        return ['Identifiction', 'Power', 'Cells'];
    }

    function getStepContent4(step4) {
        switch (step4) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Model</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setModelAddFormArray(e, 'model_info')
                            }} error={addBatteryErrors && modelAddForm.model_info === ""}
                            size="small" id="outlined" value={modelAddForm.model_info} placeholder="eg: Battery Model" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Battery Type</Typography>
                        <Select
                            onChange={(e) => {
                                setModelAddFormArray(e, 'battery_type')
                            }}
                            value={modelAddForm.battery_type}
                            className={classes.textField}
                        >
                            <MenuItem value="Storage Battery">Storage Battery</MenuItem>
                            <MenuItem value="Mobility Battery">Mobility Battery</MenuItem>
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Manufacturer </Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'cell_maufacturer')
                        }}
                            error={addBatteryErrors && modelAddForm.cell_maufacturer === ""}

                            size="small" id="outlined" value={modelAddForm.cell_maufacturer} placeholder="eg: Manufacturer " className={classes.textField} />
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>OEM </Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'oem')
                        }}
                            size="small" id="outlined" value={modelAddForm.oem} placeholder="eg: OEM " className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Length (mm)</Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'length')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.length} placeholder="eg: Battery Length (mm)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Width (mm)</Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'width')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.width} placeholder="eg: Battery Width (mm)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Height (mm)</Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'height')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.height} placeholder="eg: Battery Height (mm)" className={classes.textField} />
                    </Grid>
                </Grid>;
            case 1:
                return <Grid container spacing={2}>
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Nominal Voltage (V)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'nominal_voltage')
                        }}
                            error={addBatteryErrors && modelAddForm.nominal_voltage === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.nominal_voltage} placeholder="eg: Nominal Voltage (V)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Capacity (Ah)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'capacity_mah')
                        }}
                            error={addBatteryErrors && modelAddForm.capacity_mah === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.capacity_mah} placeholder="eg: Capacity (Ah)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={3} />
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Power (Wh)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'power')
                        }}
                            error={addBatteryErrors && modelAddForm.power === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.power} placeholder="eg: Power (Wh)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Thermistor </Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                            error={addBatteryErrors && modelAddForm.thermistor === ""}

                            onChange={(e) => {
                                setModelAddFormArray(e, 'thermistor')
                            }}
                            size="small" id="outlined"
                            value={modelAddForm.thermistor}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            placeholder="eg: 12 " className={classes.textField} />
                    </Grid>
                </Grid>;
            case 2:
                return <Grid container spacing={2}>
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'number_of_cells_series')
                        }}
                            error={addBatteryErrors && modelAddForm.number_of_cells_series === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.number_of_cells_series} placeholder="eg: Number of Cells Series" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'number_of_cells_parallel')
                        }}
                            error={addBatteryErrors && modelAddForm.number_of_cells_parallel === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.number_of_cells_parallel} placeholder="eg: Number of Cells Parallel" className={classes.textField} />
                    </Grid>
                    <Grid item lg={3} />
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'cell_chemisty')
                        }}
                            error={addBatteryErrors && modelAddForm.cell_chemisty === ""}

                            size="small" id="outlined" value={modelAddForm.cell_chemisty} placeholder="eg: Cell Chemistry" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Cell Type</Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'cell_type')
                        }}
                            size="small" id="outlined" value={modelAddForm.cell_type} placeholder="eg: Cell Type" className={classes.textField} />
                    </Grid>
                    <Grid item lg={4.5} />

                </Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep4, setActiveStep4] = React.useState(0);
    const [completed4, setCompleted4] = React.useState({});
    const steps4 = getSteps4();

    const totalSteps4 = () => steps4.length;

    const completedSteps4 = () => Object.keys(completed4).length;

    const isLastStep4 = () => activeStep4 === totalSteps4() - 1;

    const allStepsCompleted4 = () => completedSteps4() === totalSteps4();

    const handleNext4 = () => {
        const newActiveStep4 = isLastStep4() && !allStepsCompleted4() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps4.findIndex((step4, i) => !(i in completed4))
            : activeStep4 + 1;
        setActiveStep4(newActiveStep4);
    };

    const handleBack4 = () => {
        setActiveStep4((prevActiveStep4) => prevActiveStep4 - 1);
    };

    const handleStep4 = (step4) => () => {
        setActiveStep4(step4);
    };

    const handleComplete4 = () => {
        const newCompleted4 = completed4;
        newCompleted4[activeStep4] = true;
        setCompleted4(newCompleted4);
        handleNext4();
    };

    const handleReset4 = () => {
        setActiveStep4(0);
        setCompleted4({});
    };

    //Edit Battery Model

    function getSteps5() {
        return ['Identifiction', 'Power', 'Cells'];
    }

    function getStepContent5(step5) {
        switch (step5) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Model</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setModelEditFormArray(e, 'model_info')
                            }}
                            error={addBatteryErrors && editArray.model_info === ""}

                            size="small" id="outlined"
                            value={editArray.model_info} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Battery Type</Typography>
                        <Select
                            onChange={(e) => {
                                setModelEditFormArray(e, 'battery_type')
                            }}
                            size="small" id="outlined" value={editArray.battery_type}
                            className={classes.textField}
                        >
                            <MenuItem value="Storage Battery">Storage Battery</MenuItem>
                            <MenuItem value="Mobility Battery">Mobility Battery</MenuItem>
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Manufacturer </Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'cell_maufacturer')
                        }}
                            error={addBatteryErrors && editArray.cell_maufacturer === ""}

                            size="small" id="outlined" value={editArray.cell_maufacturer} className={classes.textField} />
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>OEM </Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'oem')
                        }}
                            size="small" id="outlined" value={editArray.oem} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Length (mm) </Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'length')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.length} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Width (mm) </Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'width')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.width} className={classes.textField} />
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Height (mm) </Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'height')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.height} className={classes.textField} />
                    </Grid>
                </Grid >;
            case 1:
                return <Grid container spacing={2}>
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Nominal Voltage (V)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'nominal_voltage')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            error={addBatteryErrors && editArray.nominal_voltage === ""}
                            size="small" id="outlined" value={editArray.nominal_voltage} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Capacity (Ah)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'capacity_mah')
                        }}
                            error={addBatteryErrors && editArray.capacity_mah === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.capacity_mah} className={classes.textField} />
                    </Grid>
                    <Grid item lg={3} />
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Power (Wh)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'power')
                        }}
                            error={addBatteryErrors && editArray.power === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.power} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Thermistor </Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setModelEditFormArray(e, 'thermistor')
                            }}
                            error={addBatteryErrors && editArray.thermistor === ""}

                            size="small" id="outlined"
                            value={editArray.thermistor}
                            className={classes.textField} />
                    </Grid>
                </Grid>;
            case 2:
                return <Grid container spacing={2}>
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'number_of_cells_series')
                        }}
                            error={addBatteryErrors && editArray.number_of_cells_series === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.number_of_cells_series} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'number_of_cells_parallel')
                        }}
                            error={addBatteryErrors && editArray.number_of_cells_parallel === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.number_of_cells_parallel} className={classes.textField} />
                    </Grid>
                    <Grid item lg={3} />
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'cell_chemisty')
                        }}
                            error={addBatteryErrors && editArray.cell_chemisty === ""}

                            size="small" id="outlined" value={editArray.cell_chemisty} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Cell Type</Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'cell_type')
                        }}
                            size="small" id="outlined" value={editArray.cell_type} className={classes.textField} />
                    </Grid>
                    <Grid item lg={4.5} />

                </Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep5, setActiveStep5] = React.useState(0);
    const [completed5, setCompleted5] = React.useState({});
    const steps5 = getSteps5();

    const totalSteps5 = () => steps5.length;

    const completedSteps5 = () => Object.keys(completed5).length;

    const isLastStep5 = () => activeStep5 === totalSteps5() - 1;

    const allStepsCompleted5 = () => completedSteps5() === totalSteps5();

    const handleNext5 = () => {
        const newActiveStep5 = isLastStep5() && !allStepsCompleted5() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps5.findIndex((step5, i) => !(i in completed5))
            : activeStep5 + 1;
        setActiveStep5(newActiveStep5);
    };

    const handleBack5 = () => {
        setActiveStep5((prevActiveStep5) => prevActiveStep5 - 1);
    };

    const handleStep5 = (step5) => () => {
        setActiveStep5(step5);
    };

    const handleComplete5 = () => {
        const newCompleted5 = completed5;
        newCompleted5[activeStep5] = true;
        setCompleted5(newCompleted5);
        handleNext5();
    };

    const handleReset5 = () => {
        setActiveStep5(0);
        setCompleted5({});
    };

    return (
        <div
            // onMouseMove={() => setFrame(!frame)}
            className={classes.table}>
            <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />
            <Snackbar open={open} autoHideDuration={3000} onClose={handleClose}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                style={{ marginTop: '300px', marginLeft: '450px' }}
            >
                <Alert onClose={handleClose} severity="warning">
                    This battery assigned to {ddd}
                </Alert>
            </Snackbar>
            <Snackbar open={open1} autoHideDuration={3000} onClose={handleClose1}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                style={{ marginTop: '335px', marginLeft: '450px' }}
            >
                <Alert onClose={handleClose1} severity="warning">
                    This battery status is {ddd1}
                </Alert>
            </Snackbar>
            <Snackbar open={open2} autoHideDuration={3000} onClose={handleClose2}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                style={{ marginTop: '300px', marginLeft: '450px' }}
            >
                <Alert onClose={handleClose2} severity="warning">
                    This battery assigned to {ddd2}
                </Alert>
            </Snackbar>
            <Snackbar open={open3} autoHideDuration={3000} onClose={handleClose3}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                style={{ marginTop: '300px', marginLeft: '450px' }}
            >
                <Alert onClose={handleClose3} severity="success">
                    {ddd3}
                </Alert>
            </Snackbar>
            <Snackbar open={open4} autoHideDuration={3000} onClose={handleClose4}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                style={{ marginTop: '300px', marginLeft: '450px' }}
            >
                <Alert onClose={handleClose4} severity="warning">
                    {ddd4}
                </Alert>
            </Snackbar>
            <Typography className={classes.pageTitle} component="h4" variant="h4">Battery {screen === true ? 'Profile' :
                batDashboard === true ? 'Dashboard' : null}</Typography>
            <br />
            {BBFetching === true || MyBatteryFetching === true || BatteryTotalFetching === true || BDashboardFetching === true ||
                BatteryProFetching === true || BatteryModelFetching === true || BMSFetching === true ?
                <><br /><br /><br /><br /><br /><br /><Box sx={{ display: 'flex', justifyContent: 'space-around' }}>
                    <CircularProgress style={{ height: '100px', width: '100px' }} />
                </Box></>
                : <>
                    {screen === true || batDashboard === true ? null :
                        <Tabs
                            className={roid === "38" ? classes.tabsSection : classes.tabsSectionrr}
                            value={value}
                            onChange={handleChange}
                            variant="fullWidth"
                            indicatorColor="primary"
                            aria-label="icon tabs example"
                        >
                            <Tab label="Battery" onClick={() => {
                                setScreen(false)
                            }} icon={<Icon icon="ic:baseline-battery-charging-full" width="22" height="22" />} aria-label="favorite" />
                            {roid === "38" ? <Tab label="Battery Model" onClick={() => {
                                setScreen(false)
                            }} icon={<Icon icon="material-symbols:tab-outline" width="22" height="22" />} aria-label="phone" /> : null}
                            {roid === "38" ? <Tab label="BMS Model" onClick={() => {
                                setScreen(false)
                            }} icon={<Icon icon="carbon:gui-management" height="22" width="22" />} aria-label="phone" /> : null}

                        </Tabs>}

                    <Paper square className={classes.root}>
                        {csvDownload === 0 ? <LinearProgress /> : null}
                    </Paper>
                    {(screen === true
                        // && (
                        // MyBatteryMetaPresent &&
                        // BatteryModelMetaPresent)
                    ) ?
                        ((BatteryProMeta.data && BatteryProMetaPresent) ?
                            (
                                <>
                                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                        <Button
                                            onClick={() => {
                                                setScreen(false)
                                                setBatDashboard(true)
                                            }} variant="contained" startIcon={<Icon icon="material-symbols:arrow-back" />} color="primary">
                                            Dashboard
                                        </Button>
                                        {/* <Button
                                                onClick={() => {
                                                    setScreen(false)
                                                    setBatDashboard(false)
                                                }}
                                                variant="contained" endIcon={<Icon icon="material-symbols:arrow-back" rotate={2} />} color="secondary">
                                                Close
                                            </Button> */}
                                    </div>
                                    <br />
                                    <div className={classes.BNcover}><div className={classes.BNopt}>
                                        {/* <a
                         ref={input}
                         href={csvUrl}
                         download="filename.csv"
                       >link</a> */}
                                        {csvDownload === 0 ?
                                            <IconButton className={classes.BNbutton} >
                                                <Icon icon="line-md:downloading-loop" color="white" width="30" height="30" />
                                            </IconButton> :
                                            csvDownload === 1 ?
                                                <IconButton className={classes.BNbutton}

                                                    onClick={() => {
                                                        downloadCsv()
                                                        setCsvDownload(0)
                                                    }} >
                                                    <Icon icon="fa:cloud-download" color="white" width="30" height="30" />
                                                </IconButton>


                                                :

                                                null
                                        }

                                        <IconButton onClick={() => {
                                            setValue(0)
                                            setScreen(false)
                                        }} className={classes.BNbutton} >
                                            <Icon icon="bi:arrow-left-circle-fill" width="26" height="26" />
                                        </IconButton>
                                    </div>
                                        <div className={classes.BNcontent}>
                                            <div style={{ display: 'flex', justifyContent: 'center' }}>
                                                <Avatar className={classes.BNavatar}>
                                                    <Icon icon="mdi:car-battery" width="36" height="36" />
                                                </Avatar></div>
                                            <Typography className={classes.BNname} gutterBottom>
                                                {validateKeyData(serial)}
                                            </Typography>
                                            <Typography className={classes.BNname} gutterBottom>
                                                {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_model"])}
                                            </Typography>
                                            <Typography className={classes.BNname} gutterBottom>
                                                {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["last_created_at"])}
                                            </Typography>
                                        </div></div>

                                    <AppBar position="static" className={classes.BNprofileTab}>
                                        <Tabs
                                            value={value}
                                            onChange={handleChangeT}
                                            variant="fullWidth"
                                            indicatorColor="primary"
                                            textColor="primary"
                                            centered

                                        >
                                            <Tab icon={<Icon icon="bxs:battery-charging" width="24" height="24" />} label="About" />
                                            <Tab icon={<Icon icon="ant-design:line-chart-outlined" width="24" height="24" />} label="Analytics" />
                                            <Tab icon={<Icon icon="ic:round-photo-library" width="24" height="24" />} label="Parameters" />
                                        </Tabs>
                                    </AppBar>
                                    {BatteryProMeta.data && value === 0 &&
                                        <TabContainer><br />
                                            <Grid container spacing={2}>
                                                <Grid item xs={12} lg={6}>
                                                    <Grid container spacing={2}>
                                                        <Grid item xs={12} lg={12}>
                                                            <Paper>
                                                                <ListItem>
                                                                    <ListItemAvatar>
                                                                        <Avatar className={classes.BNavatar1}>
                                                                            <Icon icon="mdi:car-battery" color="#82e219" width="26" height="26" />
                                                                        </Avatar>
                                                                    </ListItemAvatar>

                                                                    <ListItemText primary={
                                                                        <Typography className={classes.BNaboutTxt}>About</Typography>
                                                                    }
                                                                        secondary={
                                                                            <React.Fragment>
                                                                                <Typography className={classes.BNaboutTxt1} >
                                                                                    <b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
                                                                                        {validateKeyData(serial)}</b> of {BatteryProMeta.data && validateKeyData(BatteryProMeta.data && BatteryProMeta.data[0]["battery_model"])}  <br /> OnBoarded on {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["created_at"])}&nbsp;
                                                                                    by&nbsp;<b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
                                                                                        {BatteryProMeta.data && validateKeyData(BatteryProMeta.data && BatteryProMeta.data[0]["fleet_name"])}  </b></Typography>
                                                                            </React.Fragment>

                                                                        }
                                                                    />
                                                                </ListItem><Divider className={classes.BNdivider} />
                                                                <Grid container spacing={1} className={classes.BNgrid}>
                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar className={classes.BNavatar1}>
                                                                                    <Icon icon="ion:hardware-chip-sharp" color="#82e219" width="24" height="24" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>HW Version</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            imei={imei}
                                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["hardware_version"])}</Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>
                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar className={classes.BNavatar1}>
                                                                                    <Icon icon="eos-icons:software-outlined" color="#82e219" width="24" height="24" />                                    </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>SW Version</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["software_version"])}</Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>
                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar className={classes.BNavatar1}>
                                                                                    <Icon icon="emojione-monotone:high-voltage" color="#82e219" width="24" height="24" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Battery Nominal Voltage</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["nominal_voltage"])}</Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>
                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar className={classes.BNavatar1}>
                                                                                    <Icon icon="mdi:chemical-weapon" color="#82e219" width="24" height="24" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Battery Chemistry</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["cell_chemisty"])}</Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>
                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar className={classes.BNavatar1}>
                                                                                    <Icon icon="carbon:cost-total" color="#82e219" width="24" height="24" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Battery pack Capacity</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["capacity_mah"])}</Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>
                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar className={classes.BNavatar1}>
                                                                                    <Icon icon="uil:cell" color="#82e219" width="24" height="24" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Cells in Series</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={classes.secondaryTextG}>
                                                                                            {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["number_of_cells_series"])}
                                                                                        </Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>
                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar className={classes.BNavatar1}>
                                                                                    <Icon icon="uil:cell" color="#82e219" width="24" height="24" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Thermistor</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={classes.secondaryTextG}>
                                                                                            {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["thermistor"])}

                                                                                        </Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>
                                                                </Grid>
                                                            </Paper>

                                                        </Grid>
                                                        <Grid item xs={12} lg={12}>
                                                            <Paper>
                                                                <ListItem>
                                                                    <ListItemAvatar>
                                                                        <Avatar className={classes.BNavatar1}>
                                                                            <Icon icon="bi:flag-fill" color="#82e219" />
                                                                        </Avatar>
                                                                    </ListItemAvatar>

                                                                    <ListItemText primary={
                                                                        <Typography className={classes.BNprimaryText}>Voltage & Temperature</Typography>
                                                                    } />
                                                                </ListItem>
                                                                <Grid container spacing={1}>
                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar style={{
                                                                                    backgroundColor:
                                                                                        BatteryProMeta.data[0]["min_cell_voltage_color"] === "amber" ? '#FFBF00' :
                                                                                            BatteryProMeta.data[0]["min_cell_voltage_color"] === "green" ? '#68A724' :
                                                                                                '#FF0000'
                                                                                }}>
                                                                                    <Icon icon="emojione-monotone:high-voltage" color="white" width="24" height="24" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>
                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Min Voltage</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={
                                                                                                BatteryProMeta.data[0]["min_cell_voltage_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_voltage_color"] === "green" ? classes.voltageG : classes.voltageR}>

                                                                                            {validateKeyData(BatteryProMeta.data[0]["min_voltage_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["min_voltage"])}&nbsp;V&nbsp;
                                                                                        </Typography>

                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>

                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar style={{
                                                                                    backgroundColor:
                                                                                        BatteryProMeta.data[0]["max_cell_voltage_color"] === "amber" ? '#FFBF00' :
                                                                                            BatteryProMeta.data[0]["max_cell_voltage_color"] === "green" ? '#68A724' :
                                                                                                '#FF0000'
                                                                                }}>
                                                                                    <Icon icon="emojione-monotone:high-voltage" color="white" width="24" height="24" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Max Voltage</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={BatteryProMeta.data[0]["max_cell_voltage_color"] === "green" ? classes.voltageG : BatteryProMeta.data[0]["max_cell_voltage_color"] === "amber" ? classes.voltageY : classes.voltageR}>
                                                                                            {validateKeyData(BatteryProMeta.data[0]["max_voltage_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["max_voltage"])}&nbsp;V
                                                                                        </Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>

                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar style={{
                                                                                    backgroundColor:
                                                                                        BatteryProMeta.data[0]["min_cell_temp_color"] === "amber" ? '#FFBF00' :
                                                                                            BatteryProMeta.data[0]["min_cell_temp_color"] === "green" ? '#68A724' :
                                                                                                '#FF0000'
                                                                                }}>
                                                                                    <Icon icon="fa:thermometer" color="white" width="22" height="22" /></Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Min Temperature</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={
                                                                                                BatteryProMeta.data[0]["min_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                                            {validateKeyData(BatteryProMeta.data[0]["min_temperature_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["min_temperature"])}&nbsp;ºC
                                                                                        </Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>

                                                                    <Grid xs={12} lg={6}>
                                                                        <ListItem>
                                                                            <ListItemAvatar>
                                                                                <Avatar style={{
                                                                                    backgroundColor:
                                                                                        BatteryProMeta.data[0]["max_cell_temp_color"] === "amber" ? '#FFBF00' :
                                                                                            BatteryProMeta.data[0]["max_cell_temp_color"] === "green" ? '#68A724' :
                                                                                                '#FF0000'
                                                                                }}>
                                                                                    <Icon icon="fa:thermometer" color="white" width="22" height="22" />
                                                                                </Avatar>
                                                                            </ListItemAvatar>

                                                                            <ListItemText primary={
                                                                                <Typography className={classes.BNprimaryText}>Max Temperature</Typography>
                                                                            }
                                                                                secondary={
                                                                                    <React.Fragment>
                                                                                        <Typography
                                                                                            className={
                                                                                                BatteryProMeta.data[0]["max_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["max_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                                            {validateKeyData(BatteryProMeta.data[0]["max_temperature_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["max_temperature"])}&nbsp;ºC
                                                                                        </Typography>
                                                                                    </React.Fragment>

                                                                                }
                                                                            />
                                                                        </ListItem>
                                                                    </Grid>
                                                                </Grid>
                                                            </Paper>

                                                        </Grid>
                                                    </Grid></Grid>
                                                <Grid item xs={12} lg={6}>
                                                    <Grid container spacing={2}>
                                                        <Grid item xs={12} lg={12}>
                                                            <Paper style={{ height: '225px' }}>
                                                                <div style={{ display: 'flex', marginLeft: 10 }}>
                                                                    <Typography style={{
                                                                        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px',
                                                                        fontWeight: 600, color: 'primary', width: '200px', marginTop: 1
                                                                    }}>Battery Current</Typography>
                                                                    <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_current"])}</Typography> </div>

                                                                <div style={{ display: 'flex', margin: 10 }}>
                                                                    <Typography style={{
                                                                        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px',
                                                                        fontWeight: 600, color: 'primary', width: '200px', marginTop: 1
                                                                    }}>Battery Voltage</Typography>
                                                                    <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_voltage"])}</Typography>
                                                                </div>

                                                                <div style={{ display: 'flex', margin: 10 }}>
                                                                    <Typography style={{
                                                                        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px',
                                                                        fontWeight: 600, color: 'primary', width: '200px', marginTop: 1
                                                                    }}>Battery State</Typography>
                                                                    <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["current_state"])}</Typography>
                                                                </div>

                                                                <br />
                                                                <Grid container spacing={2}>
                                                                    <Grid item xs={12} lg={6}><Paper
                                                                        className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNstyledPaper :
                                                                            BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNstyledPaper2 : classes.BNstyledPaper3}
                                                                        elevation={4}>
                                                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                                            <Typography className={classes.BNstateText}>State Of Health
                                                                            </Typography>
                                                                            <Chip
                                                                                avatar={(
                                                                                    <Avatar className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNchip :
                                                                                        BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNchip2 : classes.BNchip3} >
                                                                                        <Icon icon="ant-design:check-circle-outlined" color="white" width="24" height="24" />
                                                                                    </Avatar>
                                                                                )}
                                                                                label={BatteryProMeta.data[0]["soh"] + "% Progress"}
                                                                            />
                                                                        </div>
                                                                        <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soh"])} />
                                                                    </Paper></Grid>
                                                                    <Grid item xs={12} lg={6}> <Paper
                                                                        className={classes.BNstyledPaper}
                                                                        elevation={4}>
                                                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                                            <Typography className={classes.BNstateText}>State Of Charge
                                                                            </Typography>
                                                                            <Chip
                                                                                avatar={(
                                                                                    <Avatar className={classes.BNchip}
                                                                                    >
                                                                                        <Icon icon="ant-design:check-circle-outlined" color="white" width="24" height="24" />
                                                                                    </Avatar>
                                                                                )}
                                                                                label={BatteryProMeta.data[0]["soc"] + "% Progress"}
                                                                            />
                                                                        </div>
                                                                        <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soc"])} />
                                                                    </Paper></Grid>
                                                                </Grid>


                                                            </Paper>
                                                        </Grid>
                                                        <Grid item xs={12} lg={12}>
                                                            <Paper className={classes.BNmap} variant="outlined" >
                                                                <SimpleMap
                                                                    zoom={13} bmsid={bmsid}
                                                                    mapRes={BatteryProMeta.data[0]["last_one_hour_lat_lon"]}
                                                                /></Paper>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>


                                            </Grid>

                                        </TabContainer>}
                                    {value === 1 && <TabContainer>
                                        <div style={{ display: 'flex' }}><Generic imei={imei} /></div>
                                    </TabContainer>}
                                    {value === 2 && <TabContainer><br />
                                        <div style={{ border: '5px solid #77b93e' }}>
                                            <TreeTable imei={imei} />
                                        </div>
                                    </TabContainer>}



                                </>
                            ) :
                            (<>
                                <IconButton onClick={() => {
                                    setValue(0)
                                    setScreen(false)
                                }} className={classes.BNbutton} >
                                    <Icon icon="bi:arrow-left-circle-fill" width="26" height="26" color="#77b93e" />
                                </IconButton><br />
                                {/* <Typography style={{fontSize:'30px', marginTop:50}}>No Data Found</Typography> */}
                                <img src={nodata} style={{ marginLeft: 350 }} />
                            </>))
                        :
                        batDashboard === true ?
                            <>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <Button
                                        onClick={() => {
                                            setBatDashboard(false)
                                        }} variant="contained" startIcon={<Icon icon="material-symbols:arrow-back" />} color="primary">
                                        Back
                                    </Button>
                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                        <div style={{ display: 'flex', flexDirection: 'column' }}><Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '16px', display: 'flex' }}>
                                            <p style={{ color: '#000' }}>Current Timestamp&nbsp;:&nbsp;</p>{BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["last_created_at"])}</Typography>
                                            <Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '16px', display: 'flex' }}>
                                                <p style={{ color: '#000' }}>Onboard Timestamp:&nbsp;</p>{BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["created_at"])}</Typography></div>
                                        <IconButton onClick={() => {
                                            DashboardList(imei)
                                        }}  ><Icon icon="fa:refresh" color="#77B93E" width="16" height="16" /></IconButton></div>
                                    {/* <Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '16px', display:'flex', alignItems: 'baseline' }}>
                                        {BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["created_at"])}</Typography> */}
                                    <Button
                                        onClick={() => {
                                            setScreen(true)
                                            setBatDashboard(false)
                                            batteryProfile(imei)
                                        }} variant="contained" endIcon={<Icon icon="material-symbols:arrow-back" rotate={2} />} color="primary" >
                                        Profile
                                    </Button>
                                </div>
                                <br />
                                {BDashboardMeta.data && BDashboardMetaPresent ?
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} lg={9}>
                                            <Item>
                                                <Grid container spacing={2}
                                                    style={{ backgroundColor: '#FFFFFF', borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                    <Grid xs={12} lg={5}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="ic:baseline-battery-charging-90" color="#000" width="24" height="24" />
                                                                </Avatar>
                                                            </ListItemAvatar>
                                                            <ListItemText
                                                                onClick={() => {
                                                                    setScreen(true)
                                                                    setBatDashboard(false)
                                                                    batteryProfile(imei)
                                                                }}
                                                                primary={<Typography style={{ color: '#000', fontWeight: 600, fontSize: '18px' }}>{serial}</Typography>}
                                                                secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '16px' }}>Battery ID</Typography>} />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={4}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="icon-park-outline:flashlamp" color="#000" width="24" height="24" />
                                                                </Avatar>
                                                            </ListItemAvatar>
                                                            <ListItemText primary={<Typography style={{ color: '#000', fontWeight: 600, fontSize: '18px' }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["battery_voltage"])}V</Typography>}
                                                                secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '16px' }}>Battery Voltage</Typography>} />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={3}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="icon-park-outline:flashlamp" color="#000" width="24" height="24" />
                                                                </Avatar>
                                                            </ListItemAvatar>
                                                            <ListItemText primary={<Typography style={{ color: '#000', fontWeight: 600, fontSize: '18px' }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["battery_current"])}</Typography>}
                                                                secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '16px' }}>Battery Current</Typography>} />
                                                        </ListItem>
                                                    </Grid>
                                                </Grid>
                                            </Item>
                                            <br />
                                            <Grid container spacing={2}>
                                                <Grid item xs={12} lg={4}>
                                                    <ListItem style={{ backgroundColor: '#0FA2C2', borderRadius: '10px' }}>
                                                        <ListItemText primary={<Typography style={{ color: '#fff', fontWeight: 600, fontSize: '24px' }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["soc"])}%</Typography>}
                                                            secondary={<Typography style={{ color: '#fff', fontWeight: 500, fontSize: '18px' }}>SOC</Typography>} />
                                                        <ListItemAvatar>
                                                            <Icon icon="ps:battery-charge" color="#fff" width="32" height="32" />
                                                        </ListItemAvatar>
                                                    </ListItem>
                                                </Grid>
                                                <Grid item xs={12} lg={4}>
                                                    <ListItem style={{ backgroundColor: '#0FA2C2', borderRadius: '10px' }}>
                                                        <ListItemText primary={<Typography style={{ color: '#fff', fontWeight: 600, fontSize: '24px' }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["soh"])}%</Typography>}
                                                            secondary={<Typography style={{ color: '#fff', fontWeight: 500, fontSize: '18px' }}>SOH</Typography>} />
                                                        <ListItemAvatar>
                                                            <Icon icon="mdi:high-voltage-outline" color="#fff" width="32" height="32" />
                                                        </ListItemAvatar>
                                                    </ListItem>
                                                </Grid>
                                                <Grid item xs={12} lg={4}>
                                                    <ListItem style={{ backgroundColor: '#0FA2C2', borderRadius: '10px' }}>
                                                        <ListItemText primary={<Typography style={{ color: '#fff', fontWeight: 600, fontSize: '24px' }}>{BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["current_state"])}</Typography>}
                                                            secondary={<Typography style={{ color: '#fff', fontWeight: 500, fontSize: '18px' }}>State</Typography>} />
                                                        <ListItemAvatar>
                                                            <Icon icon="pajamas:status-health" color="#fff" width="32" height="32" />
                                                        </ListItemAvatar>
                                                    </ListItem>
                                                </Grid>
                                            </Grid><br />
                                            <Item>
                                                <Grid container spacing={2}
                                                    style={{ backgroundColor: '#FFFFFF', borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                    <Grid item xs={12} lg={12}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="material-symbols:warning" color="#000" width="20" height="20" />
                                                                </Avatar>
                                                            </ListItemAvatar>
                                                            {/* {BDashboardMeta.data && BDashboardMeta.data[0].Warning.length && BDashboardMeta.data[0].Warning.map((warn) => {
                                                    return (
                                                        <Chip label={warn.w_status} style={{ backgroundColor: "#FFBF00", color: "#fff" }} /> 
                                                    );
                                                })} */}
                                                            <ListItemText secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '16px',width:'100%', whiteSpace:'wrap'}}>Warning -&nbsp; 
                                                                {BDashboardMeta.data && BDashboardMeta.data[0].Warning.length && BDashboardMeta.data[0].Warning.map((warn) => {
                                                                    return (
                                                                        <>
                                                                        <Chip label={warn.w_status} style={{ backgroundColor: "#FFBF00", color: "#fff", marginBottom:'5px' }} />&nbsp;
                                                                        </>
                                                                    );
                                                                })}
                                                            </Typography>} />
                                                        </ListItem>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="cib:server-fault" color="#000" width="20" height="20" />
                                                                </Avatar>
                                                            </ListItemAvatar>
                                                            <ListItemText secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '16px',width:'100%', whiteSpace:'wrap' }}>Fault -&nbsp;
                                                            {BDashboardMeta.data && BDashboardMeta.data[0].Fault.length && BDashboardMeta.data[0].Fault.map((fal) => {
                                                                    return (
                                                                        <><Chip label={fal.f_status} style={{ backgroundColor: "#FF0000", color: "#fff" , marginBottom:'5px'}} />&nbsp;</>
                                                                    );
                                                                })}</Typography>} />
                                                        </ListItem>
                                                    </Grid>
                                                </Grid>
                                            </Item>
                                            <br />
                                            <Grid container spacing={2}>
                                                <Grid item xs={12} lg={6}>
                                                    <Item style={{ borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                        <Typography style={{ fontStyle: '18px', fontWeight: 600, color: '#77B93E' }}>Battery Current</Typography>
                                                        <BatteryCurrent imei={imei} />
                                                    </Item>
                                                </Grid>
                                                <Grid item xs={12} lg={6}>
                                                    <Item style={{ borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                        <Typography style={{ fontStyle: '18px', fontWeight: 600, color: '#77B93E' }}>Battery Voltage</Typography>
                                                        <BatteryVoltage imei={imei} />
                                                    </Item>
                                                </Grid>
                                                <Grid item xs={12} lg={6}>
                                                    <Item style={{ borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                        <Typography style={{ fontStyle: '18px', fontWeight: 600, color: '#77B93E' }}>Cell Voltage</Typography>
                                                        <CellVolt imei={imei} />
                                                    </Item>
                                                </Grid>
                                                <Grid item xs={12} lg={6}>
                                                    <Item style={{ borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                        <Typography style={{ fontStyle: '18px', fontWeight: 600, color: '#77B93E' }}>Cell Temperature</Typography>
                                                        <CellTemp imei={imei} />
                                                    </Item>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                        <Grid item xs={12} lg={3}>
                                            <Item>
                                                <Grid container spacing={2}
                                                    style={{ display: 'flex', alignItems: 'center', backgroundColor: '#FFFFFF', borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                    <Grid item xs={12}>
                                                        <Typography style={{ fontStyle: '18px', fontWeight: 600, color: '#77B93E', marginTop: 3 }}>Cell Temperature</Typography>
                                                    </Grid>
                                                    <Grid item xs={3}>
                                                        <ListItemAvatar>
                                                            <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                <Icon icon="carbon:temperature-celsius" color="#000" width="24" height="24" />
                                                            </Avatar>
                                                        </ListItemAvatar>
                                                    </Grid>
                                                    <Grid item xs={9}>
                                                        <Grid container spacing={2}>
                                                            <Grid item xs={6}>
                                                                <ListItemText primary={<Typography style={{
                                                                    textTransform: 'capitalize',
                                                                    color:
                                                                        BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["max_cell_temp_color"]) === "green" ? '#68A724' :
                                                                            "red" ? '#FF0000' : "amber" ? '#FFBF00' : '#000', fontWeight: 600, fontSize: '16px'
                                                                }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["max_temperature"])}°C&nbsp;|&nbsp;
                                                                    {BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["max_temperature_cell"])}</Typography>}
                                                                    secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '14px' }}>Max</Typography>} />
                                                            </Grid>
                                                            <Grid item xs={6}>
                                                                <ListItemText primary={<Typography style={{
                                                                    textTransform: 'capitalize',
                                                                    color:
                                                                        BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["min_cell_temp_color"]) === "green" ? '#68A724' :
                                                                            "red" ? '#FF0000' : "amber" ? '#FFBF00' : '#000', fontWeight: 600, fontSize: '16px'
                                                                }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["min_temperature"])}°C&nbsp;|&nbsp;
                                                                    {BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["min_temperature_cell"])}</Typography>}
                                                                    secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '14px' }}>Min</Typography>} />
                                                            </Grid>
                                                            <Grid item xs={6}>
                                                                <ListItemText primary={<Typography style={{ color: '#000', fontWeight: 600, fontSize: '16px' }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["cell_temparature_delta"])}°C</Typography>}
                                                                    secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '14px' }}>Delta</Typography>} />
                                                            </Grid>
                                                            <Grid item xs={6}>
                                                                <ListItemText primary={<Typography style={{ color: '#000', fontWeight: 600, fontSize: '16px' }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["cell_temparature_ambinet"])}</Typography>}
                                                                    secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '14px' }}>Ambient</Typography>} />
                                                            </Grid>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>
                                            </Item>
                                            <br />
                                            <Item>
                                                <Grid container spacing={2}
                                                    style={{ display: 'flex', alignItems: 'center', backgroundColor: '#FFFFFF', borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                    <Grid item xs={12}>
                                                        <Typography style={{ fontStyle: '18px', fontWeight: 600, color: '#77B93E', marginTop: 3 }}>Cell Voltage</Typography>
                                                    </Grid>
                                                    <Grid item xs={3}>
                                                        <ListItemAvatar>
                                                            <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                <Icon icon="emojione-monotone:high-voltage" color="#000" width="24" height="24" />
                                                            </Avatar>
                                                        </ListItemAvatar>
                                                    </Grid>
                                                    <Grid item xs={9}>
                                                        <Grid container spacing={2}>
                                                            <Grid item xs={12}>
                                                                <ListItemText primary={<Typography style={{
                                                                    textTransform: 'capitalize',
                                                                    color:
                                                                        BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["max_cell_voltage_color"]) === "green" ? '#68A724' :
                                                                            "red" ? '#FF0000' : "amber" ? '#FFBF00' : '#000', fontWeight: 600, fontSize: '16px'
                                                                }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["max_voltage"])}V&nbsp;|&nbsp;
                                                                    {BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["max_voltage_cell"])}</Typography>}
                                                                    secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '14px' }}>Max</Typography>} />
                                                            </Grid>
                                                            <Grid item xs={8}>
                                                                <ListItemText primary={<Typography style={{
                                                                    textTransform: 'capitalize',
                                                                    color:
                                                                        BDashboardMeta.data && validateKeyData(BDashboardMeta.data[0]["min_cell_voltage_color"]) === "green" ? '#68A724' :
                                                                            "red" ? '#FF0000' : "amber" ? '#FFBF00' : '#000', fontWeight: 600, fontSize: '16px'
                                                                }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["min_voltage"])}V&nbsp;|&nbsp;
                                                                    {BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["min_voltage_cell"])}</Typography>}
                                                                    secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '14px' }}>Min</Typography>} />
                                                            </Grid>
                                                            <Grid item xs={4}>
                                                                <ListItemText primary={<Typography style={{ color: '#000', fontWeight: 600, fontSize: '16px' }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["cell_voltage_delta"])}mV</Typography>}
                                                                    secondary={<Typography style={{ color: '#77B93E', fontWeight: 600, fontSize: '14px' }}>Delta</Typography>} />
                                                            </Grid>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>
                                            </Item>
                                            <br />
                                            <Item>
                                                <Grid container spacing={2}
                                                    style={{ backgroundColor: '#FFFFFF', borderRadius: '15px', border: '1px solid #77B93E' }}>
                                                    <Grid item xs={12}>
                                                        <Typography style={{ fontStyle: '18px', fontWeight: 600, color: '#77B93E' }}>Parameters</Typography><br />
                                                        <Grid container spacing={2} style={{ marginTop: 4 }}>
                                                            <Grid item xs={12} lg={2} md={2}>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="mdi:battery-recycle" color="#000" width="20" height="20" />
                                                                </Avatar>
                                                            </Grid>
                                                            <Grid item xs={12} lg={6} md={6}>
                                                                <Typography style={{ color: '#77B93E', fontWeight: 600, marginTop: 1 }}>Battery Cycle Count</Typography>
                                                            </Grid>
                                                            <Grid item xs={12} lg={4} md={4}>
                                                                <Chip label={<Typography style={{ fontWeight: 600 }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["battery_cycle_count"])}</Typography>} color="primary" style={{ borderRadius: 0, width: '100%' }} />
                                                            </Grid>
                                                        </Grid><br />
                                                        <Grid container spacing={2} style={{ marginTop: 4 }}>
                                                            <Grid item xs={12} lg={2} md={2}>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="ri:battery-2-charge-fill" color="#000" width="20" height="20" />
                                                                </Avatar>
                                                            </Grid>
                                                            <Grid item xs={12} lg={6} md={6}>
                                                                <Typography style={{ color: '#77B93E', fontWeight: 600, marginTop: 5 }}>Total Charge Ah</Typography>
                                                            </Grid>
                                                            <Grid item xs={12} lg={4} md={4}>
                                                                <Chip label={<Typography style={{ fontWeight: 600 }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["total_charge"])}</Typography>} color="primary" style={{ borderRadius: 0, width: '100%' }} />
                                                            </Grid>
                                                        </Grid><br />
                                                        <Grid container spacing={2} style={{ marginTop: 4 }}>
                                                            <Grid item xs={12} lg={2} md={2}>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="material-symbols:output-circle" color="#000" width="20" height="20" />
                                                                </Avatar>
                                                            </Grid>
                                                            <Grid item xs={12} lg={6} md={6}>
                                                                <Typography style={{ color: '#77B93E', fontWeight: 600, marginTop: 4 }}>Total Discharge Ah</Typography>
                                                            </Grid>
                                                            <Grid item xs={12} lg={4} md={4}>
                                                                <Chip label={<Typography style={{ fontWeight: 600 }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["total_discharge"])}</Typography>} color="primary" style={{ borderRadius: 0, width: '100%' }} />
                                                            </Grid>
                                                        </Grid><br />
                                                        <Grid container spacing={2} style={{ marginTop: 4 }}>
                                                            <Grid item xs={12} lg={2} md={2}>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="game-icons:regeneration" color="#000" width="20" height="20" />
                                                                </Avatar>
                                                            </Grid>
                                                            <Grid item xs={12} lg={6} md={6}>
                                                                <Typography style={{ color: '#77B93E', fontWeight: 600, marginTop: 5 }}>Total Regen Ah</Typography>
                                                            </Grid>
                                                            <Grid item xs={12} lg={4} md={4}>
                                                                <Chip label={<Typography style={{ fontWeight: 600 }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["total_regen"])}</Typography>} color="primary" style={{ borderRadius: 0, width: '100%' }} />
                                                            </Grid>
                                                        </Grid><br />
                                                        <Grid container spacing={2} style={{ marginTop: 4 }}>
                                                            <Grid item xs={12} lg={2} md={2}>
                                                                <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                    <Icon icon="fluent-mdl2:fast-forward-two-x" color="#000" width="20" height="20" />
                                                                </Avatar>
                                                            </Grid>
                                                            <Grid item xs={12} lg={6} md={6}>
                                                                <Typography style={{ color: '#77B93E', fontWeight: 600, marginTop: 5 }}>Total Fast Ah</Typography>
                                                            </Grid>
                                                            <Grid item xs={12} lg={4} md={4}>
                                                                <Chip label={<Typography style={{ fontWeight: 600 }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["fast_charging"])}</Typography>} color="primary" style={{ borderRadius: 0, width: '100%' }} />
                                                            </Grid>
                                                        </Grid>
                                                        {/* <Grid container spacing={2}>
                                                                <Grid item xs={12} lg={2} md={2}>
                                                                    <Avatar style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
                                                                        <Icon icon="fluent:target-arrow-16-filled" color="#000" width="20" height="20" />
                                                                    </Avatar>
                                                                </Grid>
                                                                <Grid item xs={12} lg={6} md={6}>
                                                                    <Typography style={{ color: '#77B93E', fontWeight: 600, marginTop: 5 }}>Columb Efficiency</Typography>
                                                                </Grid>
                                                                <Grid item xs={12} lg={4} md={4}>
                                                                    <Chip label={<Typography style={{ fontWeight: 600 }}>{BDashboardMeta.data && validateKeyData1(BDashboardMeta.data[0]["columb_effiency"])}</Typography>} color="primary" style={{ borderRadius: 0, width: '100%' }} />
                                                                </Grid>
                                                            </Grid> */}
                                                    </Grid>
                                                </Grid>
                                            </Item>
                                        </Grid>
                                        <Grid item xs={12} lg={12}>
                                            <Paper style={{ height: 460, overflowY: 'hidden', borderRadius: 2, position: 'relative' }} variant="outlined" >
                                                <SimpleMap2
                                                    zoom={13}
                                                    mapRes={BDashboardMeta.data[0]["last_one_hour_lat_lon"]}
                                                />

                                            </Paper>
                                        </Grid>
                                    </Grid> : <img src={nodata} style={{ marginLeft: 350 }} />}
                            </>
                            :
                            (
                                value === 0 ?
                                    <>
                                        {openAddBattery === true ?
                                            <div style={{
                                                width: '100%', overflow: 'hidden'
                                            }}><br />
                                                <h3>Onboarding Battery</h3><br />
                                                <Stepper nonLinear activeStep={activeStep}>
                                                    {steps.map((label, index) => (
                                                        <Step key={label}>
                                                            <StepButton onClick={handleStep(index)} completed={completed[index]}>
                                                                {label}
                                                            </StepButton>
                                                        </Step>
                                                    ))}
                                                </Stepper>
                                                <div>
                                                    {allStepsCompleted() ? (
                                                        <div>
                                                            <Typography style={{
                                                                marginTop: theme.spacing(1),
                                                                marginBottom: theme.spacing(1)
                                                            }}>
                                                                All steps completed - you&apos;re finished
                                                            </Typography>
                                                            <Button onClick={handleReset}>Reset</Button>
                                                        </div>
                                                    ) : (
                                                        <div><br />
                                                            <Typography style={{
                                                                marginTop: theme.spacing(1),
                                                                marginBottom: theme.spacing(1)
                                                            }}>{getStepContent(activeStep)}</Typography>
                                                            <br /><br /><br /><br />
                                                            <div>
                                                                <Button
                                                                    onClick={() => {
                                                                        setOpenAddBattery(false);
                                                                        handleReset()
                                                                        setBatteryAddForm({})
                                                                    }}
                                                                    style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}>
                                                                    Cancel
                                                                </Button>
                                                                <Button disabled={activeStep === 0} onClick={handleBack} style={{
                                                                    marginRight: theme.spacing(1)
                                                                }}>
                                                                    Back
                                                                </Button>
                                                                {batteryAddForm.battery_model_id &&
                                                                    batteryAddForm.serial_number && batteryAddForm.bms_unique_id ? <Button
                                                                        variant="contained"
                                                                        color="primary"
                                                                        onClick={handleNext}
                                                                        style={{
                                                                            marginRight: theme.spacing(1)
                                                                        }} disabled={activeStep === totalSteps() - 1}
                                                                    >
                                                                    Next
                                                                </Button> : <Button disabled={activeStep === totalSteps() - 1}
                                                                    variant="contained"
                                                                    style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}
                                                                >
                                                                    Next
                                                                </Button>}
                                                                {activeStep === totalSteps() - 1 ?
                                                                    <Button variant="contained" color="primary"
                                                                        onClick={() => {
                                                                            submitBattery(true);
                                                                        }}
                                                                    >Finish
                                                                    </Button> : <Button disabled variant="contained">Finish
                                                                    </Button>}


                                                                {/* ))
                                            } */}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div><br /><br /><br />
                                            </div> :
                                            openEditBattery === true ?
                                                <div style={{
                                                    width: '100%', overflow: 'hidden'
                                                }}><br />
                                                    <h3>Battery Profile</h3><br />
                                                    <Stepper nonLinear activeStep={activeStep1}>
                                                        {steps1.map((label1, index) => (
                                                            <Step key={label1}>
                                                                <StepButton onClick={handleStep1(index)} completed={completed1[index]}>
                                                                    {label1}
                                                                </StepButton>
                                                            </Step>
                                                        ))}
                                                    </Stepper>
                                                    <div>
                                                        {allStepsCompleted1() ? (
                                                            <div>
                                                                <Typography style={{
                                                                    marginTop: theme.spacing(1),
                                                                    marginBottom: theme.spacing(1)
                                                                }}>
                                                                    All steps completed - you&apos;re finished
                                                                </Typography>
                                                                <Button onClick={handleReset1}>Reset</Button>
                                                            </div>
                                                        ) : (
                                                            <div><br />
                                                                <Typography style={{
                                                                    marginTop: theme.spacing(1),
                                                                    marginBottom: theme.spacing(1)
                                                                }}>{getStepContent1(activeStep1)}</Typography>
                                                                <br /><br /><br /><br />
                                                                <div>
                                                                    <Button
                                                                        onClick={() => {
                                                                            setOpenEditBattery(false);
                                                                            handleReset1()
                                                                        }}
                                                                        style={{
                                                                            marginRight: theme.spacing(1)
                                                                        }}>
                                                                        Cancel
                                                                    </Button>
                                                                    <Button disabled={activeStep1 === 0} onClick={handleBack1} style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}>
                                                                        Back
                                                                    </Button>
                                                                    {/* {editBatArray.serial_number ?  */}
                                                                    <Button
                                                                        variant="contained"
                                                                        color="primary"
                                                                        onClick={handleNext1}
                                                                        style={{
                                                                            marginRight: theme.spacing(1)
                                                                        }}
                                                                        disabled={activeStep1 === totalSteps1() - 1}
                                                                    >
                                                                        Next
                                                                    </Button>
                                                                    {/* : <Button disabled
                                                                    variant="contained"
                                                                    style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}
                                                                >
                                                                    Next
                                                                </Button>
                                                                } */}
                                                                    {activeStep1 === totalSteps1() - 1 ?
                                                                        <Button variant="contained" color="primary"
                                                                            onClick={() => {
                                                                                submitEditBattery(true);
                                                                            }}
                                                                        >Finish
                                                                        </Button> : <Button disabled variant="contained">Finish
                                                                        </Button>}


                                                                    {/* ))
                                                    } */}
                                                                </div>
                                                            </div>
                                                        )}
                                                    </div><br /><br /><br />
                                                </div>
                                                : <><MUIDataTable
                                                    checkboxSelection={false}
                                                    title="Battery"
                                                    // data={BBMeta.data}
                                                    // data={MyBatteryMeta.data}
                                                    data={dataOnD === true ? BBMeta.data : dataOn === true ? BBMeta.data : MyBatteryMeta.data}
                                                    columns={batteryEditAccess === true ? columnsBattery : columnsBattery1}
                                                    options={options}
                                                    selectableRowsHideCheckboxes
                                                /><br /><Pagination color="secondary" count={MyBatteryPageCount} page={batPage} onChange={changePageBat} /></>}
                                    </>
                                    : value === 1 ? <>
                                        {openAddModel === true ?
                                            <div style={{
                                                width: '100%', overflow: 'hidden'
                                            }}><br />
                                                <h3>Onboarding Battery Model</h3><br />
                                                <Stepper nonLinear activeStep={activeStep4}>
                                                    {steps4.map((label4, index) => (
                                                        <Step key={label4}>
                                                            <StepButton onClick={handleStep4(index)} completed={completed4[index]}>
                                                                {label4}
                                                            </StepButton>
                                                        </Step>
                                                    ))}
                                                </Stepper>
                                                <div>
                                                    {allStepsCompleted4() ? (
                                                        <div>
                                                            <Typography style={{
                                                                marginTop: theme.spacing(1),
                                                                marginBottom: theme.spacing(1)
                                                            }}>
                                                                All steps completed - you&apos;re finished
                                                            </Typography>
                                                            <Button onClick={handleReset4}>Reset</Button>
                                                        </div>
                                                    ) : (
                                                        <div><br />
                                                            <Typography style={{
                                                                marginTop: theme.spacing(1),
                                                                marginBottom: theme.spacing(1)
                                                            }}>{getStepContent4(activeStep4)}</Typography>
                                                            <br /><br /><br /><br />
                                                            <div>
                                                                <Button
                                                                    onClick={() => {
                                                                        setOpenAddModel(false);
                                                                        handleReset4()
                                                                        setModelAddForm({})
                                                                    }}
                                                                    style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}>
                                                                    Cancel
                                                                </Button>
                                                                <Button disabled={activeStep4 === 0} onClick={handleBack4} style={{
                                                                    marginRight: theme.spacing(1)
                                                                }}>
                                                                    Back
                                                                </Button>
                                                                {modelAddForm.model_info != '' && modelAddForm.cell_maufacturer != '' ?
                                                                    <Button disabled={activeStep4 === 1 && modelAddForm.thermistor === '' || activeStep4 === totalSteps4() - 1}
                                                                        variant="contained"
                                                                        color="primary"
                                                                        onClick={handleNext4}
                                                                        style={{
                                                                            marginRight: theme.spacing(1)
                                                                        }}
                                                                    >
                                                                        Next
                                                                    </Button> :
                                                                    activeStep4 === 1 && modelAddForm.nominal_voltage != '' && modelAddForm.capacity_mah != '' &&
                                                                        modelAddForm.power != '' && modelAddForm.thermistor != '' ?
                                                                        <Button variant="contained"
                                                                            color="primary"
                                                                            onClick={handleNext4}
                                                                            style={{
                                                                                marginRight: theme.spacing(1)
                                                                            }}
                                                                        >
                                                                            Next
                                                                        </Button>
                                                                        : null}
                                                                {modelAddForm.number_of_cells_series != '' && modelAddForm.number_of_cells_parallel != '' &&
                                                                    modelAddForm.cell_chemisty != '' ?
                                                                    <Button variant="contained" color="primary"
                                                                        onClick={() => {
                                                                            submitModel(true);
                                                                        }}
                                                                    >Finish
                                                                    </Button> : <Button disabled variant="contained">Finish
                                                                    </Button>}

                                                            </div>
                                                        </div>
                                                    )}
                                                </div><br /><br /><br />
                                            </div>
                                            : openEditModel === true ?
                                                <div style={{
                                                    width: '100%', overflow: 'hidden'
                                                }}><br />
                                                    <h3>Battery Model Profile</h3><br />
                                                    <Stepper nonLinear activeStep={activeStep5}>
                                                        {steps5.map((label5, index) => (
                                                            <Step key={label5}>
                                                                <StepButton onClick={handleStep5(index)} completed={completed5[index]}>
                                                                    {label5}
                                                                </StepButton>
                                                            </Step>
                                                        ))}
                                                    </Stepper>
                                                    <div>
                                                        {allStepsCompleted5() ? (
                                                            <div>
                                                                <Typography style={{
                                                                    marginTop: theme.spacing(1),
                                                                    marginBottom: theme.spacing(1)
                                                                }}>
                                                                    All steps completed - you&apos;re finished
                                                                </Typography>
                                                                <Button onClick={handleReset5}>Reset</Button>
                                                            </div>
                                                        ) : (
                                                            <div><br />
                                                                <Typography style={{
                                                                    marginTop: theme.spacing(1),
                                                                    marginBottom: theme.spacing(1)
                                                                }}>{getStepContent5(activeStep5)}</Typography>
                                                                <br /><br /><br /><br />
                                                                <div>
                                                                    <Button
                                                                        onClick={() => {
                                                                            setOpenEditModel(false);
                                                                            handleReset5()
                                                                        }}
                                                                        style={{
                                                                            marginRight: theme.spacing(1)
                                                                        }}>
                                                                        Cancel
                                                                    </Button>
                                                                    <Button disabled={activeStep5 === 0} onClick={handleBack5} style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}>
                                                                        Back
                                                                    </Button>
                                                                    {editArray.model_info != '' && editArray.cell_maufacturer != '' ?
                                                                        <Button disabled={activeStep5 === 1 && editArray.thermistor === '' || activeStep5 === totalSteps5() - 1}
                                                                            variant="contained"
                                                                            color="primary"
                                                                            onClick={handleNext5}
                                                                            style={{
                                                                                marginRight: theme.spacing(1)
                                                                            }}
                                                                        >
                                                                            Next
                                                                        </Button> :
                                                                        activeStep5 === 1 && editArray.nominal_voltage != '' && editArray.capacity_mah != '' &&
                                                                            editArray.power != '' && editArray.thermistor != '' ?
                                                                            <Button variant="contained"
                                                                                color="primary"
                                                                                onClick={handleNext5}
                                                                                style={{
                                                                                    marginRight: theme.spacing(1)
                                                                                }}
                                                                            >
                                                                                Next
                                                                            </Button>
                                                                            : null}
                                                                    {editArray.number_of_cells_series != '' && editArray.number_of_cells_parallel != '' &&
                                                                        editArray.cell_chemisty != '' ?
                                                                        <Button variant="contained" color="primary"
                                                                            onClick={() => {
                                                                                submitModelEdit(true);
                                                                            }}
                                                                        >Finish
                                                                        </Button> : <Button disabled variant="contained">Finish
                                                                        </Button>}

                                                                </div>
                                                            </div>
                                                        )}
                                                    </div><br /><br /><br />
                                                </div>
                                                : <><MUIDataTable
                                                    checkboxSelection={false}
                                                    title="Battery Model"
                                                    // data={dataModel}
                                                    data={dataOn === true ? BatteryModelLMeta.data : BatteryModelMeta.data}
                                                    columns={batteryEditAccess === true ? columsModel : columsModel1}
                                                    options={options1}

                                                /><br />
                                                    <Pagination color="secondary" count={MyBatteryPageMCount} page={modelPage} onChange={changePageBatModel} /></>}
                                    </>
                                        : <>
                                            {openAddBMS === true ? <div style={{
                                                width: '100%', overflow: 'hidden'
                                            }}><br />
                                                <h3>Onboarding BMS Model</h3><br />
                                                <Stepper nonLinear activeStep={activeStep2}>
                                                    {steps2.map((label2, index) => (
                                                        <Step key={label2}>
                                                            <StepButton onClick={handleStep2(index)} completed={completed2[index]}>
                                                                {label2}
                                                            </StepButton>
                                                        </Step>
                                                    ))}
                                                </Stepper>
                                                <div>
                                                    {allStepsCompleted2() ? (
                                                        <div>
                                                            <Typography style={{
                                                                marginTop: theme.spacing(1),
                                                                marginBottom: theme.spacing(1)
                                                            }}>
                                                                All steps completed - you&apos;re finished
                                                            </Typography>
                                                            <Button onClick={handleReset2}>Reset</Button>
                                                        </div>
                                                    ) : (
                                                        <div><br />
                                                            <Typography style={{
                                                                marginTop: theme.spacing(1),
                                                                marginBottom: theme.spacing(1)
                                                            }}>{getStepContent2(activeStep2)}</Typography>
                                                            <br /><br /><br /><br />
                                                            <div>
                                                                <Button
                                                                    onClick={() => {
                                                                        setOpenAddBMS(false);
                                                                        handleReset2()
                                                                        setBmsAddForm({})
                                                                    }}
                                                                    style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}>
                                                                    Cancel
                                                                </Button>
                                                                {/* <Button disabled={activeStep2 === 0} onClick={handleBack2} style={{
                                                                marginRight: theme.spacing(1)
                                                            }}>
                                                                Back
                                                            </Button> */}
                                                                {/* {bmsAddForm.model_info && bmsAddForm.hw_version &&
                                                                bmsAddForm.oem ? <Button
                                                                    variant="contained"
                                                                    color="primary"
                                                                    onClick={handleNext2}
                                                                    style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}
                                                                >
                                                                Next
                                                            </Button> : <Button disabled
                                                                variant="contained"
                                                                style={{
                                                                    marginRight: theme.spacing(1)
                                                                }}
                                                            >
                                                                Next
                                                            </Button>
                                                            } */}
                                                                {bmsAddForm.model_info && bmsAddForm.hw_version &&
                                                                    bmsAddForm.oem ?
                                                                    <Button variant="contained" color="primary"
                                                                        onClick={() => {
                                                                            submitBMS(true);
                                                                        }}
                                                                    >Finish
                                                                    </Button> : <Button disabled variant="contained">Finish
                                                                    </Button>}


                                                                {/* ))
                        } */}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div><br /><br /><br />
                                            </div> :
                                                openEditBMS === true ? <div style={{
                                                    width: '100%', overflow: 'hidden'
                                                }}><br />
                                                    <h3>BMS Model Profile</h3><br />
                                                    <Stepper nonLinear activeStep={activeStep3}>
                                                        {steps3.map((label3, index) => (
                                                            <Step key={label3}>
                                                                <StepButton onClick={handleStep3(index)} completed={completed3[index]}>
                                                                    {label3}
                                                                </StepButton>
                                                            </Step>
                                                        ))}
                                                    </Stepper>
                                                    <div>
                                                        {allStepsCompleted3() ? (
                                                            <div>
                                                                <Typography style={{
                                                                    marginTop: theme.spacing(1),
                                                                    marginBottom: theme.spacing(1)
                                                                }}>
                                                                    All steps completed - you&apos;re finished
                                                                </Typography>
                                                                <Button onClick={handleReset3}>Reset</Button>
                                                            </div>
                                                        ) : (
                                                            <div><br />
                                                                <Typography style={{
                                                                    marginTop: theme.spacing(1),
                                                                    marginBottom: theme.spacing(1)
                                                                }}>{getStepContent3(activeStep3)}</Typography>
                                                                <br /><br /><br /><br />
                                                                <div>
                                                                    <Button
                                                                        onClick={() => {
                                                                            setOpenEditBMS(false);
                                                                            handleReset3()
                                                                        }}
                                                                        style={{
                                                                            marginRight: theme.spacing(1)
                                                                        }}>
                                                                        Cancel
                                                                    </Button>
                                                                    {/* <Button disabled={activeStep3 === 0} onClick={handleBack3} style={{
                                                                marginRight: theme.spacing(1)
                                                            }}>
                                                                Back
                                                            </Button> */}
                                                                    {/* {editBMSArray.model_info && editBMSArray.hw_version &&
                                                                editBMSArray.oem ? <Button
                                                                    variant="contained"
                                                                    color="primary"
                                                                    onClick={handleNext3}
                                                                    style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}
                                                                >
                                                                Next
                                                            </Button> : <Button disabled
                                                                variant="contained"
                                                                style={{
                                                                    marginRight: theme.spacing(1)
                                                                }}
                                                            >
                                                                Next
                                                            </Button>
                                                            } */}
                                                                    {editBMSArray.model_info && editBMSArray.hw_version &&
                                                                        editBMSArray.oem ?
                                                                        <Button variant="contained" color="primary"
                                                                            onClick={() => {
                                                                                submitEditBMS(true);
                                                                            }}
                                                                        >Finish
                                                                        </Button> : <Button disabled variant="contained">Finish
                                                                        </Button>}


                                                                    {/* ))
                        } */}
                                                                </div>
                                                            </div>
                                                        )}
                                                    </div><br /><br /><br />
                                                </div>
                                                    : <><MUIDataTable
                                                        checkboxSelection={false}
                                                        title="BMS Model"
                                                        // data={dataModel}
                                                        data={dataOn === true ? BMSLMeta.data : BMSMeta.data}
                                                        columns={batteryEditAccess === true ? columsBMS : columsBMS1}
                                                        options={options1}

                                                    /><br />
                                                        <Pagination color="secondary" count={MyBatteryPageBMCount} page={bmsPage} onChange={changePageBMS} /></>}
                                        </>


                            )}

                    {/* Vehicle Assignment */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={openVehicleActive}
                        maxWidth={"lg"}
                        onClose={() => setOpenVehicleActive(false)}
                        aria-labelledby="responsive-dialog-title"
                        // className={!fullScreen ? classes.dialog : null}
                        style={{ marginLeft: '650px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Vehicle Assignment"}</DialogTitle>
                        <DialogContent>
                            <DialogContentText>
                                <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:&nbsp;{validateKeyData(serial)}</b> </Typography><br />
                                {/* <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}> */}
                                <b style={{ color: '#00000080', fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600 }}>Vehicle Number:</b>
                                <Select style={{ width: '100%' }}

                                    onChange={(e) => {
                                        setAssignVech((state) => ({
                                            ...state,
                                            "vehicle_id": e.target.value
                                        }))
                                    }}
                                >

                                    <MenuItem value="">Select Vehicle</MenuItem>
                                    {BVAMeta.data.length && BVAMeta.data.map((vehicle) => {
                                        return (
                                            <MenuItem value={vehicle[1]}>{vehicle[0]}</MenuItem>

                                        )
                                    }
                                    )}
                                </Select>

                                {/* </div> */}


                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button autoFocus
                                onClick={() => setOpenVehicleActive(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button
                                onClick={() => {
                                    assVehicle()
                                }}
                                color="secondary" autoFocus>
                                Assign
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Vehicle Deactivation */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={openDeActiveV}
                        maxWidth={"lg"}
                        onClose={() => setOpenDeActiveV(false)}
                        aria-labelledby="responsive-dialog-title"
                        // className={!fullScreen ? classes.dialog : null}
                        style={{ marginLeft: '650px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Vehicle Deactivation"}</DialogTitle>
                        <DialogContent style={{ height: '100px', width: '350px' }}><br />
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                        <Typography className={classes.secondaryTextG}>Vehicle Number:&nbsp;{validateKeyData(vn)}</Typography>

                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button autoFocus
                                onClick={() => setOpenDeActiveV(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button autoFocus
                                onClick={() => {
                                    DeactiveV(vehBatID)

                                }}
                                color="secondary">
                                Deactivate
                            </Button>
                        </DialogActions>
                    </Dialog>
                    {/* Battery Active */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={openBatteryActive}
                        maxWidth={"lg"}
                        onClose={() => setOpenBatteryActive(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ marginLeft: '650px' }} >
                        <DialogTitle id="responsive-dialog-title">{"Battery Activation"}</DialogTitle>
                        <DialogContent
                            style={{ height: '100px', width: '300px' }}
                        // style={{height: '340px',width:'320px',position: 'relative', marginLeft: '680px', marginTop:'250px'}}
                        ><br />
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:&nbsp; {validateKeyData(serial)}</b></Typography>

                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button autoFocus
                                onClick={() => setOpenBatteryActive(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button autoFocus
                                onClick={() => {
                                    assBat(bid)
                                }}
                                color="secondary">
                                On
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Battery De-Active */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={openDeActiveB}
                        maxWidth={"lg"}
                        onClose={() => setOpenDeActiveB(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ marginLeft: '650px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Battery Deactivation"}</DialogTitle>
                        <DialogContent style={{ height: '100px', width: '350px' }}><br />
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                        <Typography style={{ color: '#00000080' }}><b className={classes.secondaryTextG} >Serial Number:&nbsp;{validateKeyData(serial)}</b> </Typography>

                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button autoFocus
                                onClick={() => setOpenDeActiveB(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button autoFocus
                                onClick={() => {
                                    assBatD(bid)
                                }}
                                color="secondary">
                                Off
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Idle On */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={openOn}
                        maxWidth={"lg"}
                        onClose={() => setOpenOn(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ marginLeft: '680px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Battery On"}</DialogTitle>
                        <DialogContent>
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                        <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                        <TextField className={classes.textField}
                                            onChange={(e) => { setOnOffPassword(e.target.value) }}
                                        />

                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button
                                onClick={() => setOpenOn(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button
                                disabled={onOffPassword !== pWord}
                                onClick={() => {
                                    On()
                                    setTimeout(() => {
                                        dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));

                                    }, 500)
                                }}
                                color="secondary">
                                On
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Idle Off */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={openOff}
                        maxWidth={"lg"}
                        onClose={() => setOpenOff(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ marginLeft: '680px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Battery Off"}</DialogTitle>
                        <DialogContent>
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                        <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                        <TextField className={classes.textField}
                                            onChange={(e) => { setOnOffPassword1(e.target.value) }}
                                        />

                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button
                                onClick={() => setOpenOff(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button
                                disabled={onOffPassword1 !== pWord}
                                onClick={() => {
                                    Off()
                                    setTimeout(() => {
                                        dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));

                                    }, 500)
                                }}
                                color="secondary">
                                Off
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Delete Battery */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={delete1}
                        maxWidth={"lg"}
                        onClose={() => setDelete1(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ marginLeft: '680px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Offboarding Battery"}</DialogTitle>
                        <DialogContent>
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                        <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                        <TextField className={classes.textField}
                                            onChange={(e) => { setPassword1(e.target.value) }}
                                        />

                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button
                                onClick={() => setDelete1(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button
                                disabled={password1 !== pWord}
                                onClick={() => {
                                    deleteBattery(selectedId1);
                                }}
                                color="secondary">
                                Offboard
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Delete Battery Model */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={delete2}
                        maxWidth={"lg"}
                        onClose={() => setDelete2(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ marginLeft: '600px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Offboarding Battery Model"}</DialogTitle>
                        <DialogContent>
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                        <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                        <TextField className={classes.textField}
                                            onChange={(e) => { setPassword2(e.target.value) }}
                                        />

                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button
                                onClick={() => setDelete2(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button
                                disabled={password2 !== pWord}
                                onClick={() => {
                                    deleteModel(selectedId2);
                                }}
                                color="secondary">
                                Offboard
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Delete BMS Model */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={delete3}
                        maxWidth={"lg"}
                        onClose={() => setDelete3(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ width: '1200px', position: 'relative', marginLeft: '680px', marginTop: '250px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Offboarding BMS Model"}</DialogTitle>
                        <DialogContent>
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                        <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                        <TextField className={classes.textField}
                                            onChange={(e) => { setPassword3(e.target.value) }}
                                        />

                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button
                                onClick={() => setDelete3(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button
                                disabled={password3 !== pWord}
                                onClick={() => {
                                    deleteBMS(selectedId3);
                                }}
                                color="secondary">
                                Offboard
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Telematics Assignment */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={openTele}
                        maxWidth={"lg"}
                        onClose={() => setOpenTele(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ marginLeft: '600px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">{"Telematics Assignment"}</DialogTitle>
                        <DialogContent>
                            <DialogContentText>
                                <Grid container spacing={2}>
                                    <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>Telematics Imei:</b>
                                    <Grid item lg={12} xs={12}>
                                        <Select
                                            onChange={(e) => {
                                                setAssignTele((state) => ({
                                                    ...state,
                                                    telematics_id: e.target.value,
                                                }));
                                            }}
                                            style={{
                                                width: "100%",
                                                color: "#7A7A7D",
                                                borderRadius: "9px",
                                                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                                                    borderColor: "#C4C4C4  !important",
                                                },
                                                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
                                            }}
                                        >
                                            <MenuItem value="">Select IMEI</MenuItem>
                                            {getImei.length &&
                                                getImei.map((imeiD) => {
                                                    return (
                                                        <MenuItem value={imeiD.telematics_id}>{imeiD.imei}</MenuItem>
                                                    );
                                                })}
                                        </Select>
                                    </Grid>
                                </Grid>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button
                                onClick={() => setOpenTele(false)}
                                color="primary">
                                Cancel
                            </Button>
                            <Button
                                onClick={() => {
                                    AssignTelematics();
                                }}
                                color="secondary">
                                Assign
                            </Button>
                        </DialogActions>
                    </Dialog>
                    {/* Telematics De-Active */}
                    <Dialog
                        fullScreen={fullScreen}
                        open={openTeleD}
                        maxWidth={"lg"}
                        onClose={() => setOpenTeleD(false)}
                        aria-labelledby="responsive-dialog-title"
                        style={{ marginLeft: '600px' }}
                    >
                        <DialogTitle id="responsive-dialog-title">
                            {"Telematics Reassignment"}
                        </DialogTitle>
                        <DialogContent style={{ height: '100px', width: '300px' }}><br />
                            <DialogContentText>
                                <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>
                                    IMEI:&nbsp;{selectedImei}</b>
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button
                                autoFocus
                                onClick={() => setOpenTeleD(false)}
                                color="primary"
                            >
                                Cancel
                            </Button>
                            <Button
                                onClick={() => {
                                    ReassignImei(assetLink)
                                }}
                                color="secondary"
                                autoFocus
                            >
                                Re-Assign
                            </Button>
                        </DialogActions>
                    </Dialog>
                </>}
            <br /><br />
            <Typography align="center" style={{ fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap' }} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
        </div>

    );



}
