import React from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import { createTheme, withStyles } from '@material-ui/core/styles';
import ThemePallete from 'enl-api/palette/themePalette';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  CartesianAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { data1 , data1year, data1month } from './sampleData';
// import styles from './fluidChart-jss';
import { Typography } from '@material-ui/core';
import endpoints from '../../../endpoints/endpoints';
const theme = createTheme(ThemePallete.magentaTheme);
const color = ({
  primary: "#68A724",
  secondary: theme.palette.secondary.main,
});

const CustomizedLabel = props => {
  const {
    x,
    y,
    stroke,
    value
  } = props;
  return (
    <text x={x} y={y} dy={-4} fill={stroke} fillOpacity="0.8" fontSize={10} textAnchor="middle">
      { value }
    </text>
  );
};

CustomizedLabel.propTypes = {
  x: PropTypes.number,
  y: PropTypes.number,
  value: PropTypes.number,
  stroke: PropTypes.string,
};

CustomizedLabel.defaultProps = {
  x: 0,
  y: 0,
  value: 0,
  stroke: '#000'
};
const CustomizedLabelnew = (props) => {
  const {text}=props;
  return(
    <Typography>{text} </Typography>
  )
}

function Chart1(props) {
  const { imei } = props;
  const [ graphData , setGraphData ] = React.useState([]);

  React.useEffect(() => {
    let Url = endpoints.baseUrl + `/battery/dashboard/`+imei;
    axios.get(Url).then((response) => {
      setGraphData(response.data.data[0].b_current)
    }).catch((error) => { })  
    
    },[])
  return (
    <div >
      <ResponsiveContainer width="100%" height={250}>
        <LineChart
          width="100%"
          height={250}
          data={graphData}
          style={{marginTop:15}}
          // margin={{
          //   top: 5,
          //   right: 30,
          //   left: 15,
          //   bottom: 5
          // }}
        >
          <XAxis dataKey="time" tickLine={false} stroke="#106dcf"/>
          <YAxis domain={graphData ? [graphData] : [0,10]} stroke="#106dcf"
            // axisLine={false} 
            tickSize={3} tickLine={false} tickFormatter={tick => `${tick}A ` } 
            tick={{ stroke: 'none' }} />
          <Tooltip />
 
          <Line dot={false} type="monotone" dataKey="battery_current" strokeWidth={3} stroke={color.primary} 
          // label={<CustomizedLabel stroke={color.primary} />}
           />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// Chart1.propTypes = {
//   classes: PropTypes.object.isRequired,
// };

export default Chart1;