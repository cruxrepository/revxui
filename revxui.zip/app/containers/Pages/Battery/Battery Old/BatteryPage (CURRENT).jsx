import React from 'react';
import axios from 'axios';
import { withStyles, makeStyles, useTheme, styled } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import LinearProgress from '@material-ui/core/LinearProgress';
import Chip from '@material-ui/core/Chip';
import MUIDataTable from 'mui-datatables';
import MenuItem from "@material-ui/core/MenuItem";
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Button from "@material-ui/core/Button";
import BatteryVoltage from "./BatteryVoltage";
import BatteryCurrent from "./BatteryCurrent";
import SOC from "./SOC";
import TotalOdometer from "./TotalOdometer";
import Select from "@material-ui/core/Select";
import Tooltip from '@material-ui/core/Tooltip';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import TabIcon from '@material-ui/icons/Tab';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import BatteryCharging30Icon from '@material-ui/icons/BatteryCharging30';
import endpoints from '../../../endpoints/endpoints';
import CustomToolbar from './CustomToobar';
import MotorcycleIcon from '@material-ui/icons/Motorcycle';
import CustomToolbarM from './CustomToobarM';
import Divider from '@material-ui/core/Divider';


import ToggleButton from '@material-ui/lab/ToggleButton';
import ToggleButtonGroup from '@material-ui/lab/ToggleButtonGroup';

import Dialog from '@material-ui/core/Dialog';
import Brightness1Icon from '@material-ui/icons/Brightness1';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { getMyBatteryBulk, getBatteryModelBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';
const useStyles = makeStyles((theme) => ({

    root: {
        margin: 10
    },
    textField: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
        'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    table: {

        '& > div': {

            '& > .MuiToolbar-regular': {
                backgroundColor: '#68A72480  !important',
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0
            },
            overflow: 'auto',
            // textAlign:'center'
        },

        '& table': {
            '& td': {
                wordBreak: 'keep-all',
                textAlign: 'center'
            },

            [theme.breakpoints.down('md')]: {
                '& td': {
                    height: 60,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                },
                '& tr:nth-child(odd)': {
                    backgroundColor: '#cfcfcf40'
                },
                '& tr:nth-child(even)': {
                    backgroundColor: '#cfcfcf20'
                },
            }
        }
    },
    graphText: {
        fontSize: 12,
        position: 'absolute',
        transform: 'rotate(270deg)',
        left: '-40px',
        top: 370,
        color: 'primary',
        fontWeight: 600
    },
    graphSelect: {
        minWidth: 150, left: '20em', marginBottom: 20
    },
    tabsSection: {
        [theme.breakpoints.up('lg')]: {
            // borderRadius:0,position:'sticky',top:0 ,width:500
            borderRadius: 0, top: 0, width: 500

        },


    },
    primaryText: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
    }, primaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '300px'
    },
    secondaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '12px', fontWeight: 600, color: '#68A724', width: '100%'
    },
    chart1: {
        marginLeft: '-20px', width: '120px', height: '50px', '.MuiPaper-root .MuiMenu-paper .MuiPopover-paper': { width: '120px !important' }
    },
    copyRight: {
        position: 'absolute', bottom: 0, right: 0, left: 0, fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    dialog: {
        // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
        position: 'relative', marginLeft: '680px'
    },
    healthy: {
        color: '#82E219', width: '5rem', fontSize: '20px'
    },
    Unhealthy: {
        color: '#FFFF00'
    },
    chart: {
        padding: theme.spacing(2)
    },
    dataView: {
        height: '300px',
    },
    tableborder: {
        border: '1px solid #000000'
    }
}));

/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function BatteryPage() {

    const MyBatteryData = useSelector((store) => store.myBattery)
    const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
    let MyBatteryMeta = useSelector((store) => store.myBattery)
    let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
    let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
    let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)

    const BatteryModelData = useSelector((store) => store.batteryModel)
    const BatteryModelDataRaw = useSelector((store) => store.batteryModel.rawData)
    let BatteryModelMeta = useSelector((store) => store.batteryModel)
    let BatteryModelFetching = useSelector((store) => store.batteryModel.fetching)
    let BatteryModelResponsecode = useSelector((store) => store.batteryModel.responseStatus)
    let BatteryModelMetaPresent = useSelector((store) => store.batteryModel.dataPresent)


    const dispatch = useDispatch();

    const [openEditModel, setOpenEditModel] = React.useState(false); 
    const [openEditBattery, setOpenEditBattery] = React.useState(false);

    const theme = useTheme();
    const classes = useStyles();
    const [screen, setScreen] = React.useState(false);
    const [idleMode, setIdleMode] = React.useState(false);




    const [value, setValue] = React.useState(0);
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    React.useEffect(() => {
        dispatch(getMyBatteryBulk());
    }, [dispatch, MyBatteryMetaPresent]);

    React.useEffect(() => {
        dispatch(getBatteryModelBulk());
    }, [dispatch, BatteryModelMetaPresent]);

    let allEditModel = BatteryModelMeta.data

    // const [editBatteryArray, setEditBatteryArray] = React.useState(
    //     {

    //     }
    // )
    // const setEditBatteryArray = (bms_id) => {
    //     let allBattery = MyBatteryDataRaw;
    //     let findEditArray = allModel.find(el => el.bms_id === bms_id);
    //     setEditBatteryArray(findEditArray);
    // }
    // const submitEditBattery = () => {
    //     const putBattery = endpoints.baseUrl + `/battery/update/` + editBatteryArray.bms_id;
    //     axios
    //         .put(putBattery, editBatteryArray)
    //         .then((response) => {
    //             dispatch(getMyBatteryBulk());

    //         });

    // }


    // const setEditBatteryFormArray = (e, key) => {
    //     setEditBatteryArray((state) => ({ ...state, [key]: e.target.value }));

    // }


    const [editArray, setEditArray] = React.useState(
        {

        }
    )
    const setModelEditArray = (battery_model_id) => {
        let allModel = BatteryModelDataRaw;
        let findArray = allModel.find(el => el.battery_model_id === battery_model_id);
        setEditArray(findArray);
    }
    const submitModelEdit = () => {
        const putModel = endpoints.baseUrl + `/batterymodel/edit/` + editArray.battery_model_id;
        axios
            .put(putModel, editArray)
            .then((response) => {
                dispatch(getBatteryModelBulk());

            });

    }

    const deleteModel = (battery_model_id) => {
        const deleteModel = endpoints.baseUrl + `/batterymodel/softdelete/` + battery_model_id;
        axios
            .delete(deleteModel)
            .then((response) => {
                dispatch(getBatteryModelBulk());
            });
    }

    const setModelEditFormArray = (e, key) => {
        setEditArray((state) => ({ ...state, [key]: e.target.value }));

    }


    const Item = styled(Paper)(({ theme }) => ({
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'left',
        color: theme.palette.text.secondary,
    }));



    const [tableMode, setTableMode] = React.useState("ericksaw");
    const handleTableChange = (event) => {
        if (tableMode === 'erickshaw') {
            setTableMode('comm');
        } else {
            setTableMode('erickshaw');
        }
    };
    const dayDropdown = [{ val: 'day', name: 'Day' }, { val: 'month', name: 'Month' }, { val: 'year', name: 'Year' }, { val: 'custom', name: 'Custom' }]





    const columsModel = [
        {
            name: 'Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography color='secondary' variant='subtitle2'>{!value ? "-" : value} </Typography>
                )
            }
        }, {
            name: 'H/W Version',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{!value ? "-" : value}</Typography>
                )
            }
        }, {
            name: 'S/W Version',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{!value ? "-" : value}</Typography>
                )
            }
        }, {
            name: 'Voltage',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{!value ? "-" : value}</Typography>
                )
            }
        }, {
            name: 'Capacity',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{!value ? "-" : value}</Typography>
                )
            }
        }, {
            name: 'Power',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{!value ? "-" : value}</Typography>
                )
            }
        }, {
            name: 'Manufacturer',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{!value ? "-" : value}</Typography>
                )
            }
        },
        {
            name: 'Action',
            options: {
                filter: true,
                customBodyRender: (value) => {
                    // if (value === 'assign') {
                    return (<Select
                        style={{ minWidth: 150, color: '#FFC130' }}
                        value='Edit'
                    >
                        <MenuItem onClick={() => 
                        // {
                            setOpenEditModel(true)
                            // setModelEditArray(value)
                        // }
                    }
                            value='Edit'>Edit</MenuItem>
                        <MenuItem
                            // onClick={() => { deleteModel(value) }}
                            style={{ color: "#FF6058 !important" }} value="Delete">
                            Delete
                        </MenuItem>
                    </Select>)
                }
            }
        },
    ]

    const [bmsid, setBmsId] = React.useState(0);
    const [serial, setSerial] = React.useState(0);

    const columnsBattery = [

        {
            name: 'Serial Number',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                        setScreen(true);
                        setBmsId(value.bms_id)
                        setSerial(value.serial_number)
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        &nbsp;&nbsp;{value.serial_number}
                    </Typography>

                )
            }
        },
        {
            name: 'Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => setScreen(true)}
                        // style={{ color: '#33a6ff', cursor: 'pointer' }} 
                        variant='subtitle2'>{value}</Typography>
                )
            }
        },
        {
            name: 'Investor',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => setScreen(true)} variant='subtitle2'>{value}</Typography>
                )
            }
        },
        {
            name: 'Operation Owner',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => setScreen(true)} variant='subtitle2'>{value}</Typography>
                )
            }
        },
        {
            name: 'Vehicle Number',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <Typography style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>{!value ? "-" : value}</Typography>
                )
            }
        },

        {
            name: 'Status',
            options: {
                filter: true,
                customBodyRender: (value) => {
                    if (value.vehicle_number && value.battery_status === "on") {
                        return (
                            <><IconButton 
                            // onClick={() => setOpenEditBattery(true)} 
                            ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="28" height="28" /></IconButton>
                                <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_number && value.battery_status === "off") {
                        return (
                            <><IconButton  
                            // onClick={() => setOpenEditBattery(true)}
                            ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }
                    else {
                        return (
                            <><IconButton 
                            // onClick={() => setOpenEditBattery(true)}
                            ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:motorbike" color="#c4c4c4" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }


                },

            },

        },
    ];

 

    const options = {
        filterType: 'dropdown',
        responsive: 'vertical',
        print: true,
        rowsPerPage: 10,
        page: 0,
        selectableRows: "none",
        customToolbar: () => {
            return (
                value === 0 ?
                    <CustomToolbar value={value} />
                    : <CustomToolbarM value={value} />
            );
        }

    };
    const [chartOneVal, setChartOneVal] = React.useState("day");
    const handleChartOneVal = (e) => {
        setChartOneVal(e.target.value);

    }





    const [frame, setFrame] = React.useState(false)
    return (
        <div
            // onMouseMove={() => setFrame(!frame)}
            className={classes.table}>


            <Tabs
                className={classes.tabsSection}
                value={value}
                onChange={handleChange}
                variant="fullWidth"
                indicatorColor="primary"
                aria-label="icon tabs example"
            >
                <Tab label="Battery" onClick={() => {
                    setScreen(false) 
                }} icon={<BatteryCharging30Icon />} aria-label="favorite" />
                <Tab label="Model" onClick={() => {
                    setScreen(false) 
                }} icon={<TabIcon />} aria-label="phone" />

            </Tabs>


            <Paper square className={classes.root}>

            </Paper>
            {(screen !== true && (
                    MyBatteryMetaPresent &&
                    BatteryModelMetaPresent)) ?
                    (
                        value === 0 ?
                            <MUIDataTable
                                className={classes.tableborder}
                                checkboxSelection={false}
                                title="Battery"
                                // data={data}
                                data={MyBatteryMeta.data}
                                columns={columnsBattery}
                                options={options}
                                selectableRowsHideCheckboxes
                            />
                            :
                            <MUIDataTable
                                className={classes.tableborder}
                                checkboxSelection={false}
                                title="MODEL"
                                // data={dataModel}
                                data={BatteryModelMeta.data}
                                columns={columsModel}
                                options={options}
                                selectableRowsHideCheckboxes
                            />

                    )
                    :
                    (
                        MyBatteryMetaPresent &&
                        BatteryModelMetaPresent) ?
                        (
                            <>
                                <Typography bmsid={bmsid} className={classes.primaryTextG} >Serial Number:&nbsp;{serial}</Typography>
                                <Typography>{value.serial_number}</Typography>
                                <Grid item container spacing={2}>
                                    <Grid item xs={12} lg={6}>
                                        <Paper className={classes.paper}><br /> <BatteryVoltage
                                            bmsid={bmsid}
                                            dataIndex={chartOneVal} /></Paper>
                                            </Grid>

                                    <Grid item xs={12} lg={6}>
                                        <Paper className={classes.paper}><br /><SOC bmsid={bmsid} dataIndex={chartOneVal} /></Paper>

                                    </Grid>

                                    <Grid item xs={12} lg={6}>
                                        <Paper className={classes.paper}><br /><TotalOdometer bmsid={bmsid} dataIndex={chartOneVal} /></Paper>

                                    </Grid>

                                    <Grid item xs={12} lg={6}>
                                        <Paper className={classes.paper}><br /><BatteryCurrent bmsid={bmsid} dataIndex={chartOneVal} /></Paper>
                                    </Grid>
                                </Grid>
                            </>
                        )

                        : MyBatteryFetching ?
                            <Loading /> :
                            MyBatteryResponsecode === 500 ?

                                <ErrorWrap /> : null



            }


            <Dialog
                fullScreen={fullScreen}
                open={openEditModel}
                maxWidth={"lg"}
                data={BatteryModelDataRaw}
                onClose={() => setOpenEditModel(false)}
                aria-labelledby="responsive-dialog-title"
                className={!fullScreen ? classes.dialog : null}
            >
                <DialogTitle id="responsive-dialog-title">{"Edit Model"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Model</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setModelEditFormArray(e, 'model_info')
                                    }}
                                    size="small" id="outlined"
                                    value={editArray.model_info} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Hardware Version</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setModelEditFormArray(e, 'hardware_version')
                                    }}
                                    size="small" id="outlined"
                                    value={editArray.hardware_version} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12} >
                                <Typography className={classes.tabHelp}>Software Version</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setModelEditFormArray(e, 'software_version')
                                    }}
                                    size="small" id="outlined" value={editArray.software_version} className={classes.textField} />
                            </Grid>
                            
                            <Grid item lg={6} xs={12} >
                                <Typography className={classes.tabHelp}>Voltage</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'nominal_voltage')
                                }}
                                    size="small" id="outlined" value={editArray.nominal_voltage} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12} >
                                <Typography className={classes.tabHelp}>Capacity</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'capacity_mah')
                                }}
                                    size="small" id="outlined" value={editArray.capacity_mah} className={classes.textField} />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Power</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'power')
                                }}
                                    size="small" id="outlined" value={editArray.power} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Manufacturer </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'cell_maufacturer')
                                }}
                                    size="small" id="outlined" value={editArray.cell_maufacturer} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>OEM </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'oem')
                                }}
                                    size="small" id="outlined" value={editArray.oem} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'number_of_cells_series')
                                }}
                                    size="small" id="outlined" value={editArray.number_of_cells_series} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'number_of_cells_parallel')
                                }}
                                    size="small" id="outlined" value={editArray.number_of_cells_parallel} className={classes.textField} />
                            </Grid>
                            
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'cell_chemisty')
                                }}
                                    size="small" id="outlined" value={editArray.cell_chemisty} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Cell Type</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'cell_type')
                                }}
                                    size="small" id="outlined" value={editArray.cell_type} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Length </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'length')
                                }}
                                    size="small" id="outlined" value={editArray.length} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Width </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'width')
                                }}
                                    size="small" id="outlined" value={editArray.width} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Height </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'height')
                                }}
                                    size="small" id="outlined" value={editArray.height} className={classes.textField} />
                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={() => setOpenEditModel(false)}
                        color="secondary">
                        Cancel
                    </Button>
                    <Button onClick={() => {
                        submitModelEdit(true)
                        setOpenEditModel(false)
                    }}
                        color="primary" autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                fullScreen={fullScreen}
                open={openEditBattery}
                maxWidth={"lg"}
                // data={BatteryModelDataRaw}
                onClose={() => setOpenEditBattery(false)}
                aria-labelledby="responsive-dialog-title"
                className={!fullScreen ? classes.dialog : null}
            >
                <DialogTitle id="responsive-dialog-title">{"Edit Battery"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                        <Grid item lg={6} xs={12}>
                    <Typography className={classes.tabHelp}>Battery Model</Typography>
                    <Select
                  // onChange={(e) => { setUserEditFormArray(e, 'role_id') }}
                  // value={editArray.role_id} 
                  className={classes.textField}>

                  <MenuItem value="">Select Battery Model</MenuItem>
                  {allEditModel.map((model) => {
                    return (
                      <MenuItem value={model[1]}>{model[0]}</MenuItem>

                    )
                  }
                  )}
                </Select>
                </Grid>
                        
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Serial Number</Typography>
                                <TextField size="small" id="outlined" placeholder="eg: Serial Number" className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                                <TextField size="small" id="outlined" placeholder="eg: Unique Identifier" className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Owner/Investor</Typography>
                                <TextField size="small" id="outlined" placeholder="eg: Battery Owner/Investor" className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Operation owner</Typography>
                                <TextField size="small" id="outlined" placeholder="eg: Battery Operation owner" className={classes.textField} />
                            </Grid>

                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={() => setOpenEditBattery(false)}
                        color="secondary">
                        Cancel
                    </Button>
                    <Button onClick={() => setOpenEditBattery(false)
                    }
                        color="primary" autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            <br /><br />
            <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
        </div>
    );
}
