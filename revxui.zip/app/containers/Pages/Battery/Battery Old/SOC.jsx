import React from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import { createTheme, withStyles } from '@material-ui/core/styles';
import ThemePallete from 'enl-api/palette/themePalette';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  CartesianAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { data1 , data1year, data1month } from './sampleData';
import styles from './fluidChart-jss';
import { Typography } from '@material-ui/core';
import endpoints from '../../../endpoints/endpoints';
const theme = createTheme(ThemePallete.magentaTheme);
const color = ({
  primary: "#68A724",
  secondary: theme.palette.secondary.main,
});

const CustomizedLabel = props => {
  const {
    x,
    y,
    stroke,
    value
  } = props;
  return (
    <text x={x} y={y} dy={-4} fill={stroke} fillOpacity="0.8" fontSize={10} textAnchor="middle">
      { value }
    </text>
  );
};

CustomizedLabel.propTypes = {
  x: PropTypes.number,
  y: PropTypes.number,
  value: PropTypes.number,
  stroke: PropTypes.string,
};

CustomizedLabel.defaultProps = {
  x: 0,
  y: 0,
  value: 0,
  stroke: '#000'
};
const CustomizedLabelnew = (props) => {
  const {text}=props;
  return(
    <Typography style={{fontSize:'12px '}}>{text} % </Typography>
  )
}

function SOC(props) {
  const { classes , dataIndex,  imei  } = props;
  const [ graphData , setGraphData ] = React.useState([]);
  const [ graphDataM , setGraphDataM ] = React.useState([]);
  const [ graphDataY , setGraphDataY ] = React.useState([]);

React.useEffect(() => {
  
  let Url = endpoints.baseUrl + `/battery/chart/soc?imei=`+imei;
  // let UrlM = endpoints.baseUrl + `/battery/chart/soc?graftype=day&bms_id=`+bmsid;
  // let UrlY = endpoints.baseUrl + `/battery/chart/soc?graftype=day&bms_id=`+bmsid;

  axios.get(Url).then((response) => {
    setGraphData(response.data.data)
  }).catch((error) => { }) 
  },[dataIndex])
  return (
    <div className={classes.chartFluid}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          width={800}
          height={600}
          data={
            dataIndex === 'day' ?
            graphData : dataIndex === 'year' ? graphDataY : data1month
          }
          margin={{
            top: 15,
            right: 30,
            left: 20,
            bottom: 5
          }}
        >
          <XAxis dataKey="time" tickLine={false} />
          <YAxis label={{className:'yaxix-value', value: 'State Of Charge', angle: -90, position: 'insideBottomLeft' }}  axisLine={false} tickSize={3} tickLine={false} tickFormatter={tick => `${tick}%` } tick={{ stroke: 'none' }} />
          <CartesianGrid vertical={false} strokeDasharray="3 3" />
          <CartesianAxis vertical={false} />
          <Tooltip />
 
          <Legend iconType="circle" content={<h3>TimeLine</h3>}  />
          <Line type="monotone" dataKey="soc" strokeWidth={3} stroke={color.primary} label={<CustomizedLabel stroke={color.primary} />} />
          {/* <Line type="monotone" dataKey="uv" strokeWidth={3} stroke={color.secondary} label={<CustomizedLabel stroke={color.secondary} />} /> */}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// SOC.propTypes = {
//   classes: PropTypes.object.isRequired,
// };

export default withStyles(styles)(SOC);


// import React from 'react';
// import PropTypes from 'prop-types';
// import { createTheme, withStyles } from '@material-ui/core/styles';
// import ThemePallete from 'enl-api/palette/themePalette';
// import {
//   LineChart,
//   Line,
//   XAxis,
//   YAxis,
//   CartesianGrid,
//   CartesianAxis,
//   Tooltip,
//   Legend,
//   ResponsiveContainer,
// } from 'recharts';
// import { data3 } from './sampleData';
// import styles from './fluidChart-jss';

// const theme = createTheme(ThemePallete.magentaTheme);
// const color = ({
//   primary:  "#68A724",
//   secondary: "#68A724",
// });

// const CustomizedLabel = props => {
//   const {
//     x,
//     y,
//     stroke,
//     value
//   } = props;
//   return (
//     <text x={x} y={y} dy={-4} fill={stroke} fillOpacity="0.8" fontSize={10} textAnchor="middle">
//       { value }
//     </text>
//   );
// };

// CustomizedLabel.propTypes = {
//   x: PropTypes.number,
//   y: PropTypes.number,
//   value: PropTypes.number,
//   stroke: PropTypes.string,
// };

// CustomizedLabel.defaultProps = {
//   x: 0,
//   y: 0,
//   value: 0,
//   stroke: '#000'
// };

// function Chart3(props) {
//   const { classes } = props;
//   return (
//     <div className={classes.chartFluid}>
//       <ResponsiveContainer width={500} height="100%">
//         <LineChart
//           width={800}
//           height={500}
//           data={data3}
//           margin={{
//             top: 5,
//             right: 30,
//             left: 20,
//             bottom: 5
//           }}
//         >
//           <XAxis dataKey="name" tickLine={false} />
//           <YAxis label={{className:'yaxix-value', value: 'State Of Charge', angle: -90, position: 'insideLeft' }}  axisLine={false} tickSize={3} tickLine={false}
//           //  tickFormatter={tick => `${tick}%` } 
//            tick={{ stroke: 'none' }} />
//           <CartesianGrid vertical={false} strokeDasharray="3 3" />
//           <CartesianAxis vertical={false} />
//           <Tooltip />
//           <Legend iconType="circle" content={<h3>TimeLine</h3>}  />
//           {/* <Line type="monotone" dataKey="pv" strokeWidth={3} stroke={color.primary} label={<CustomizedLabel stroke={color.primary} />} /> */}
//           <Line type="monotone" dataKey="uv" strokeWidth={3} stroke={color.secondary} label={<CustomizedLabel stroke={color.secondary} />} />
//         </LineChart>
//       </ResponsiveContainer>
//     </div>
//   );
// }

// Chart3.propTypes = {
//   classes: PropTypes.object.isRequired,
// };

// export default withStyles(styles)(Chart3);