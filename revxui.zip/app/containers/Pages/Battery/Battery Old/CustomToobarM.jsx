import React from "react";
import axios from 'axios';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { withStyles, makeStyles, useTheme, styled, useStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import AddModel from './AddModel';
import AddBattery from './AddBattery';
import { Icon } from '@iconify/react';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import FormControl from '@material-ui/core/FormControl';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import classNames from 'classnames';
import { getBatteryModelBulk } from '../../../redux/actions/asyncActions';
import { useDispatch, useSelector, useState } from 'react-redux';
import endpoints from '../../../endpoints/endpoints';

export default function CustomToolbar() {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const [openAddModel, setOpenAddModel] = React.useState(false);

  const handleClick = () => {
  }
  const useStyles = makeStyles((theme) => ({
    IconButton: {
      '&:hover': {
        color: '#9ccc65'
      },
      transform: !fullScreen ? "translateX(-12em)" : null
    },
    textField: {
      width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
      'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    IconButton1: {
      '&:hover': {
        color: '#9ccc65'
      },
      transform: !fullScreen ? "translateX(-14em)" : null
    },
    dialog: {
      // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
      position: 'relative', marginLeft: '680px'
    }
  }));

  //   const theme = useTheme();
  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const [hardware, setHardware] = React.useState('');
  const [software, setSoftware] = React.useState('');
  const [cellmanufact, setCellmanufact] = React.useState('');
  const [modelAddForm, setModelAddForm] = React.useState(
    {
      model_info: "",
      hardware_version: "",
      software_version: "",
      nominal_voltage: "",
      capacity_mah: "",
      power: "",
      cell_maufacturer: "",
      oem: " ",
      number_of_cells_series: " ",
      number_of_cells_parallel: " ",
      cell_chemisty: " ",
      cell_type: " ",
      length: " ",
      width: " ",
      height: " "
    }
  )
  const BatteryModelData = useSelector((store) => store.batteryModel)
  let BatteryModelMeta = useSelector((store) => store.batteryModel)
  const BatteryModelDataRaw = useSelector((store) => store.batteryModel.rawData)
  let BatteryModelFetching = useSelector((store) => store.batteryModel.fetching)
  let BatteryModelResponsecode = useSelector((store) => store.batteryModel.responseStatus)
  let BatteryModelMetaPresent = useSelector((store) => store.batteryModel.dataPresent)


  // const batteryArr = makeAPICall();
  // const [fetchedData, setFetchedData] = React.useState([]);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getBatteryModelBulk());
  }, [dispatch, BatteryModelMetaPresent]);

  const submitModel = () => {
    const postModel = endpoints.baseUrl + `/batterymodel/add`;
    axios
      .post(postModel, modelAddForm)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        dispatch(getBatteryModelBulk());

      });
  }
  const setModelAddFormArray = (e, key) => {
    setModelAddForm((state) => ({ ...state, [key]: e.target.value }));

  }
  const handleChange1 = (event) => {
    setHardware(event.target.value);
  };
  const handleChange2 = (event) => {
    setSoftware(event.target.value);
  };
  const handleChange3 = (event) => {
    setCellmanufact(event.target.value);
  };
  return (
    <React.Fragment>
      
<Tooltip style={{ flex: 'left' }} title={"Onboarding Model"}>
      <IconButton className={classes.IconButton} onClick={() => setOpenAddModel(true)}>
        <Icon icon="fluent:tab-add-24-filled" />
        </IconButton>
      </Tooltip>
      <Dialog
        fullScreen={fullScreen}
        open={openAddModel}
        maxWidth={"lg"}
        onClose={() => setOpenAddModel(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Onboarding Model"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {/* <AddModel /> */}
            <Grid container spacing={2}>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Model</Typography>
                <TextField
                  onChange={(e) => {
                    setModelAddFormArray(e, 'model_info')
                  }}
                  size="small" id="outlined" value={modelAddForm.model_info} placeholder="eg: Model" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12} >
                <Typography className={classes.tabHelp}>Voltage</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'nominal_voltage')
                }}
                  size="small" id="outlined" value={modelAddForm.nominal_voltage} placeholder="eg: Voltage" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12} >
                <Typography className={classes.tabHelp}>Capacity</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'capacity_mah')
                }}
                  size="small" id="outlined" value={modelAddForm.capacity_mah} placeholder="eg: Capacity" className={classes.textField} />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Power</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'power')
                }}
                  size="small" id="outlined" value={modelAddForm.power} placeholder="eg: Power" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Manufacturer </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'cell_maufacturer')
                }}
                  size="small" id="outlined" value={modelAddForm.cell_maufacturer} placeholder="eg: Manufacturer " className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>OEM </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'oem')
                }}
                  size="small" id="outlined" value={modelAddForm.oem} placeholder="eg: OEM " className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'number_of_cells_series')
                }}
                  size="small" id="outlined" value={modelAddForm.number_of_cells_series} placeholder="eg: Number of Cells Series" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'number_of_cells_parallel')
                }}
                  size="small" id="outlined" value={modelAddForm.number_of_cells_parallel} placeholder="eg: Number of Cells Parallel" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'cell_chemisty')
                }}
                  size="small" id="outlined" value={modelAddForm.cell_chemisty} placeholder="eg: Cell Chemistry" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Cell Type</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'cell_type')
                }}
                  size="small" id="outlined" value={modelAddForm.cell_type} placeholder="eg: Cell Type" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Length </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'length')
                }}
                  size="small" id="outlined" value={modelAddForm.length} placeholder="eg: Length " className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Width </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'width')
                }}
                  size="small" id="outlined" value={modelAddForm.width} placeholder="eg: Width " className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Height </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'height')
                }}
                  size="small" id="outlined" value={modelAddForm.height} placeholder="eg: Height " className={classes.textField} />
              </Grid>
              <Grid item lg={6} xs={12}></Grid>
        <DialogTitle id="responsive-dialog-title">{"BMS Model"}</DialogTitle>
              <Grid item lg={6} xs={12}></Grid>

              
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>BMS Model </Typography>
                <TextField 
                // onChange={(e) => {
                //   setModelAddFormArray(e, 'height')
                // }}
                  size="small" id="outlined" 
                  // value={modelAddForm.height} 
                  placeholder="eg: BMS Model " className={classes.textField} />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Hardware </Typography>
                <TextField 
                // onChange={(e) => {
                //   setModelAddFormArray(e, 'height')
                // }}
                  size="small" id="outlined" 
                  // value={modelAddForm.height} 
                  placeholder="eg: Hardware " className={classes.textField} />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>OEM </Typography>
                <TextField 
                // onChange={(e) => {
                //   setModelAddFormArray(e, 'height')
                // }}
                  size="small" id="outlined" 
                  // value={modelAddForm.height} 
                  placeholder="eg: OEM " className={classes.textField} />
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenAddModel(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            onClick={() => {
              submitModel(true)
              setOpenAddModel(false)
              // refreshPage(true)
            }}
            color="secondary" autoFocus>
            Submit
          </Button>
        </DialogActions>
      </Dialog>
 
    </React.Fragment>

  );


}

// export default withStyles(CustomToolbar, defaultToolbarStyles, { name: "CustomToolbar" });
