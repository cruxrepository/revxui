import React, { useState } from 'react';
import axios from 'axios';
import { withStyles, makeStyles, useTheme, styled, alpha, darken } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import LinearProgress from '@material-ui/core/LinearProgress';
import Chip from '@material-ui/core/Chip';
import MUIDataTable from 'mui-datatables';
import MenuItem from "@material-ui/core/MenuItem";
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Button from "@material-ui/core/Button";
import BatteryVoltage from "./BatteryVoltage";
import BatteryCurrent from "./BatteryCurrent";
import SOC from "./SOC";
import TotalOdometer from "./TotalOdometer";
import Select from "@material-ui/core/Select";
import Tooltip from '@material-ui/core/Tooltip';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import TabIcon from '@material-ui/icons/Tab';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import BatteryCharging30Icon from '@material-ui/icons/BatteryCharging30';
import endpoints from '../../../endpoints/endpoints';
import CustomToolbar from './CustomToobar';
import MotorcycleIcon from '@material-ui/icons/Motorcycle';
import CustomToolbarM from './CustomToobarM';
import Divider from '@material-ui/core/Divider';


import AcUnit from '@material-ui/icons/AcUnit';
import Adb from '@material-ui/icons/Adb';
import AllInclusive from '@material-ui/icons/AllInclusive';
import AssistantPhoto from '@material-ui/icons/AssistantPhoto';
import AppBar from '@material-ui/core/AppBar';
import PhotoLibrary from '@material-ui/icons/PhotoLibrary';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import SimpleMap from "./SimpleMap";
import TreeTable from "./TreeTable";
import Pagination from '@material-ui/lab/Pagination';


import Dialog from '@material-ui/core/Dialog';
import Brightness1Icon from '@material-ui/icons/Brightness1';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { getMyBatteryBulk, getBatteryModelBulk, getBatteryProBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';

const useStyles = makeStyles((theme) => ({
    tableborder: { display: 'none' },
    root: {
        margin: 10
    },
    textField: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
        'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    table: {

        '& > div': {

            '& > .MuiToolbar-regular': {
                backgroundColor: '#68A72480  !important',
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0
            },
            // overflow: 'auto',
            // textAlign:'center'
        },

        '& table': {
            '& td': {
                wordBreak: 'keep-all',
                textAlign: 'center'
            },

            [theme.breakpoints.down('md')]: {
                '& td': {
                    height: 60,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                },
                '& tr:nth-child(odd)': {
                    backgroundColor: '#cfcfcf40'
                },
                '& tr:nth-child(even)': {
                    backgroundColor: '#cfcfcf20'
                },
            }
        }
    },
    graphText: {
        fontSize: 12,
        position: 'absolute',
        transform: 'rotate(270deg)',
        left: '-40px',
        top: 370,
        color: 'primary',
        fontWeight: 600
    },
    graphSelect: {
        minWidth: 150, left: '20em', marginBottom: 20
    },
    tabsSection: {
        [theme.breakpoints.up('lg')]: {
            // borderRadius:0,position:'sticky',top:0 ,width:500
            borderRadius: 0, top: 0, width: 510

        },


    },
    addTab:{backgroundColor:'#b3d391', color:"#fff"},
    primaryText: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
    }, primaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '300px'
    },
    secondaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '100%'
    },
    voltageG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724'
    },
    voltageY: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FFBF00'
    },
    voltageR: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FF0000'
    },
    chart1: {
        marginLeft: '-20px', width: '120px', height: '50px', '.MuiPaper-root .MuiMenu-paper .MuiPopover-paper': { width: '120px !important' }
    },
    copyRight: {
        position: 'absolute', bottom: 0, right: 0, left: 0, fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    dialog: {
        // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
        position: 'relative', marginLeft: '680px'
    },
    healthy: {
        color: '#82E219', width: '5rem', fontSize: '20px'
    },
    Unhealthy: {
        color: '#FFFF00'
    },
    chart: {
        padding: theme.spacing(2)
    },
    dataView: {
        height: '300px',
    },
    BNavatar: { height: '60px', width: '60px', border: '1px solid #fff', backgroundColor: "rgba(76, 175, 80, 1.0)" },
    BNavatar1: { backgroundColor: '#f3efef' },
    BNgrid: { marginLeft: 20 },
    BNprimaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '16px', fontWeight: 600, color: 'primary', width: '200px',
    },
    BNstateText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '20px', fontWeight: 500, color: '#fff', width: '250px',
    },
    BNsecondaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary',
    },
    BNsecondaryTextG: { color: '#00FF00' },
    BNsecondaryText1: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary', width: '150px',
    },
    BNIcon: {
        marginRight: 10, marginTop: 10
    },
    BNtitle: {},
    BNsubtitle: {},

    BNchip: { backgroundColor: '#4caf50b5' },
    BNchip2: { backgroundColor: '#FFBF00' },
    BNchip3: { backgroundColor: '#FF0000' },
    BNstyledPaper: {
        backgroundColor: '#4caf50b5',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper2: {
        backgroundColor: '#FFBF00',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper3: {
        backgroundColor: '#FF0000',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNprogressWidget: {
        marginTop: 20,
        background: theme.palette.secondary.dark,
        '& div': {
            background: theme.palette.primary.light,
        }
    },
    BNmap: {
        height: 200, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    BNcover: {
        '& $name, & $subheading': {
            color: theme.palette.common.white
        },
        position: 'relative',
        width: '100%',
        overflow: 'hidden',
        height: 165,
        backgroundColor: "rgba(76, 175, 80, 1.0)"
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        ,
        // backgroundColor:
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        // ,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundSize: 'cover',
        textAlign: 'center',
        boxShadow: theme.shadows[7],
        backgroundPosition: 'bottom center',
        borderRadius: '10px 10px 0px 0px',
    },
    BNname: {
        fontSize: '24px', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400, color: '#fff'
    },
    BNopt: {
        position: 'absolute',
        top: 0,
        right: 10,
        '& button': {
            color: theme.palette.common.white
        }
    },
    BNprofileTab: {
        marginTop: 0,
        [theme.breakpoints.down('sm')]: {
            marginTop: 0,
        },
        borderRadius: '0px 0px 10px 10px',
        background:
            // alpha(theme.palette.background.paper, 0.8)
            "#dcead7",
        position: 'relative'
    },
    BNaboutTxt: {
        fontSize: '1rem', fontWeight: 600, color: '#000000'
    },

    BNaboutTxt1: {
        fontSize: '1rem', fontWeight: 400, color: '#000000'
    },
    BNdriving: {
        color: '#82E219', marginLeft: '-90px'
    },
    BNdrivingR: {
        color: '#ff0000', marginLeft: '-90px'
    },
    BNorangeAvatar: {
        backgroundColor: '#ff5722',
    },
    BNpurpleAvatar: {
        backgroundColor: '#673ab7',
    },
    BNpinkAvatar: {
        backgroundColor: '#e91e63',
    },
    BNgreenAvatar: {
        backgroundColor: '#4caf50',
    },
    BNdivider: {
        width: '92%', marginLeft: '20px'
    },
    pageTitle: {
        textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600
    }
}));
function TabContainer(props) {
    const { children } = props;
    return (
        <div style={{ paddingTop: 8 * 3 }}>
            {children}
        </div>
    );
}

TabContainer.propTypes = {
    children: PropTypes.node.isRequired,
};

/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/

export default function BatteryPage() {

    const MyBatteryData = useSelector((store) => store.myBattery)
    const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
    let MyBatteryMeta = useSelector((store) => store.myBattery)
    // let MyBatteryMeta =  getBatteryModelBulk()
    // let MyBatteryMeta=[];
    let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
    let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
    let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)

    const BatteryProData = useSelector((store) => store.batteryPro)
    const BatteryModelProRaw = useSelector((store) => store.batteryPro.rawData)
    let BatteryProMeta = useSelector((store) => store.batteryPro)
    let BatteryProFetching = useSelector((store) => store.batteryPro.fetching)
    let BatteryProResponsecode = useSelector((store) => store.batteryPro.responseStatus)
    let BatteryProMetaPresent = useSelector((store) => store.batteryPro.dataPresent)

    const BatteryModelData = useSelector((store) => store.batteryModel)
    const BatteryModelDataRaw = useSelector((store) => store.batteryModel.rawData)
    let BatteryModelMeta = useSelector((store) => store.batteryModel)
    let BatteryModelFetching = useSelector((store) => store.batteryModel.fetching)
    let BatteryModelResponsecode = useSelector((store) => store.batteryModel.responseStatus)
    let BatteryModelMetaPresent = useSelector((store) => store.batteryModel.dataPresent)

    const logged_user = useSelector((store) => store.user.loggeduser);
    let enty = logged_user.entity_id
    const dispatch = useDispatch();

    const [openEditModel, setOpenEditModel] = React.useState(false);
    const [openEditBattery, setOpenEditBattery] = React.useState(false);

    const theme = useTheme();
    const classes = useStyles();
    const [screen, setScreen] = React.useState(false);
    const [idleMode, setIdleMode] = React.useState(false);
    const [openAddBattery, setOpenAddBattery] = React.useState(false);
    const [openAddModel, setOpenAddModel] = React.useState(false);

    let allModel = BatteryModelMeta.data
    const [batteryAddForm, setBatteryAddForm] = React.useState(
        {
            battery_model_id: "",
            serial_number: "",
            bms_unique_id: "",
            investor: "",
            operation_owner: "",
            sw_version: ""
        }
    )
    const submitBattery = () => {
        const postBattery = endpoints.baseUrl + `/battery/post`;
        axios
            .post(postBattery, batteryAddForm)
            .then((response) => {
                dispatch(getMyBatteryBulk());

            });
    }
    const setBatteryAddFormArray = (e, key) => {
        setBatteryAddForm((state) => ({ ...state, [key]: e.target.value }));

    }

    const [modelAddForm, setModelAddForm] = React.useState(
        {
          model_info: "",
          hardware_version: "",
          software_version: "",
          nominal_voltage: "",
          capacity_mah: "",
          power: "",
          cell_maufacturer: "",
          oem: " ",
          number_of_cells_series: " ",
          number_of_cells_parallel: " ",
          cell_chemisty: " ",
          cell_type: " ",
          length: " ",
          width: " ",
          height: " "
        }
      )
      const submitModel = () => {
        const postModel = endpoints.baseUrl + `/batterymodel/add`;
        axios
          .post(postModel, modelAddForm)
          .then((response) => {
            // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
            dispatch(getBatteryModelBulk());
    
          });
      }
      const setModelAddFormArray = (e, key) => {
        setModelAddForm((state) => ({ ...state, [key]: e.target.value }));
    
      }
    const [zoomVar, setZoomVar] = React.useState(0);

    const [value, setValue] = React.useState(0);
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const handleChangeT = (event, val) => {
        setValue(val);
    };


    React.useEffect(() => {
        // typeof enty != "undefined" ? dispatch(getMyBatteryBulk(enty)) : null;
        dispatch(
            getBatteryModelBulk()
        );

    }, [MyBatteryMetaPresent]);


    let allEditModel = BatteryModelMeta.data
    {/* Battery*/ }
    const [editBatArray, setEditBatArray] = React.useState(
        {

        }
    )
    const setEditBatteryArray = (bms_id) => {
        let allBattery = MyBatteryDataRaw;
        let findEditArray = allBattery.find(el => el.bms_id === bms_id);
        setEditBatArray(findEditArray);
    }
    const submitEditBattery = () => {
        const putBattery = endpoints.baseUrl + `/battery/update/` + editBatArray.bms_id;
        axios
            .put(putBattery, editBatArray)
            .then((response) => {
                dispatch(getMyBatteryBulk());

            });

    }


    const setEditBatteryFormArray = (e, key) => {
        setEditBatArray((state) => ({ ...state, [key]: e.target.value }));

    }

    {/* Model*/ }
    const [editArray, setEditArray] = React.useState(
        {

        }
    )
    const setModelEditArray = (battery_model_id) => {
        let allModel = BatteryModelDataRaw;
        let findArray = allModel.find(el => el.battery_model_id === battery_model_id);
        setEditArray(findArray);
    }
    const submitModelEdit = () => {
        const putModel = endpoints.baseUrl + `/batterymodel/edit/` + editArray.battery_model_id;
        axios
            .put(putModel, editArray)
            .then((response) => {
                dispatch(getBatteryModelBulk());

            });

    }

    const deleteModel = (battery_model_id) => {
        const deleteModel = endpoints.baseUrl + `/batterymodel/softdelete/` + battery_model_id;
        axios
            .delete(deleteModel)
            .then((response) => {
                dispatch(getBatteryModelBulk());
            });
    }

    const setModelEditFormArray = (e, key) => {
        setEditArray((state) => ({ ...state, [key]: e.target.value }));

    }


    const Item = styled(Paper)(({ theme }) => ({
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'left',
        color: theme.palette.text.secondary,
    }));

    const validateKeyData = (key) => {
        return key ? key : "-";
    };

    const [tableMode, setTableMode] = React.useState("ericksaw");
    const handleTableChange = (event) => {
        if (tableMode === 'erickshaw') {
            setTableMode('comm');
        } else {
            setTableMode('erickshaw');
        }
    };
    const dayDropdown = [{ val: 'day', name: 'Day' }, { val: 'month', name: 'Month' }, { val: 'year', name: 'Year' }, { val: 'custom', name: 'Custom' }]


    const [zoom, setZoom] = React.useState(10);



    const columsModel = [
        {
            name: 'Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography color='secondary' variant='subtitle2'>{validateKeyData(value)} </Typography>
                )
            }
        },
        {
            name: 'Voltage',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Capacity',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Power',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Manufacturer',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Action',
            options: {
                filter: true,
                customBodyRender: (value) => {
                    // if (value === 'assign') {
                    return (<Select
                        style={{ minWidth: 150, color: '#FFC130' }}
                        value='Edit'
                    >
                        <MenuItem onClick={() => {
                            setOpenEditModel(true)
                            setModelEditArray(value)
                        }
                        }
                            value='Edit'>Edit</MenuItem>
                        <MenuItem
                            onClick={() => { deleteModel(value) }}
                            style={{ color: "#FF6058 !important" }} value="Delete">
                            Delete
                        </MenuItem>
                    </Select>)
                }
            }
        },
    ]

    const [bmsid, setBmsId] = React.useState(0);
    const [serial, setSerial] = React.useState(0);
    const [model, setModel] = React.useState(0);
    const [operation, setOperation] = React.useState(0);

    const batteryProfile = (bmsid) => {
        dispatch(getBatteryProBulk(bmsid));
    }

    const columnsBattery = [

        {
            name: 'Serial Number',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                        setScreen(true)
                        setBmsId(validateKeyData(value.bms_id))
                        setSerial(validateKeyData(value.serial_number))
                        setModel(validateKeyData(value.battery_model))
                        setOperation(validateKeyData(value.operation_owner))
                        batteryProfile(validateKeyData(value.bms_id))
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        &nbsp;&nbsp;{value.serial_number}
                    </Typography>

                )
            }
        },
        {
            name: 'Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                        setScreen(true)
                        setModel(value.model)
                    }}
                        // style={{ color: '#33a6ff', cursor: 'pointer' }} 
                        variant='subtitle2'>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Investor',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => setScreen(true)} variant='subtitle2'>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Operation Owner',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => setScreen(true)} variant='subtitle2'>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Vehicle Number',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <Typography style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>{validateKeyData(value)}</Typography>
                )
            }
        },

        {
            name: 'Status',
            options: {
                filter: true,
                customBodyRender: (value) => {
                    if (value.vehicle_number && value.battery_status === "on") {
                        return (
                            <><IconButton
                                onClick={() => {
                                    setOpenEditBattery(true)
                                    setEditBatteryArray(value.bms_id)
                                }}
                            ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="28" height="28" /></IconButton>
                                <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_number && value.battery_status === "off") {
                        return (
                            <><IconButton
                                onClick={() => {
                                    setOpenEditBattery(true)
                                    setEditBatteryArray(value.bms_id)
                                }}
                            ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }
                    else {
                        return (
                            <><IconButton
                                onClick={() => {
                                    setOpenEditBattery(true)
                                    setEditBatteryArray(value.bms_id)
                                }}
                            ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:motorbike" color="#c4c4c4" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }


                },

            },

        },
    ];



    const options = {
        filterType: 'dropdown',
        responsive: 'vertical',
        print: true,
        rowsPerPage: 50,
        page: 0,
        selectableRows: "none",
        // customToolbar: () => {
        //     return (
        //         value === 0 ?
        //             <CustomToolbar value={value} />
        //             : <CustomToolbarM value={value} />
        //     );
        // }

    };
    const [chartOneVal, setChartOneVal] = React.useState("day");
    const handleChartOneVal = (e) => {
        setChartOneVal(e.target.value);

    }



    const [frame, setFrame] = React.useState(false)

    // const myStr = BatteryProMeta.data[0]["min_voltage_cell"];
    // const newStr = myStr.replace("Voltage", " ");

    // const myStr1 = BatteryProMeta.data[0]["max_voltage_cell"];
    // const newStr1 = myStr1.replace("Voltage", " ");

    // const myStr2 = BatteryProMeta.data[0]["min_temperature_cell"];
    // const newStr2 = myStr2.replace("Temperature", " ");

    // const myStr3 = BatteryProMeta.data[0]["max_temperature_cell"] ? BatteryProMeta.data[0]["max_temperature_cell"] : null ;
    // const newStr3 = myStr3.replace("Temperature", " ");

    return (
        <div
            // onMouseMove={() => setFrame(!frame)}
            className={classes.table}>
            {screen !== true ? <Typography className={classes.pageTitle} component="h4" variant="h4">Battery</Typography> :
                <Typography className={classes.pageTitle} component="h4" variant="h4">Battery Profile</Typography>}

            {screen !== true ?
                <Tabs
                    className={classes.tabsSection}
                    value={value}
                    onChange={handleChange}
                    variant="fullWidth"
                    indicatorColor="primary"
                    aria-label="icon tabs example"
                >
                    <Tab label="Battery" onClick={() => {
                        setScreen(false)
                    }} icon={<BatteryCharging30Icon />} aria-label="favorite" />
                    <Tab label="Model" onClick={() => {
                        setScreen(false)
                    }} icon={<TabIcon />} aria-label="phone" />
                    {value === 0 ? <Button onClick={() => {
                       setOpenAddBattery(true)
                    }} variant="contained" className={classes.addTab}
                    startIcon={<Icon icon="fluent:phone-add-24-regular" height="25" width="25" />}>
                        Onboarding<br/>Battery</Button> 
                        : <Button onClick={() => {
                            setOpenAddModel(true)
                         }} variant="contained"  className={classes.addTab} 
                         startIcon={<Icon icon="fluent:tab-add-24-filled"  height="25" width="25"/>}>
                             Onboarding<br/>Model</Button>}

                </Tabs> : null}


            <Paper square className={classes.root}>

            </Paper>
            {(screen !== true
                // && (
                // MyBatteryMetaPresent &&
                // BatteryModelMetaPresent)
            ) ?
                (
                    value === 0 ?
                        <MUIDataTable
                            checkboxSelection={false}
                            title="Battery"
                            // data={data}
                            data={MyBatteryMeta.data}
                            columns={columnsBattery}
                            options={options}
                            selectableRowsHideCheckboxes
                        />
                        :
                        <MUIDataTable
                            checkboxSelection={false}
                            title="MODEL"
                            // data={dataModel}
                            data={BatteryModelMeta.data}
                            columns={columsModel}
                            options={options}
                            selectableRowsHideCheckboxes
                        />


                )
                :
                (
                    //     //     MyBatteryMetaPresent &&
                    BatteryProMetaPresent) ?
                    (
                        <>

                            <div className={classes.BNcover}><div className={classes.BNopt}>
                                <IconButton className={classes.BNbutton} >
                                    <Icon icon="fa:cloud-download" color="white" width="30" height="30" />
                                </IconButton>
                                <IconButton onClick={() => {
                                    setScreen(false)
                                }} className={classes.BNbutton} >
                                    <Icon icon="bi:arrow-left-circle-fill" width="26" height="26" />
                                </IconButton>
                            </div>
                                <div className={classes.BNcontent}>
                                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                                        <Avatar className={classes.BNavatar}>
                                            <Icon icon="mdi:car-battery" width="40" height="40" />
                                        </Avatar></div>
                                    <Typography className={classes.BNname} gutterBottom>
                                        {validateKeyData(serial)}
                                    </Typography>
                                    <Typography className={classes.BNname} gutterBottom>
                                        {validateKeyData(model)}
                                    </Typography>
                                </div></div>

                            <AppBar position="static" className={classes.BNprofileTab}>
                                <Tabs
                                    value={value}
                                    onChange={handleChangeT}
                                    variant="fullWidth"
                                    indicatorColor="primary"
                                    textColor="primary"
                                    centered

                                >
                                    <Tab icon={<Icon icon="bxs:battery-charging" width="30" height="30" />} label="About" />
                                    <Tab icon={<Icon icon="ant-design:line-chart-outlined" width="30" height="30" />} label="Chart" />
                                    <Tab icon={<PhotoLibrary />} label="Parameters" />
                                </Tabs>
                            </AppBar>
                            {value === 0 &&
                                <TabContainer><br />
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} lg={6}>
                                            <Paper>
                                                <ListItem>
                                                    <ListItemAvatar>
                                                        <Avatar className={classes.BNavatar1}>
                                                            <Icon icon="mdi:car-battery" color="#82e219" width="26" height="26" />
                                                        </Avatar>
                                                    </ListItemAvatar>

                                                    <ListItemText primary={
                                                        <Typography className={classes.BNaboutTxt}>About</Typography>
                                                    }
                                                        secondary={
                                                            <React.Fragment>
                                                                <Typography className={classes.BNaboutTxt1} >
                                                                    <b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
                                                                        {validateKeyData(serial)}</b> of {model}  <br /> OnBoarded on 09-23-2022 18:04:29 by
                                                                    <b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
                                                                        {validateKeyData(operation)}</b></Typography>
                                                            </React.Fragment>

                                                        }
                                                    />
                                                </ListItem><Divider className={classes.BNdivider} />
                                                <Grid container spacing={1} className={classes.BNgrid}>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="ion:hardware-chip-sharp" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>HW Version</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography bmsid={bmsid}
                                                                            className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["hardware_version"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="eos-icons:software-outlined" color="82e219" width="30" height="30" />                                    </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>SW Version</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["software_version"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="emojione-monotone:high-voltage" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Battery Nominal Voltage</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["nominal_voltage"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="mdi:chemical-weapon" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Battery Chemistry</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["cell_chemisty"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="carbon:cost-total" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Battery pack Capacity</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["capacity_mah"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                </Grid>
                                            </Paper>

                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper style={{ height: '315px' }}>
                                                <div style={{ display: 'flex', marginLeft: 10 }}>
                                                    <Typography className={classes.BNprimaryText}>Battery Current</Typography>
                                                    <Typography className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["battery_current"])}</Typography> </div>

                                                <div style={{ display: 'flex', margin: 10 }}>
                                                    <Typography className={classes.BNprimaryText}>Battery Voltage</Typography>
                                                    <Typography className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["battery_voltage"])}</Typography>
                                                </div>

                                                <div style={{ display: 'flex', margin: 10 }}>
                                                    <Typography className={classes.BNprimaryText}>Battery State</Typography>
                                                    <Typography className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["current_state"])}</Typography>
                                                </div>


                                                <Paper
                                                    className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNstyledPaper :
                                                        BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNstyledPaper2 : classes.BNstyledPaper3}
                                                    elevation={4}>
                                                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                        <Typography className={classes.BNstateText}>State Of Health
                                                        </Typography>
                                                        <Chip
                                                            avatar={(
                                                                <Avatar className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNchip :
                                                                    BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNchip2 : classes.BNchip3} >
                                                                    <Icon icon="ant-design:check-circle-outlined" color="white" width="30" height="30" />
                                                                </Avatar>
                                                            )}
                                                            label={validateKeyData(BatteryProMeta.data[0]["soh"]) + "% Progress"}
                                                        />
                                                    </div>
                                                    <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soh"])} />
                                                </Paper><br />

                                                <Paper
                                                    className={classes.BNstyledPaper}
                                                    elevation={4}>
                                                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                        <Typography className={classes.BNstateText}>State Of Charge
                                                        </Typography>
                                                        <Chip
                                                            avatar={(
                                                                <Avatar className={classes.BNchip}
                                                                >
                                                                    <Icon icon="ant-design:check-circle-outlined" color="white" width="30" height="30" />
                                                                </Avatar>
                                                            )}
                                                            label={validateKeyData(BatteryProMeta.data[0]["soc"]) + "% Progress"}
                                                        />
                                                    </div>
                                                    <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soc"])} />
                                                </Paper></Paper>
                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper>
                                                <ListItem>
                                                    <ListItemAvatar>
                                                        <Avatar className={classes.BNavatar1}>
                                                            <Icon icon="bi:flag-fill" color="#82e219" />
                                                        </Avatar>
                                                    </ListItemAvatar>

                                                    <ListItemText primary={
                                                        <Typography className={classes.BNprimaryText}>Voltage & Temperature</Typography>
                                                    } />
                                                </ListItem>
                                                <Grid container spacing={1}>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNpurpleAvatar}>
                                                                    <AcUnit />
                                                                </Avatar>
                                                            </ListItemAvatar>
                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Min Voltage</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={
                                                                                BatteryProMeta.data[0]["min_cell_voltage_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_voltage_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                            {/* {newStr} 
                                                                            &nbsp;-&nbsp;*/}
                                                                            {validateKeyData(BatteryProMeta.data[0]["min_voltage"])}&nbsp;V&nbsp;
                                                                        </Typography>

                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>

                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNpinkAvatar}>
                                                                    <AllInclusive />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Max Voltage</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={BatteryProMeta.data[0]["max_cell_voltage_color"] === "green" ? classes.voltageG : BatteryProMeta.data[0]["max_cell_voltage_color"] === "amber" ? classes.voltageY : classes.voltageR}>
                                                                            {/* {newStr} 
                                                                            &nbsp;-&nbsp;*/}
                                                                            {validateKeyData(BatteryProMeta.data[0]["max_voltage"])}&nbsp;V
                                                                        </Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>

                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNgreenAvatar}>
                                                                    <Adb /></Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Min Temperature</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={
                                                                                BatteryProMeta.data[0]["min_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                            {/* {newStr2} 
                                                                            &nbsp;-&nbsp;*/}
                                                                            {validateKeyData(BatteryProMeta.data[0]["min_temperature"])}&nbsp;ºC
                                                                        </Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>

                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNorangeAvatar}>
                                                                    <AssistantPhoto />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Max Temperature</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={
                                                                                BatteryProMeta.data[0]["max_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["max_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                            {/* {newStr3} 
                                                                            &nbsp;-&nbsp;*/}
                                                                            {validateKeyData(BatteryProMeta.data[0]["max_temperature"])}&nbsp;ºC
                                                                        </Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                </Grid>
                                            </Paper>

                                        </Grid>
                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.BNmap} variant="outlined" >
                                                <SimpleMap
                                                    zoom={10} bmsid={bmsid}
                                                /></Paper>
                                        </Grid>
                                    </Grid>
                                </TabContainer>}
                            {value === 1 && <TabContainer><br />

                                <><Grid item container spacing={2}>
                                    <Grid item xs={12} lg={6}>
                                        <Paper className={classes.paper}><br /> <BatteryVoltage
                                            bmsid={bmsid}
                                            dataIndex={chartOneVal} /></Paper>
                                    </Grid>

                                    <Grid item xs={12} lg={6}>
                                        <Paper className={classes.paper}><br /><SOC bmsid={bmsid} dataIndex={chartOneVal} /></Paper>

                                    </Grid>

                                    <Grid item xs={12} lg={6}>
                                        <Paper className={classes.paper}><br /><TotalOdometer bmsid={bmsid} dataIndex={chartOneVal} /></Paper>

                                    </Grid>

                                    <Grid item xs={12} lg={6}>
                                        <Paper className={classes.paper}><br /><BatteryCurrent bmsid={bmsid} dataIndex={chartOneVal} /></Paper>
                                    </Grid>
                                </Grid></>
                            </TabContainer>}
                            {value === 2 && <TabContainer><br />
                                <TreeTable bmsid={bmsid} />
                            </TabContainer>}



                        </>
                    )

                    : MyBatteryFetching ?
                        <Loading /> :
                        MyBatteryResponsecode === 500 ?

                            <ErrorWrap /> : null



            }
            {/* Add Battery */}
            <Dialog
                fullScreen={fullScreen}
                open={openAddBattery}
                maxWidth={"lg"}
                onClose={() => setOpenAddBattery(false)}
                aria-labelledby="responsive-dialog-title"
                className={!fullScreen ? classes.dialog : null}
            >
                <DialogTitle id="responsive-dialog-title">{"Onboarding Battery"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Model</Typography>
                                {/* <TextField size="small" id="outlined" placeholder="eg: Battery Model" className={classes.textField} /> */}
                                <Select onChange={(e) => {
                                    setBatteryAddFormArray(e, 'battery_model_id')
                                }}
                                    value={batteryAddForm.battery_model_id}
                                    className={classes.textField}>

                                    <MenuItem value="">Select Battery Model</MenuItem>
                                    {/* {allModel.map((model) => { 
                    return (
                      <MenuItem value={model[0]}>{model[0]}</MenuItem>

                    )
                  }
                  )} */}
                                </Select>
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Serial Number</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setBatteryAddFormArray(e, 'serial_number')
                                    }}
                                    size="small" id="outlined" value={batteryAddForm.serial_number} placeholder="eg: Serial Number" className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setBatteryAddFormArray(e, 'bms_unique_id')
                                    }}
                                    size="small" id="outlined" value={batteryAddForm.bms_unique_id} placeholder="eg: Unique Identifier" className={classes.textField} />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Owner/Investor</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setBatteryAddFormArray(e, 'investor')
                                    }}
                                    size="small" id="outlined" value={batteryAddForm.investor} placeholder="eg: Owner/Investor" className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Operation owner</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setBatteryAddFormArray(e, 'operation_owner')
                                    }}
                                    size="small" id="outlined" value={batteryAddForm.operation_owner} placeholder="eg: Operation owner" className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Software Version</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setBatteryAddFormArray(e, 'sw_version')
                                    }}
                                    size="small" id="outlined"
                                    value={batteryAddForm.sw_version}
                                    placeholder="eg: Software Version" className={classes.textField} />
                            </Grid>


                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus
                        onClick={() => setOpenAddBattery(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button
                        onClick={() => {
                            submitBattery(true)
                            setOpenAddBattery(false)
                        }}
                        color="secondary" autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            {/* Add Model */}
            <Dialog
        fullScreen={fullScreen}
        open={openAddModel}
        maxWidth={"lg"}
        onClose={() => setOpenAddModel(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Onboarding Model"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {/* <AddModel /> */}
            <Grid container spacing={2}>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Model</Typography>
                <TextField
                  onChange={(e) => {
                    setModelAddFormArray(e, 'model_info')
                  }}
                  size="small" id="outlined" value={modelAddForm.model_info} placeholder="eg: Model" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12} >
                <Typography className={classes.tabHelp}>Voltage</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'nominal_voltage')
                }}
                  size="small" id="outlined" value={modelAddForm.nominal_voltage} placeholder="eg: Voltage" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12} >
                <Typography className={classes.tabHelp}>Capacity</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'capacity_mah')
                }}
                  size="small" id="outlined" value={modelAddForm.capacity_mah} placeholder="eg: Capacity" className={classes.textField} />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Power</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'power')
                }}
                  size="small" id="outlined" value={modelAddForm.power} placeholder="eg: Power" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Manufacturer </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'cell_maufacturer')
                }}
                  size="small" id="outlined" value={modelAddForm.cell_maufacturer} placeholder="eg: Manufacturer " className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>OEM </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'oem')
                }}
                  size="small" id="outlined" value={modelAddForm.oem} placeholder="eg: OEM " className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'number_of_cells_series')
                }}
                  size="small" id="outlined" value={modelAddForm.number_of_cells_series} placeholder="eg: Number of Cells Series" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'number_of_cells_parallel')
                }}
                  size="small" id="outlined" value={modelAddForm.number_of_cells_parallel} placeholder="eg: Number of Cells Parallel" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'cell_chemisty')
                }}
                  size="small" id="outlined" value={modelAddForm.cell_chemisty} placeholder="eg: Cell Chemistry" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Cell Type</Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'cell_type')
                }}
                  size="small" id="outlined" value={modelAddForm.cell_type} placeholder="eg: Cell Type" className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Length </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'length')
                }}
                  size="small" id="outlined" value={modelAddForm.length} placeholder="eg: Length " className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Width </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'width')
                }}
                  size="small" id="outlined" value={modelAddForm.width} placeholder="eg: Width " className={classes.textField} />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Height </Typography>
                <TextField onChange={(e) => {
                  setModelAddFormArray(e, 'height')
                }}
                  size="small" id="outlined" value={modelAddForm.height} placeholder="eg: Height " className={classes.textField} />
              </Grid>
              <Grid item lg={6} xs={12}></Grid>
        <DialogTitle id="responsive-dialog-title">{"BMS Model"}</DialogTitle>
              <Grid item lg={6} xs={12}></Grid>

              
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>BMS Model </Typography>
                <TextField 
                // onChange={(e) => {
                //   setModelAddFormArray(e, 'height')
                // }}
                  size="small" id="outlined" 
                  // value={modelAddForm.height} 
                  placeholder="eg: BMS Model " className={classes.textField} />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>Hardware </Typography>
                <TextField 
                // onChange={(e) => {
                //   setModelAddFormArray(e, 'height')
                // }}
                  size="small" id="outlined" 
                  // value={modelAddForm.height} 
                  placeholder="eg: Hardware " className={classes.textField} />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.tabHelp}>OEM </Typography>
                <TextField 
                // onChange={(e) => {
                //   setModelAddFormArray(e, 'height')
                // }}
                  size="small" id="outlined" 
                  // value={modelAddForm.height} 
                  placeholder="eg: OEM " className={classes.textField} />
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenAddModel(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            onClick={() => {
              submitModel(true)
              setOpenAddModel(false)
              // refreshPage(true)
            }}
            color="secondary" autoFocus>
            Submit
          </Button>
        </DialogActions>
             </Dialog>
             {/* Edit Battery */}
             <Dialog
                fullScreen={fullScreen}
                open={openEditBattery}
                maxWidth={"lg"}
                // data={BatteryModelDataRaw}
                onClose={() => setOpenEditBattery(false)}
                aria-labelledby="responsive-dialog-title"
                className={!fullScreen ? classes.dialog : null}
            >
                <DialogTitle id="responsive-dialog-title">{"Edit Battery"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Model</Typography>
                                <Select
                                    onChange={(e) => { setEditBatteryFormArray(e, 'battery_model_id') }}
                                    value={editBatArray.battery_model_id}
                                    className={classes.textField}>

                                    <MenuItem value="">Select Battery Model</MenuItem>
                                    {/* {allEditModel.map((model) => {
                                        return (
                                            <MenuItem value={model[0]}>{model[0]}</MenuItem>

                                        )
                                    }
                                    )} */}
                                </Select>
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Serial Number</Typography>
                                <TextField size="small" id="outlined" value={editBatArray.serial_number}
                                    onChange={(e) => { setEditBatteryFormArray(e, 'serial_number') }}
                                    className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                                <TextField size="small" id="outlined" value={editBatArray.bms_unique_id}
                                    onChange={(e) => { setEditBatteryFormArray(e, 'bms_unique_id') }} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Owner/Investor</Typography>
                                <TextField size="small" id="outlined" value={editBatArray.investor}
                                    onChange={(e) => { setEditBatteryFormArray(e, 'investor') }} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Battery Operation owner</Typography>
                                <TextField size="small" id="outlined" value={editBatArray.operation_owner}
                                    onChange={(e) => { setEditBatteryFormArray(e, 'operation_owner') }} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Software Version</Typography>
                                <TextField size="small" id="outlined"
                                    // value={editBatArray.sw_version}
                                    // onChange={(e) => { setEditBatteryFormArray(e, 'sw_version') }} 
                                    className={classes.textField} />
                            </Grid>

                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={() => setOpenEditBattery(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button onClick={() => {
                        submitEditBattery(true)
                        setOpenEditBattery(false)
                    }
                    }
                        color="secondary" autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            {/* Edit Model */}
            <Dialog
                fullScreen={fullScreen}
                open={openEditModel}
                maxWidth={"lg"}
                data={BatteryModelDataRaw}
                onClose={() => setOpenEditModel(false)}
                aria-labelledby="responsive-dialog-title"
                className={!fullScreen ? classes.dialog : null}
            >
                <DialogTitle id="responsive-dialog-title">{"Edit Model"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Model</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setModelEditFormArray(e, 'model_info')
                                    }}
                                    size="small" id="outlined"
                                    value={editArray.model_info} className={classes.textField} />
                            </Grid>

                            {/* <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Hardware Version</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setModelEditFormArray(e, 'hardware_version')
                                    }}
                                    size="small" id="outlined"
                                    value={editArray.hardware_version} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12} >
                                <Typography className={classes.tabHelp}>Software Version</Typography>
                                <TextField
                                    onChange={(e) => {
                                        setModelEditFormArray(e, 'software_version')
                                    }}
                                    size="small" id="outlined" value={editArray.software_version} className={classes.textField} />
                            </Grid> */}

                            <Grid item lg={6} xs={12} >
                                <Typography className={classes.tabHelp}>Voltage</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'nominal_voltage')
                                }}
                                    size="small" id="outlined" value={editArray.nominal_voltage} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12} >
                                <Typography className={classes.tabHelp}>Capacity</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'capacity_mah')
                                }}
                                    size="small" id="outlined" value={editArray.capacity_mah} className={classes.textField} />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Power</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'power')
                                }}
                                    size="small" id="outlined" value={editArray.power} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Manufacturer </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'cell_maufacturer')
                                }}
                                    size="small" id="outlined" value={editArray.cell_maufacturer} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>OEM </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'oem')
                                }}
                                    size="small" id="outlined" value={editArray.oem} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'number_of_cells_series')
                                }}
                                    size="small" id="outlined" value={editArray.number_of_cells_series} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'number_of_cells_parallel')
                                }}
                                    size="small" id="outlined" value={editArray.number_of_cells_parallel} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'cell_chemisty')
                                }}
                                    size="small" id="outlined" value={editArray.cell_chemisty} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Cell Type</Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'cell_type')
                                }}
                                    size="small" id="outlined" value={editArray.cell_type} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Length </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'length')
                                }}
                                    size="small" id="outlined" value={editArray.length} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Width </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'width')
                                }}
                                    size="small" id="outlined" value={editArray.width} className={classes.textField} />
                            </Grid>

                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Height </Typography>
                                <TextField onChange={(e) => {
                                    setModelEditFormArray(e, 'height')
                                }}
                                    size="small" id="outlined" value={editArray.height} className={classes.textField} />
                            </Grid>
                            <Grid item lg={6} xs={12}></Grid>
                            <DialogTitle id="responsive-dialog-title">{"BMS Model"}</DialogTitle>
                            <Grid item lg={6} xs={12}></Grid>


                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>BMS Model </Typography>
                                <TextField size="small" id="outlined"
                                    placeholder="eg: BMS Model " className={classes.textField} />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>Hardware </Typography>
                                <TextField size="small" id="outlined"
                                    placeholder="eg: Hardware " className={classes.textField} />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>OEM </Typography>
                                <TextField
                                    size="small" id="outlined"
                                    placeholder="eg: OEM " className={classes.textField} />
                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={() => setOpenEditModel(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button onClick={() => {
                        submitModelEdit(true)
                        setOpenEditModel(false)
                    }}
                        color="secondary" autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            
            <br /><br />
            <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
        </div>
    );
}



































// import React, { useState } from 'react';
// import axios from 'axios';
// import { withStyles, makeStyles, useTheme, styled, alpha, darken } from '@material-ui/core/styles';
// import PropTypes from 'prop-types';
// import LinearProgress from '@material-ui/core/LinearProgress';
// import Chip from '@material-ui/core/Chip';
// import MUIDataTable from 'mui-datatables';
// import MenuItem from "@material-ui/core/MenuItem";
// import FormGroup from '@material-ui/core/FormGroup';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import Switch from '@material-ui/core/Switch';
// import Grid from '@material-ui/core/Grid';
// import Typography from '@material-ui/core/Typography';
// import Button from "@material-ui/core/Button";
// import BatteryVoltage from "./BatteryVoltage";
// import BatteryCurrent from "./BatteryCurrent";
// import SOC from "./SOC";
// import TotalOdometer from "./TotalOdometer";
// import Select from "@material-ui/core/Select";
// import Tooltip from '@material-ui/core/Tooltip';
// import Paper from '@material-ui/core/Paper';
// import Tabs from '@material-ui/core/Tabs';
// import Tab from '@material-ui/core/Tab';
// import TabIcon from '@material-ui/icons/Tab';
// import TextField from '@material-ui/core/TextField';
// import Box from '@material-ui/core/Box';
// import IconButton from '@material-ui/core/IconButton';
// import { Icon } from '@iconify/react';
// import BatteryCharging30Icon from '@material-ui/icons/BatteryCharging30';
// import endpoints from '../../../endpoints/endpoints';
// import CustomToolbar from './CustomToobar';
// import MotorcycleIcon from '@material-ui/icons/Motorcycle';
// import CustomToolbarM from './CustomToobarM';
// import Divider from '@material-ui/core/Divider';


// import AcUnit from '@material-ui/icons/AcUnit';
// import Adb from '@material-ui/icons/Adb';
// import AllInclusive from '@material-ui/icons/AllInclusive';
// import AssistantPhoto from '@material-ui/icons/AssistantPhoto';
// import AppBar from '@material-ui/core/AppBar';
// import PhotoLibrary from '@material-ui/icons/PhotoLibrary';
// import List from '@material-ui/core/List';
// import ListItem from '@material-ui/core/ListItem';
// import ListItemText from '@material-ui/core/ListItemText';
// import ListItemAvatar from '@material-ui/core/ListItemAvatar';
// import Avatar from '@material-ui/core/Avatar';
// import SimpleMap from "./SimpleMap";
// import TreeTable from "./TreeTable";
// import Pagination from '@material-ui/lab/Pagination';


// import Dialog from '@material-ui/core/Dialog';
// import Brightness1Icon from '@material-ui/icons/Brightness1';
// import DialogActions from '@material-ui/core/DialogActions';
// import DialogContent from '@material-ui/core/DialogContent';
// import DialogContentText from '@material-ui/core/DialogContentText';
// import DialogTitle from '@material-ui/core/DialogTitle';
// import useMediaQuery from '@material-ui/core/useMediaQuery';
// import { useLocation } from 'react-router-dom';
// import { useDispatch, useSelector } from 'react-redux';
// import clearMyBattery from '../../../redux/actions/normalActions';
// import { getMyBatteryBulk, getBatteryModelBulk, getBatteryProBulk } from '../../../redux/actions/asyncActions';
// import Loading from '../../../components/Loading';
// import ErrorWrap from '../../../components/Error/ErrorWrap';

// const useStyles = makeStyles((theme) => ({
//     tableborder: { display: 'none' },
//     root: {
//         margin: 10
//     },
//     textField: {
//         width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
//         'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
//     },
//     table: {

//         '& > div': {

//             '& > .MuiToolbar-regular': {
//                 backgroundColor: '#68A72480  !important',
//                 borderBottomLeftRadius: 0,
//                 borderBottomRightRadius: 0
//             },
//             // overflow: 'auto',
//             // textAlign:'center'
//         },

//         '& table': {
//             '& td': {
//                 wordBreak: 'keep-all',
//                 textAlign: 'center'
//             },

//             [theme.breakpoints.down('md')]: {
//                 '& td': {
//                     height: 60,
//                     overflow: 'hidden',
//                     textOverflow: 'ellipsis'
//                 },
//                 '& tr:nth-child(odd)': {
//                     backgroundColor: '#cfcfcf40'
//                 },
//                 '& tr:nth-child(even)': {
//                     backgroundColor: '#cfcfcf20'
//                 },
//             }
//         }
//     },
//     graphText: {
//         fontSize: 12,
//         position: 'absolute',
//         transform: 'rotate(270deg)',
//         left: '-40px',
//         top: 370,
//         color: 'primary',
//         fontWeight: 600
//     },
//     graphSelect: {
//         minWidth: 150, left: '20em', marginBottom: 20
//     },
//     tabsSection: {
//         [theme.breakpoints.up('lg')]: {
//             // borderRadius:0,position:'sticky',top:0 ,width:500
//             borderRadius: 0, top: 0, width: 500

//         },


//     },
//     primaryText: {
//         fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
//     }, primaryTextG: {
//         fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '300px'
//     },
//     secondaryTextG: {
//         fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '100%'
//     },
//     voltageG: {
//         fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724'
//     },
//     voltageY: {
//         fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FFBF00'
//     },
//     voltageR: {
//         fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FF0000'
//     },
//     chart1: {
//         marginLeft: '-20px', width: '120px', height: '50px', '.MuiPaper-root .MuiMenu-paper .MuiPopover-paper': { width: '120px !important' }
//     },
//     copyRight: {
//         position: 'absolute', bottom: 0, right: 0, left: 0, fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
//     },
//     dialog: {
//         // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
//         position: 'relative', marginLeft: '680px'
//     },
//     healthy: {
//         color: '#82E219', width: '5rem', fontSize: '20px'
//     },
//     Unhealthy: {
//         color: '#FFFF00'
//     },
//     chart: {
//         padding: theme.spacing(2)
//     },
//     dataView: {
//         height: '300px',
//     },
//     BNavatar: { height: '60px', width: '60px', border: '1px solid #fff', backgroundColor: "rgba(76, 175, 80, 1.0)" },
//     BNavatar1: { backgroundColor: '#f3efef' },
//     BNgrid: { marginLeft: 20 },
//     BNprimaryText: {
//         fontFamily: 'Maven Pro,sans-serif', fontSize: '16px', fontWeight: 600, color: 'primary', width: '200px',
//     },
//     BNstateText: {
//         fontFamily: 'Maven Pro,sans-serif', fontSize: '20px', fontWeight: 500, color: '#fff', width: '250px',
//     },
//     BNsecondaryText: {
//         fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary',
//     },
//     BNsecondaryTextG: { color: '#00FF00' },
//     BNsecondaryText1: {
//         fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary', width: '150px',
//     },
//     BNIcon: {
//         marginRight: 10, marginTop: 10
//     },
//     BNtitle: {},
//     BNsubtitle: {},

//     BNchip: { backgroundColor: '#4caf50b5' },
//     BNchip2: { backgroundColor: '#FFBF00' },
//     BNchip3: { backgroundColor: '#FF0000' },
//     BNstyledPaper: {
//         backgroundColor: '#4caf50b5',
//         height: 95,
//         padding: 10,
//         '& $title, & $subtitle': {
//             color: theme.palette.common.white
//         }
//     },
//     BNstyledPaper2: {
//         backgroundColor: '#FFBF00',
//         height: 95,
//         padding: 10,
//         '& $title, & $subtitle': {
//             color: theme.palette.common.white
//         }
//     },
//     BNstyledPaper3: {
//         backgroundColor: '#FF0000',
//         height: 95,
//         padding: 10,
//         '& $title, & $subtitle': {
//             color: theme.palette.common.white
//         }
//     },
//     BNprogressWidget: {
//         marginTop: 20,
//         background: theme.palette.secondary.dark,
//         '& div': {
//             background: theme.palette.primary.light,
//         }
//     },
//     BNmap: {
//         height: 200, overflowY: 'hidden', borderRadius: 2, position: 'relative'
//     },
//     BNcover: {
//         '& $name, & $subheading': {
//             color: theme.palette.common.white
//         },
//         position: 'relative',
//         width: '100%',
//         overflow: 'hidden',
//         height: 165,
//         backgroundColor: "rgba(76, 175, 80, 1.0)"
//         // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
//         ,
//         // backgroundColor:
//         // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
//         // ,
//         display: 'flex',
//         justifyContent: 'center',
//         alignItems: 'flex-end',
//         backgroundSize: 'cover',
//         textAlign: 'center',
//         boxShadow: theme.shadows[7],
//         backgroundPosition: 'bottom center',
//         borderRadius: '10px 10px 0px 0px',
//     },
//     BNname: {
//         fontSize: '24px', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400, color: '#fff'
//     },
//     BNopt: {
//         position: 'absolute',
//         top: 0,
//         right: 10,
//         '& button': {
//             color: theme.palette.common.white
//         }
//     },
//     BNprofileTab: {
//         marginTop: 0,
//         [theme.breakpoints.down('sm')]: {
//             marginTop: 0,
//         },
//         borderRadius: '0px 0px 10px 10px',
//         background:
//             // alpha(theme.palette.background.paper, 0.8)
//             "#dcead7",
//         position: 'relative'
//     },
//     BNaboutTxt: {
//         fontSize: '1rem', fontWeight: 600, color: '#000000'
//     },

//     BNaboutTxt1: {
//         fontSize: '1rem', fontWeight: 400, color: '#000000'
//     },
//     BNdriving: {
//         color: '#82E219', marginLeft: '-90px'
//     },
//     BNdrivingR: {
//         color: '#ff0000', marginLeft: '-90px'
//     },
//     BNorangeAvatar: {
//         backgroundColor: '#ff5722',
//     },
//     BNpurpleAvatar: {
//         backgroundColor: '#673ab7',
//     },
//     BNpinkAvatar: {
//         backgroundColor: '#e91e63',
//     },
//     BNgreenAvatar: {
//         backgroundColor: '#4caf50',
//     },
//     BNdivider: {
//         width: '92%', marginLeft: '20px'
//     },
//     pageTitle: {
//         textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600
//     }
// }));
// function TabContainer(props) {
//     const { children } = props;
//     return (
//         <div style={{ paddingTop: 8 * 3 }}>
//             {children}
//         </div>
//     );
// }

// TabContainer.propTypes = {
//     children: PropTypes.node.isRequired,
// };

// /*
//   It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
//   Checkout full documentation here :
//   https://github.com/gregnb/mui-datatables/blob/master/README.md
// */

// export default function BatteryPage() {

//     const MyBatteryData = useSelector((store) => store.myBattery)
//     const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
//     let MyBatteryMeta = useSelector((store) => store.myBattery)
//     let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
//     let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
//     let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)

//     const BatteryProData = useSelector((store) => store.batteryPro)
//     const BatteryModelProRaw = useSelector((store) => store.batteryPro.rawData)
//     let BatteryProMeta = useSelector((store) => store.batteryPro)
//     let BatteryProFetching = useSelector((store) => store.batteryPro.fetching)
//     let BatteryProResponsecode = useSelector((store) => store.batteryPro.responseStatus)
//     let BatteryProMetaPresent = useSelector((store) => store.batteryPro.dataPresent)

//     const BatteryModelData = useSelector((store) => store.batteryModel)
//     const BatteryModelDataRaw = useSelector((store) => store.batteryModel.rawData)
//     let BatteryModelMeta = useSelector((store) => store.batteryModel)
//     let BatteryModelFetching = useSelector((store) => store.batteryModel.fetching)
//     let BatteryModelResponsecode = useSelector((store) => store.batteryModel.responseStatus)
//     let BatteryModelMetaPresent = useSelector((store) => store.batteryModel.dataPresent)

//     const logged_user = useSelector((store) => store.user.loggeduser);
//     let enty = logged_user.entity_id
//     const dispatch = useDispatch();

//     const [openEditModel, setOpenEditModel] = React.useState(false);
//     const [openEditBattery, setOpenEditBattery] = React.useState(false);

//     const theme = useTheme();
//     const classes = useStyles();
//     const [screen, setScreen] = React.useState(false);
//     const [idleMode, setIdleMode] = React.useState(false);



//     const [zoomVar, setZoomVar] = React.useState(0);

//     const [value, setValue] = React.useState(0);
//     const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
//     const handleChange = (event, newValue) => {
//         setValue(newValue);
//     };
//     const handleChangeT = (event, val) => {
//         setValue(val);
//     };


//     React.useEffect(() => {
//         typeof enty != "undefined" ? dispatch(getMyBatteryBulk(enty)) : null;
//         dispatch(
//             getBatteryModelBulk()
//         );

//     }, [MyBatteryMetaPresent]);

//     let allEditModel = BatteryModelMeta.data
//     {/* Battery*/ }
//     const [editBatArray, setEditBatArray] = React.useState(
//         {

//         }
//     )
//     const setEditBatteryArray = (bms_id) => {
//         let allBattery = MyBatteryDataRaw;
//         let findEditArray = allBattery.find(el => el.bms_id === bms_id);
//         setEditBatArray(findEditArray);
//     }
//     const submitEditBattery = () => {
//         const putBattery = endpoints.baseUrl + `/battery/update/` + editBatArray.bms_id;
//         axios
//             .put(putBattery, editBatArray)
//             .then((response) => {
//                 dispatch(getMyBatteryBulk());

//             });

//     }


//     const setEditBatteryFormArray = (e, key) => {
//         setEditBatArray((state) => ({ ...state, [key]: e.target.value }));

//     }

//     {/* Model*/ }
//     const [editArray, setEditArray] = React.useState(
//         {

//         }
//     )
//     const setModelEditArray = (battery_model_id) => {
//         let allModel = BatteryModelDataRaw;
//         let findArray = allModel.find(el => el.battery_model_id === battery_model_id);
//         setEditArray(findArray);
//     }
//     const submitModelEdit = () => {
//         const putModel = endpoints.baseUrl + `/batterymodel/edit/` + editArray.battery_model_id;
//         axios
//             .put(putModel, editArray)
//             .then((response) => {
//                 dispatch(getBatteryModelBulk());

//             });

//     }

//     const deleteModel = (battery_model_id) => {
//         const deleteModel = endpoints.baseUrl + `/batterymodel/softdelete/` + battery_model_id;
//         axios
//             .delete(deleteModel)
//             .then((response) => {
//                 dispatch(getBatteryModelBulk());
//             });
//     }

//     const setModelEditFormArray = (e, key) => {
//         setEditArray((state) => ({ ...state, [key]: e.target.value }));

//     }


//     const Item = styled(Paper)(({ theme }) => ({
//         ...theme.typography.body2,
//         padding: theme.spacing(1),
//         textAlign: 'left',
//         color: theme.palette.text.secondary,
//     }));

//     const validateKeyData = (key) => {
//         return key ? key : "-";
//     };

//     const [tableMode, setTableMode] = React.useState("ericksaw");
//     const handleTableChange = (event) => {
//         if (tableMode === 'erickshaw') {
//             setTableMode('comm');
//         } else {
//             setTableMode('erickshaw');
//         }
//     };
//     const dayDropdown = [{ val: 'day', name: 'Day' }, { val: 'month', name: 'Month' }, { val: 'year', name: 'Year' }, { val: 'custom', name: 'Custom' }]


//     const [zoom, setZoom] = React.useState(10);



//     const columsModel = [
//         {
//             name: 'Model',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography color='secondary' variant='subtitle2'>{validateKeyData(value)} </Typography>
//                 )
//             }
//         },
//         {
//             name: 'Voltage',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
//                 )
//             }
//         }, {
//             name: 'Capacity',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
//                 )
//             }
//         }, {
//             name: 'Power',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
//                 )
//             }
//         }, {
//             name: 'Manufacturer',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
//                 )
//             }
//         },
//         {
//             name: 'Action',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => {
//                     // if (value === 'assign') {
//                     return (<Select
//                         style={{ minWidth: 150, color: '#FFC130' }}
//                         value='Edit'
//                     >
//                         <MenuItem onClick={() => {
//                             setOpenEditModel(true)
//                             setModelEditArray(value)
//                         }
//                         }
//                             value='Edit'>Edit</MenuItem>
//                         <MenuItem
//                             onClick={() => { deleteModel(value) }}
//                             style={{ color: "#FF6058 !important" }} value="Delete">
//                             Delete
//                         </MenuItem>
//                     </Select>)
//                 }
//             }
//         },
//     ]

//     const [bmsid, setBmsId] = React.useState(0);
//     const [serial, setSerial] = React.useState(0);
//     const [model, setModel] = React.useState(0);
//     const [operation, setOperation] = React.useState(0);

//     const batteryProfile = (bmsid) => {
//         dispatch(getBatteryProBulk(bmsid));
//     }
//     const clearBattery = () => {
//     }
//     const columnsBattery = [

//         {
//             name: 'Serial Number',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography onClick={() => {
//                         // dispatch(clearMyBattery());
//                         setScreen(true)
//                         setBmsId(validateKeyData(value.bms_id))
//                         setSerial(validateKeyData(value.serial_number))
//                         setModel(validateKeyData(value.battery_model))
//                         setOperation(validateKeyData(value.operation_owner))
//                         batteryProfile(validateKeyData(value.bms_id))


//                     }}
//                         style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
//                         &nbsp;&nbsp;{value.serial_number}
//                     </Typography>

//                 )
//             }
//         },
//         {
//             name: 'Model',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography onClick={() => {
//                         setScreen(true)
//                         setModel(value.model)
//                     }}
//                         // style={{ color: '#33a6ff', cursor: 'pointer' }}
//                         variant='subtitle2'>{validateKeyData(value)}</Typography>
//                 )
//             }
//         },
//         {
//             name: 'Investor',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography onClick={() => setScreen(true)} variant='subtitle2'>{validateKeyData(value)}</Typography>
//                 )
//             }
//         },
//         {
//             name: 'Operation Owner',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => (
//                     <Typography onClick={() => setScreen(true)} variant='subtitle2'>{validateKeyData(value)}</Typography>
//                 )
//             }
//         },
//         {
//             name: 'Vehicle Number',
//             options: {
//                 filter: false,
//                 customBodyRender: (value) => (
//                     <Typography style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>{validateKeyData(value)}</Typography>
//                 )
//             }
//         },

//         {
//             name: 'Status',
//             options: {
//                 filter: true,
//                 customBodyRender: (value) => {
//                     if (value.vehicle_number && value.battery_status === "on") {
//                         return (
//                             <><IconButton
//                                 onClick={() => {
//                                     setOpenEditBattery(true)
//                                     setEditBatteryArray(value.bms_id)
//                                 }}
//                             ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="28" height="28" /></IconButton>
//                                 <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
//                                 <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>
//                             </>
//                         )
//                     }
//                     else if (value.vehicle_number && value.battery_status === "off") {
//                         return (
//                             <><IconButton
//                                 onClick={() => {
//                                     setOpenEditBattery(true)
//                                     setEditBatteryArray(value.bms_id)
//                                 }}
//                             ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
//                                 <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
//                                 <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
//                             </>
//                         )
//                     }
//                     else {
//                         return (
//                             <><IconButton
//                                 onClick={() => {
//                                     setOpenEditBattery(true)
//                                     setEditBatteryArray(value.bms_id)
//                                 }}
//                             ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
//                                 <IconButton><Icon icon="mdi:motorbike" color="#c4c4c4" width="30" height="30" /></IconButton>
//                                 <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
//                             </>
//                         )
//                     }


//                 },

//             },

//         },
//     ];



//     const options = {
//         filterType: 'dropdown',
//         responsive: 'vertical',
//         print: true,
//         rowsPerPage: 50,
//         page: 0,
//         selectableRows: "none",
//         // customToolbar: () => {
//         //     return (
//         //         value === 0 ?
//         //             <CustomToolbar value={value} />
//         //             : <CustomToolbarM value={value} />
//         //     );
//         // }

//     };
//     const [chartOneVal, setChartOneVal] = React.useState("day");
//     const handleChartOneVal = (e) => {
//         setChartOneVal(e.target.value);

//     }



//     const [frame, setFrame] = React.useState(false)

//     // const myStr = BatteryProMeta.data[0]["min_voltage_cell"];
//     // const newStr = myStr.replace("Voltage", " ");

//     // const myStr1 = BatteryProMeta.data[0]["max_voltage_cell"];
//     // const newStr1 = myStr1.replace("Voltage", " ");

//     // const myStr2 = BatteryProMeta.data[0]["min_temperature_cell"];
//     // const newStr2 = myStr2.replace("Temperature", " ");

//     // const myStr3 = BatteryProMeta.data[0]["max_temperature_cell"] ? BatteryProMeta.data[0]["max_temperature_cell"] : null ;
//     // const newStr3 = myStr3.replace("Temperature", " ");

//     return (
//         <div
//             // onMouseMove={() => setFrame(!frame)}
//             className={classes.table}>
//             {screen !== true ? <Typography className={classes.pageTitle} component="h4" variant="h4">Battery</Typography> :
//                 <Typography className={classes.pageTitle} component="h4" variant="h4">Battery Profile</Typography>}

//             {screen !== true ?
//                 <Tabs
//                     className={classes.tabsSection}
//                     value={value}
//                     onChange={handleChange}
//                     variant="fullWidth"
//                     indicatorColor="primary"
//                     aria-label="icon tabs example"
//                 >
//                     <Tab label="Battery" onClick={() => {
//                         setScreen(false)
//                     }} icon={<BatteryCharging30Icon />} aria-label="favorite" />
//                     <Tab label="Model" onClick={() => {
//                         setScreen(false)
//                     }} icon={<TabIcon />} aria-label="phone" />

//                 </Tabs> : null}


//             <Paper square className={classes.root}>

//             </Paper>
//             {(screen !== true
//                 // && (
//                 // MyBatteryMetaPresent &&
//                 // BatteryModelMetaPresent)
//             ) ?
//                 (
//                     value === 0 ?
//                         <MUIDataTable
//                             checkboxSelection={false}
//                             title="Battery"
//                             // data={data}
//                             data={MyBatteryMeta.data}
//                             columns={columnsBattery}
//                             options={options}
//                             selectableRowsHideCheckboxes
//                         />
//                         :
//                         <MUIDataTable
//                             checkboxSelection={false}
//                             title="MODEL"
//                             // data={dataModel}
//                             data={BatteryModelMeta.data}
//                             columns={columsModel}
//                             options={options}
//                             selectableRowsHideCheckboxes
//                         />


//                 )
//                 :
//                 (
//                     //     //     MyBatteryMetaPresent &&
//                     BatteryProMetaPresent) ?
//                     (
//                         <>

//                             <div className={classes.BNcover}><div className={classes.BNopt}>
//                                 <IconButton className={classes.BNbutton} >
//                                     <Icon icon="fa:cloud-download" color="white" width="30" height="30" />
//                                 </IconButton>
//                                 <IconButton onClick={() => {
//                                     setScreen(false)
//                                 }} className={classes.BNbutton} >
//                                     <Icon icon="bi:arrow-left-circle-fill" width="26" height="26" />
//                                 </IconButton>
//                             </div>
//                                 <div className={classes.BNcontent}>
//                                     <div style={{ display: 'flex', justifyContent: 'center' }}>
//                                         <Avatar className={classes.BNavatar}>
//                                             <Icon icon="mdi:car-battery" width="40" height="40" />
//                                         </Avatar></div>
//                                     <Typography className={classes.BNname} gutterBottom>
//                                         {validateKeyData(serial)}
//                                     </Typography>
//                                     <Typography className={classes.BNname} gutterBottom>
//                                         {validateKeyData(model)}
//                                     </Typography>
//                                 </div></div>

//                             <AppBar position="static" className={classes.BNprofileTab}>
//                                 <Tabs
//                                     value={value}
//                                     onChange={handleChangeT}
//                                     variant="fullWidth"
//                                     indicatorColor="primary"
//                                     textColor="primary"
//                                     centered

//                                 >
//                                     <Tab icon={<Icon icon="bxs:battery-charging" width="30" height="30" />} label="About" />
//                                     <Tab icon={<Icon icon="ant-design:line-chart-outlined" width="30" height="30" />} label="Chart" />
//                                     <Tab icon={<PhotoLibrary />} label="Parameters" />
//                                 </Tabs>
//                             </AppBar>
//                             {value === 0 &&
//                                 <TabContainer><br />
//                                     <Grid container spacing={2}>
//                                         <Grid item xs={12} lg={6}>
//                                             <Paper>
//                                                 <ListItem>
//                                                     <ListItemAvatar>
//                                                         <Avatar className={classes.BNavatar1}>
//                                                             <Icon icon="mdi:car-battery" color="#82e219" width="26" height="26" />
//                                                         </Avatar>
//                                                     </ListItemAvatar>

//                                                     <ListItemText primary={
//                                                         <Typography className={classes.BNaboutTxt}>About</Typography>
//                                                     }
//                                                         secondary={
//                                                             <React.Fragment>
//                                                                 <Typography className={classes.BNaboutTxt1} >
//                                                                     <b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
//                                                                         {validateKeyData(serial)}</b> of {model}  <br /> OnBoarded on 09-23-2022 18:04:29 by
//                                                                     <b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
//                                                                         {validateKeyData(operation)}</b></Typography>
//                                                             </React.Fragment>

//                                                         }
//                                                     />
//                                                 </ListItem><Divider className={classes.BNdivider} />
//                                                 <Grid container spacing={1} className={classes.BNgrid}>
//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNavatar1}>
//                                                                     <Icon icon="ion:hardware-chip-sharp" color="82e219" width="30" height="30" />
//                                                                 </Avatar>
//                                                             </ListItemAvatar>

//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>HW Version</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography bmsid={bmsid}
//                                                                             className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["hardware_version"])}</Typography>
//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>
//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNavatar1}>
//                                                                     <Icon icon="eos-icons:software-outlined" color="82e219" width="30" height="30" />                                    </Avatar>
//                                                             </ListItemAvatar>

//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>SW Version</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography
//                                                                             className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["software_version"])}</Typography>
//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>
//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNavatar1}>
//                                                                     <Icon icon="emojione-monotone:high-voltage" color="82e219" width="30" height="30" />
//                                                                 </Avatar>
//                                                             </ListItemAvatar>

//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>Battery Nominal Voltage</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography
//                                                                             className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["nominal_voltage"])}</Typography>
//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>
//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNavatar1}>
//                                                                     <Icon icon="mdi:chemical-weapon" color="82e219" width="30" height="30" />
//                                                                 </Avatar>
//                                                             </ListItemAvatar>

//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>Battery Chemistry</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography
//                                                                             className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["cell_chemisty"])}</Typography>
//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>
//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNavatar1}>
//                                                                     <Icon icon="carbon:cost-total" color="82e219" width="30" height="30" />
//                                                                 </Avatar>
//                                                             </ListItemAvatar>

//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>Battery pack Capacity</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography
//                                                                             className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["capacity_mah"])}</Typography>
//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>
//                                                 </Grid>
//                                             </Paper>

//                                         </Grid>

//                                         <Grid item xs={12} lg={6}>
//                                             <Paper style={{ height: '315px' }}>
//                                                 <div style={{ display: 'flex', marginLeft: 10 }}>
//                                                     <Typography className={classes.BNprimaryText}>Battery Current</Typography>
//                                                     <Typography className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["battery_current"])}</Typography> </div>

//                                                 <div style={{ display: 'flex', margin: 10 }}>
//                                                     <Typography className={classes.BNprimaryText}>Battery Voltage</Typography>
//                                                     <Typography className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["battery_voltage"])}</Typography>
//                                                 </div>

//                                                 <div style={{ display: 'flex', margin: 10 }}>
//                                                     <Typography className={classes.BNprimaryText}>Battery State</Typography>
//                                                     <Typography className={classes.secondaryTextG}>{validateKeyData(BatteryProMeta.data[0]["current_state"])}</Typography>
//                                                 </div>


//                                                 <Paper
//                                                     className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNstyledPaper :
//                                                         BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNstyledPaper2 : classes.BNstyledPaper3}
//                                                     elevation={4}>
//                                                     <div style={{ display: 'flex', justifyContent: 'space-between' }}>
//                                                         <Typography className={classes.BNstateText}>State Of Health
//                                                         </Typography>
//                                                         <Chip
//                                                             avatar={(
//                                                                 <Avatar className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNchip :
//                                                                     BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNchip2 : classes.BNchip3} >
//                                                                     <Icon icon="ant-design:check-circle-outlined" color="white" width="30" height="30" />
//                                                                 </Avatar>
//                                                             )}
//                                                             label={validateKeyData(BatteryProMeta.data[0]["soh"]) + "% Progress"}
//                                                         />
//                                                     </div>
//                                                     <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soh"])} />
//                                                 </Paper><br />

//                                                 <Paper
//                                                     className={classes.BNstyledPaper}
//                                                     elevation={4}>
//                                                     <div style={{ display: 'flex', justifyContent: 'space-between' }}>
//                                                         <Typography className={classes.BNstateText}>State Of Charge
//                                                         </Typography>
//                                                         <Chip
//                                                             avatar={(
//                                                                 <Avatar className={classes.BNchip}
//                                                                 >
//                                                                     <Icon icon="ant-design:check-circle-outlined" color="white" width="30" height="30" />
//                                                                 </Avatar>
//                                                             )}
//                                                             label={validateKeyData(BatteryProMeta.data[0]["soc"]) + "% Progress"}
//                                                         />
//                                                     </div>
//                                                     <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soc"])} />
//                                                 </Paper></Paper>
//                                         </Grid>

//                                         <Grid item xs={12} lg={6}>
//                                             <Paper>
//                                                 <ListItem>
//                                                     <ListItemAvatar>
//                                                         <Avatar className={classes.BNavatar1}>
//                                                             <Icon icon="bi:flag-fill" color="#82e219" />
//                                                         </Avatar>
//                                                     </ListItemAvatar>

//                                                     <ListItemText primary={
//                                                         <Typography className={classes.BNprimaryText}>Voltage & Temperature</Typography>
//                                                     } />
//                                                 </ListItem>
//                                                 <Grid container spacing={1}>
//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNpurpleAvatar}>
//                                                                     <AcUnit />
//                                                                 </Avatar>
//                                                             </ListItemAvatar>
//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>Min Voltage</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography
//                                                                             className={
//                                                                                 BatteryProMeta.data[0]["min_cell_voltage_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_voltage_color"] === "green" ? classes.voltageG : classes.voltageR}>
//                                                                             {/* {newStr}
//                                                                             &nbsp;-&nbsp;*/}
//                                                                             {validateKeyData(BatteryProMeta.data[0]["min_voltage"])}&nbsp;V&nbsp;
//                                                                         </Typography>

//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>

//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNpinkAvatar}>
//                                                                     <AllInclusive />
//                                                                 </Avatar>
//                                                             </ListItemAvatar>

//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>Max Voltage</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography
//                                                                             className={BatteryProMeta.data[0]["max_cell_voltage_color"] === "green" ? classes.voltageG : BatteryProMeta.data[0]["max_cell_voltage_color"] === "amber" ? classes.voltageY : classes.voltageR}>
//                                                                             {/* {newStr}
//                                                                             &nbsp;-&nbsp;*/}
//                                                                             {validateKeyData(BatteryProMeta.data[0]["max_voltage"])}&nbsp;V
//                                                                         </Typography>
//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>

//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNgreenAvatar}>
//                                                                     <Adb /></Avatar>
//                                                             </ListItemAvatar>

//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>Min Temperature</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography
//                                                                             className={
//                                                                                 BatteryProMeta.data[0]["min_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
//                                                                             {/* {newStr2}
//                                                                             &nbsp;-&nbsp;*/}
//                                                                             {validateKeyData(BatteryProMeta.data[0]["min_temperature"])}&nbsp;ºC
//                                                                         </Typography>
//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>

//                                                     <Grid xs={12} lg={6}>
//                                                         <ListItem>
//                                                             <ListItemAvatar>
//                                                                 <Avatar className={classes.BNorangeAvatar}>
//                                                                     <AssistantPhoto />
//                                                                 </Avatar>
//                                                             </ListItemAvatar>

//                                                             <ListItemText primary={
//                                                                 <Typography className={classes.BNprimaryText}>Max Temperature</Typography>
//                                                             }
//                                                                 secondary={
//                                                                     <React.Fragment>
//                                                                         <Typography
//                                                                             className={
//                                                                                 BatteryProMeta.data[0]["max_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["max_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
//                                                                             {/* {newStr3}
//                                                                             &nbsp;-&nbsp;*/}
//                                                                             {validateKeyData(BatteryProMeta.data[0]["max_temperature"])}&nbsp;ºC
//                                                                         </Typography>
//                                                                     </React.Fragment>

//                                                                 }
//                                                             />
//                                                         </ListItem>
//                                                     </Grid>
//                                                 </Grid>
//                                             </Paper>

//                                         </Grid>
//                                         <Grid item xs={12} lg={6}>
//                                             <Paper className={classes.BNmap} variant="outlined" >
//                                                 <SimpleMap
//                                                     zoom={10} bmsid={bmsid}
//                                                 /></Paper>
//                                         </Grid>
//                                     </Grid>
//                                 </TabContainer>}
//                             {value === 1 && <TabContainer><br />

//                                 <><Grid item container spacing={2}>
//                                     <Grid item xs={12} lg={6}>
//                                         <Paper className={classes.paper}><br /> <BatteryVoltage
//                                             bmsid={bmsid}
//                                             dataIndex={chartOneVal} /></Paper>
//                                     </Grid>

//                                     <Grid item xs={12} lg={6}>
//                                         <Paper className={classes.paper}><br /><SOC bmsid={bmsid} dataIndex={chartOneVal} /></Paper>

//                                     </Grid>

//                                     <Grid item xs={12} lg={6}>
//                                         <Paper className={classes.paper}><br /><TotalOdometer bmsid={bmsid} dataIndex={chartOneVal} /></Paper>

//                                     </Grid>

//                                     <Grid item xs={12} lg={6}>
//                                         <Paper className={classes.paper}><br /><BatteryCurrent bmsid={bmsid} dataIndex={chartOneVal} /></Paper>
//                                     </Grid>
//                                 </Grid></>
//                             </TabContainer>}
//                             {value === 2 && <TabContainer><br />
//                                 <TreeTable bmsid={bmsid} />
//                             </TabContainer>}



//                         </>
//                     )

//                     : MyBatteryFetching ?
//                         <Loading /> :
//                         MyBatteryResponsecode === 500 ?

//                             <ErrorWrap /> : null



//             }


//             <Dialog
//                 fullScreen={fullScreen}
//                 open={openEditModel}
//                 maxWidth={"lg"}
//                 data={BatteryModelDataRaw}
//                 onClose={() => setOpenEditModel(false)}
//                 aria-labelledby="responsive-dialog-title"
//                 className={!fullScreen ? classes.dialog : null}
//             >
//                 <DialogTitle id="responsive-dialog-title">{"Edit Model"}</DialogTitle>
//                 <DialogContent>
//                     <DialogContentText>
//                         <Grid container spacing={2}>
//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Model</Typography>
//                                 <TextField
//                                     onChange={(e) => {
//                                         setModelEditFormArray(e, 'model_info')
//                                     }}
//                                     size="small" id="outlined"
//                                     value={editArray.model_info} className={classes.textField} />
//                             </Grid>

//                             {/* <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Hardware Version</Typography>
//                                 <TextField
//                                     onChange={(e) => {
//                                         setModelEditFormArray(e, 'hardware_version')
//                                     }}
//                                     size="small" id="outlined"
//                                     value={editArray.hardware_version} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12} >
//                                 <Typography className={classes.tabHelp}>Software Version</Typography>
//                                 <TextField
//                                     onChange={(e) => {
//                                         setModelEditFormArray(e, 'software_version')
//                                     }}
//                                     size="small" id="outlined" value={editArray.software_version} className={classes.textField} />
//                             </Grid> */}

//                             <Grid item lg={6} xs={12} >
//                                 <Typography className={classes.tabHelp}>Voltage</Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'nominal_voltage')
//                                 }}
//                                     size="small" id="outlined" value={editArray.nominal_voltage} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12} >
//                                 <Typography className={classes.tabHelp}>Capacity</Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'capacity_mah')
//                                 }}
//                                     size="small" id="outlined" value={editArray.capacity_mah} className={classes.textField} />
//                             </Grid>
//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Power</Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'power')
//                                 }}
//                                     size="small" id="outlined" value={editArray.power} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Manufacturer </Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'cell_maufacturer')
//                                 }}
//                                     size="small" id="outlined" value={editArray.cell_maufacturer} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>OEM </Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'oem')
//                                 }}
//                                     size="small" id="outlined" value={editArray.oem} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Number of Cells Series</Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'number_of_cells_series')
//                                 }}
//                                     size="small" id="outlined" value={editArray.number_of_cells_series} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'number_of_cells_parallel')
//                                 }}
//                                     size="small" id="outlined" value={editArray.number_of_cells_parallel} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Cell Chemistry</Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'cell_chemisty')
//                                 }}
//                                     size="small" id="outlined" value={editArray.cell_chemisty} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Cell Type</Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'cell_type')
//                                 }}
//                                     size="small" id="outlined" value={editArray.cell_type} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Length </Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'length')
//                                 }}
//                                     size="small" id="outlined" value={editArray.length} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Width </Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'width')
//                                 }}
//                                     size="small" id="outlined" value={editArray.width} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Height </Typography>
//                                 <TextField onChange={(e) => {
//                                     setModelEditFormArray(e, 'height')
//                                 }}
//                                     size="small" id="outlined" value={editArray.height} className={classes.textField} />
//                             </Grid>
//                             <Grid item lg={6} xs={12}></Grid>
//                             <DialogTitle id="responsive-dialog-title">{"BMS Model"}</DialogTitle>
//                             <Grid item lg={6} xs={12}></Grid>


//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>BMS Model </Typography>
//                                 <TextField size="small" id="outlined"
//                                     placeholder="eg: BMS Model " className={classes.textField} />
//                             </Grid>
//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Hardware </Typography>
//                                 <TextField size="small" id="outlined"
//                                     placeholder="eg: Hardware " className={classes.textField} />
//                             </Grid>
//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>OEM </Typography>
//                                 <TextField
//                                     size="small" id="outlined"
//                                     placeholder="eg: OEM " className={classes.textField} />
//                             </Grid>
//                         </Grid>
//                     </DialogContentText>
//                 </DialogContent>
//                 <DialogActions>
//                     <Button autoFocus onClick={() => setOpenEditModel(false)}
//                         color="primary">
//                         Cancel
//                     </Button>
//                     <Button onClick={() => {
//                         submitModelEdit(true)
//                         setOpenEditModel(false)
//                     }}
//                         color="secondary" autoFocus>
//                         Submit
//                     </Button>
//                 </DialogActions>
//             </Dialog>
//             <Dialog
//                 fullScreen={fullScreen}
//                 open={openEditBattery}
//                 maxWidth={"lg"}
//                 // data={BatteryModelDataRaw}
//                 onClose={() => setOpenEditBattery(false)}
//                 aria-labelledby="responsive-dialog-title"
//                 className={!fullScreen ? classes.dialog : null}
//             >
//                 <DialogTitle id="responsive-dialog-title">{"Edit Battery"}</DialogTitle>
//                 <DialogContent>
//                     <DialogContentText>
//                         <Grid container spacing={2}>
//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Battery Model</Typography>
//                                 <Select
//                                     onChange={(e) => { setEditBatteryFormArray(e, 'battery_model_id') }}
//                                     value={editBatArray.battery_model_id}
//                                     className={classes.textField}>

//                                     <MenuItem value="">Select Battery Model</MenuItem>
//                                     {/* {allEditModel.map((model) => {
//                                         return (
//                                             <MenuItem value={model[0]}>{model[0]}</MenuItem>

//                                         )
//                                     }
//                                     )} */}
//                                 </Select>
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Serial Number</Typography>
//                                 <TextField size="small" id="outlined" value={editBatArray.serial_number}
//                                     onChange={(e) => { setEditBatteryFormArray(e, 'serial_number') }}
//                                     className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
//                                 <TextField size="small" id="outlined" value={editBatArray.bms_unique_id}
//                                     onChange={(e) => { setEditBatteryFormArray(e, 'bms_unique_id') }} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Battery Owner/Investor</Typography>
//                                 <TextField size="small" id="outlined" value={editBatArray.investor}
//                                     onChange={(e) => { setEditBatteryFormArray(e, 'investor') }} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Battery Operation owner</Typography>
//                                 <TextField size="small" id="outlined" value={editBatArray.operation_owner}
//                                     onChange={(e) => { setEditBatteryFormArray(e, 'operation_owner') }} className={classes.textField} />
//                             </Grid>

//                             <Grid item lg={6} xs={12}>
//                                 <Typography className={classes.tabHelp}>Software Version</Typography>
//                                 <TextField size="small" id="outlined"
//                                     // value={editBatArray.sw_version}
//                                     // onChange={(e) => { setEditBatteryFormArray(e, 'sw_version') }}
//                                     className={classes.textField} />
//                             </Grid>

//                         </Grid>
//                     </DialogContentText>
//                 </DialogContent>
//                 <DialogActions>
//                     <Button autoFocus onClick={() => setOpenEditBattery(false)}
//                         color="primary">
//                         Cancel
//                     </Button>
//                     <Button onClick={() => {
//                         submitEditBattery(true)
//                         setOpenEditBattery(false)
//                     }
//                     }
//                         color="secondary" autoFocus>
//                         Submit
//                     </Button>
//                 </DialogActions>
//             </Dialog>
//             <br /><br />
//             <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
//         </div>
//     );
// }
