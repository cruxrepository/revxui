import React, { useState } from 'react';
import axios from 'axios';
import { withStyles, makeStyles, useTheme, styled, alpha, darken } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import LinearProgress from '@material-ui/core/LinearProgress';
import Chip from '@material-ui/core/Chip';
import MUIDataTable from 'mui-datatables';
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import Grid from '@material-ui/core/Grid';
import Switch from '@material-ui/core/Switch';
import Typography from '@material-ui/core/Typography';
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import Tooltip from '@material-ui/core/Tooltip';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import TabIcon from '@material-ui/icons/Tab';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import BatteryCharging30Icon from '@material-ui/icons/BatteryCharging30';
import endpoints from '../../../endpoints/endpoints';
import Divider from '@material-ui/core/Divider';
import SimpleSnackbar from '../Users/SimpleSnackbar';
// import LinearProgress from '@material-ui/core/LinearProgress';
import './styles.css';
import AcUnit from '@material-ui/icons/AcUnit';
import Adb from '@material-ui/icons/Adb';
import AllInclusive from '@material-ui/icons/AllInclusive';
import AssistantPhoto from '@material-ui/icons/AssistantPhoto';
import AppBar from '@material-ui/core/AppBar';
import PhotoLibrary from '@material-ui/icons/PhotoLibrary';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import FormControl from '@material-ui/core/FormControl';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import SimpleMap from "./SimpleMap";
import TreeTable from "./TreeTable";
import Pagination from '@material-ui/lab/Pagination';
import Generic from '../Analytic/Generic';

import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
    GetBBBulk,
    getMyBatteryBulk, getBatteryModelBulk, getBatteryModelLBulk, getBatteryProBulk, getBMSBulk, getBMSLBulk,
    getIV2Bulk, getOMBulk, getFleetBulk, getBVABulk, getTeleModelBulk
} from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';
import clearMyBattery from '../../../redux/actions/normalActions';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import nodata from './imgs/nodata.jpg';
import { StepButton } from "@material-ui/core";
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';

const useStyles = makeStyles((theme) => ({
    tableborder: { display: 'none' },
    root: {
        margin: 10
    },
    textField: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
        'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    dialogPaper: {
        height: "85%",
        width: "50%",
        marginLeft: '700px'
    },
    table: {

        '& > div': {

            '& > .MuiToolbar-regular': {
                backgroundColor: '#68A72480  !important',
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0
            },
            // overflow: 'auto',
            // textAlign:'center'
        },

        '& table': {
            '& td': {
                wordBreak: 'keep-all',
                textAlign: 'center'
            },

            [theme.breakpoints.down('md')]: {
                '& td': {
                    height: 60,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                },
                '& tr:nth-child(odd)': {
                    backgroundColor: '#cfcfcf40'
                },
                '& tr:nth-child(even)': {
                    backgroundColor: '#cfcfcf20'
                },
            }
        }
    },
    graphText: {
        fontSize: 12,
        position: 'absolute',
        transform: 'rotate(270deg)',
        left: '-40px',
        top: 370,
        color: 'primary',
        fontWeight: 600
    },
    graphSelect: {
        minWidth: 150, left: '20em', marginBottom: 20
    },
    tabsSection: {
        [theme.breakpoints.up('lg')]: {
            // borderRadius:0,position:'sticky',top:0 ,width:500
            borderRadius: 0, top: 0, width: 500

        },


    },
    primaryText: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
    }, primaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '300px'
    },
    secondaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '100%'
    },
    voltageG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724'
    },
    voltageY: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FFBF00'
    },
    voltageR: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FF0000'
    },
    chart1: {
        marginLeft: '-20px', width: '120px', height: '50px', '.MuiPaper-root .MuiMenu-paper .MuiPopover-paper': { width: '120px !important' }
    },
    copyRight: {
        position: 'absolute', bottom: 0, right: 0, left: 0, fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    dialog: {
        // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
        position: 'relative', marginLeft: '680px'
    },
    healthy: {
        color: '#82E219', width: '5rem', fontSize: '20px'
    },
    Unhealthy: {
        color: '#FFFF00'
    },
    chart: {
        padding: theme.spacing(2)
    },
    dataView: {
        height: '300px',
    },
    BNavatar: { height: '60px', width: '60px', border: '1px solid #fff', backgroundColor: "#77b93e" },
    BNavatar1: { backgroundColor: '#f3efef' },
    BNgrid: { marginLeft: 20 },
    BNprimaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '16px', fontWeight: 600, color: 'primary', width: '200px',
    },
    BNstateText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '20px', fontWeight: 500, color: '#fff', width: '250px',
    },
    BNsecondaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary',
    },
    BNsecondaryTextG: { color: '#00FF00' },
    BNsecondaryText1: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary', width: '150px',
    },
    BNIcon: {
        marginRight: 10, marginTop: 10
    },
    BNtitle: {},
    BNsubtitle: {},

    BNchip: { backgroundColor: '#4caf50b5' },
    BNchip2: { backgroundColor: '#FFBF00' },
    BNchip3: { backgroundColor: '#FF0000' },
    BNstyledPaper: {
        backgroundColor: '#a2c97d',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper2: {
        backgroundColor: '#FFBF00',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper3: {
        backgroundColor: '#FF0000',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNprogressWidget: {
        marginTop: 20,
        background: theme.palette.secondary.dark,
        '& div': {
            background: theme.palette.primary.light,
        }
    },
    BNmap: {
        height: 200, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    BNcover: {
        '& $name, & $subheading': {
            color: theme.palette.common.white
        },
        position: 'relative',
        width: '100%',
        overflow: 'hidden',
        height: 200,
        backgroundColor: "#77b93e"
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        ,
        // backgroundColor:
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        // ,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundSize: 'cover',
        textAlign: 'center',
        boxShadow: theme.shadows[7],
        backgroundPosition: 'bottom center',
        borderRadius: '10px 10px 0px 0px',
    },
    BNname: {
        fontSize: '24px', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400, color: '#fff'
    },
    BNopt: {
        position: 'absolute',
        top: 0,
        right: 10,
        '& button': {
            color: theme.palette.common.white
        }
    },
    BNprofileTab: {
        marginTop: 0,
        [theme.breakpoints.down('sm')]: {
            marginTop: 0,
        },
        borderRadius: '0px 0px 10px 10px',
        background:
            // alpha(theme.palette.background.paper, 0.8)
            "#dcead7",
        position: 'relative'
    },
    BNaboutTxt: {
        fontSize: '1rem', fontWeight: 600, color: '#000000'
    },

    BNaboutTxt1: {
        fontSize: '1rem', fontWeight: 400, color: '#000000'
    },
    BNdriving: {
        color: '#82E219', marginLeft: '-90px'
    },
    BNdrivingR: {
        color: '#ff0000', marginLeft: '-90px'
    },
    BNorangeAvatar: {
        backgroundColor: '#ff5722',
    },
    BNpurpleAvatar: {
        backgroundColor: '#673ab7',
    },
    BNpinkAvatar: {
        backgroundColor: '#e91e63',
    },
    BNgreenAvatar: {
        backgroundColor: '#4caf50',
    },
    BNdivider: {
        width: '92%', marginLeft: '20px'
    },
    addTab: { backgroundColor: '#b3d391', color: "#fff" },
    pageTitle: {
        textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600
    }
}));
function TabContainer(props) {
    const { children } = props;
    return (
        <div style={{ paddingTop: 8 * 3 }}>
            {children}
        </div>
    );
}

TabContainer.propTypes = {
    children: PropTypes.node.isRequired,
};


export default function BatteryPage() {
    function Alert(props) {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
    }
    const BBData = useSelector((store) => store.bbAll)
    const BBDataRaw = useSelector((store) => store.bbAll.rawData)
    let BBMeta = useSelector((store) => store.bbAll)
    let BBFetching = useSelector((store) => store.bbAll.fetching)
    let BBResponsecode = useSelector((store) => store.bbAll.responseStatus)
    let BBMetaPresent = useSelector((store) => store.bbAll.dataPresent)

    const MyBatteryData = useSelector((store) => store.myBattery)
    const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
    const MyBatteryPage = useSelector((store) => store.myBattery.page_number)
    const MyBatteryPageCount = Math.ceil(useSelector((store) => store.myBattery.total_records) / 10)
    //   let MyBatteryMeta = useSelector((store) => store.myBattery)
    // let MyBatteryMeta =  getBatteryModelBulk()
    let MyBatteryMeta = {};
    MyBatteryMeta.data = [];
    let MyBatteryMetaa = useSelector((store) => store.myBattery)
    if (MyBatteryMetaa.data.length >= 1) {
        MyBatteryMeta.data = MyBatteryMetaa.data;
    }
    let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
    let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
    let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)


    const BatteryTotalData = useSelector((store) => store.batteryTotal)
    const BatteryTotalDataRaw = useSelector((store) => store.batteryTotal.rawData)
    let BatteryTotalMeta = {};
    BatteryTotalMeta.data = [];
    let BatteryTotalMetaa = useSelector((store) => store.batteryTotal)
    if (BatteryTotalMetaa.data.length >= 1) {
        BatteryTotalMeta.data = BatteryTotalMetaa.data;
    }
    let BatteryTotalFetching = useSelector((store) => store.batteryTotal.fetching)
    let BatteryTotalResponsecode = useSelector((store) => store.batteryTotal.responseStatus)
    let BatteryTotalMetaPresent = useSelector((store) => store.batteryTotal.dataPresent)


    let SerialNumber = BatteryTotalMeta.data.map(function (el) { return el[0]; });
    let BatteryModel = BatteryTotalMeta.data.map(function (el) { return el[1]; });
    let BatteryInvestor = BatteryTotalMeta.data.map(function (el) { return el[2]; });
    let BatteryOperation = BatteryTotalMeta.data.map(function (el) { return el[3]; });
    let BatteryVehicleNumber = BatteryTotalMeta.data.map(function (el) { return el[4]; });
    let BatteryIdle = BatteryTotalMeta.data.map(function (el) { return el[5]; });
    let BatteryVehicleStatus = BatteryTotalMeta.data.map(function (el) { return el[6]; });
    let BatteryStatus = BatteryTotalMeta.data.map(function (el) { return el[7]; });
    let BatteryBMS = BatteryTotalMeta.data.map(function (el) { return el[8]; });
    let BatterySW = BatteryTotalMeta.data.map(function (el) { return el[9]; });

    const BatteryProData = useSelector((store) => store.batteryPro)
    const BatteryProRaw = useSelector((store) => store.batteryPro.rawData)
    let BatteryProMeta = useSelector((store) => store.batteryPro)
    let BatteryProFetching = useSelector((store) => store.batteryPro.fetching)
    let BatteryProResponsecode = useSelector((store) => store.batteryPro.responseStatus)
    let BatteryProMetaPresent = useSelector((store) => store.batteryPro.dataPresent)

    const BatteryModelData = useSelector((store) => store.batteryModel)
    const MyBatteryMPage = useSelector((store) => store.batteryModel.page_number)
    const MyBatteryPageMCount = Math.ceil(useSelector((store) => store.batteryModel.total_records) / 10)

    const BatteryModelDataRaw = useSelector((store) => store.batteryModel.rawData)
    let BatteryModelMeta = useSelector((store) => store.batteryModel)
    let BatteryModelFetching = useSelector((store) => store.batteryModel.fetching)
    let BatteryModelResponsecode = useSelector((store) => store.batteryModel.responseStatus)
    let BatteryModelMetaPresent = useSelector((store) => store.batteryModel.dataPresent)

    const BatteryModelLData = useSelector((store) => store.batteryModell)
    const BatteryModelLDataRaw = useSelector((store) => store.batteryModell.rawData)
    let BatteryModelLMeta = useSelector((store) => store.batteryModell)
    let BatteryModelLFetching = useSelector((store) => store.batteryModell.fetching)
    let BatteryModelLResponsecode = useSelector((store) => store.batteryModell.responseStatus)
    let BatteryModelLMetaPresent = useSelector((store) => store.batteryModell.dataPresent)

    const BMSData = useSelector((store) => store.bmsAll)
    const BMSDataRaw = useSelector((store) => store.bmsAll.rawData)
    const MyBatteryBMPage = useSelector((store) => store.bmsAll.page_number)
    const MyBatteryPageBMCount = Math.ceil(useSelector((store) => store.bmsAll.total_records) / 10)
    let BMSMeta = useSelector((store) => store.bmsAll)
    let BMSFetching = useSelector((store) => store.bmsAll.fetching)
    let BMSResponsecode = useSelector((store) => store.bmsAll.responseStatus)
    let BMSMetaPresent = useSelector((store) => store.bmsAll.dataPresent)

    const BMSLData = useSelector((store) => store.bmslAll)
    const BMSLDataRaw = useSelector((store) => store.bmslAll.rawData)
    let BMSLMeta = useSelector((store) => store.bmslAll)
    let BMSLFetching = useSelector((store) => store.bmslAll.fetching)
    let BMSLResponsecode = useSelector((store) => store.bmslAll.responseStatus)
    let BMSLMetaPresent = useSelector((store) => store.bmslAll.dataPresent)

    const IV2Data = useSelector((store) => store.iv2All)
    const IV2DataRaw = useSelector((store) => store.iv2All.rawData)
    let IV2Meta = useSelector((store) => store.iv2All)
    let IV2Fetching = useSelector((store) => store.iv2All.fetching)
    let IV2Responsecode = useSelector((store) => store.iv2All.responseStatus)
    let IV2MetaPresent = useSelector((store) => store.iv2All.dataPresent)
    console.log("IV2Meta", IV2Meta)
    //  Operation
    const OMData = useSelector((store) => store.omAll)
    const OMDataRaw = useSelector((store) => store.omAll.rawData)
    let OMMeta = useSelector((store) => store.omAll.data)
    let OMFetching = useSelector((store) => store.omAll.fetching)
    let OMResponsecode = useSelector((store) => store.omAll.responseStatus)
    let OMMetaPresent = useSelector((store) => store.omAll.dataPresent)



    //Fleet
    const FleetData = useSelector((store) => store.fleetAll)
    const FleetDataRaw = useSelector((store) => store.fleetAll.rawData)

    let FleetMeta = useSelector((store) => store.fleetAll)
    let FleetFetching = useSelector((store) => store.fleetAll.fetching)
    let FleetResponsecode = useSelector((store) => store.fleetAll.responseStatus)
    let FleetMetaPresent = useSelector((store) => store.fleetAll.dataPresent)

    //Vehicle Assign
    const BVAData = useSelector((store) => store.bvaAll)
    const BVADataRaw = useSelector((store) => store.bvaAll.rawData)
    let BVAMeta = useSelector((store) => store.bvaAll)
    let BVAFetching = useSelector((store) => store.bvaAll.fetching)
    let BVAResponsecode = useSelector((store) => store.bvaAll.responseStatus)
    let BVAMetaPresent = useSelector((store) => store.bvaAll.dataPresent)

    //Telematics Model
    const TeleModelData = useSelector((store) => store.teleModelAll)
    const TeleModelDataRaw = useSelector((store) => store.teleModelAll.rawData)
    let TeleModelMeta = useSelector((store) => store.teleModelAll)
    let TeleModelFetching = useSelector((store) => store.teleModelAll.fetching)
    let TeleModelResponsecode = useSelector((store) => store.teleModelAll.responseStatus)
    let TeleModelMetaPresent = useSelector((store) => store.teleModelAll.dataPresent)

    const logged_user = useSelector((store) => store.login.result);
    // console.log(logged_user)
    let enty1 = logged_user.entity_id === "1"
    let enty = logged_user.entity_id
    let UserIdd = logged_user.user_id
    // console.log(UserIdd)
    let uName = logged_user.username
    let pWord = logged_user.password
    let roid = logged_user.role_id
    let batteryEditAccess = logged_user.battery === "edit"
    const dispatch = useDispatch();
    let batteryPageNum = 0;
    const [openEditModel, setOpenEditModel] = React.useState(false);
    const [openEditBattery, setOpenEditBattery] = React.useState(false);

    const theme = useTheme();
    const classes = useStyles();
    const [screen, setScreen] = React.useState(false);
    const [idleMode, setIdleMode] = React.useState(false);
    const [openAddBattery, setOpenAddBattery] = React.useState(false);
    const [openAddModel, setOpenAddModel] = React.useState(false);
    const [openAddBMS, setOpenAddBMS] = React.useState(false);
    const [openEditBMS, setOpenEditBMS] = React.useState(false);
    const [openVehicleActive, setOpenVehicleActive] = React.useState(false);
    const [openBatteryActive, setOpenBatteryActive] = React.useState(false);
    const [notificationTimeOut, setNotificationTimeOut] = React.useState(3000)

    const [openDeActiveV, setOpenDeActiveV] = React.useState(false);
    const [openDeActiveB, setOpenDeActiveB] = React.useState(false);

    const [dataOn, setDataOn] = React.useState(false);

    const [openPass, setOpenPass] = React.useState(false);
    const [openOn, setOpenOn] = React.useState(false);
    const [openOff, setOpenOff] = React.useState(false);


    const [open, setOpen] = React.useState(false);
    const [ddd, setDdd] = React.useState(false);

    const handleClick = () => {
        setOpen(true);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };


    const [getImei, setGetImei] = React.useState({});
    React.useEffect(() => {
        const get = endpoints.baseUrl + `/telematics/assign/get`;
        const cinemaCatGet = axios
            .get(get)
            .then((response) => {
                setGetImei(response.data.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);
    console.log("getImei", getImei)

    const [openTele, setOpenTele] = React.useState(false);
    const [openTeleD, setOpenTeleD] = React.useState(false);
    const [assetLink, setAssetLink] = React.useState(0);

    const [password1, setPassword1] = React.useState("");
    const [password2, setPassword2] = React.useState("");
    const [password3, setPassword3] = React.useState("");
    const [delete1, setDelete1] = React.useState("");
    const [delete2, setDelete2] = React.useState("");
    const [delete3, setDelete3] = React.useState("");
    const [selectedId1, setSelectedId1] = React.useState("");
    const [selectedId2, setSelectedId2] = React.useState("");
    const [selectedId3, setSelectedId3] = React.useState("");

    const [idleOn, setIdleOn] = React.useState({
        status: "true",
        imei: ""
    })

    const On = () => {
        if (idleOn.status && idleOn.imei) {
            const postOn = endpoints.baseUrl + `/battery/onoff`;

            axios
                .post(postOn, idleOn)
                .then((response) => {

                    setAddBatteryErrors(true);

                    // dispatch(getMyBatteryBulk(enty, batPage));
                    response.status === 200 ? setAddResponce("Idle on") : setAddResponce(response.message)
                    // dispatch(getMyBatteryBulk(enty, batPage));

                }).catch((err) => {
                    // console.log("err", err)
                    setAddBatteryErrors(true);

                    setAddResponce("connection error.")

                });
            setOpenOn(false)

        }
        else {
            setAddBatteryErrors(true);

            setAddResponce("Something went wrong..")

        }

    }

    const [idleOff, setIdleOff] = React.useState({
        status: "false",
        imei: ""
    })

    const Off = () => {

        if (idleOff.status && idleOff.imei) {
            const postOff = endpoints.baseUrl + `/battery/onoff`;

            axios
                .post(postOff, idleOff)
                .then((response) => {
                    setAddBatteryErrors(true);

                    // dispatch(getMyBatteryBulk(enty, batPage));
                    response.status === 200 ? setAddResponce("Idle off") : setAddResponce(response.message)
                    // dispatch(getMyBatteryBulk(enty, batPage));
                }).catch((err) => {
                    // console.log("err", err)
                    setAddBatteryErrors(true);

                    setAddResponce("connection error.")

                });
            setOpenOff(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Something went wrong..")

        }

    }

    const [assignVech, setAssignVech] = React.useState({
        vehicle_id: "",
        battery_id: ""
    })

    const assVehicle = () => {

        if (assignVech.vehicle_id && assignVech.battery_id) {
            const postVeh = endpoints.baseUrl + `/battery/vehicle/add`;

            axios
                .post(postVeh, assignVech)
                .then((response) => {
                    setAddBatteryErrors(true);

                    // dispatch(getMyBatteryBulk(enty,UserIdd, batPage));
                    response.status === 200 ? setAddResponce("Vehicle assigned successfully!") : setAddResponce(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                });
            setOpenVehicleActive(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }
    const [assignBat, setAssignBat] = React.useState({
        battery_status: "enabled"
    })

    const assBat = () => {

        if (assignBat.battery_status) {
            const putBat = endpoints.baseUrl + `/battery/status/` + bid;

            axios
                .put(putBat, assignBat)
                .then((response) => {
                    setAddBatteryErrors(true);

                    // dispatch(getMyBatteryBulk(enty,UserIdd, batPage));
                    response.status === 200 ? setAddResponce("Battery enabled") : setAddResponce(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                });
            setOpenBatteryActive(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }

    const [assignDBat, setAssignDBat] = React.useState({
        battery_status: "disabled"
    })

    const assBatD = () => {

        if (assignDBat.battery_status) {
            const putBatD = endpoints.baseUrl + `/battery/status/` + bid;

            axios
                .put(putBatD, assignDBat)
                .then((response) => {
                    setAddBatteryErrors(true);

                    // dispatch(getMyBatteryBulk(enty, UserIdd,batPage));
                    response.status === 200 ? setAddResponce("Battery disbled") : setAddResponce(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                });
            setOpenDeActiveB(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }

    const [modelAddForm, setModelAddForm] = React.useState(
        {
            model_info: "",
            nominal_voltage: "",
            capacity_mah: "",
            power: "",
            cell_maufacturer: "",
            oem: "",
            number_of_cells_series: "",
            number_of_cells_parallel: "",
            cell_chemisty: "",
            cell_type: "",
            length: "",
            width: "",
            height: "",
            thermistor: "",
            // bms_model_id:""

        }
    )
    const [batteryAddForm, setBatteryAddForm] = React.useState(
        {
            serial_number: "",
            bms_unique_id: "",
            battery_model_id: "",
            sw_version: "",
            bms_model_id: "",
            asset: {
                asset_type: "battery",
                entity_id: ""
            },
            investors: {
                asset_type: "battery",
                entity_id: enty,
                user_id: "0"
            },
            user: {
                asset_type: "battery",
                entity_id: enty,
                user_id: "0"
            },
            telematics: {
                telematics_data_id: "",
                imei: "",
                sim_operator: "",
                mobile_number: ""
            }
        }
    )
    const submitBattery = () => {

        if (batteryAddForm.battery_model_id && batteryAddForm.serial_number) {
            const postBattery = endpoints.baseUrl + `/battery/post`;
            axios
                .post(postBattery, batteryAddForm)
                .then((response) => {
                    setAddBatteryErrors(true);
                    response.status === 201 ? setAddResponce("Battery onboarded successfully!") : setAddResponce(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                    setOpenAddBattery(false)
                    setBatteryAddForm({})
                    handleReset()
                });

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }
    const setBatteryAddFormArray = (e, key, array) => {
        if (array) {
            setBatteryAddForm((state) => ({
                ...state, [array]: {
                    ...state[array],
                    [key]: e.target.value
                }
            }));
        } else {
            setBatteryAddForm((state) => ({ ...state, [key]: e.target.value }));

        }

    }

    const [editBatArray, setEditBatArray] = React.useState(
        {}
    )
    const deleteBattery = (bms_id) => {
        const deleteB = endpoints.baseUrl + `/battery/softdelete/` + bms_id;
        axios
            .delete(deleteB)
            .then((response) => {
                setAddBatteryErrors(true);
                response.status === 200 ? setAddResponce("Battery offboarded successfully!") : setAddResponce(response.message)
                setDelete1(false)
                setPassword1()
                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
            });
    }
    const [bmsAddForm, setBmsAddForm] = React.useState(
        {
            model_info: "",
            hw_version: "",
            oem: "",
        }
    )
    const [editBMSArray, setEditBMSArray] = React.useState(
        {}
    )
    const submitBMS = () => {

        if (bmsAddForm.model_info && bmsAddForm.hw_version && bmsAddForm.oem) {
            const postBMS = endpoints.baseUrl + `/battery/bms/add`;
            axios
                .post(postBMS, bmsAddForm)
                .then((response) => {
                    setAddBatteryErrors(true);
                    dispatch(getBMSBulk());
                    response.status === 201 ? setAddResponce("BMS onboarded successfully!") : null
                    // response.status === 400 ? setAddResponce("BMS Onboarded successfully!") : setAddResponce(response.message)
                    setOpenAddBMS(false)

                    setBmsAddForm({
                        model_info: "",
                        hw_version: "",
                        oem: "",
                    })
                }).catch((err) => {
                    setAddResponce("This details already exists")
                });


        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }
    const setBMSAddFormArray = (e, key) => {
        setBmsAddForm((state) => ({ ...state, [key]: e.target.value }));

    }

    const setEditBmsFormArray = (e, key) => {
        setEditBMSArray((state) => ({ ...state, [key]: e.target.value }));

    }


    const submitEditBMS = () => {
        // setAddBatteryErrors(true);
        if (editBMSArray.model_info && editBMSArray.hw_version && editBMSArray.oem) {
            const putBMS = endpoints.baseUrl + `/battery/bms/edit/` + editBMSArray.bms_model_id;
            let newEditBMSArray = editBMSArray;
            axios
                .put(putBMS, newEditBMSArray)
                .then((response) => {
                    setAddBatteryErrors(true);
                    setOpenEditBMS(false)

                    dispatch(getBMSBulk());
                    response.status === 200 ? setAddResponce("Battery details edited successfully!") : setAddResponce(response.message)
                    setEditBMSArray({

                    })
                });
            setOpenEditBMS(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }

    const setEditBMSSArray = (bms_model_id) => {

        let allBMS = BMSDataRaw;
        let findEditBMSArray = allBMS.find(el => el.bms_model_id === bms_model_id);
        setEditBMSArray(findEditBMSArray);
    }
    const deleteBMS = (bms_model_id) => {
        const deleteBMSM = endpoints.baseUrl + `/battery/bms/delete/` + bms_model_id;
        axios
            .delete(deleteBMSM)
            .then((response) => {
                setAddBatteryErrors(true);
                response.status === 200 ? setAddResponce("BMS model offboarded successfully!") : setAddResponce(response.message)
                setDelete3(false)
                setPassword3();
                dispatch(getBMSBulk());
            });
    }
    const [value, setValue] = React.useState(0);
    const [bmsmodel, setBmsmodel] = React.useState(0);
    const [bmsid, setBmsId] = React.useState(0);
    const [bid, setBId] = React.useState(0);
    const [imei, setImei] = React.useState(0);
    const [serial, setSerial] = React.useState(0);
    const [vn, setVn] = React.useState(0);
    const [vehBatID, setVehBatID] = React.useState(0);
    const [model, setModel] = React.useState(0);

    const [tableMode, setTableMode] = React.useState("ericksaw");


    const [csvDownload, setCsvDownload] = React.useState(1);
    const [chartOneVal, setChartOneVal] = React.useState("day");

    const [onOffPassword, setOnOffPassword] = React.useState("")
    const [onOffPassword1, setOnOffPassword1] = React.useState("")
    const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
    const [addResponse, setAddResponce] = React.useState("")
    const [batPage, setBatPage] = React.useState(1);
    const [modelPage, setModelPage] = React.useState(1);
    const [bmsPage, setBmsPage] = React.useState(1);

    const [editArray, setEditArray] = React.useState({

    })
    const [state, setState] = React.useState({
        checkedA: false,
    });
    const [state1, setState1] = React.useState({
        checkedB: false,
    });
    React.useEffect(() => {
        setEditArray(modelPage ? modelPage : 1)
        typeof enty && roid != "undefined" ? dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage)) : null;

        dispatch(
            getBatteryModelBulk(modelPage)
        );
    }, [MyBatteryMetaPresent, batPage, BatteryTotalMetaPresent, modelPage]);

    React.useEffect(() => {
        dispatch(getBMSBulk(bmsPage));
        dispatch(getBatteryModelLBulk());
        dispatch(getBMSLBulk());
        dispatch(getIV2Bulk(enty));
        dispatch(getFleetBulk());
        dispatch(getBVABulk());
        dispatch(getTeleModelBulk());
    }, [BatteryModelLMetaPresent, BatteryTotalMetaPresent, BMSMetaPresent, BMSLMetaPresent, bmsPage, FleetMetaPresent, IV2MetaPresent, BVAMetaPresent, TeleModelMetaPresent]);


    let allModels = BatteryModelMeta.data
    let allBMSData = BMSLMeta.data
    const changePageBat = (event, newValue) => {
        setBatPage(newValue);
    };
    const changePageBatModel = (event, newValue) => {
        setModelPage(newValue);
    };
    const changePageBMS = (event, newValue) => {
        setBmsPage(newValue);
    };



    const submitModel = () => {
        setAddBatteryErrors(true);

        if (
            modelAddForm.capacity_mah && modelAddForm.model_info && modelAddForm.nominal_voltage &
            modelAddForm.power && modelAddForm.thermistor
        ) {
            const postModel = endpoints.baseUrl + `/batterymodel/add`;
            axios
                .post(postModel, modelAddForm)
                .then((response) => {
                    setAddBatteryErrors(true);

                    dispatch(getBatteryModelBulk());
                    setAddResponce("Model onboarded successfully!")
                    setModelAddForm({
                        model_info: "",
                        nominal_voltage: "",
                        capacity_mah: "",
                        power: "",
                        cell_maufacturer: "",
                        oem: "",
                        number_of_cells_series: "",
                        number_of_cells_parallel: "",
                        cell_chemisty: "",
                        cell_type: "",
                        length: "",
                        width: "",
                        height: "",
                        thermistor: "",
                        // bms_model_id:""
                    })
                    handleReset4()
                });
            setOpenAddModel(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }
    const setModelAddFormArray = (e, key, array) => {
        if (array) {
            setModelAddForm((state) => ({
                ...state, bms: {
                    ...state.bms,
                    [key]: e.target.value
                }
            }));
        } else {
            setModelAddForm((state) => ({ ...state, [key]: e.target.value }));

        }


    }

    const setModelEditFormArray = (e, key, array) => {
        if (array) {
            setEditArray((state) => ({
                ...state, bms: {
                    ...state.bms,
                    [key]: e.target.value
                }
            }));
        } else {
            setEditArray((state) => ({ ...state, [key]: e.target.value }));

        }


    }
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
    const handleChange = (event, newValue) => {
        setValue(newValue);
        setOpenEditModel(false)
        setOpenEditBattery(false)
        setOpenAddBattery(false)
        setOpenAddModel(false)
        setOpenAddBMS(false)
        setOpenEditBMS(false)
        handleReset()
        handleReset1()
        handleReset2()
        handleReset3()
    };

    const handleChangeT = (event, val) => {
        setValue(val);
    };


    let allEditModel = BatteryModelMeta.data
    {/* Battery*/ }

    const setEditBatteryFormArray = (e, key, array) => {
        if (array) {
            setEditBatArray((state) => ({
                ...state, [array]: {
                    ...state[array],
                    [key]: e.target.value
                }
            }));
        } else {
            setEditBatArray((state) => ({ ...state, [key]: e.target.value }));

        }

    }


    const submitEditBattery = () => {
        setAddBatteryErrors(true);
        if (editBatArray.bms_unique_id && editBatArray.serial_number) {
            const putBattery = endpoints.baseUrl + `/battery/update/` + editBatArray.bms_id;
            axios
                .put(putBattery, editBatArray)
                .then((response) => {
                    setAddBatteryErrors(true);

                    response.status === 200 ? setAddResponce("Battery details edited successfully!") : setAddResponce(response.message)
                    dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                    setOpenEditBattery(false)
                    handleReset1()
                });

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }

    const setEditBatteryArray = (bms_id) => {
        let allBattery = MyBatteryDataRaw;
        let findEditArray = allBattery.length && allBattery.find(el => el.bms_id === bms_id);
        setEditBatArray(findEditArray);
    }

    {/* Model*/ }

    const setModelEditArray = (battery_model_id) => {
        let allModel = BatteryModelDataRaw;
        let findArray = allModel.find(el => el.battery_model_id === battery_model_id);
        setEditArray(findArray);
    }
    const submitModelEdit = () => {

        setAddBatteryErrors(true);

        if (
            editArray.capacity_mah && editArray.model_info && editArray.nominal_voltage && editArray.number_of_cells_parallel && editArray.number_of_cells_series
            && editArray.power && editArray.thermistor
            //  && editArray.bms_model_info
        ) {


            const putModel = endpoints.baseUrl + `/batterymodel/edit/` + editArray.battery_model_id;
            axios
                .put(putModel, editArray)
                .then((response) => {
                    dispatch(getBatteryModelBulk());
                    response.status === 200 ? setAddResponce("Model details edited successfully!") : setAddResponce(response.message)
                    setEditArray({

                    })
                });
            setOpenEditModel(false)
            handleReset5()

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }

    const deleteModel = (battery_model_id) => {
        const deleteModel = endpoints.baseUrl + `/batterymodel/softdelete/` + battery_model_id;
        axios
            .delete(deleteModel)
            .then((response) => {
                setAddBatteryErrors(true);
                response.status === 200 ? setAddResponce("Battery model offboarded successfully!") : setAddResponce(response.message)
                setDelete2(false)
                setPassword2()
                dispatch(getBatteryModelBulk());
            });
    }
    const Item = styled(Paper)(({ theme }) => ({
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'left',
        color: theme.palette.text.secondary,
    }));

    const validateKeyData = (key) => {
        return key ? key : "-";
    };

    const handleTableChange = (event) => {
        if (tableMode === 'erickshaw') {
            setTableMode('comm');
        } else {
            setTableMode('erickshaw');
        }
    };
    const batteryProfile = (imei) => {
        dispatch(getBatteryProBulk(imei));
        setCsvDownload(1)
    }
    const downloadCsv = () => {
        let getCsvUrl = endpoints.baseUrl + `/battery/datadownload/` + imei;
        const a = document.createElement('a')
        a.setAttribute('href', getCsvUrl)
        // a.setAttribute('download', 'download.csv');
        a.click()
        setAddBatteryErrors(true);
        setNotificationTimeOut(60000)
        setAddResponce("Preparing Your csv for Download, Please wait..")

        axios
            .get(getCsvUrl)
            .then((response) => {
                // setFinalCsv(response);
                setCsvDownload(1)
                // const blob = new Blob([response.data], { type: 'text/csv' });
                // const url = window.URL.createObjectURL(blob)


                //  input.current.click()
                setAddBatteryErrors(false);
                setNotificationTimeOut(6000)

                //  input.current.click()
                setAddBatteryErrors(true);

                setAddResponce("Downloaded successfully!")

            })
            .catch((error) => {

                let status = null;
                let data = null;
                setCsvDownload(4)
                setAddBatteryErrors(true);

                setAddResponce("Try again")

                //If no response from server
                if (!error.response) {
                    status = 500;
                    data = "No response from server";
                } else {
                    status = error.response.status;
                    data = error.response.data;
                }

            });

    }
    const handleSubmiAddBattery = () => {
        submitBattery()
    }
    const handleSubmitEditBattery = () => {
        submitEditBattery()
    }

    const DeactiveV = (vehicle_battery_id) => {
        const DeactiveVeh = endpoints.baseUrl + `/battery/vehicle/deactivate/` + vehicle_battery_id;
        axios
            .delete(DeactiveVeh)
            .then((response) => {
                setAddResponce("Vehicle deactivated")
                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));
                setOpenDeActiveV(false)
            });
    }
    const eIdles = React.useState(MyBatteryMeta.data);

    let allIdles = [];
    if (MyBatteryMetaPresent && BBMetaPresent) {
        allIdles = MyBatteryMeta.data
        // .map((ob) => {
        //     ob.idleMode = false;
        //     return ob;
        // })
    }
    const [selectedItem, setSelectedItem] = React.useState({ newmode: true })

    const checkPassword = () => {

        if (onOffPassword === pWord) {
            On()
        }
        else if (onOffPassword1 === pWord) {
            Off()
        }
        else {
            return null;
        }
    }

    const handleIdleMode = (dialog, imei, mode) => {
        setOpenPass(true)
        setSelectedItem((state) => ({
            ...state,
            imei: imei,
            mode: mode
        }))




    }


    const columsModel = [
        {
            name: 'Battery Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>{validateKeyData(value)} </Typography>
                )
            }
        },
        {
            name: 'Nominal Voltage (V)',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Capacity (Ah)',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Power (Wh)',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Manufacturer',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Action',
            options: {
                filter: true,
                customBodyRender: (value) => {
                    return (
                        <><IconButton
                            onClick={() => {
                                setOpenEditModel(true)
                                setAddBatteryErrors(false)
                                setModelEditArray(value)
                            }}
                        ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
                            <IconButton
                                onClick={() => {
                                    setDelete2(true);
                                    setSelectedId2(value);
                                }}
                            ><Icon icon="ic:baseline-delete"
                                color="#fa5d41"
                                width="22"
                                height="22" /> </IconButton>
                        </>
                    )
                }
            }
        },
    ]
    const columsModel1 = [
        {
            name: 'Battery Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>{validateKeyData(value)} </Typography>
                )
            }
        },
        {
            name: 'Nominal Voltage (V)',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-30px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Capacity (Ah)',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Power (Wh)',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'Manufacturer',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }
    ]

    const [clear, setClear] = React.useState([]);
    const [clear1, setClear1] = React.useState([]);
    const [clear2, setClear2] = React.useState([]);
    const [clear3, setClear3] = React.useState([]);
    const [clear4, setClear4] = React.useState([]);
    const [clear5, setClear5] = React.useState([]);
    const [clear6, setClear6] = React.useState([]);
    const [clear7, setClear7] = React.useState([]);
    const [clear8, setClear8] = React.useState([]);
    const [clear9, setClear9] = React.useState([]);


    const [selectedImei, setSelectedImei] = React.useState("");
    React.useEffect(() => {
        setAssignTele({
            battery_id: "",
            telematics_id: "",
        });
    }, [selectedImei]);

    const [assignTele, setAssignTele] = React.useState({
        battery_id: "",
        telematics_id: "",
    });

    const AssignTelematics = () => {
        if (assignTele.battery_id && assignTele.telematics_id) {
            const postImei = endpoints.baseUrl + `/telematics/assign/battery`;

            axios.post(postImei, assignTele).then((response) => {
                setAddBatteryErrors(true);
                response.status === 200
                    ? setAddResponce("Telematics assigned successfully!")
                    : setAddResponce(response.message);
                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage))
                setOpenTele(false);
            });
            setOpenTele(false);
        } else {
            setAddBatteryErrors(true);
            setAddResponce("Please fill the required fields");
        }
    };
    const ReassignImei = (asset_linkage_id) => {
        const Dimei = endpoints.baseUrl + `/telematics/deactivate/` + asset_linkage_id;
        axios.delete(Dimei).then((response) => {
            response.status === 200
                ? setAddResponce("Imei deactivated")
                : setAddResponce("Imei deactivated");
            dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage))
            setOpenTeleD(false);
        });
    };

    const columnsBattery = [

        {
            name: 'Battery',
            options: {
                filter: false,
                field: value.serial_number,
                customBodyRender: (value) => (
                    <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-start', marginLeft: '60px' }}>
                        {value.battery_status === 'enabled' ? <><Tooltip style={{ flex: "left" }} title={"Enabled"}>
                            <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px' }}>
                                <Icon
                                    icon="mdi:car-battery"
                                    color="#fff"
                                    width="22"
                                    height="22"
                                />
                            </Avatar>
                        </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                            <><Tooltip style={{ flex: "left" }} title={"Disabled"}>
                                <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                                    <Icon
                                        icon="mdi:car-battery"
                                        color="#fff"
                                        width="22"
                                        height="22"
                                    />
                                </Avatar>
                            </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></>}
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                            <Typography onClick={() => {
                                setScreen(true)
                                setBmsId(validateKeyData(value.bms_id))
                                setImei(validateKeyData(value.imei))
                                setSerial(validateKeyData(value.serial_number))
                                batteryProfile(validateKeyData(value.imei))
                            }}
                                style={{ cursor: "pointer", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}>
                                &nbsp;&nbsp;{value.serial_number}
                            </Typography>
                            <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>
                                &nbsp;&nbsp;{value.battery_model}
                            </Typography>
                        </div>
                    </div>

                )
            }
        },
        {
            name: 'Vehicle',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', marginLeft: '30px' }}>
                        <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}>{validateKeyData(value.vehicle_number)}</Typography>
                        <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>{validateKeyData(value.updated_at)}</Typography></div>
                )
            }
        },
        {
            name: 'Investor',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-25px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Operation Manager',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-25px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Active',
            options: {
                filter: false,  //setImei(validateKeyData(value.imei))
                customBodyRender: (value) => {
                    if (value.status === "true") {
                        return (<Switch checked={true}
                            onClick={() => {
                                setImei(validateKeyData(value.imei))
                                setOpenOff(true)
                                setIdleOff((state) => ({
                                    ...state,
                                    "imei": value.imei
                                }))
                            }} />)
                    }
                    else {
                        return (<Switch checked={false} onClick={() => {
                            setImei(validateKeyData(value.imei))
                            setOpenOn(true)
                            setIdleOn((state) => ({
                                ...state,
                                "imei": value.imei
                            }))
                        }} />)
                    }
                }

            }
        },
        {
            name: 'Assignment',
            options: {
                filter: false,
                customBodyRender: (value) => {

                    if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "disabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setAddBatteryErrors(false)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton>
                                    <Icon icon="codicon:blank" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setOpenBatteryActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setSelectedImei(value.imei)
                                        setEditBatteryArray(value.bms_id)
                                        setAssetLink(value.asset_linkage_id);
                                        setOpenTeleD(true)
                                    }}
                                >
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "disabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setAddBatteryErrors(false)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton>
                                    <Icon icon="codicon:blank" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setOpenBatteryActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAssignTele((state) => ({
                                            ...state,
                                            battery_id: value.battery_id,
                                        }));
                                        setOpenTele(true)
                                    }}>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "enabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setAddBatteryErrors(false)

                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton>
                                    <Icon icon="codicon:blank" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setOpenDeActiveB(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setSelectedImei(value.imei)
                                        setEditBatteryArray(value.bms_id)
                                        setAssetLink(value.asset_linkage_id);
                                        setOpenTeleD(true)
                                    }}
                                >
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>} </>
                        )
                    }
                    else if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "enabled" && value.telematics_status === "unassign") {
                        return (
                            <><IconButton
                                onClick={() => {
                                    setOpenEditBattery(true)
                                    setAddBatteryErrors(false)

                                    setEditBatteryArray(value.bms_id)
                                }}
                            ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
                                <IconButton>
                                    <Icon icon="codicon:blank" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setOpenDeActiveB(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAssignTele((state) => ({
                                            ...state,
                                            battery_id: value.battery_id,
                                        }));
                                        setOpenTele(true)
                                    }}>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>} </>
                        )
                    }
                    else if (value.vehicle_status === "assign" && value.battery_status === "enabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAddBatteryErrors(false)
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setSerial(validateKeyData(value.serial_number))
                                        setOpenDeActiveV(true)
                                        setVehBatID(validateKeyData(value.vehicle_battery_id))
                                    }}><Icon icon="mdi:motorbike" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setSerial(validateKeyData(value.serial_number))
                                        setOpenDeActiveB(true)
                                        setBId(validateKeyData(value.battery_id))
                                    }}>
                                    <Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setSelectedImei(value.imei)
                                        setEditBatteryArray(value.bms_id)
                                        setAssetLink(value.asset_linkage_id);
                                        setOpenTeleD(true)
                                    }}
                                >
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else if (value.vehicle_status === "assign" && value.battery_status === "disabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAddBatteryErrors(false)
                                        setOpenDeActiveV(true)
                                        setVn(validateKeyData(value.vehicle_number))
                                        setVehBatID(validateKeyData(value.vehicle_battery_id))
                                        setEditBatteryArray(value.bms_id)
                                        setSerial(validateKeyData(value.serial_number))
                                    }}><Icon icon="mdi:motorbike" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setOpenBatteryActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAssignTele((state) => ({
                                            ...state,
                                            battery_id: value.battery_id,
                                        }));
                                        setOpenTele(true)
                                    }}>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else if (value.vehicle_status === "unassign" && value.battery_status === "enabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAddBatteryErrors(false)
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setOpenVehicleActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setAssignVech((state) => ({
                                            ...state,
                                            "battery_id": value.bms_id
                                        }))

                                    }}><Icon icon="mdi:motorbike" color="#C4C4C4" width="22" height="22" /></IconButton>
                                <IconButton
                                    onClick={() => {
                                        setSerial(validateKeyData(value.serial_number))
                                        setOpenDeActiveB(true)
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAssignTele((state) => ({
                                            ...state,
                                            battery_id: value.battery_id,
                                        }));
                                        setOpenTele(true)
                                    }}>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else if (value.vehicle_status === "unassign" && value.battery_status === "disabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAddBatteryErrors(false)
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setOpenVehicleActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setAssignVech((state) => ({
                                            ...state,
                                            "battery_id": value.bms_id
                                        }))
                                    }}><Icon icon="mdi:motorbike" color="#C4C4C4" width="22" height="22" /></IconButton>

                                <IconButton
                                    onClick={() => {
                                        setOpenBatteryActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setSelectedImei(value.imei)
                                        setEditBatteryArray(value.bms_id)
                                        setAssetLink(value.asset_linkage_id);
                                        setOpenTeleD(true)
                                    }}
                                >
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else if (value.vehicle_status === "assign" && value.battery_status === "enabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAddBatteryErrors(false)
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setSerial(validateKeyData(value.serial_number))
                                        setOpenDeActiveV(true)
                                        setVehBatID(validateKeyData(value.vehicle_battery_id))
                                    }}><Icon icon="mdi:motorbike" color="#68a724" width="22" height="22" />
                                </IconButton>

                                <IconButton
                                    onClick={() => {
                                        setSerial(validateKeyData(value.serial_number))
                                        setOpenDeActiveB(true)
                                        setBId(validateKeyData(value.battery_id))

                                    }}>
                                    <Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAssignTele((state) => ({
                                            ...state,
                                            battery_id: value.battery_id,
                                        }));
                                        setOpenTele(true)
                                    }}>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else if (value.vehicle_status === "unassign" && value.battery_status === "enabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAddBatteryErrors(false)
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setOpenVehicleActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setAssignVech((state) => ({
                                            ...state,
                                            "battery_id": value.bms_id
                                        }))
                                    }}><Icon icon="mdi:motorbike" color="#C4C4C4" width="22" height="22" /></IconButton>

                                <IconButton
                                    onClick={() => {
                                        setSerial(validateKeyData(value.serial_number))
                                        setOpenDeActiveB(true)
                                        setBId(validateKeyData(value.battery_id))

                                    }}>
                                    <Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setSelectedImei(value.imei)
                                        setEditBatteryArray(value.bms_id)
                                        setAssetLink(value.asset_linkage_id);
                                        setOpenTeleD(true)
                                    }}
                                >
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else if (value.vehicle_status === "assign" && value.battery_status === "disabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAddBatteryErrors(false)
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setSerial(validateKeyData(value.serial_number))
                                        setOpenDeActiveV(true)
                                        setVehBatID(validateKeyData(value.vehicle_battery_id))
                                    }}><Icon icon="mdi:motorbike" color="#68a724" width="22" height="22" />
                                </IconButton>

                                <IconButton
                                    onClick={() => {
                                        setOpenBatteryActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" />
                                </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setSelectedImei(value.imei)
                                        setEditBatteryArray(value.bms_id)
                                        setAssetLink(value.asset_linkage_id);
                                        setOpenTeleD(true)
                                    }}
                                >
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }
                    else {
                        return (
                            <><IconButton
                                onClick={() => {
                                    setOpenEditBattery(true)
                                    setEditBatteryArray(value.bms_id)
                                }}
                            ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAddBatteryErrors(false)
                                        setVn(validateKeyData(value.vehicle_number))
                                        setEditBatteryArray(value.bms_id)
                                        setOpenVehicleActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setAssignVech((state) => ({
                                            ...state,
                                            "battery_id": value.bms_id
                                        }))
                                    }}><Icon icon="mdi:motorbike" color="#c4c4c4" width="22" height="22" />
                                </IconButton>

                                <IconButton
                                    onClick={() => {
                                        setOpenBatteryActive(true)
                                        setSerial(validateKeyData(value.serial_number))
                                        setBId(validateKeyData(value.battery_id))

                                    }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" /> </IconButton>
                                <IconButton
                                    onClick={() => {
                                        setAssignTele((state) => ({
                                            ...state,
                                            battery_id: value.battery_id,
                                        }));
                                        setOpenTele(true)
                                    }}>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                                {value.vehicle_status === "assign" ?
                                    <IconButton
                                        onClick={() => {
                                            handleClick(true);
                                            setDdd(value.vehicle_number)
                                        }}
                                    >
                                        <Icon
                                            icon="ic:baseline-delete"
                                            color="#fa5d41"
                                            width="22"
                                            height="22"
                                        />
                                    </IconButton> :
                                    value.battery_status === "enabled" ?
                                        <IconButton
                                            onClick={() => {
                                                setAddBatteryErrors(true);
                                                setAddResponce(<p style={{ marginTop: '8px' }}>This battery status is&nbsp;{value.battery_status}</p>);
                                            }}
                                        >
                                            <Icon
                                                icon="ic:baseline-delete"
                                                color="#fa5d41"
                                                width="22"
                                                height="22"
                                            />
                                        </IconButton> :
                                        value.telematics_status === "assign" ?
                                            <IconButton
                                                onClick={() => {
                                                    setAddBatteryErrors(true);
                                                    setAddResponce(<p style={{ marginTop: '8px' }}>This battery assigned to&nbsp;{value.imei}</p>);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton> :
                                            <IconButton
                                                onClick={() => {
                                                    setDelete1(true);
                                                    setSelectedId1(value.bms_id);
                                                }}
                                            >
                                                <Icon
                                                    icon="ic:baseline-delete"
                                                    color="#fa5d41"
                                                    width="22"
                                                    height="22"
                                                />
                                            </IconButton>}
                            </>
                        )
                    }


                },

            },

        },
    ]
    const columnsBattery1 = [

        {
            name: 'Battery',
            options: {
                filter: false,
                field: value.serial_number,
                customBodyRender: (value) => (
                    <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-start', marginLeft: '60px' }}>
                        {value.battery_status === 'enabled' ? <><Tooltip style={{ flex: "left" }} title={"Enabled"}>
                            <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px' }}>
                                <Icon
                                    icon="mdi:car-battery"
                                    color="#fff"
                                    width="22"
                                    height="22"
                                />
                            </Avatar>
                        </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                            <><Tooltip style={{ flex: "left" }} title={"Disabled"}>
                                <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                                    <Icon
                                        icon="mdi:car-battery"
                                        color="#fff"
                                        width="22"
                                        height="22"
                                    />
                                </Avatar>
                            </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></>}
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                            <Typography onClick={() => {
                                setScreen(true)
                                setBmsId(validateKeyData(value.bms_id))
                                setImei(validateKeyData(value.imei))
                                setSerial(validateKeyData(value.serial_number))
                                batteryProfile(validateKeyData(value.imei))
                            }}
                                style={{ cursor: "pointer", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}>
                                &nbsp;&nbsp;{value.serial_number}
                            </Typography>
                            <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>
                                &nbsp;&nbsp;{value.battery_model}
                            </Typography>
                        </div>
                    </div>

                )
            }
        },
        {
            name: 'Vehicle',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', marginLeft: '30px' }}>
                        <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}>{validateKeyData(value)}</Typography>
                        <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>{validateKeyData(value.updated_at)} </Typography></div>
                )
            }
        },
        {
            name: 'Investor',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-25px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Operation Manager',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-25px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Assignment',
            options: {
                filter: false,
                customBodyRender: (value) => {

                    if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "disabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton>
                                    <Icon icon="codicon:blank" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "disabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton>
                                    <Icon icon="codicon:blank" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "enabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton>
                                    <Icon icon="codicon:blank" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton> </>
                        )
                    }
                    else if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "enabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton>
                                    <Icon icon="codicon:blank" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton></>
                        )
                    }
                    else if (value.vehicle_status === "assign" && value.battery_status === "enabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton>
                                    <Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_status === "assign" && value.battery_status === "disabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_status === "unassign" && value.battery_status === "enabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#C4C4C4" width="22" height="22" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_status === "unassign" && value.battery_status === "disabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#C4C4C4" width="22" height="22" /></IconButton>

                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" />
                                </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_status === "assign" && value.battery_status === "enabled" && value.telematics_status === "unassign") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#68a724" width="22" height="22" />
                                </IconButton>

                                <IconButton>
                                    <Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_status === "unassign" && value.battery_status === "enabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#C4C4C4" width="22" height="22" /></IconButton>
                                <IconButton>
                                    <Icon icon="mdi:car-battery" color="#68a724" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_status === "assign" && value.battery_status === "disabled" && value.telematics_status === "assign") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#68a724" width="22" height="22" />
                                </IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" />
                                </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#68a724"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }
                    else {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#c4c4c4" width="22" height="22" />
                                </IconButton>

                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="22" height="22" /> </IconButton>
                                <IconButton>
                                    <Icon
                                        icon="material-symbols:wifi"
                                        color="#c4c4c4"
                                        width="20"
                                        height="20"
                                    />
                                </IconButton>
                            </>
                        )
                    }


                },

            },

        },
    ]
    const columsBMS = [
        {
            name: 'BMS Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)} </Typography>
                )
            }
        },
        {
            name: 'Hardware',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'OEM',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
        {
            name: 'Action',
            options: {
                filter: true,
                customBodyRender: (value) => {
                    // if (value === 'assign') {
                    return (
                        <><IconButton
                            onClick={() => {
                                setOpenEditBMS(true)
                                //     setAddBatteryErrors(false)
                                setEditBMSSArray(value)
                            }}
                        ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
                            <IconButton
                                onClick={() => {
                                    setDelete3(true);
                                    setSelectedId3(value);
                                }}
                            ><Icon icon="ic:baseline-delete"
                                color="#fa5d41"
                                width="22"
                                height="22" /> </IconButton></>

                    )
                }
            }
        },
    ]
    const columsBMS1 = [
        {
            name: 'BMS Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)} </Typography>
                )
            }
        },
        {
            name: 'Hardware',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        }, {
            name: 'OEM',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
                )
            }
        },
    ]
    const dataModel = [
        ['Model 1', 'v12.00', 'v2', '50V', '10 Ah', '500 wh', 'Samsung', 'deactive'],
        ['Model 2', 'v12.30', 'v5', '20V', '10 Ah', '500 wh', 'Panasonic', 'deactive'],
        ['Model 3', 'v12.50', 'v2.1', '52V', '10 Ah', '500 wh', 'LG', 'deactive'],


    ];

    const options = {
        filter: false,
        filterType: 'dropdown',
        responsive: 'vertical',
        print: false,
        search: true,
        rowsPerPage: 100,
        onDownload: (buildHead, buildBody, columns, data) => {
            buildHead = () => {
                return ["Serial Number", "Model", "Investor", "Operational Manager", "Vehicle Number", "Active"]
            }
            buildBody = () => {
                let allRows = []

                data.map((col) => {
                    let newRow = [];
                    newRow.push(col.data[0]['serial_number'])
                    newRow.push(col.data[1])
                    newRow.push(col.data[2])
                    newRow.push(col.data[3])
                    newRow.push(col.data[4]['vehicle_number'])
                    newRow.push(col.data[5]['status'])
                    allRows.push("\n" + newRow)
                })

                return allRows;
            }
            return "\uFEFF" + buildHead() + buildBody();
        },
        selectableRows: "none",
        onFilterReset: () => {
            return dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage))
        },
        customToolbar: () => {
            if (batteryEditAccess === true) {
                return (
                    <Tooltip style={{ flex: 'left' }} title={"Onboarding Battery"}>
                        <IconButton style={{ transform: "translateX(-8em)" }} onClick={() => {
                            setOpenAddBattery(true)
                        }}>
                            <Icon icon="fluent:phone-add-24-regular" height="22" width="22" />
                        </IconButton></Tooltip>

                );
            }
            else {
                null
            }

        }

    };

    const options1 = {
        filter: false,
        filterType: 'dropdown',
        responsive: 'vertical',
        print: false,
        search: true,
        selectableRows: "none",
        customToolbar: () => {
            if (batteryEditAccess === true) {
                return (
                    value === 1 ? <Tooltip style={{ flex: 'left' }} title={"Onboarding Model"}>
                        <IconButton style={{ transform: "translateX(-8em)" }} onClick={() => {
                            setOpenAddModel(true)
                        }}>
                            <Icon icon="fluent:tab-add-24-filled" height="22" width="22" />
                        </IconButton></Tooltip>
                        : <Tooltip style={{ flex: 'left' }} title={"Onboarding Model"}>
                            <IconButton style={{ transform: "translateX(-8em)" }} onClick={() => {
                                setOpenAddBMS(true)
                            }}>
                                <Icon icon="carbon:gui-management" height="22" width="22" />
                            </IconButton></Tooltip>
                );
            }
            else {
                null
            }

        }

    };


    const handleChangeC = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked });
    };
    const handleChangeD = (event) => {
        setState1({ ...state, [event.target.name]: event.target.checked });
    };


    //Add Battery

    function getSteps() {
        return ['Identifiction', 'Association', 'Mobilize'];
    }

    function getStepContent(step) {
        switch (step) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>BMS Model</Typography>
                        <Select
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'bms_model_id')

                            }}
                            value={batteryAddForm.bms_model_id}
                            className={classes.textField}>

                            <MenuItem value="">Select BMS Model</MenuItem>
                            {BMSLMeta.data.length && BMSLMeta.data.map((bms) => {
                                return (
                                    <MenuItem
                                        // onClick={() => {
                                        //    bms[0] !== 0 ? allHV(bms[0]) :null
                                        // }} 
                                        value={bms[3]}>{bms[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Model</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <Select onChange={(e) => {
                            setBatteryAddFormArray(e, 'battery_model_id')
                        }}
                            error={addBatteryErrors && batteryAddForm.battery_model_id === ""}
                            value={batteryAddForm.battery_model_id}
                            className={classes.textField}>

                            <MenuItem value="">Select Battery Model</MenuItem>
                            {BatteryModelLMeta.data.length && BatteryModelLMeta.data.map((model) => {
                                return (
                                    <MenuItem value={model[5]}>{model[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Serial Number</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField error={addBatteryErrors && batteryAddForm.serial_number === ""}
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'serial_number')
                            }}
                            helperText={'Enter valid alphanumeric Serial Number without space'}
                            size="small" id="outlined" value={batteryAddForm.serial_number && batteryAddForm.serial_number.toUpperCase() && batteryAddForm.serial_number.toUpperCase().trim()} placeholder="eg: Serial Number" className={classes.textField} />
                    </Grid>

                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField error={addBatteryErrors && batteryAddForm.bms_unique_id === ""}
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'bms_unique_id')
                            }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={batteryAddForm.bms_unique_id && batteryAddForm.bms_unique_id.trim()} placeholder="eg: Unique Identifier" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>BMS Software Version</Typography>
                        <TextField
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'sw_version')
                            }}
                            size="small" id="outlined"
                            value={batteryAddForm.sw_version && batteryAddForm.sw_version.toUpperCase() && batteryAddForm.sw_version.toUpperCase().trim()}
                            placeholder="eg: BMS Software Version" className={classes.textField} />
                    </Grid></Grid>;
            case 1:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.styleL}>Fleet Name</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography> </div>
                        {enty1 === true ?
                            <Select
                                onChange={(e) => {
                                    setBatteryAddFormArray(e, 'entity_id', 'asset')
                                    dispatch(getOMBulk(e.target.value));
                                }}
                                error={addBatteryErrors && (batteryAddForm.asset && batteryAddForm.asset.entity_id === "")}
                                value={batteryAddForm.asset && batteryAddForm.asset.entity_id}
                                className={classes.textField}
                            >
                                <MenuItem value="">Select your Fleet First </MenuItem>
                                {FleetMeta.data.length && FleetMeta.data.map((fleet) => {
                                    return (
                                        <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>

                                    )
                                }
                                )}
                            </Select> :
                            <TextField
                                size="small" id="outlined" value={uName} className={classes.textField} />}
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Operation Manager</Typography>
                        {batteryAddForm.asset.entity_id === '' ? <Select
                            className={classes.textField}
                        >
                            <MenuItem value="">Select your Fleet</MenuItem>
                        </Select> :
                            <Select
                                onChange={(e) => { setBatteryAddFormArray(e, 'user_id', 'user') }}
                                value={batteryAddForm.user && batteryAddForm.user.user_id}
                                className={classes.textField}
                            >
                                <MenuItem value="">Select your Manager</MenuItem>
                                {OMMeta.length && OMMeta.map((om) => {
                                    return (
                                        <MenuItem value={om[1]}>{om[0]}</MenuItem>

                                    )
                                }
                                )}
                            </Select>}
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Investor</Typography>
                        {IV2Meta.data.length === 0 ?
                            <Select
                                className={classes.textField}
                            >
                                <MenuItem value="">No Data</MenuItem>
                            </Select> :
                            <Select
                                onChange={(e) => { setBatteryAddFormArray(e, 'user_id', 'investors') }}
                                value={batteryAddForm.investors && batteryAddForm.investors.user_id}
                                className={classes.textField}
                            >
                                <MenuItem value="">Select your Investor</MenuItem>
                                {IV2Meta.data.length && IV2Meta.data.map((ivv) => {
                                    return (
                                        <MenuItem value={ivv[1]}>{ivv[0]}</MenuItem>

                                    )
                                }
                                )}
                            </Select>}
                    </Grid>
                </Grid>;
            case 2:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>
                            IMEI Number
                        </Typography>
                        <TextField
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'imei', 'telematics')
                            }}
                            size="small" id="outlined"
                            value={batteryAddForm.telematics && batteryAddForm.telematics.imei && batteryAddForm.telematics.imei.trim()}
                            className={classes.textField}
                            placeholder="eg:  imei"
                        />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>
                            Model Info
                        </Typography>
                        <Select onChange={(e) => {
                            setBatteryAddFormArray(e, 'telematics_data_id', 'telematics')
                        }}
                            // error={addBatteryErrors && batteryAddForm.model_info === ""}
                            value={batteryAddForm.telematics && batteryAddForm.telematics.telematics_data_id}
                            className={classes.textField}>

                            <MenuItem value="">Select Telematics Model</MenuItem>
                            {TeleModelMeta.data.length && TeleModelMeta.data.map((telem) => {
                                return (
                                    <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>SIM Operator</Typography>
                        <Select className={classes.textField}
                            onChange={(e) => { setBatteryAddFormArray(e, 'sim_operator', 'telematics') }}
                            // error={addBatteryErrors && cVAddForm.model_id === ""}
                            value={batteryAddForm.telematics && batteryAddForm.telematics.sim_operator}
                        >
                            <MenuItem value="">Select your Model</MenuItem>
                            <MenuItem value="Airtel">Airtel</MenuItem>
                            <MenuItem value="Jio">Jio</MenuItem>
                            <MenuItem value="VI">VI</MenuItem>
                        </Select>
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Mobile Number</Typography>
                        <TextField type="number"
                            onChange={(e) => {
                                setBatteryAddFormArray(e, 'mobile_number', 'telematics')
                            }}
                            value={batteryAddForm.telematics && batteryAddForm.telematics.mobile_number && batteryAddForm.telematics.mobile_number.trim()}
                            helperText={batteryAddForm.telematics && batteryAddForm.telematics.mobile_number != '' &&
                                !/^[0-9]{10}$/.test(batteryAddForm.telematics && batteryAddForm.telematics.mobile_number) ?
                                'Mobile number must be 10 digits' : null}
                            className={classes.textField}
                            placeholder="eg:  9876678666"
                        />
                    </Grid>
                    <Grid item lg={4.5} />

                </Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep, setActiveStep] = React.useState(0);
    const [completed, setCompleted] = React.useState({});
    const steps = getSteps();

    const totalSteps = () => steps.length;

    const completedSteps = () => Object.keys(completed).length;

    const isLastStep = () => activeStep === totalSteps() - 1;

    const allStepsCompleted = () => completedSteps() === totalSteps();

    const handleNext = () => {
        const newActiveStep = isLastStep() && !allStepsCompleted() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps.findIndex((step, i) => !(i in completed))
            : activeStep + 1;
        setActiveStep(newActiveStep);
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleStep = (step) => () => {
        setActiveStep(step);
    };

    const handleComplete = () => {
        const newCompleted = completed;
        newCompleted[activeStep] = true;
        setCompleted(newCompleted);
        handleNext();
    };

    const handleReset = () => {
        setActiveStep(0);
        setCompleted({});
    };

    //Edit Battery

    function getSteps1() {
        return ['Identifiction', 'Association', 'Mobilize'];
    }

    function getStepContent1(step1) {
        switch (step1) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>BMS Model</Typography>
                        <TextField disabled size="small" id="outlined" value={editBatArray.bms_model_info}
                            // onChange={(e) => { setEditBatteryFormArray(e, 'bms_model_id') }}
                            className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Model</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField disabled size="small" id="outlined" value={editBatArray.battery_model}
                            // onChange={(e) => { setEditBatteryFormArray(e, 'battery_model') }}
                            className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Serial Number</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                            helperText={'Enter valid alphanumeric Serial Number without space'}
                            size="small" id="outlined" value={editBatArray.serial_number && editBatArray.serial_number.toUpperCase() && editBatArray.serial_number.toUpperCase().trim()}
                            onChange={(e) => { setEditBatteryFormArray(e, 'serial_number') }}
                            className={classes.textField} />
                    </Grid>

                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField type="number"
                            // error={addBatteryErrors && editBatArray.bms_unique_id === ""} 
                            size="small" id="outlined" value={editBatArray.bms_unique_id && editBatArray.bms_unique_id.trim()}
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            onChange={(e) => { setEditBatteryFormArray(e, 'bms_unique_id') }} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>BMS Software Version</Typography>
                        <TextField size="small" id="outlined" value={editBatArray.sw_version && editBatArray.sw_version.trim()}
                            // error={addBatteryErrors && editBatArray.sw_version === ""}
                            onChange={(e) => { setEditBatteryFormArray(e, 'sw_version') }} className={classes.textField} />
                    </Grid></Grid>;
            case 1:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.styleL}>Fleet Name</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography> </div>
                        {enty1 === true ? <Select
                            onChange={(e) => {
                                setEditBatteryFormArray(e, 'entity_id', 'asset')
                                dispatch(getOMBulk(e.target.value));
                            }}
                            value={editBatArray.asset && editBatArray.asset.entity_id}
                            className={classes.textField}
                        >
                            {FleetMeta.data.length && FleetMeta.data.map((fleet) => {
                                return (
                                    <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select> :
                            <TextField
                                size="small" id="outlined" value={uName} className={classes.textField} />}
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Operation Manager</Typography>
                        <Select
                            onChange={(e) => { setEditBatteryFormArray(e, 'user_id', 'user') }}
                            value={editBatArray.user && editBatArray.user.user_id}
                            className={classes.textField}
                        >
                            {OMMeta.length && OMMeta.map((om) => {
                                return (
                                    <MenuItem value={om[1]}>{om[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select>

                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Investor</Typography>
                        {IV2Meta.data.length === 0 ?
                            <Select
                                className={classes.textField}
                            >
                                <MenuItem value="">No Data</MenuItem>
                            </Select> : <Select
                                onChange={(e) => { setEditBatteryFormArray(e, 'user_id', 'investors') }}
                                value={editBatArray.investors && editBatArray.investors.user_id}
                                className={classes.textField}
                            >
                                {IV2Meta.data.length && IV2Meta.data.map((ivv) => {
                                    return (
                                        <MenuItem value={ivv[1]}>{ivv[0]}</MenuItem>

                                    )
                                }
                                )}
                            </Select>}
                    </Grid>
                </Grid>;
            case 2:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>
                            IMEI Number
                        </Typography>
                        <TextField
                            onChange={(e) => {
                                setEditBatteryFormArray(e, 'imei', 'telematics')
                            }}
                            size="small" id="outlined"
                            value={editBatArray.telematics && editBatArray.telematics.imei && editBatArray.telematics.imei.trim()}
                            className={classes.textField}
                        />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>
                            Model Info
                        </Typography>
                        <Select onChange={(e) => {
                            setEditBatteryFormArray(e, 'telematics_data_id', 'telematics')
                        }}
                            value={editBatArray.telematics && editBatArray.telematics.telematics_data_id}
                            className={classes.textField}>

                            {TeleModelMeta.data.length && TeleModelMeta.data.map((telem) => {
                                return (
                                    <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                                )
                            }
                            )}
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>SIM Operator</Typography>
                        <Select className={classes.textField}
                            onChange={(e) => { setEditBatteryFormArray(e, 'sim_operator', 'telematics') }}
                            value={editBatArray.telematics && editBatArray.telematics.sim_operator}
                        >
                            <MenuItem value="">Select your Model</MenuItem>
                            <MenuItem value="Airtel">Airtel</MenuItem>
                            <MenuItem value="Jio">Jio</MenuItem>
                            <MenuItem value="VI">VI</MenuItem>

                        </Select>
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Mobile Number</Typography>
                        <TextField
                            type="number"
                            onChange={(e) => {
                                setEditBatteryFormArray(e, 'mobile_number', 'telematics')
                            }}
                            value={editBatArray.telematics && editBatArray.telematics.mobile_number && editBatArray.telematics.mobile_number.trim()}
                            helperText={editBatArray.telematics && editBatArray.telematics.mobile_number != '' &&
                                !/^[0-9]{10}$/.test(editBatArray.telematics && editBatArray.telematics.mobile_number) ?
                                'Mobile number must be 10 digits' : null}
                            className={classes.textField}
                        />
                    </Grid>
                    <Grid item lg={4.5} />

                </Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep1, setActiveStep1] = React.useState(0);
    const [completed1, setCompleted1] = React.useState({});
    const steps1 = getSteps1();

    const totalSteps1 = () => steps1.length;

    const completedSteps1 = () => Object.keys(completed1).length;

    const isLastStep1 = () => activeStep1 === totalSteps1() - 1;

    const allStepsCompleted1 = () => completedSteps1() === totalSteps1();

    const handleNext1 = () => {
        const newActiveStep1 = isLastStep1() && !allStepsCompleted1() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps1.findIndex((step1, i) => !(i in completed1))
            : activeStep1 + 1;
        setActiveStep1(newActiveStep1);
    };

    const handleBack1 = () => {
        setActiveStep1((prevActiveStep1) => prevActiveStep1 - 1);
    };

    const handleStep1 = (step1) => () => {
        setActiveStep1(step1);
    };

    const handleComplete1 = () => {
        const newCompleted1 = completed1;
        newCompleted1[activeStep1] = true;
        setCompleted1(newCompleted1);
        handleNext1();
    };

    const handleReset1 = () => {
        setActiveStep1(0);
        setCompleted1({});
    };
    //Add BMS
    function getSteps2() {
        return ['Identifiction'];
    }

    function getStepContent2(step2) {
        switch (step2) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>BMS Model Info</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setBMSAddFormArray(e, 'model_info')
                            }} error={addBatteryErrors && bmsAddForm.model_info === ""}
                            size="small" id="outlined"
                            value={bmsAddForm.model_info && bmsAddForm.model_info.toUpperCase() && bmsAddForm.model_info.toUpperCase().trim()}
                            placeholder="eg: BMS Model" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Hardware Version</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setBMSAddFormArray(e, 'hw_version')
                            }} error={addBatteryErrors && bmsAddForm.hw_version === ""}
                            size="small" id="outlined"
                            value={bmsAddForm.hw_version && bmsAddForm.hw_version.toUpperCase() && bmsAddForm.hw_version.toUpperCase().trim()}
                            placeholder="eg: Version" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>OEM</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setBMSAddFormArray(e, 'oem')
                            }} error={addBatteryErrors && bmsAddForm.oem === ""}
                            size="small" id="outlined"
                            value={bmsAddForm.oem && bmsAddForm.oem.toUpperCase() && bmsAddForm.oem.toUpperCase().trim()}
                            placeholder="eg: OEM" className={classes.textField} />
                    </Grid></Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep2, setActiveStep2] = React.useState(0);
    const [completed2, setCompleted2] = React.useState({});
    const steps2 = getSteps2();

    const totalSteps2 = () => steps2.length;

    const completedSteps2 = () => Object.keys(completed2).length;

    const isLastStep2 = () => activeStep2 === totalSteps2() - 1;

    const allStepsCompleted2 = () => completedSteps2() === totalSteps2();

    const handleNext2 = () => {
        const newActiveStep2 = isLastStep2() && !allStepsCompleted2() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps2.findIndex((step2, i) => !(i in completed2))
            : activeStep2 + 1;
        setActiveStep2(newActiveStep2);
    };

    const handleBack2 = () => {
        setActiveStep2((prevActiveStep2) => prevActiveStep2 - 1);
    };

    const handleStep2 = (step2) => () => {
        setActiveStep2(step2);
    };

    const handleComplete2 = () => {
        const newCompleted2 = completed2;
        newCompleted2[activeStep2] = true;
        setCompleted2(newCompleted2);
        handleNext2();
    };

    const handleReset2 = () => {
        setActiveStep2(0);
        setCompleted2({});
    };

    //Edit BMS
    function getSteps3() {
        return ['Identifiction'];
    }

    function getStepContent3(step) {
        switch (step) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>BMS Model Info</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setEditBmsFormArray(e, 'model_info')
                            }} error={addBatteryErrors && editBMSArray.model_info === ""}
                            size="small" id="outlined"
                            value={editBMSArray.model_info && editBMSArray.model_info.toUpperCase() && editBMSArray.model_info.toUpperCase().trim()}
                            placeholder="eg: BMS Model" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Hardware Version</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setEditBmsFormArray(e, 'hw_version')
                            }} error={addBatteryErrors && editBMSArray.hw_version === ""}
                            size="small" id="outlined"
                            value={editBMSArray.hw_version && editBMSArray.hw_version.toUpperCase() && editBMSArray.hw_version.toUpperCase().trim()}
                            placeholder="eg: Version" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>OEM</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '20px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setEditBmsFormArray(e, 'oem')
                            }} error={addBatteryErrors && editBMSArray.oem === ""}
                            size="small" id="outlined"
                            value={editBMSArray.oem && editBMSArray.oem.toUpperCase() && editBMSArray.oem.toUpperCase().trim()}
                            placeholder="eg: OEM" className={classes.textField} />
                    </Grid></Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep3, setActiveStep3] = React.useState(0);
    const [completed3, setCompleted3] = React.useState({});
    const steps3 = getSteps3();

    const totalSteps3 = () => steps3.length;

    const completedSteps3 = () => Object.keys(completed3).length;

    const isLastStep3 = () => activeStep3 === totalSteps3() - 1;

    const allStepsCompleted3 = () => completedSteps3() === totalSteps3();

    const handleNext3 = () => {
        const newActiveStep3 = isLastStep3() && !allStepsCompleted3() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps3.findIndex((step3, i) => !(i in completed3))
            : activeStep3 + 1;
        setActiveStep3(newActiveStep3);
    };

    const handleBack3 = () => {
        setActiveStep3((prevActiveStep3) => prevActiveStep3 - 1);
    };

    const handleStep3 = (step3) => () => {
        setActiveStep3(step3);
    };

    const handleComplete3 = () => {
        const newCompleted3 = completed3;
        newCompleted3[activeStep3] = true;
        setCompleted3(newCompleted3);
        handleNext3();
    };

    const handleReset3 = () => {
        setActiveStep3(0);
        setCompleted3({});
    };

    //Add battery Model

    function getSteps4() {
        return ['Identifiction', 'Power', 'Cells'];
    }

    function getStepContent4(step4) {
        switch (step4) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Model</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setModelAddFormArray(e, 'model_info')
                            }} error={addBatteryErrors && modelAddForm.model_info === ""}
                            size="small" id="outlined" value={modelAddForm.model_info} placeholder="eg: Battery Model" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Battery Type</Typography>
                        <Select
                            // onChange={(e) => { setEditBatteryFormArray(e, 'user_id', 'investors') }}
                            // value={editBatArray.investors && editBatArray.investors.user_id}
                            className={classes.textField}
                        >
                            <MenuItem value="Storage Battery">Storage Battery</MenuItem>
                            <MenuItem value="Mobility Battery">Mobility Battery</MenuItem>
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Manufacturer </Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'cell_maufacturer')
                        }}
                            error={addBatteryErrors && modelAddForm.cell_maufacturer === ""}

                            size="small" id="outlined" value={modelAddForm.cell_maufacturer} placeholder="eg: Manufacturer " className={classes.textField} />
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>OEM </Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'oem')
                        }}
                            size="small" id="outlined" value={modelAddForm.oem} placeholder="eg: OEM " className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Length (mm)</Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'length')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.length} placeholder="eg: Battery Length (mm)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Width (mm)</Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'width')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.width} placeholder="eg: Battery Width (mm)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Height (mm)</Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'height')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.height} placeholder="eg: Battery Height (mm)" className={classes.textField} />
                    </Grid>
                </Grid>;
            case 1:
                return <Grid container spacing={2}>
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Nominal Voltage (V)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'nominal_voltage')
                        }}
                            error={addBatteryErrors && modelAddForm.nominal_voltage === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.nominal_voltage} placeholder="eg: Nominal Voltage (V)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Capacity (Ah)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'capacity_mah')
                        }}
                            error={addBatteryErrors && modelAddForm.capacity_mah === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.capacity_mah} placeholder="eg: Capacity (Ah)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={3} />
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Power (Wh)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'power')
                        }}
                            error={addBatteryErrors && modelAddForm.power === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.power} placeholder="eg: Power (Wh)" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Thermistor </Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                            error={addBatteryErrors && modelAddForm.thermistor === ""}

                            onChange={(e) => {
                                setModelAddFormArray(e, 'thermistor')
                            }}
                            size="small" id="outlined"
                            value={modelAddForm.thermistor}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            placeholder="eg: 12 " className={classes.textField} />
                    </Grid>
                </Grid>;
            case 2:
                return <Grid container spacing={2}>
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'number_of_cells_series')
                        }}
                            error={addBatteryErrors && modelAddForm.number_of_cells_series === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.number_of_cells_series} placeholder="eg: Number of Cells Series" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'number_of_cells_parallel')
                        }}
                            error={addBatteryErrors && modelAddForm.number_of_cells_parallel === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={modelAddForm.number_of_cells_parallel} placeholder="eg: Number of Cells Parallel" className={classes.textField} />
                    </Grid>
                    <Grid item lg={3} />
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'cell_chemisty')
                        }}
                            error={addBatteryErrors && modelAddForm.cell_chemisty === ""}

                            size="small" id="outlined" value={modelAddForm.cell_chemisty} placeholder="eg: Cell Chemistry" className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Cell Type</Typography>
                        <TextField onChange={(e) => {
                            setModelAddFormArray(e, 'cell_type')
                        }}
                            size="small" id="outlined" value={modelAddForm.cell_type} placeholder="eg: Cell Type" className={classes.textField} />
                    </Grid>
                    <Grid item lg={4.5} />

                </Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep4, setActiveStep4] = React.useState(0);
    const [completed4, setCompleted4] = React.useState({});
    const steps4 = getSteps4();

    const totalSteps4 = () => steps4.length;

    const completedSteps4 = () => Object.keys(completed4).length;

    const isLastStep4 = () => activeStep4 === totalSteps4() - 1;

    const allStepsCompleted4 = () => completedSteps4() === totalSteps4();

    const handleNext4 = () => {
        const newActiveStep4 = isLastStep4() && !allStepsCompleted4() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps4.findIndex((step4, i) => !(i in completed4))
            : activeStep4 + 1;
        setActiveStep4(newActiveStep4);
    };

    const handleBack4 = () => {
        setActiveStep4((prevActiveStep4) => prevActiveStep4 - 1);
    };

    const handleStep4 = (step4) => () => {
        setActiveStep4(step4);
    };

    const handleComplete4 = () => {
        const newCompleted4 = completed4;
        newCompleted4[activeStep4] = true;
        setCompleted4(newCompleted4);
        handleNext4();
    };

    const handleReset4 = () => {
        setActiveStep4(0);
        setCompleted4({});
    };

    //Edit Battery Model

    function getSteps5() {
        return ['Identifiction', 'Power', 'Cells'];
    }

    function getStepContent5(step5) {
        switch (step5) {
            case 0:
                return <Grid container spacing={2}>
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Battery Model</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setModelEditFormArray(e, 'model_info')
                            }}
                            error={addBatteryErrors && editArray.model_info === ""}

                            size="small" id="outlined"
                            value={editArray.model_info} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.styleL}>Battery Type</Typography>
                        <Select
                            // onChange={(e) => { setEditBatteryFormArray(e, 'user_id', 'investors') }}
                            // value={editBatArray.investors && editBatArray.investors.user_id}
                            className={classes.textField}
                        >
                            <MenuItem value="Storage Battery">Storage Battery</MenuItem>
                            <MenuItem value="Mobility Battery">Mobility Battery</MenuItem>
                        </Select>
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Manufacturer </Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'cell_maufacturer')
                        }}
                            error={addBatteryErrors && editArray.cell_maufacturer === ""}

                            size="small" id="outlined" value={editArray.cell_maufacturer} className={classes.textField} />
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>OEM </Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'oem')
                        }}
                            size="small" id="outlined" value={editArray.oem} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Length (mm) </Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'length')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.length} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Width (mm) </Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'width')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.width} className={classes.textField} />
                    </Grid>
                    <Grid item lg={1} />
                    <Grid item lg={1} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Battery Height (mm) </Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'height')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.height} className={classes.textField} />
                    </Grid>
                </Grid>;
            case 1:
                return <Grid container spacing={2}>
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Nominal Voltage (V)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'nominal_voltage')
                        }}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            error={addBatteryErrors && editArray.nominal_voltage === ""}
                            size="small" id="outlined" value={editArray.nominal_voltage} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Capacity (Ah)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'capacity_mah')
                        }}
                            error={addBatteryErrors && editArray.capacity_mah === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.capacity_mah} className={classes.textField} />
                    </Grid>
                    <Grid item lg={3} />
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Power (Wh)</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'power')
                        }}
                            error={addBatteryErrors && editArray.power === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.power} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Thermistor </Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                            onChange={(e) => {
                                setModelEditFormArray(e, 'thermistor')
                            }}
                            error={addBatteryErrors && editArray.thermistor === ""}

                            size="small" id="outlined"
                            value={editArray.thermistor}
                            className={classes.textField} />
                    </Grid>
                </Grid>;
            case 2:
                return <Grid container spacing={2}>
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'number_of_cells_series')
                        }}
                            error={addBatteryErrors && editArray.number_of_cells_series === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.number_of_cells_series} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'number_of_cells_parallel')
                        }}
                            error={addBatteryErrors && editArray.number_of_cells_parallel === ""}
                            type="number"
                            onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                            size="small" id="outlined" value={editArray.number_of_cells_parallel} className={classes.textField} />
                    </Grid>
                    <Grid item lg={3} />
                    <Grid item lg={2} />
                    <Grid item lg={3} xs={12}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'cell_chemisty')
                        }}
                            error={addBatteryErrors && editArray.cell_chemisty === ""}

                            size="small" id="outlined" value={editArray.cell_chemisty} className={classes.textField} />
                    </Grid>
                    <Grid item lg={0.5} />
                    <Grid item lg={3} xs={12}>
                        <Typography className={classes.tabHelp}>Cell Type</Typography>
                        <TextField onChange={(e) => {
                            setModelEditFormArray(e, 'cell_type')
                        }}
                            size="small" id="outlined" value={editArray.cell_type} className={classes.textField} />
                    </Grid>
                    <Grid item lg={4.5} />

                </Grid>;
            default:
                return 'Unknown step';
        }
    }

    const [activeStep5, setActiveStep5] = React.useState(0);
    const [completed5, setCompleted5] = React.useState({});
    const steps5 = getSteps5();

    const totalSteps5 = () => steps5.length;

    const completedSteps5 = () => Object.keys(completed5).length;

    const isLastStep5 = () => activeStep5 === totalSteps5() - 1;

    const allStepsCompleted5 = () => completedSteps5() === totalSteps5();

    const handleNext5 = () => {
        const newActiveStep5 = isLastStep5() && !allStepsCompleted5() // It's the last step, but not all steps have been completed,
            // find the first step that has been completed
            ? steps5.findIndex((step5, i) => !(i in completed5))
            : activeStep5 + 1;
        setActiveStep5(newActiveStep5);
    };

    const handleBack5 = () => {
        setActiveStep5((prevActiveStep5) => prevActiveStep5 - 1);
    };

    const handleStep5 = (step5) => () => {
        setActiveStep5(step5);
    };

    const handleComplete5 = () => {
        const newCompleted5 = completed5;
        newCompleted5[activeStep5] = true;
        setCompleted5(newCompleted5);
        handleNext5();
    };

    const handleReset5 = () => {
        setActiveStep5(0);
        setCompleted5({});
    };

    return (
        <div
            // onMouseMove={() => setFrame(!frame)}
            className={classes.table}>
            <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />
            <Snackbar open={open} autoHideDuration={3000} onClose={handleClose}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                style={{ marginTop: '215px' }}
            >
                <Alert onClose={handleClose} severity="warning">
                    This battery assigned to {ddd}
                </Alert>
            </Snackbar>

            {screen !== true ? <Typography className={classes.pageTitle} component="h4" variant="h4">Battery</Typography> :
                <Typography className={classes.pageTitle} component="h4" variant="h4">Battery Profile</Typography>}

            {screen !== true ?
                <Tabs
                    className={classes.tabsSection}
                    value={value}
                    onChange={handleChange}
                    variant="fullWidth"
                    indicatorColor="primary"
                    aria-label="icon tabs example"
                >
                    <Tab label="Battery" onClick={() => {
                        setScreen(false)
                    }} icon={<Icon icon="ic:baseline-battery-charging-full" width="22" height="22" />} aria-label="favorite" />
                    <Tab label="Battery Model" onClick={() => {
                        setScreen(false)
                    }} icon={<Icon icon="material-symbols:tab-outline" width="22" height="22" />} aria-label="phone" />
                    <Tab label="BMS Model" onClick={() => {
                        setScreen(false)
                    }} icon={<Icon icon="carbon:gui-management" height="22" width="22" />} aria-label="phone" />

                </Tabs> : null}

            <Paper square className={classes.root}>
                {csvDownload === 0 ? <LinearProgress /> : null}
            </Paper>
            {(screen !== true
                // && (
                // MyBatteryMetaPresent &&
                // BatteryModelMetaPresent)
            ) ?
                (
                    value === 0 ?
                        <>
                            {openAddBattery === true ?
                                <div style={{
                                    width: '100%', overflow: 'hidden'
                                }}><br />
                                    <h3>Onboarding Battery</h3><br />
                                    <Stepper nonLinear activeStep={activeStep}>
                                        {steps.map((label, index) => (
                                            <Step key={label}>
                                                <StepButton onClick={handleStep(index)} completed={completed[index]}>
                                                    {label}
                                                </StepButton>
                                            </Step>
                                        ))}
                                    </Stepper>
                                    <div>
                                        {allStepsCompleted() ? (
                                            <div>
                                                <Typography style={{
                                                    marginTop: theme.spacing(1),
                                                    marginBottom: theme.spacing(1)
                                                }}>
                                                    All steps completed - you&apos;re finished
                                                </Typography>
                                                <Button onClick={handleReset}>Reset</Button>
                                            </div>
                                        ) : (
                                            <div><br />
                                                <Typography style={{
                                                    marginTop: theme.spacing(1),
                                                    marginBottom: theme.spacing(1)
                                                }}>{getStepContent(activeStep)}</Typography>
                                                <br /><br /><br /><br />
                                                <div>
                                                    <Button
                                                        onClick={() => {
                                                            setOpenAddBattery(false);
                                                            handleReset()
                                                            setBatteryAddForm({})
                                                        }}
                                                        style={{
                                                            marginRight: theme.spacing(1)
                                                        }}>
                                                        Cancel
                                                    </Button>
                                                    <Button disabled={activeStep === 0} onClick={handleBack} style={{
                                                        marginRight: theme.spacing(1)
                                                    }}>
                                                        Back
                                                    </Button>
                                                    {batteryAddForm.battery_model_id &&
                                                        batteryAddForm.serial_number && batteryAddForm.bms_unique_id ? <Button
                                                            variant="contained"
                                                            color="primary"
                                                            onClick={handleNext}
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }} disabled={activeStep === totalSteps() - 1}
                                                        >
                                                        Next
                                                    </Button> : <Button disabled={activeStep === totalSteps() - 1}
                                                        variant="contained"
                                                        style={{
                                                            marginRight: theme.spacing(1)
                                                        }}
                                                    >
                                                        Next
                                                    </Button>}
                                                    {activeStep === totalSteps() - 1 ?
                                                        <Button variant="contained" color="primary"
                                                            onClick={() => {
                                                                submitBattery(true);
                                                            }}
                                                        >Finish
                                                        </Button> : <Button disabled variant="contained">Finish
                                                        </Button>}


                                                    {/* ))
                                    } */}
                                                </div>
                                            </div>
                                        )}
                                    </div><br /><br /><br />
                                </div> :
                                openEditBattery === true ?
                                    <div style={{
                                        width: '100%', overflow: 'hidden'
                                    }}><br />
                                        <h3>Battery Profile</h3><br />
                                        <Stepper nonLinear activeStep={activeStep1}>
                                            {steps1.map((label1, index) => (
                                                <Step key={label1}>
                                                    <StepButton onClick={handleStep1(index)} completed={completed1[index]}>
                                                        {label1}
                                                    </StepButton>
                                                </Step>
                                            ))}
                                        </Stepper>
                                        <div>
                                            {allStepsCompleted1() ? (
                                                <div>
                                                    <Typography style={{
                                                        marginTop: theme.spacing(1),
                                                        marginBottom: theme.spacing(1)
                                                    }}>
                                                        All steps completed - you&apos;re finished
                                                    </Typography>
                                                    <Button onClick={handleReset1}>Reset</Button>
                                                </div>
                                            ) : (
                                                <div><br />
                                                    <Typography style={{
                                                        marginTop: theme.spacing(1),
                                                        marginBottom: theme.spacing(1)
                                                    }}>{getStepContent1(activeStep1)}</Typography>
                                                    <br /><br /><br /><br />
                                                    <div>
                                                        <Button
                                                            onClick={() => {
                                                                setOpenEditBattery(false);
                                                                handleReset1()
                                                            }}
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }}>
                                                            Cancel
                                                        </Button>
                                                        <Button disabled={activeStep1 === 0} onClick={handleBack1} style={{
                                                            marginRight: theme.spacing(1)
                                                        }}>
                                                            Back
                                                        </Button>
                                                        {/* {editBatArray.serial_number ?  */}
                                                        <Button
                                                            variant="contained"
                                                            color="primary"
                                                            onClick={handleNext1}
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }}
                                                            disabled={activeStep1 === totalSteps1() - 1}
                                                        >
                                                            Next
                                                        </Button>
                                                        {/* : <Button disabled
                                                            variant="contained"
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }}
                                                        >
                                                            Next
                                                        </Button>
                                                        } */}
                                                        {activeStep1 === totalSteps1() - 1 ?
                                                            <Button variant="contained" color="primary"
                                                                onClick={() => {
                                                                    submitEditBattery(true);
                                                                }}
                                                            >Finish
                                                            </Button> : <Button disabled variant="contained">Finish
                                                            </Button>}


                                                        {/* ))
                                            } */}
                                                    </div>
                                                </div>
                                            )}
                                        </div><br /><br /><br />
                                    </div>
                                    : <><MUIDataTable
                                        checkboxSelection={false}
                                        title="Battery"
                                        // data={BBMeta.data}
                                        data={MyBatteryMeta.data}
                                        // data={dataOn === true ? BBMeta.data : MyBatteryMeta.data}
                                        columns={batteryEditAccess === true ? columnsBattery : columnsBattery1}
                                        options={options}
                                        selectableRowsHideCheckboxes
                                    /><br /><Pagination count={MyBatteryPageCount} page={MyBatteryPage} onChange={changePageBat} /></>}
                        </>
                        : value === 1 ? <>
                            {openAddModel === true ?
                                <div style={{
                                    width: '100%', overflow: 'hidden'
                                }}><br />
                                    <h3>Onboarding Battery Model</h3><br />
                                    <Stepper nonLinear activeStep={activeStep4}>
                                        {steps4.map((label4, index) => (
                                            <Step key={label4}>
                                                <StepButton onClick={handleStep4(index)} completed={completed4[index]}>
                                                    {label4}
                                                </StepButton>
                                            </Step>
                                        ))}
                                    </Stepper>
                                    <div>
                                        {allStepsCompleted4() ? (
                                            <div>
                                                <Typography style={{
                                                    marginTop: theme.spacing(1),
                                                    marginBottom: theme.spacing(1)
                                                }}>
                                                    All steps completed - you&apos;re finished
                                                </Typography>
                                                <Button onClick={handleReset4}>Reset</Button>
                                            </div>
                                        ) : (
                                            <div><br />
                                                <Typography style={{
                                                    marginTop: theme.spacing(1),
                                                    marginBottom: theme.spacing(1)
                                                }}>{getStepContent4(activeStep4)}</Typography>
                                                <br /><br /><br /><br />
                                                <div>
                                                    <Button
                                                        onClick={() => {
                                                            setOpenAddModel(false);
                                                            handleReset4()
                                                            setModelAddForm({})
                                                        }}
                                                        style={{
                                                            marginRight: theme.spacing(1)
                                                        }}>
                                                        Cancel
                                                    </Button>
                                                    <Button disabled={activeStep4 === 0} onClick={handleBack4} style={{
                                                        marginRight: theme.spacing(1)
                                                    }}>
                                                        Back
                                                    </Button>
                                                    {modelAddForm.model_info != '' && modelAddForm.cell_maufacturer != '' ?
                                                        <Button disabled={activeStep4 === 1 && modelAddForm.thermistor === '' || activeStep4 === totalSteps4() - 1}
                                                            variant="contained"
                                                            color="primary"
                                                            onClick={handleNext4}
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }}
                                                        >
                                                            Next
                                                        </Button> :
                                                        activeStep4 === 1 && modelAddForm.nominal_voltage != '' && modelAddForm.capacity_mah != '' &&
                                                            modelAddForm.power != '' && modelAddForm.thermistor != '' ?
                                                            <Button variant="contained"
                                                                color="primary"
                                                                onClick={handleNext4}
                                                                style={{
                                                                    marginRight: theme.spacing(1)
                                                                }}
                                                            >
                                                                Next
                                                            </Button>
                                                            : null}
                                                    {modelAddForm.number_of_cells_series != '' && modelAddForm.number_of_cells_parallel != '' &&
                                                        modelAddForm.cell_chemisty != '' ?
                                                        <Button variant="contained" color="primary"
                                                            onClick={() => {
                                                                submitModel(true);
                                                            }}
                                                        >Finish
                                                        </Button> : <Button disabled variant="contained">Finish
                                                        </Button>}

                                                </div>
                                            </div>
                                        )}
                                    </div><br /><br /><br />
                                </div>
                                : openEditModel === true ?
                                    <div style={{
                                        width: '100%', overflow: 'hidden'
                                    }}><br />
                                        <h3>Battery Model Profile</h3><br />
                                        <Stepper nonLinear activeStep={activeStep5}>
                                            {steps5.map((label5, index) => (
                                                <Step key={label5}>
                                                    <StepButton onClick={handleStep5(index)} completed={completed5[index]}>
                                                        {label5}
                                                    </StepButton>
                                                </Step>
                                            ))}
                                        </Stepper>
                                        <div>
                                            {allStepsCompleted5() ? (
                                                <div>
                                                    <Typography style={{
                                                        marginTop: theme.spacing(1),
                                                        marginBottom: theme.spacing(1)
                                                    }}>
                                                        All steps completed - you&apos;re finished
                                                    </Typography>
                                                    <Button onClick={handleReset5}>Reset</Button>
                                                </div>
                                            ) : (
                                                <div><br />
                                                    <Typography style={{
                                                        marginTop: theme.spacing(1),
                                                        marginBottom: theme.spacing(1)
                                                    }}>{getStepContent5(activeStep5)}</Typography>
                                                    <br /><br /><br /><br />
                                                    <div>
                                                        <Button
                                                            onClick={() => {
                                                                setOpenEditModel(false);
                                                                handleReset5()
                                                            }}
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }}>
                                                            Cancel
                                                        </Button>
                                                        <Button disabled={activeStep5 === 0} onClick={handleBack5} style={{
                                                            marginRight: theme.spacing(1)
                                                        }}>
                                                            Back
                                                        </Button>
                                                        {editArray.model_info != '' && editArray.cell_maufacturer != '' ?
                                                            <Button disabled={activeStep5 === 1 && editArray.thermistor === '' || activeStep5 === totalSteps5() - 1}
                                                                variant="contained"
                                                                color="primary"
                                                                onClick={handleNext5}
                                                                style={{
                                                                    marginRight: theme.spacing(1)
                                                                }}
                                                            >
                                                                Next
                                                            </Button> :
                                                            activeStep5 === 1 && editArray.nominal_voltage != '' && editArray.capacity_mah != '' &&
                                                                editArray.power != '' && editArray.thermistor != '' ?
                                                                <Button variant="contained"
                                                                    color="primary"
                                                                    onClick={handleNext5}
                                                                    style={{
                                                                        marginRight: theme.spacing(1)
                                                                    }}
                                                                >
                                                                    Next
                                                                </Button>
                                                                : null}
                                                        {editArray.number_of_cells_series != '' && editArray.number_of_cells_parallel != '' &&
                                                            editArray.cell_chemisty != '' ?
                                                            <Button variant="contained" color="primary"
                                                                onClick={() => {
                                                                    submitModelEdit(true);
                                                                }}
                                                            >Finish
                                                            </Button> : <Button disabled variant="contained">Finish
                                                            </Button>}

                                                    </div>
                                                </div>
                                            )}
                                        </div><br /><br /><br />
                                    </div>
                                    : <><MUIDataTable
                                        checkboxSelection={false}
                                        title="Battery Model"
                                        // data={dataModel}
                                        data={BatteryModelMeta.data}
                                        columns={batteryEditAccess === true ? columsModel : columsModel1}
                                        options={options1}

                                    /><br />
                                        <Pagination count={MyBatteryPageMCount} page={MyBatteryMPage} onChange={changePageBatModel} /></>}
                        </>
                            : <>
                                {openAddBMS === true ? <div style={{
                                    width: '100%', overflow: 'hidden'
                                }}><br />
                                    <h3>Onboarding BMS Model</h3><br />
                                    <Stepper nonLinear activeStep={activeStep2}>
                                        {steps2.map((label2, index) => (
                                            <Step key={label2}>
                                                <StepButton onClick={handleStep2(index)} completed={completed2[index]}>
                                                    {label2}
                                                </StepButton>
                                            </Step>
                                        ))}
                                    </Stepper>
                                    <div>
                                        {allStepsCompleted2() ? (
                                            <div>
                                                <Typography style={{
                                                    marginTop: theme.spacing(1),
                                                    marginBottom: theme.spacing(1)
                                                }}>
                                                    All steps completed - you&apos;re finished
                                                </Typography>
                                                <Button onClick={handleReset2}>Reset</Button>
                                            </div>
                                        ) : (
                                            <div><br />
                                                <Typography style={{
                                                    marginTop: theme.spacing(1),
                                                    marginBottom: theme.spacing(1)
                                                }}>{getStepContent2(activeStep2)}</Typography>
                                                <br /><br /><br /><br />
                                                <div>
                                                    <Button
                                                        onClick={() => {
                                                            setOpenAddBMS(false);
                                                            handleReset2()
                                                            setBmsAddForm({})
                                                        }}
                                                        style={{
                                                            marginRight: theme.spacing(1)
                                                        }}>
                                                        Cancel
                                                    </Button>
                                                    {/* <Button disabled={activeStep2 === 0} onClick={handleBack2} style={{
                                                        marginRight: theme.spacing(1)
                                                    }}>
                                                        Back
                                                    </Button> */}
                                                    {/* {bmsAddForm.model_info && bmsAddForm.hw_version &&
                                                        bmsAddForm.oem ? <Button
                                                            variant="contained"
                                                            color="primary"
                                                            onClick={handleNext2}
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }}
                                                        >
                                                        Next
                                                    </Button> : <Button disabled
                                                        variant="contained"
                                                        style={{
                                                            marginRight: theme.spacing(1)
                                                        }}
                                                    >
                                                        Next
                                                    </Button>
                                                    } */}
                                                    {bmsAddForm.model_info && bmsAddForm.hw_version &&
                                                        bmsAddForm.oem ?
                                                        <Button variant="contained" color="primary"
                                                            onClick={() => {
                                                                submitBMS(true);
                                                            }}
                                                        >Finish
                                                        </Button> : <Button disabled variant="contained">Finish
                                                        </Button>}


                                                    {/* ))
    } */}
                                                </div>
                                            </div>
                                        )}
                                    </div><br /><br /><br />
                                </div> :
                                    openEditBMS === true ? <div style={{
                                        width: '100%', overflow: 'hidden'
                                    }}><br />
                                        <h3>BMS Model Profile</h3><br />
                                        <Stepper nonLinear activeStep={activeStep3}>
                                            {steps3.map((label3, index) => (
                                                <Step key={label3}>
                                                    <StepButton onClick={handleStep3(index)} completed={completed3[index]}>
                                                        {label3}
                                                    </StepButton>
                                                </Step>
                                            ))}
                                        </Stepper>
                                        <div>
                                            {allStepsCompleted3() ? (
                                                <div>
                                                    <Typography style={{
                                                        marginTop: theme.spacing(1),
                                                        marginBottom: theme.spacing(1)
                                                    }}>
                                                        All steps completed - you&apos;re finished
                                                    </Typography>
                                                    <Button onClick={handleReset3}>Reset</Button>
                                                </div>
                                            ) : (
                                                <div><br />
                                                    <Typography style={{
                                                        marginTop: theme.spacing(1),
                                                        marginBottom: theme.spacing(1)
                                                    }}>{getStepContent3(activeStep3)}</Typography>
                                                    <br /><br /><br /><br />
                                                    <div>
                                                        <Button
                                                            onClick={() => {
                                                                setOpenEditBMS(false);
                                                                handleReset3()
                                                            }}
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }}>
                                                            Cancel
                                                        </Button>
                                                        {/* <Button disabled={activeStep3 === 0} onClick={handleBack3} style={{
                                                        marginRight: theme.spacing(1)
                                                    }}>
                                                        Back
                                                    </Button> */}
                                                        {/* {editBMSArray.model_info && editBMSArray.hw_version &&
                                                        editBMSArray.oem ? <Button
                                                            variant="contained"
                                                            color="primary"
                                                            onClick={handleNext3}
                                                            style={{
                                                                marginRight: theme.spacing(1)
                                                            }}
                                                        >
                                                        Next
                                                    </Button> : <Button disabled
                                                        variant="contained"
                                                        style={{
                                                            marginRight: theme.spacing(1)
                                                        }}
                                                    >
                                                        Next
                                                    </Button>
                                                    } */}
                                                        {editBMSArray.model_info && editBMSArray.hw_version &&
                                                            editBMSArray.oem ?
                                                            <Button variant="contained" color="primary"
                                                                onClick={() => {
                                                                    submitEditBMS(true);
                                                                }}
                                                            >Finish
                                                            </Button> : <Button disabled variant="contained">Finish
                                                            </Button>}


                                                        {/* ))
    } */}
                                                    </div>
                                                </div>
                                            )}
                                        </div><br /><br /><br />
                                    </div>
                                        : <><MUIDataTable
                                            checkboxSelection={false}
                                            title="BMS Model"
                                            // data={dataModel}
                                            data={BMSMeta.data}
                                            columns={batteryEditAccess === true ? columsBMS : columsBMS1}
                                            options={options1}

                                        /><br />
                                            <Pagination count={MyBatteryPageBMCount} page={MyBatteryBMPage} onChange={changePageBMS} /></>}
                            </>


                )
                :
                (
                    //     //     MyBatteryMetaPresent &&
                    BatteryProMeta.data && BatteryProMetaPresent) ?
                    (
                        <>

                            <div className={classes.BNcover}><div className={classes.BNopt}>
                                {/* <a
                                 ref={input}
                                 href={csvUrl}
                                 download="filename.csv"
                               >link</a> */}
                                {csvDownload === 0 ?
                                    <IconButton className={classes.BNbutton} >
                                        <Icon icon="line-md:downloading-loop" color="white" width="30" height="30" />
                                    </IconButton> :
                                    csvDownload === 1 ?
                                        <IconButton className={classes.BNbutton}

                                            onClick={() => {
                                                downloadCsv()
                                                setCsvDownload(0)
                                            }} >
                                            <Icon icon="fa:cloud-download" color="white" width="30" height="30" />
                                        </IconButton>


                                        :

                                        null
                                }

                                <IconButton onClick={() => {
                                    setValue(0)
                                    setScreen(false)
                                }} className={classes.BNbutton} >
                                    <Icon icon="bi:arrow-left-circle-fill" width="26" height="26" />
                                </IconButton>
                            </div>
                                <div className={classes.BNcontent}>
                                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                                        <Avatar className={classes.BNavatar}>
                                            <Icon icon="mdi:car-battery" width="40" height="40" />
                                        </Avatar></div>
                                    <Typography className={classes.BNname} gutterBottom>
                                        {validateKeyData(serial)}
                                    </Typography>
                                    <Typography className={classes.BNname} gutterBottom>
                                        {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_model"])}
                                    </Typography>
                                    <Typography className={classes.BNname} gutterBottom>
                                        {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["last_created_at"])}
                                    </Typography>
                                </div></div>

                            <AppBar position="static" className={classes.BNprofileTab}>
                                <Tabs
                                    value={value}
                                    onChange={handleChangeT}
                                    variant="fullWidth"
                                    indicatorColor="primary"
                                    textColor="primary"
                                    centered

                                >
                                    <Tab icon={<Icon icon="bxs:battery-charging" width="30" height="30" />} label="About" />
                                    <Tab icon={<Icon icon="ant-design:line-chart-outlined" width="30" height="30" />} label="Analytics" />
                                    <Tab icon={<PhotoLibrary />} label="Parameters" />
                                </Tabs>
                            </AppBar>
                            {BatteryProMeta.data && value === 0 &&
                                <TabContainer><br />
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} lg={6}>
                                            <Paper>
                                                <ListItem>
                                                    <ListItemAvatar>
                                                        <Avatar className={classes.BNavatar1}>
                                                            <Icon icon="mdi:car-battery" color="#82e219" width="26" height="26" />
                                                        </Avatar>
                                                    </ListItemAvatar>

                                                    <ListItemText primary={
                                                        <Typography className={classes.BNaboutTxt}>About</Typography>
                                                    }
                                                        secondary={
                                                            <React.Fragment>
                                                                <Typography className={classes.BNaboutTxt1} >
                                                                    <b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
                                                                        {validateKeyData(serial)}</b> of {BatteryProMeta.data && validateKeyData(BatteryProMeta.data && BatteryProMeta.data[0]["battery_model"])}  <br /> OnBoarded on {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["created_at"])}&nbsp;
                                                                    by&nbsp;<b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
                                                                        {BatteryProMeta.data && validateKeyData(BatteryProMeta.data && BatteryProMeta.data[0]["fleet_name"])}  </b></Typography>
                                                            </React.Fragment>

                                                        }
                                                    />
                                                </ListItem><Divider className={classes.BNdivider} />
                                                <Grid container spacing={1} className={classes.BNgrid}>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="ion:hardware-chip-sharp" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>HW Version</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            imei={imei}
                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["hardware_version"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="eos-icons:software-outlined" color="82e219" width="30" height="30" />                                    </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>SW Version</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["software_version"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="emojione-monotone:high-voltage" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Battery Nominal Voltage</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["nominal_voltage"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="mdi:chemical-weapon" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Battery Chemistry</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["cell_chemisty"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="carbon:cost-total" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Battery pack Capacity</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["capacity_mah"])}</Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="uil:cell" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Cells in Series</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>
                                                                            {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["number_of_cells_series"])}
                                                                        </Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNavatar1}>
                                                                    <Icon icon="uil:cell" color="82e219" width="30" height="30" />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Thermistor</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={classes.secondaryTextG}>
                                                                            {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["thermistor"])}

                                                                        </Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                </Grid>
                                            </Paper>

                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper style={{ height: '388px' }}>
                                                <div style={{ display: 'flex', marginLeft: 10 }}>
                                                    <Typography className={classes.BNprimaryText}>Battery Current</Typography>
                                                    <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_current"])}</Typography> </div>

                                                <div style={{ display: 'flex', margin: 10 }}>
                                                    <Typography className={classes.BNprimaryText}>Battery Voltage</Typography>
                                                    <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_voltage"])}</Typography>
                                                </div>

                                                <div style={{ display: 'flex', margin: 10 }}>
                                                    <Typography className={classes.BNprimaryText}>Battery State</Typography>
                                                    <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["current_state"])}</Typography>
                                                </div>

                                                <br />
                                                <Paper
                                                    className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNstyledPaper :
                                                        BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNstyledPaper2 : classes.BNstyledPaper3}
                                                    elevation={4}>
                                                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                        <Typography className={classes.BNstateText}>State Of Health
                                                        </Typography>
                                                        <Chip
                                                            avatar={(
                                                                <Avatar className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNchip :
                                                                    BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNchip2 : classes.BNchip3} >
                                                                    <Icon icon="ant-design:check-circle-outlined" color="white" width="30" height="30" />
                                                                </Avatar>
                                                            )}
                                                            label={validateKeyData(BatteryProMeta.data[0]["soh"]) + "% Progress"}
                                                        />
                                                    </div>
                                                    <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soh"])} />
                                                </Paper><br /><br />

                                                <Paper
                                                    className={classes.BNstyledPaper}
                                                    elevation={4}>
                                                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                        <Typography className={classes.BNstateText}>State Of Charge
                                                        </Typography>
                                                        <Chip
                                                            avatar={(
                                                                <Avatar className={classes.BNchip}
                                                                >
                                                                    <Icon icon="ant-design:check-circle-outlined" color="white" width="30" height="30" />
                                                                </Avatar>
                                                            )}
                                                            label={validateKeyData(BatteryProMeta.data[0]["soc"]) + "% Progress"}
                                                        />
                                                    </div>
                                                    <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soc"])} />
                                                </Paper></Paper>
                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper>
                                                <ListItem>
                                                    <ListItemAvatar>
                                                        <Avatar className={classes.BNavatar1}>
                                                            <Icon icon="bi:flag-fill" color="#82e219" />
                                                        </Avatar>
                                                    </ListItemAvatar>

                                                    <ListItemText primary={
                                                        <Typography className={classes.BNprimaryText}>Voltage & Temperature</Typography>
                                                    } />
                                                </ListItem>
                                                <Grid container spacing={1}>
                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNpurpleAvatar}>
                                                                    <AcUnit />
                                                                </Avatar>
                                                            </ListItemAvatar>
                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Min Voltage</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={
                                                                                BatteryProMeta.data[0]["min_cell_voltage_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_voltage_color"] === "green" ? classes.voltageG : classes.voltageR}>

                                                                            {validateKeyData(BatteryProMeta.data[0]["min_voltage_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["min_voltage"])}&nbsp;V&nbsp;
                                                                        </Typography>

                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>

                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNpinkAvatar}>
                                                                    <AllInclusive />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Max Voltage</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={BatteryProMeta.data[0]["max_cell_voltage_color"] === "green" ? classes.voltageG : BatteryProMeta.data[0]["max_cell_voltage_color"] === "amber" ? classes.voltageY : classes.voltageR}>
                                                                            {validateKeyData(BatteryProMeta.data[0]["max_voltage_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["max_voltage"])}&nbsp;V
                                                                        </Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>

                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNgreenAvatar}>
                                                                    <Adb /></Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Min Temperature</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={
                                                                                BatteryProMeta.data[0]["min_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                            {validateKeyData(BatteryProMeta.data[0]["min_temperature_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["min_temperature"])}&nbsp;ºC
                                                                        </Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>

                                                    <Grid xs={12} lg={6}>
                                                        <ListItem>
                                                            <ListItemAvatar>
                                                                <Avatar className={classes.BNorangeAvatar}>
                                                                    <AssistantPhoto />
                                                                </Avatar>
                                                            </ListItemAvatar>

                                                            <ListItemText primary={
                                                                <Typography className={classes.BNprimaryText}>Max Temperature</Typography>
                                                            }
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Typography
                                                                            className={
                                                                                BatteryProMeta.data[0]["max_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["max_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                            {validateKeyData(BatteryProMeta.data[0]["max_temperature_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["max_temperature"])}&nbsp;ºC
                                                                        </Typography>
                                                                    </React.Fragment>

                                                                }
                                                            />
                                                        </ListItem>
                                                    </Grid>
                                                </Grid>
                                            </Paper>

                                        </Grid>
                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.BNmap} variant="outlined" >
                                                <SimpleMap
                                                    zoom={10} bmsid={bmsid}
                                                    mapRes={BatteryProMeta.data[0]["last_one_hour_lat_lon"]}
                                                /></Paper>
                                        </Grid>
                                    </Grid>
                                </TabContainer>}
                            {value === 1 && <TabContainer>
                                <div style={{ display: 'flex' }}><Generic imei={imei} /></div>
                                {/* <><Grid item container spacing={2}>
                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.paper}><br /> <BatteryVoltage
                                                imei={imei}
                                                dataIndex={chartOneVal} /></Paper>
                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.paper}><br /><SOC imei={imei} dataIndex={chartOneVal} /></Paper>

                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.paper}><br /><TodayTripDistance imei={imei} dataIndex={chartOneVal} /></Paper>

                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.paper}><br /><BatteryCurrent imei={imei} dataIndex={chartOneVal} /></Paper>
                                        </Grid>
                                    </Grid></> */}
                            </TabContainer>}
                            {value === 2 && <TabContainer><br />
                                <div style={{ border: '5px solid #77b93e' }}><TreeTable imei={imei} /></div>
                            </TabContainer>}



                        </>
                    )

                    : MyBatteryFetching ?
                        <Loading /> :
                        MyBatteryResponsecode === 500 ?

                            <ErrorWrap /> :
                            // <Loading />
                            <>
                                <IconButton onClick={() => {
                                    setValue(0)
                                    setScreen(false)
                                }} className={classes.BNbutton} >
                                    <Icon icon="bi:arrow-left-circle-fill" width="26" height="26" color="#77b93e" />
                                </IconButton><br />
                                {/* <Typography style={{fontSize:'30px', marginTop:50}}>No Data Found</Typography> */}
                                <img src={nodata} style={{ marginLeft: 350 }} />
                            </>


            }






            {/* Vehicle Assignment */}
            <Dialog
                fullScreen={fullScreen}
                open={openVehicleActive}
                maxWidth={"lg"}
                onClose={() => setOpenVehicleActive(false)}
                aria-labelledby="responsive-dialog-title"
                // className={!fullScreen ? classes.dialog : null}
                style={{ marginLeft: '650px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Vehicle Assignment"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:&nbsp;{validateKeyData(serial)}</b> </Typography><br />
                        {/* <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}> */}
                        <b style={{ color: '#00000080', fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600 }}>Vehicle Number:</b>
                        <Select style={{ width: '100%' }}

                            onChange={(e) => {
                                setAssignVech((state) => ({
                                    ...state,
                                    "vehicle_id": e.target.value
                                }))
                            }}
                        >

                            <MenuItem value="">Select Vehicle</MenuItem>
                            {BVAMeta.data.length && BVAMeta.data.map((vehicle) => {
                                return (
                                    <MenuItem value={vehicle[1]}>{vehicle[0]}</MenuItem>

                                )
                            }
                            )}
                        </Select>

                        {/* </div> */}


                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus
                        onClick={() => setOpenVehicleActive(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button
                        onClick={() => {
                            assVehicle()
                        }}
                        color="secondary" autoFocus>
                        Assign
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Vehicle Deactivation */}
            <Dialog
                fullScreen={fullScreen}
                open={openDeActiveV}
                maxWidth={"lg"}
                onClose={() => setOpenDeActiveV(false)}
                aria-labelledby="responsive-dialog-title"
                // className={!fullScreen ? classes.dialog : null}
                style={{ marginLeft: '650px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Vehicle Deactivation"}</DialogTitle>
                <DialogContent style={{ height: '100px', width: '350px' }}><br />
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={12} xs={12}>
                                <Typography className={classes.secondaryTextG}>Vehicle Number:&nbsp;{validateKeyData(vn)}</Typography>

                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus
                        onClick={() => setOpenDeActiveV(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button autoFocus
                        onClick={() => {
                            DeactiveV(vehBatID)

                        }}
                        color="secondary">
                        Deactivate
                    </Button>
                </DialogActions>
            </Dialog>
            {/* Battery Active */}
            <Dialog
                fullScreen={fullScreen}
                open={openBatteryActive}
                maxWidth={"lg"}
                onClose={() => setOpenBatteryActive(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ marginLeft: '650px' }} >
                <DialogTitle id="responsive-dialog-title">{"Battery Activation"}</DialogTitle>
                <DialogContent
                    style={{ height: '100px', width: '300px' }}
                // style={{height: '340px',width:'320px',position: 'relative', marginLeft: '680px', marginTop:'250px'}}
                ><br />
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={12} xs={12}>
                                <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:&nbsp; {validateKeyData(serial)}</b></Typography>

                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus
                        onClick={() => setOpenBatteryActive(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button autoFocus
                        onClick={() => {
                            assBat(bid)
                        }}
                        color="secondary">
                        On
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Battery De-Active */}
            <Dialog
                fullScreen={fullScreen}
                open={openDeActiveB}
                maxWidth={"lg"}
                onClose={() => setOpenDeActiveB(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ marginLeft: '650px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Battery Deactivation"}</DialogTitle>
                <DialogContent style={{ height: '100px', width: '350px' }}><br />
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={12} xs={12}>
                                <Typography style={{ color: '#00000080' }}><b className={classes.secondaryTextG} >Serial Number:&nbsp;{validateKeyData(serial)}</b> </Typography>

                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus
                        onClick={() => setOpenDeActiveB(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button autoFocus
                        onClick={() => {
                            assBatD(bid)
                        }}
                        color="secondary">
                        Off
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Idle On */}
            <Dialog
                fullScreen={fullScreen}
                open={openOn}
                maxWidth={"lg"}
                onClose={() => setOpenOn(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ marginLeft: '680px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Battery On"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={12} xs={12}>
                                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                <TextField className={classes.textField}
                                    onChange={(e) => { setOnOffPassword(e.target.value) }}
                                />

                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={() => setOpenOn(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button
                        disabled={onOffPassword !== pWord}
                        onClick={() => {
                            On()
                            setTimeout(() => {
                                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));

                            }, 500)
                        }}
                        color="secondary">
                        On
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Idle Off */}

            <Dialog
                fullScreen={fullScreen}
                open={openOff}
                maxWidth={"lg"}
                onClose={() => setOpenOff(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ marginLeft: '680px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Battery Off"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={12} xs={12}>
                                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                <TextField className={classes.textField}
                                    onChange={(e) => { setOnOffPassword1(e.target.value) }}
                                />

                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={() => setOpenOff(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button
                        disabled={onOffPassword1 !== pWord}
                        onClick={() => {
                            Off()
                            setTimeout(() => {
                                dispatch(getMyBatteryBulk(enty, UserIdd, roid, batPage));

                            }, 500)
                        }}
                        color="secondary">
                        Off
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Delete Battery */}
            <Dialog
                fullScreen={fullScreen}
                open={delete1}
                maxWidth={"lg"}
                onClose={() => setDelete1(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ marginLeft: '680px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Offboarding Battery"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={12} xs={12}>
                                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                <TextField className={classes.textField}
                                    onChange={(e) => { setPassword1(e.target.value) }}
                                />

                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={() => setDelete1(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button
                        disabled={password1 !== pWord}
                        onClick={() => {
                            deleteBattery(selectedId1);
                        }}
                        color="secondary">
                        Offboard
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Delete Battery Model */}
            <Dialog
                fullScreen={fullScreen}
                open={delete2}
                maxWidth={"lg"}
                onClose={() => setDelete2(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ marginLeft: '600px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Offboarding Battery Model"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={12} xs={12}>
                                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                <TextField className={classes.textField}
                                    onChange={(e) => { setPassword2(e.target.value) }}
                                />

                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={() => setDelete2(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button
                        disabled={password2 !== pWord}
                        onClick={() => {
                            deleteModel(selectedId2);
                        }}
                        color="secondary">
                        Offboard
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Delete BMS Model */}
            <Dialog
                fullScreen={fullScreen}
                open={delete3}
                maxWidth={"lg"}
                onClose={() => setDelete3(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ width: '1200px', position: 'relative', marginLeft: '680px', marginTop: '250px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Offboarding BMS Model"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <Grid item lg={12} xs={12}>
                                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                                <TextField className={classes.textField}
                                    onChange={(e) => { setPassword3(e.target.value) }}
                                />

                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={() => setDelete3(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button
                        disabled={password3 !== pWord}
                        onClick={() => {
                            deleteBMS(selectedId3);
                        }}
                        color="secondary">
                        Offboard
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Telematics Assignment */}
            <Dialog
                fullScreen={fullScreen}
                open={openTele}
                maxWidth={"lg"}
                onClose={() => setOpenTele(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ marginLeft: '600px' }}
            >
                <DialogTitle id="responsive-dialog-title">{"Telematics Assignment"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        <Grid container spacing={2}>
                            <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>Telematics Imei:</b>
                            <Grid item lg={12} xs={12}>
                                <Select
                                    onChange={(e) => {
                                        setAssignTele((state) => ({
                                            ...state,
                                            telematics_id: e.target.value,
                                        }));
                                    }}
                                    style={{
                                        width: "100%",
                                        color: "#7A7A7D",
                                        borderRadius: "9px",
                                        ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                                            borderColor: "#C4C4C4  !important",
                                        },
                                        "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
                                    }}
                                >
                                    <MenuItem value="">Select IMEI</MenuItem>
                                    {getImei.length &&
                                        getImei.map((imeiD) => {
                                            return (
                                                <MenuItem value={imeiD.telematics_id}>{imeiD.imei}</MenuItem>
                                            );
                                        })}
                                </Select>
                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={() => setOpenTele(false)}
                        color="primary">
                        Cancel
                    </Button>
                    <Button
                        onClick={() => {
                            AssignTelematics();
                        }}
                        color="secondary">
                        Assign
                    </Button>
                </DialogActions>
            </Dialog>
            {/* Telematics De-Active */}
            <Dialog
                fullScreen={fullScreen}
                open={openTeleD}
                maxWidth={"lg"}
                onClose={() => setOpenTeleD(false)}
                aria-labelledby="responsive-dialog-title"
                style={{ marginLeft: '600px' }}
            >
                <DialogTitle id="responsive-dialog-title">
                    {"Telematics Reassignment"}
                </DialogTitle>
                <DialogContent style={{ height: '100px', width: '300px' }}><br />
                    <DialogContentText>
                        <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>
                            IMEI:&nbsp;{selectedImei}</b>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button
                        autoFocus
                        onClick={() => setOpenTeleD(false)}
                        color="primary"
                    >
                        Cancel
                    </Button>
                    <Button
                        onClick={() => {
                            ReassignImei(assetLink)
                        }}
                        color="secondary"
                        autoFocus
                    >
                        Re-Assign
                    </Button>
                </DialogActions>
            </Dialog>

            <br /><br />
            <Typography align="center" style={{ fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap' }} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
        </div>
    );



}
