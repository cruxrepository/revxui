import React, { useState } from 'react';
import axios from 'axios';
import { withStyles, makeStyles, useTheme, styled, alpha, darken } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import LinearProgress from '@material-ui/core/LinearProgress';
import Chip from '@material-ui/core/Chip';
import MUIDataTable from 'mui-datatables';
import MenuItem from "@material-ui/core/MenuItem";
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Button from "@material-ui/core/Button";
import BatteryVoltage from "./BatteryVoltage";
import BatteryCurrent from "./BatteryCurrent";
import SOC from "./SOC";
import TodayTripDistance from "./TodayTripDistance";
import Select from "@material-ui/core/Select";
import Tooltip from '@material-ui/core/Tooltip';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import TabIcon from '@material-ui/icons/Tab';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import BatteryCharging30Icon from '@material-ui/icons/BatteryCharging30';
import endpoints from '../../../endpoints/endpoints';
import CustomToolbar from './CustomToobar';
import MotorcycleIcon from '@material-ui/icons/Motorcycle';
import CustomToolbarM from './CustomToobarM';
import Divider from '@material-ui/core/Divider';
import SimpleSnackbar from '../Users/SimpleSnackbar';
// import LinearProgress from '@material-ui/core/LinearProgress';

import AcUnit from '@material-ui/icons/AcUnit';
import Adb from '@material-ui/icons/Adb';
import AllInclusive from '@material-ui/icons/AllInclusive';
import AssistantPhoto from '@material-ui/icons/AssistantPhoto';
import AppBar from '@material-ui/core/AppBar';
import PhotoLibrary from '@material-ui/icons/PhotoLibrary';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import SimpleMap from "./SimpleMap";
import TreeTable from "./TreeTable";
import Pagination from '@material-ui/lab/Pagination';


import Dialog from '@material-ui/core/Dialog';
import Brightness1Icon from '@material-ui/icons/Brightness1';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { getMyBatteryBulk, getBatteryModelBulk, getBatteryProBulk, getBMSBulk,
    //  getBMSHVBulk, 
     getBatteryViewBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';
import clearMyBattery from '../../../redux/actions/normalActions';

const useStyles = makeStyles((theme) => ({
    tableborder: { display: 'none' },
    root: {
        margin: 10
    },
    textField: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
        'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    table: {

        '& > div': {

            '& > .MuiToolbar-regular': {
                backgroundColor: '#68A72480  !important',
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0
            },
            // overflow: 'auto',
            // textAlign:'center'
        },

        '& table': {
            '& td': {
                wordBreak: 'keep-all',
                textAlign: 'center'
            },

            [theme.breakpoints.down('md')]: {
                '& td': {
                    height: 60,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                },
                '& tr:nth-child(odd)': {
                    backgroundColor: '#cfcfcf40'
                },
                '& tr:nth-child(even)': {
                    backgroundColor: '#cfcfcf20'
                },
            }
        }
    },
    graphText: {
        fontSize: 12,
        position: 'absolute',
        transform: 'rotate(270deg)',
        left: '-40px',
        top: 370,
        color: 'primary',
        fontWeight: 600
    },
    graphSelect: {
        minWidth: 150, left: '20em', marginBottom: 20
    },
    tabsSection: {
        [theme.breakpoints.up('lg')]: {
            // borderRadius:0,position:'sticky',top:0 ,width:500
            borderRadius: 0, top: 0, width: 500

        },


    },
    primaryText: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
    }, primaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '300px'
    },
    secondaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '100%'
    },
    voltageG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724'
    },
    voltageY: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FFBF00'
    },
    voltageR: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FF0000'
    },
    chart1: {
        marginLeft: '-20px', width: '120px', height: '50px', '.MuiPaper-root .MuiMenu-paper .MuiPopover-paper': { width: '120px !important' }
    },
    copyRight: {
        position: 'absolute', bottom: 0, right: 0, left: 0, fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    dialog: {
        // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
        position: 'relative', marginLeft: '680px'
    },
    healthy: {
        color: '#82E219', width: '5rem', fontSize: '20px'
    },
    Unhealthy: {
        color: '#FFFF00'
    },
    chart: {
        padding: theme.spacing(2)
    },
    dataView: {
        height: '300px',
    },
    BNavatar: { height: '60px', width: '60px', border: '1px solid #fff', backgroundColor: "#77b93e" },
    BNavatar1: { backgroundColor: '#f3efef' },
    BNgrid: { marginLeft: 20 },
    BNprimaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '16px', fontWeight: 600, color: 'primary', width: '200px',
    },
    BNstateText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '20px', fontWeight: 500, color: '#fff', width: '250px',
    },
    BNsecondaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary',
    },
    BNsecondaryTextG: { color: '#00FF00' },
    BNsecondaryText1: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary', width: '150px',
    },
    BNIcon: {
        marginRight: 10, marginTop: 10
    },
    BNtitle: {},
    BNsubtitle: {},

    BNchip: { backgroundColor: '#4caf50b5' },
    BNchip2: { backgroundColor: '#FFBF00' },
    BNchip3: { backgroundColor: '#FF0000' },
    BNstyledPaper: {
        backgroundColor: '#4caf50b5',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper2: {
        backgroundColor: '#FFBF00',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper3: {
        backgroundColor: '#FF0000',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNprogressWidget: {
        marginTop: 20,
        background: theme.palette.secondary.dark,
        '& div': {
            background: theme.palette.primary.light,
        }
    },
    BNmap: {
        height: 200, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    BNcover: {
        '& $name, & $subheading': {
            color: theme.palette.common.white
        },
        position: 'relative',
        width: '100%',
        overflow: 'hidden',
        height: 200,
        backgroundColor: "#77b93e"
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        ,
        // backgroundColor:
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        // ,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundSize: 'cover',
        textAlign: 'center',
        boxShadow: theme.shadows[7],
        backgroundPosition: 'bottom center',
        borderRadius: '10px 10px 0px 0px',
    },
    BNname: {
        fontSize: '24px', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400, color: '#fff'
    },
    BNopt: {
        position: 'absolute',
        top: 0,
        right: 10,
        '& button': {
            color: theme.palette.common.white
        }
    },
    BNprofileTab: {
        marginTop: 0,
        [theme.breakpoints.down('sm')]: {
            marginTop: 0,
        },
        borderRadius: '0px 0px 10px 10px',
        background:
            // alpha(theme.palette.background.paper, 0.8)
            "#dcead7",
        position: 'relative'
    },
    BNaboutTxt: {
        fontSize: '1rem', fontWeight: 600, color: '#000000'
    },

    BNaboutTxt1: {
        fontSize: '1rem', fontWeight: 400, color: '#000000'
    },
    BNdriving: {
        color: '#82E219', marginLeft: '-90px'
    },
    BNdrivingR: {
        color: '#ff0000', marginLeft: '-90px'
    },
    BNorangeAvatar: {
        backgroundColor: '#ff5722',
    },
    BNpurpleAvatar: {
        backgroundColor: '#673ab7',
    },
    BNpinkAvatar: {
        backgroundColor: '#e91e63',
    },
    BNgreenAvatar: {
        backgroundColor: '#4caf50',
    },
    BNdivider: {
        width: '92%', marginLeft: '20px'
    },
    addTab: { backgroundColor: '#b3d391', color: "#fff" },
    pageTitle: {
        textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600
    }
}));
function TabContainer(props) {
    const { children } = props;
    return (
        <div style={{ paddingTop: 8 * 3 }}>
            {children}
        </div>
    );
}

TabContainer.propTypes = {
    children: PropTypes.node.isRequired,
};


export default function BatteryPage() {
    const MyBatteryData = useSelector((store) => store.myBattery)
    const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
    //   let MyBatteryMeta = useSelector((store) => store.myBattery)
    // let MyBatteryMeta =  getBatteryModelBulk()
    let MyBatteryMeta = {};
    MyBatteryMeta.data = [];
    let MyBatteryMetaa = useSelector((store) => store.myBattery)
    if (MyBatteryMetaa.data.length >= 1) {
        MyBatteryMeta.data = MyBatteryMetaa.data;
    }
    let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
    let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
    let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)

    const BatteryProData = useSelector((store) => store.batteryPro)
    const BatteryProRaw = useSelector((store) => store.batteryPro.rawData)
    let BatteryProMeta = useSelector((store) => store.batteryPro)
    let BatteryProFetching = useSelector((store) => store.batteryPro.fetching)
    let BatteryProResponsecode = useSelector((store) => store.batteryPro.responseStatus)
    let BatteryProMetaPresent = useSelector((store) => store.batteryPro.dataPresent)

    const BatteryModelData = useSelector((store) => store.batteryModel)
    const BatteryModelDataRaw = useSelector((store) => store.batteryModel.rawData)
    let BatteryModelMeta = useSelector((store) => store.batteryModel)
    let BatteryModelFetching = useSelector((store) => store.batteryModel.fetching)
    let BatteryModelResponsecode = useSelector((store) => store.batteryModel.responseStatus)
    let BatteryModelMetaPresent = useSelector((store) => store.batteryModel.dataPresent)

    const BMSData = useSelector((store) => store.bmsAll)
    const BMSDataRaw = useSelector((store) => store.bmsAll.rawData)
    let BMSMeta = useSelector((store) => store.bmsAll)
    let BMSFetching = useSelector((store) => store.bmsAll.fetching)
    let BMSResponsecode = useSelector((store) => store.bmsAll.responseStatus)
    let BMSMetaPresent = useSelector((store) => store.bmsAll.dataPresent)

    // const BMSHVData = useSelector((store) => store.hvAll)
    // const BMSHVRaw = useSelector((store) => store.batteryPro.hvAll)
    // let BMSHVMeta = useSelector((store) => store.hvAll)
    // let BMSHVFetching = useSelector((store) => store.hvAll.fetching)
    // let BMSHVResponsecode = useSelector((store) => store.hvAll.responseStatus)
    // let BMSHVMetaPresent = useSelector((store) => store.hvAll.dataPresent)


    const logged_user = useSelector((store) => store.user.loggeduser);
    // let enty = logged_user.entity_id
    const dispatch = useDispatch();

    const [openEditModel, setOpenEditModel] = React.useState(false);
    const [openEditBattery, setOpenEditBattery] = React.useState(false);

    const theme = useTheme();
    const classes = useStyles();
    const [screen, setScreen] = React.useState(false);
    const [idleMode, setIdleMode] = React.useState(false);
    const [openAddBattery, setOpenAddBattery] = React.useState(false);
    const [openAddModel, setOpenAddModel] = React.useState(false);
    const [openAddBMS, setOpenAddBMS] = React.useState(false);
    const [openEditBMS, setOpenEditBMS] = React.useState(false);
    const [openVehicleReAssign, setOpenVehicleReAssign] = React.useState(false);
    const [openVehicleAssign, setOpenVehicleAssign] = React.useState(false);
    const [openBatteryActive, setOpenBatteryActive] = React.useState(false);
    const [openBatteryDeActive, setOpenBatteryDeActive] = React.useState(false);
    const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)
    const [modelAddForm, setModelAddForm] = React.useState(
        {
            model_info: "",
            nominal_voltage: "",
            capacity_mah: "",
            power: "",
            cell_maufacturer: "",
            // oem: "",
            number_of_cells_series: "",
            number_of_cells_parallel: "",
            cell_chemisty: "",
            cell_type: "",
            length: "",
            width: "",
            height: "",
            thermistor: "",
            // bms: {
            //     bms_model_id: "",
            //     oem: "",
            //     hw_version: ""

            // }
        }
    )
    const [batteryAddForm, setBatteryAddForm] = React.useState(
        {
            battery_model_id: "",
            serial_number: "",
            bms_unique_id: "",
            investor: "",
            operation_owner: "",
            sw_version: ""
        }
    )
    const [editBatArray, setEditBatArray] = React.useState(
        {}
    )

    const [bmsAddForm, setBmsAddForm] = React.useState(
        {
            model_info: "",
            hw_version: "",
            oem: "",
        }
    )
    const [editBMSArray, setEditBMSArray] = React.useState(
        {}
    )
    const submitBMS = () => {

        if (bmsAddForm.model_info && bmsAddForm.hw_version && bmsAddForm.oem) {
            const postBMS = endpoints.baseUrl + `/battery/bms/add`;
            axios
                .post(postBMS, bmsAddForm)
                .then((response) => {
                    setAddBatteryErrors(true);
                    setOpenAddBMS(false)
                    dispatch(getBMSBulk());
                    response.status === 201 ? setAddResponce("BMS Onboarded Successfully") : null
                    // response.status === 400 ? setAddResponce("BMS Onboarded Successfully") : setAddResponce(response.message)

                    setBmsAddForm({
                        model_info: "",
                        hw_version: "",
                        oem: "",
                    })
                }).catch((err) => {
                    setAddResponce("This Details already exists")
                });


        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }
    const setBMSAddFormArray = (e, key) => {
        setBmsAddForm((state) => ({ ...state, [key]: e.target.value }));

    }

    const setEditBmsFormArray = (e, key) => {
        setEditBMSArray((state) => ({ ...state, [key]: e.target.value }));

    }


    const submitEditBMS = () => {
        // setAddBatteryErrors(true);
        if (editBMSArray.model_info && editBMSArray.hw_version && editBMSArray.oem) {
            const putBMS = endpoints.baseUrl + `/battery/bms/edit/` + editBMSArray.bms_model_id;
            let newEditBMSArray = editBMSArray;
            axios
                .put(putBMS, newEditBMSArray)
                .then((response) => {
                    setAddBatteryErrors(true);
                    setOpenEditBMS(false)

                    dispatch(getBMSBulk());
                    response.status === 200 ? setAddResponce("Battery Edited Successfully") : setAddResponce(response.message)
                    setBMSEditForm({

                    })
                });
            setOpenEditBMS(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }

    const setEditBMSSArray = (bms_model_id) => {

        let allBMS = BMSDataRaw;
        let findEditBMSArray = allBMS.find(el => el.bms_model_id === bms_model_id);
        setEditBMSArray(findEditBMSArray);
    }

    const [value, setValue] = React.useState(0);
    const [bmsmodel, setBmsmodel] = React.useState(0);
    const [bmsid, setBmsId] = React.useState(0);
    const [serial, setSerial] = React.useState(0);
    const [model, setModel] = React.useState(0);
    const [operation, setOperation] = React.useState(0);

    const [tableMode, setTableMode] = React.useState("ericksaw");


    const [csvDownload, setCsvDownload] = React.useState(1);
    const [chartOneVal, setChartOneVal] = React.useState("day");
    const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)

    const [addResponse, setAddResponce] = React.useState("")
    const [modelPage, setModelPage] = React.useState(1);
    const [bmsPage, setBmsPage] = React.useState(1);
    const [modelHardware, setModelHardware] = React.useState([])
    const [modelOem, setModelOem] = React.useState([])

    const [editArray, setEditArray] = React.useState({

        })

    // React.useEffect(() => {
    //     setEditArray(modelPage ? modelPage : 1)
    //     typeof enty != "undefined" ? dispatch(getMyBatteryBulk(enty)) : null;

    //     dispatch(
    //         getBatteryModelBulk(modelPage)
    //     );

    // }, [MyBatteryMetaPresent, modelPage]);
    React.useEffect(() => {
        dispatch(getBMSBulk(bmsPage));
    }, [BMSMetaPresent, bmsPage]);

    // React.useEffect(() => {
    //     dispatch(getBMSHVBulk(bmsmodel));
    // }, [dispatch, BMSHVMetaPresent]);

    let allModels = BatteryModelMeta.data
    let allBMSData = BMSMeta.data
    // const allHV = (val) => {
    //     let getHVUrl = endpoints.baseUrl + `/battery/bmshwinfo/list/` + val
    //    val !== 0 ? axios
    //         .get(getHVUrl)
    //         .then((response) => {
    //             setModelHardware(response.data.data)
    //         }) :null
    //     // dispatch(getBMSHVBulk(bmsmodel));

    // }
    // let allBMSHVData = modelHardware

    // const allHW = (val) => {
    //     let getHWUrl = endpoints.baseUrl + `/battery/oem?model_info=` + modelAddForm.model_info + `&hw_version=`+val
    //     val && val1 !== 0 ? axios
    //     .get(getHWUrl)
    //     .then((response) => {
    //             setModelOem(response.data.data)
    //         }) :null
            
           
    //     }
    // const allOEM = (val, val1) => {
    //     let getOEMUrl = endpoints.baseUrl + `/battery/oem?model_info=` + val + `&hw_version=`+val1
    //     axios
    //         .get(getOEMUrl)
    //         .then((response) => {
    //             setModelOem(response.data.data)
    //         })

    // }
    // let allOEMData = modelOem
    const changePageBatModel = (event, newValue) => {
        setModelPage(newValue);
    };
    const changePageBMS = (event, newValue) => {
        setBmsPage(newValue);
    };
    const submitBattery = () => {

        if (batteryAddForm.sw_version && batteryAddForm.investor && batteryAddForm.battery_model_id && batteryAddForm.operation_owner && batteryAddForm.serial_number) {
            const postBattery = endpoints.baseUrl + `/battery/post`;
            axios
                .post(postBattery, batteryAddForm)
                .then((response) => {
                    setAddBatteryErrors(true);

                    dispatch(getMyBatteryBulk());
                    response.status === 201 ? setAddResponce("Battery Onboarded Successfully") : setAddResponce(response.message)
                    setBatteryAddForm({
                        battery_model_id: "",
                        serial_number: "",
                        bms_unique_id: "",
                        investor: "",
                        operation_owner: "",
                        sw_version: ""
                    })
                });
            setOpenAddBattery(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }
    const setBatteryAddFormArray = (e, key) => {
        setBatteryAddForm((state) => ({ ...state, [key]: e.target.value }));

    }


    const submitModel = () => {
        setAddBatteryErrors(true);

        if (
            modelAddForm.capacity_mah && modelAddForm.cell_chemisty && modelAddForm.cell_maufacturer && modelAddForm.cell_type && modelAddForm.height && modelAddForm.length
            && modelAddForm.model_info && modelAddForm.nominal_voltage && modelAddForm.number_of_cells_parallel && modelAddForm.number_of_cells_series &&
            // modelAddForm.oem && 
            modelAddForm.power && modelAddForm.thermistor && modelAddForm.width
        ) {
            const postModel = endpoints.baseUrl + `/batterymodel/add`;
            axios
                .post(postModel, modelAddForm)
                .then((response) => {
                    setAddBatteryErrors(true);

                    // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
                    dispatch(getBatteryModelBulk());
                    setAddResponce("Model Onboarded Successfully")
                    setModelAddForm({
                        model_info: "",
                        nominal_voltage: "",
                        capacity_mah: "",
                        power: "",
                        cell_maufacturer: "",
                        // oem: "",
                        number_of_cells_series: "",
                        number_of_cells_parallel: "",
                        cell_chemisty: "",
                        cell_type: "",
                        length: "",
                        width: "",
                        height: "",
                        thermistor: "",
                        bms: {
                            bms_model_id: "",
                            oem: "",
                            hw_version: ""

                        }
                    })
                });
            setOpenAddModel(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }
    const setModelAddFormArray = (e, key, array) => {
        if (array) {
            setModelAddForm((state) => ({
                ...state, bms: {
                    ...state.bms,
                    [key]: e.target.value
                }
            }));
        } else {
            setModelAddForm((state) => ({ ...state, [key]: e.target.value }));

        }


    }

    const setModelEditFormArray = (e, key, array) => {
        if (array) {
            setEditArray((state) => ({
                ...state, bms: {
                    ...state.bms,
                    [key]: e.target.value
                }
            }));
        } else {
            setEditArray((state) => ({ ...state, [key]: e.target.value }));

        }


    }
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const handleChangeT = (event, val) => {
        setValue(val);
    };


    let allEditModel = BatteryModelMeta.data
    {/* Battery*/ }

    const setEditBatteryFormArray = (e, key) => {
        setEditBatArray((state) => ({ ...state, [key]: e.target.value }));

    }


    const submitEditBattery = () => {
        setAddBatteryErrors(true);
        if (editBatArray.bms_unique_id && editBatArray.investor && editBatArray.operation_owner && editBatArray.serial_number && editBatArray.software_version) {
            const putBattery = endpoints.baseUrl + `/battery/update/` + editBatArray.bms_id;
            let newEditArray = editBatArray;
            newEditArray.sw_version = editBatArray.software_version
            axios
                .put(putBattery, newEditArray)
                .then((response) => {
                    setAddBatteryErrors(true);

                    dispatch(getMyBatteryBulk());
                    response.status === 200 ? setAddResponce("Battery Edited Successfully") : setAddResponce(response.message)
                    setBatteryEditForm({

                    })
                });
            setOpenEditBattery(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }

    const setEditBatteryArray = (bms_id) => {

        let allBattery = MyBatteryDataRaw;
        let findEditArray = allBattery.find(el => el.bms_id === bms_id);
        setEditBatArray(findEditArray);
    }

    {/* Model*/ }

    const setModelEditArray = (battery_model_id) => {
        let allModel = BatteryModelDataRaw;
        let findArray = allModel.find(el => el.battery_model_id === battery_model_id);
        setEditArray(findArray);
    }
    const submitModelEdit = () => {

        setAddBatteryErrors(true);

        if (
            editArray.capacity_mah && editArray.cell_chemisty && editArray.cell_maufacturer && editArray.cell_type && editArray.height && editArray.length
            && editArray.model_info && editArray.nominal_voltage && editArray.number_of_cells_parallel && editArray.number_of_cells_series && editArray.oem
            && editArray.power && editArray.thermistor && editArray.width
        ) {


            const putModel = endpoints.baseUrl + `/batterymodel/edit/` + editArray.battery_model_id;
            axios
                .put(putModel, editArray)
                .then((response) => {
                    dispatch(getBatteryModelBulk());
                    response.status === 200 ? setAddResponce("Model Edited Successfully") : setAddResponce(response.message)
                    setEditArray({

                    })
                });
            setOpenEditModel(false)

        } else {
            setAddBatteryErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }

    const deleteModel = (battery_model_id) => {
        const deleteModel = endpoints.baseUrl + `/batterymodel/softdelete/` + battery_model_id;
        axios
            .delete(deleteModel)
            .then((response) => {

                dispatch(getBatteryModelBulk());
            });
    }





    const Item = styled(Paper)(({ theme }) => ({
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'left',
        color: theme.palette.text.secondary,
    }));

    const validateKeyData = (key) => {
        return key ? key : "-";
    };

    const handleTableChange = (event) => {
        if (tableMode === 'erickshaw') {
            setTableMode('comm');
        } else {
            setTableMode('erickshaw');
        }
    };
    const batteryProfile = (bmsid) => {
        dispatch(getBatteryProBulk(bmsid));
        setCsvDownload(1)
    }
    const downloadCsv = () => {
        let getCsvUrl = endpoints.baseUrl + `/battery/datadownload/` + bmsid;
        setAddBatteryErrors(true);
        setNotificationTimeOut(60000)
        setAddResponce("Preparing Your csv for Download, Please wait..")

        axios
            .get(getCsvUrl)
            .then((response) => {
                // setFinalCsv(response);
                setCsvDownload(1)
                const blob = new Blob([response.data], { type: 'text/csv' });
                const url = window.URL.createObjectURL(blob)
                const a = document.createElement('a')
                a.setAttribute('href', url)
                a.setAttribute('download', 'download.csv');
                a.click()

                //  input.current.click()
                setAddBatteryErrors(false);
                setNotificationTimeOut(6000)

                //  input.current.click()
                setAddBatteryErrors(true);

                setAddResponce("Downloaded Successfully")

            })
            .catch((error) => {

                let status = null;
                let data = null;
                setCsvDownload(4)
                setAddBatteryErrors(true);

                setAddResponce("Try Again")

                //If no response from server
                if (!error.response) {
                    status = 500;
                    data = "No response from server";
                } else {
                    status = error.response.status;
                    data = error.response.data;
                }

            });

    }
    const handleSubmiAddBattery = () => {
        submitBattery()
    }
    const handleSubmitEditBattery = () => {
        submitEditBattery()
    }
    if (MyBatteryMetaPresent) {




        const currDate = new Date().toLocaleDateString();
        const currTime = new Date().toLocaleTimeString();

        const dayDropdown = [{ val: 'day', name: 'Day' }, { val: 'month', name: 'Month' }, { val: 'year', name: 'Year' }, { val: 'custom', name: 'Custom' }]




        const columsModel = [
            {
                name: 'Model',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography color='secondary' variant='subtitle2'>{validateKeyData(value)} </Typography>
                    )
                }
            },
            {
                name: 'Voltage',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            }, {
                name: 'Capacity',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            }, {
                name: 'Power',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            }, {
                name: 'Manufacturer',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            },
            {
                name: 'Action',
                options: {
                    filter: true,
                    customBodyRender: (value) => {
                        // if (value === 'assign') {
                        return (
                            <><IconButton
                                onClick={() => {
                                    setOpenEditModel(true)
                                    setAddBatteryErrors(false)
                                    setModelEditArray(value)
                                }}
                            ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="fluent:tab-arrow-left-20-filled" color="#82E219" width="30" height="30" /> </IconButton>
                            </>
                            //     <Select
                            //         style={{ minWidth: 150, color: '#FFC130' }}
                            //         value='Edit'
                            //     >
                            //         <MenuItem onClick={() => {
                            //             setOpenEditModel(true)
                            //             setModelEditArray(value)
                            //         }
                            //         }
                            //             value='Edit'>Edit</MenuItem>
                            //         <MenuItem
                            // onClick={() => { deleteModel(value) }}

                            //             style={{ color: "#FF6058 !important" }} value="Delete">
                            //             Deactivate
                            //         </MenuItem>
                            //     </Select>
                        )
                    }
                }
            },
        ]

        const columnsBattery = [

            {
                name: 'Serial Number',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography onClick={() => {
                            setScreen(true)
                            setBmsId(validateKeyData(value.bms_id))
                            setSerial(validateKeyData(value.serial_number))
                            setModel(validateKeyData(value.battery_model))
                            setOperation(validateKeyData(value.operation_owner))
                            batteryProfile(validateKeyData(value.bms_id))
                        }}
                            style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                            &nbsp;&nbsp;{value.serial_number}
                        </Typography>

                    )
                }
            },
            {
                name: 'Model',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography onClick={() => {
                            setScreen(true)
                            //   setModel(value.model)
                        }}
                            // style={{ color: '#33a6ff', cursor: 'pointer' }} 
                            variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            },
            {
                name: 'Investor',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography onClick={() => setScreen(true)} variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            },
            {
                name: 'Operation Owner',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography onClick={() => setScreen(true)} variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            },
            {
                name: 'Vehicle Number',
                options: {
                    filter: false,
                    customBodyRender: (value) => {
                        if (value.serial_number === "OFG144V380Ah_20221") {
                            return (<Typography style={{ color: '#33a6ff', cursor: 'pointer' }}
                                variant='subtitle2'>-</Typography>)
                        }
                        else {
                            return (
                                <Typography style={{ color: '#33a6ff', cursor: 'pointer' }}
                                    variant='subtitle2'>{validateKeyData(value.vehicle_number)}</Typography>
                            )
                        }
                    }

                }
            },

            {
                name: 'Action',
                options: {
                    filter: true,
                    customBodyRender: (value) => {

                        if (value.serial_number === "OFG144V380Ah_20221") {
                            return (
                                <><IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setAddBatteryErrors(false)

                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                    <IconButton>
                                        <Icon icon="codicon:blank" color="#82E219" width="30" height="30" />
                                    </IconButton>
                                    <IconButton
                                        onClick={() => {
                                            setOpenBatteryActive(true)
                                            setSerial(validateKeyData(value.serial_number))
                                        }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                                </>
                            )
                        }
                        else if (value.vehicle_number && value.battery_status === "on") {
                            return (
                                <><IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="28" height="28" /></IconButton>
                                    <IconButton
                                        onClick={() => {
                                            setAddBatteryErrors(false)

                                            setOpenVehicleReAssign(true)
                                            setSerial(validateKeyData(value.serial_number))
                                        }}><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" />
                                    </IconButton>
                                    <Dialog
                                        fullScreen={fullScreen}
                                        open={openVehicleReAssign}
                                        maxWidth={"lg"}
                                        onClose={() => setOpenVehicleReAssign(false)}
                                        aria-labelledby="responsive-dialog-title"
                                        className={!fullScreen ? classes.dialog : null}
                                    >
                                        <DialogTitle id="responsive-dialog-title">{"Vehicle Assignment"}</DialogTitle>
                                        <DialogContent>
                                            <DialogContentText>
                                                <Grid container spacing={2}>
                                                    <Grid item lg={8} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:</b> {validateKeyData(serial)}</Typography>

                                                    </Grid>
                                                    <Grid item lg={8} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Vehicle Number:</b></Typography>
                                                        <Select className={classes.textField}>

                                                            <MenuItem value="">Select Vehicle</MenuItem>
                                                            {/* {allVehicles.map((vehicle) => { 
                                                            return (
                                                            <MenuItem value={vehicle[0]}>{vehicle[0]}</MenuItem>
    
                                                             )
                                                              }
                                                              )}  */}
                                                        </Select>
                                                    </Grid>
                                                </Grid>
                                            </DialogContentText>
                                        </DialogContent>
                                        <DialogActions>
                                            <Button autoFocus
                                                onClick={() => setOpenVehicleReAssign(false)}
                                                color="primary">
                                                Cancel
                                            </Button>
                                            <Button
                                                onClick={() => {
                                                    setOpenVehicleReAssign(false)
                                                }}
                                                color="secondary" autoFocus>
                                                Deactivate
                                            </Button>
                                        </DialogActions>
                                    </Dialog>
                                    <IconButton
                                        onClick={() => {
                                            setOpenBatteryDeActive(true)
                                            setSerial(validateKeyData(value.serial_number))
                                        }}><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>
                                    <Dialog
                                        fullScreen={fullScreen}
                                        open={openBatteryDeActive}
                                        maxWidth={"lg"}
                                        onClose={() => setOpenBatteryDeActive(false)}
                                        aria-labelledby="responsive-dialog-title"
                                        className={!fullScreen ? classes.dialog : null}
                                    >
                                        <DialogTitle id="responsive-dialog-title">{"Battery Activation"}</DialogTitle>
                                        <DialogContent>
                                            <DialogContentText>
                                                <Grid container spacing={2}>
                                                    <Grid item lg={12} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:</b> {validateKeyData(serial)}</Typography>

                                                    </Grid>
                                                </Grid>
                                            </DialogContentText>
                                        </DialogContent>
                                        <DialogActions>
                                            <Button autoFocus
                                                onClick={() => setOpenBatteryDeActive(false)}
                                                color="primary">
                                                Cancel
                                            </Button>
                                            <Button autoFocus
                                                onClick={() => setOpenBatteryDeActive(false)}
                                                color="secondary">
                                                Deactivate
                                            </Button>
                                        </DialogActions>
                                    </Dialog>
                                </>
                            )
                        }
                        else if (value.vehicle_number && value.battery_status === "off") {
                            return (
                                <><IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                    <IconButton
                                        onClick={() => {
                                            setAddBatteryErrors(false)

                                            setOpenVehicleReAssign(true)
                                            setSerial(validateKeyData(value.serial_number))
                                        }}><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                                    <Dialog
                                        fullScreen={fullScreen}
                                        open={openVehicleReAssign}
                                        maxWidth={"lg"}
                                        onClose={() => setOpenVehicleReAssign(false)}
                                        aria-labelledby="responsive-dialog-title"
                                        className={!fullScreen ? classes.dialog : null}
                                    >
                                        <DialogTitle id="responsive-dialog-title">{"Vehicle Assignment"}</DialogTitle>
                                        <DialogContent>
                                            <DialogContentText>
                                                <Grid container spacing={2}>
                                                    <Grid item lg={8} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:</b> {validateKeyData(serial)}</Typography>

                                                    </Grid>
                                                    <Grid item lg={8} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Vehicle Number:</b></Typography>
                                                        <Select className={classes.textField}>

                                                            <MenuItem value="">Select Vehicle</MenuItem>
                                                            {/* {allVehicles.map((vehicle) => { 
                                                            return (
                                                            <MenuItem value={vehicle[0]}>{vehicle[0]}</MenuItem>
    
                                                             )
                                                              }
                                                              )}  */}
                                                        </Select>
                                                    </Grid>
                                                </Grid>
                                            </DialogContentText>
                                        </DialogContent>
                                        <DialogActions>
                                            <Button autoFocus
                                                onClick={() => setOpenVehicleReAssign(false)}
                                                color="primary">
                                                Cancel
                                            </Button>
                                            <Button
                                                onClick={() => {
                                                    setOpenVehicleReAssign(false)
                                                }}
                                                color="secondary" autoFocus>
                                                Deactivate
                                            </Button>
                                        </DialogActions>
                                    </Dialog>
                                    <IconButton
                                        onClick={() => {
                                            setOpenBatteryActive(true)
                                            setSerial(validateKeyData(value.serial_number))
                                        }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" />
                                    </IconButton>
                                    <Dialog
                                        fullScreen={fullScreen}
                                        open={openBatteryActive}
                                        maxWidth={"lg"}
                                        onClose={() => setOpenBatteryActive(false)}
                                        aria-labelledby="responsive-dialog-title"
                                        className={!fullScreen ? classes.dialog : null}
                                    >
                                        <DialogTitle id="responsive-dialog-title">{"Battery Activation"}</DialogTitle>
                                        <DialogContent>
                                            <DialogContentText>
                                                <Grid container spacing={2}>
                                                    <Grid item lg={12} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:</b> {validateKeyData(serial)}</Typography>

                                                    </Grid>
                                                </Grid>
                                            </DialogContentText>
                                        </DialogContent>
                                        <DialogActions>
                                            <Button autoFocus
                                                onClick={() => setOpenBatteryActive(false)}
                                                color="primary">
                                                Cancel
                                            </Button>
                                            <Button autoFocus
                                                onClick={() => setOpenBatteryActive(false)}
                                                color="secondary">
                                                Activate
                                            </Button>
                                        </DialogActions>
                                    </Dialog>
                                </>
                            )
                        }
                        else {
                            return (
                                <><IconButton
                                    onClick={() => {
                                        setOpenEditBattery(true)
                                        setEditBatteryArray(value.bms_id)
                                    }}
                                ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                    <IconButton
                                        onClick={() => {
                                            setAddBatteryErrors(false)

                                            setOpenVehicleAssign(true)
                                            setSerial(validateKeyData(value.serial_number))
                                        }}><Icon icon="mdi:motorbike" color="#c4c4c4" width="30" height="30" />
                                    </IconButton>
                                    <Dialog
                                        fullScreen={fullScreen}
                                        open={openVehicleAssign}
                                        maxWidth={"lg"}
                                        onClose={() => setOpenVehicleAssign(false)}
                                        aria-labelledby="responsive-dialog-title"
                                        className={!fullScreen ? classes.dialog : null}
                                    >
                                        <DialogTitle id="responsive-dialog-title">{"Vehicle Assignment"}</DialogTitle>
                                        <DialogContent>
                                            <DialogContentText>
                                                <Grid container spacing={2}>
                                                    <Grid item lg={8} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:</b> {validateKeyData(serial)}</Typography>

                                                    </Grid>
                                                    <Grid item lg={8} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Vehicle Number:</b></Typography>
                                                        <Select className={classes.textField}>

                                                            <MenuItem value="">Select Vehicle</MenuItem>
                                                            {/* {allVehicles.map((vehicle) => { 
                                                            return (
                                                            <MenuItem value={vehicle[0]}>{vehicle[0]}</MenuItem>
    
                                                             )
                                                              }
                                                              )}  */}
                                                        </Select>
                                                    </Grid>
                                                </Grid>
                                            </DialogContentText>
                                        </DialogContent>
                                        <DialogActions>
                                            <Button autoFocus
                                                onClick={() => setOpenVehicleAssign(false)}
                                                color="primary">
                                                Cancel
                                            </Button>
                                            <Button
                                                onClick={() => {
                                                    setOpenVehicleAssign(false)
                                                }}
                                                color="secondary" autoFocus>
                                                Activate
                                            </Button>
                                        </DialogActions>
                                    </Dialog>
                                    <IconButton
                                        onClick={() => {
                                            setOpenBatteryActive(true)
                                            setSerial(validateKeyData(value.serial_number))
                                        }}><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                                    <Dialog
                                        fullScreen={fullScreen}
                                        open={openBatteryActive}
                                        maxWidth={"lg"}
                                        onClose={() => setOpenBatteryActive(false)}
                                        aria-labelledby="responsive-dialog-title"
                                        className={!fullScreen ? classes.dialog : null}
                                    >
                                        <DialogTitle id="responsive-dialog-title">{"Battery Activation"}</DialogTitle>
                                        <DialogContent>
                                            <DialogContentText>
                                                <Grid container spacing={2}>
                                                    <Grid item lg={12} xs={12}>
                                                        <Typography className={classes.secondaryTextG}><b style={{ color: '#00000080' }}>Serial Number:</b> {validateKeyData(serial)}</Typography>

                                                    </Grid>
                                                </Grid>
                                            </DialogContentText>
                                        </DialogContent>
                                        <DialogActions>
                                            <Button autoFocus
                                                onClick={() => setOpenBatteryActive(false)}
                                                color="primary">
                                                Cancel
                                            </Button>
                                            <Button autoFocus
                                                onClick={() => setOpenBatteryActive(false)}
                                                color="secondary">
                                                Activate
                                            </Button>
                                        </DialogActions>
                                    </Dialog>
                                </>
                            )
                        }


                    },

                },

            },

        ]

        const columsBMS = [
            {
                name: 'BMS Model',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography color='secondary' variant='subtitle2'>{validateKeyData(value)} </Typography>
                    )
                }
            },
            {
                name: 'Hardware',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            }, {
                name: 'OEM',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            },
            {
                name: 'Action',
                options: {
                    filter: true,
                    customBodyRender: (value) => {
                        // if (value === 'assign') {
                        return (
                            <><IconButton
                                onClick={() => {
                                    setOpenEditBMS(true)
                                    //     setAddBatteryErrors(false)
                                    setEditBMSSArray(value)
                                }}
                            ><Icon icon="bxs:edit-alt" color="#c4c4c4" width="30" height="30" /></IconButton>
                                {/* <IconButton><Icon icon="fluent:tab-arrow-left-20-filled" color="#82E219" width="30" height="30" /> </IconButton> */}
                            </>

                        )
                    }
                }
            },
        ]
        const dataModel = [
            ['Model 1', 'v12.00', 'v2', '50V', '10 Ah', '500 wh', 'Samsung', 'deactive'],
            ['Model 2', 'v12.30', 'v5', '20V', '10 Ah', '500 wh', 'Panasonic', 'deactive'],
            ['Model 3', 'v12.50', 'v2.1', '52V', '10 Ah', '500 wh', 'LG', 'deactive'],


        ];
        const options = {
            filterType: 'dropdown',
            responsive: 'vertical',
            print: true,
            rowsPerPage: 10,

            selectableRows: "none",
            // customToolbar: () => {
            //     return (
            //         value === 0 ?
            //             <CustomToolbar value={value} />
            //             : <CustomToolbarM value={value} />
            //     );
            // }

        };


        // return <h1>Hello World!</h1>;
        // const [finalCsv, setFinalCsv] = React.useState("")
        // const [csvUrl, setCsvUrl] = React.useState("")
        // const input = React.useRef()

        return (
            <div
                // onMouseMove={() => setFrame(!frame)}
                className={classes.table}>
                <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />

                {screen !== true ? <Typography className={classes.pageTitle} component="h4" variant="h4">Battery</Typography> :
                    <Typography className={classes.pageTitle} component="h4" variant="h4">Battery Profile</Typography>}

                <div style={{ display: 'flex', justifyContent: 'space-between' }}><>{screen !== true ?
                    <Tabs
                        className={classes.tabsSection}
                        value={value}
                        onChange={handleChange}
                        variant="fullWidth"
                        indicatorColor="primary"
                        aria-label="icon tabs example"
                    >
                        <Tab label="Battery" onClick={() => {
                            setScreen(false)
                        }} icon={<BatteryCharging30Icon />} aria-label="favorite" />
                        <Tab label="Model" onClick={() => {
                            setScreen(false)
                        }} icon={<TabIcon />} aria-label="phone" />
                        <Tab label="BMS Model" onClick={() => {
                            setScreen(false)
                        }} icon={<Icon icon="carbon:gui-management" height="25" width="25" />} aria-label="phone" />

                    </Tabs> : null}</>
                    <>{screen !== true ?
                        <>{value === 0 ?
                            <Tooltip style={{ flex: 'left' }} title={"Onboarding Battery"}>
                                <IconButton onClick={() => {
                                    setOpenAddBattery(true)
                                }}>
                                    <Icon icon="fluent:phone-add-24-regular" height="25" width="25" color="#b3d391" />
                                </IconButton></Tooltip>

                            : value === 1 ? <Tooltip style={{ flex: 'left' }} title={"Onboarding Model"}>
                                <IconButton onClick={() => {
                                    setOpenAddModel(true)
                                }}>
                                    <Icon icon="fluent:tab-add-24-filled" height="25" width="25" color="#b3d391" />
                                </IconButton></Tooltip>
                                : <Tooltip style={{ flex: 'left' }} title={"Onboarding Model"}>
                                    <IconButton onClick={() => {
                                        setOpenAddBMS(true)
                                    }}>
                                        <Icon icon="carbon:gui-management" height="25" width="25" color="#b3d391" />
                                    </IconButton></Tooltip>}</> : null}</></div>

                <Paper square className={classes.root}>
                    {csvDownload === 0 ? <LinearProgress /> : null}
                </Paper>
                {(screen !== true
                    // && (
                    // MyBatteryMetaPresent &&
                    // BatteryModelMetaPresent)
                ) ?
                    (
                        value === 0 ?
                            <MUIDataTable
                                checkboxSelection={false}
                                title="Battery"
                                // // data={data}
                                data={MyBatteryMeta.data}
                                columns={columnsBattery}
                                options={options}
                                selectableRowsHideCheckboxes
                            />
                            : value === 1 ? <>
                                <MUIDataTable
                                    checkboxSelection={false}
                                    title="MODEL"
                                    // data={dataModel}
                                    data={BatteryModelMeta.data}
                                    columns={columsModel}
                                    options={options}

                                />
                                <Typography>Page: {modelPage}</Typography>
                                <br />
                                <Pagination count={10} page={modelPage} onChange={changePageBatModel} />
                            </>
                                : <>
                                    <MUIDataTable
                                        checkboxSelection={false}
                                        title="BMS MODEL"
                                        // data={dataModel}
                                        data={BMSMeta.data}
                                        columns={columsBMS}
                                        options={options}

                                    />
                                    <Typography>Page: {bmsPage}</Typography>
                                    <br />
                                    <Pagination count={10} page={bmsPage} onChange={changePageBMS} />
                                </>


                    )
                    :
                    (
                        //     //     MyBatteryMetaPresent &&
                        BatteryProMeta.data && BatteryProMetaPresent) ?
                        (
                            <>

                                <div className={classes.BNcover}><div className={classes.BNopt}>
                                    {/* <a
                                 ref={input}
                                 href={csvUrl}
                                 download="filename.csv"
                               >link</a> */}
                                    {csvDownload === 0 ?
                                        <IconButton className={classes.BNbutton} >
                                            <Icon icon="line-md:downloading-loop" color="white" width="30" height="30" />
                                        </IconButton> :
                                        csvDownload === 1 ?
                                            <IconButton className={classes.BNbutton}

                                                onClick={() => {
                                                    downloadCsv()
                                                    setCsvDownload(0)
                                                }} >
                                                <Icon icon="fa:cloud-download" color="white" width="30" height="30" />
                                            </IconButton>


                                            :

                                            null
                                    }
                                    {/* <IconButton className={classes.BNbutton} >
                                    <Icon icon="fa:cloud-download" color="white" width="30" height="30" />
                                </IconButton> */}
                                    <IconButton onClick={() => {
                                        setValue(0)
                                        setScreen(false)
                                    }} className={classes.BNbutton} >
                                        <Icon icon="bi:arrow-left-circle-fill" width="26" height="26" />
                                    </IconButton>
                                </div>
                                    <div className={classes.BNcontent}>
                                        <div style={{ display: 'flex', justifyContent: 'center' }}>
                                            <Avatar className={classes.BNavatar}>
                                                <Icon icon="mdi:car-battery" width="40" height="40" />
                                            </Avatar></div>
                                        <Typography className={classes.BNname} gutterBottom>
                                            {validateKeyData(serial)}
                                        </Typography>
                                        <Typography className={classes.BNname} gutterBottom>
                                            {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_model"])}
                                        </Typography>
                                        <Typography className={classes.BNname} gutterBottom>
                                            {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["last_created_at"])}
                                            {/* {validateKeyData(currDate)}&nbsp;&nbsp;{validateKeyData(currTime)} */}
                                        </Typography>
                                    </div></div>

                                <AppBar position="static" className={classes.BNprofileTab}>
                                    <Tabs
                                        value={value}
                                        onChange={handleChangeT}
                                        variant="fullWidth"
                                        indicatorColor="primary"
                                        textColor="primary"
                                        centered

                                    >
                                        <Tab icon={<Icon icon="bxs:battery-charging" width="30" height="30" />} label="About" />
                                        <Tab icon={<Icon icon="ant-design:line-chart-outlined" width="30" height="30" />} label="Chart" />
                                        <Tab icon={<PhotoLibrary />} label="Parameters" />
                                    </Tabs>
                                </AppBar>
                                {BatteryProMeta.data && value === 0 &&
                                    <TabContainer><br />
                                        <Grid container spacing={2}>
                                            <Grid item xs={12} lg={6}>
                                                <Paper>
                                                    <ListItem>
                                                        <ListItemAvatar>
                                                            <Avatar className={classes.BNavatar1}>
                                                                <Icon icon="mdi:car-battery" color="#82e219" width="26" height="26" />
                                                            </Avatar>
                                                        </ListItemAvatar>

                                                        <ListItemText primary={
                                                            <Typography className={classes.BNaboutTxt}>About</Typography>
                                                        }
                                                            secondary={
                                                                <React.Fragment>
                                                                    <Typography className={classes.BNaboutTxt1} >
                                                                        <b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
                                                                            {validateKeyData(serial)}</b> of {BatteryProMeta.data && validateKeyData(BatteryProMeta.data && BatteryProMeta.data[0]["battery_model"])}  <br /> OnBoarded on {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["created_at"])}&nbsp;
                                                                        by&nbsp;<b style={{ color: '#82e219', textDecorationLine: 'underline' }}>
                                                                            {validateKeyData(operation)}</b></Typography>
                                                                </React.Fragment>

                                                            }
                                                        />
                                                    </ListItem><Divider className={classes.BNdivider} />
                                                    <Grid container spacing={1} className={classes.BNgrid}>
                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNavatar1}>
                                                                        <Icon icon="ion:hardware-chip-sharp" color="82e219" width="30" height="30" />
                                                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>HW Version</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography bmsid={bmsid}
                                                                                className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["hardware_version"])}</Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>
                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNavatar1}>
                                                                        <Icon icon="eos-icons:software-outlined" color="82e219" width="30" height="30" />                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>SW Version</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["software_version"])}</Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>
                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNavatar1}>
                                                                        <Icon icon="emojione-monotone:high-voltage" color="82e219" width="30" height="30" />
                                                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Battery Nominal Voltage</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["nominal_voltage"])}</Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>
                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNavatar1}>
                                                                        <Icon icon="mdi:chemical-weapon" color="82e219" width="30" height="30" />
                                                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Battery Chemistry</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["cell_chemisty"])}</Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>
                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNavatar1}>
                                                                        <Icon icon="carbon:cost-total" color="82e219" width="30" height="30" />
                                                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Battery pack Capacity</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["capacity_mah"])}</Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>
                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNavatar1}>
                                                                        <Icon icon="uil:cell" color="82e219" width="30" height="30" />
                                                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Cells in Series</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={classes.secondaryTextG}>
                                                                                {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["number_of_cells_series"])}
                                                                            </Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>
                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNavatar1}>
                                                                        <Icon icon="uil:cell" color="82e219" width="30" height="30" />
                                                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Thermistor</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={classes.secondaryTextG}>
                                                                                {BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["thermistor"])}
                                                                            </Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>
                                                    </Grid>
                                                </Paper>

                                            </Grid>

                                            <Grid item xs={12} lg={6}>
                                                <Paper style={{ height: '388px' }}>
                                                    <div style={{ display: 'flex', marginLeft: 10 }}>
                                                        <Typography className={classes.BNprimaryText}>Battery Current</Typography>
                                                        <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_current"])}</Typography> </div>

                                                    <div style={{ display: 'flex', margin: 10 }}>
                                                        <Typography className={classes.BNprimaryText}>Battery Voltage</Typography>
                                                        <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["battery_voltage"])}</Typography>
                                                    </div>

                                                    <div style={{ display: 'flex', margin: 10 }}>
                                                        <Typography className={classes.BNprimaryText}>Battery State</Typography>
                                                        <Typography className={classes.secondaryTextG}>{BatteryProMeta.data && validateKeyData(BatteryProMeta.data[0]["current_state"])}</Typography>
                                                    </div>

                                                    <br />
                                                    <Paper
                                                        className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNstyledPaper :
                                                            BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNstyledPaper2 : classes.BNstyledPaper3}
                                                        elevation={4}>
                                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                            <Typography className={classes.BNstateText}>State Of Health
                                                            </Typography>
                                                            <Chip
                                                                avatar={(
                                                                    <Avatar className={BatteryProMeta.data[0]["soh"] >= 80 ? classes.BNchip :
                                                                        BatteryProMeta.data[0]["soh"] <= 79 && BatteryProMeta.data[0]["soh"] >= 71 ? classes.BNchip2 : classes.BNchip3} >
                                                                        <Icon icon="ant-design:check-circle-outlined" color="white" width="30" height="30" />
                                                                    </Avatar>
                                                                )}
                                                                label={validateKeyData(BatteryProMeta.data[0]["soh"]) + "% Progress"}
                                                            />
                                                        </div>
                                                        <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soh"])} />
                                                    </Paper><br /><br />

                                                    <Paper
                                                        className={classes.BNstyledPaper}
                                                        elevation={4}>
                                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                            <Typography className={classes.BNstateText}>State Of Charge
                                                            </Typography>
                                                            <Chip
                                                                avatar={(
                                                                    <Avatar className={classes.BNchip}
                                                                    >
                                                                        <Icon icon="ant-design:check-circle-outlined" color="white" width="30" height="30" />
                                                                    </Avatar>
                                                                )}
                                                                label={validateKeyData(BatteryProMeta.data[0]["soc"]) + "% Progress"}
                                                            />
                                                        </div>
                                                        <LinearProgress variant="determinate" className={classes.BNprogressWidget} value={validateKeyData(BatteryProMeta.data[0]["soc"])} />
                                                    </Paper></Paper>
                                            </Grid>

                                            <Grid item xs={12} lg={6}>
                                                <Paper>
                                                    <ListItem>
                                                        <ListItemAvatar>
                                                            <Avatar className={classes.BNavatar1}>
                                                                <Icon icon="bi:flag-fill" color="#82e219" />
                                                            </Avatar>
                                                        </ListItemAvatar>

                                                        <ListItemText primary={
                                                            <Typography className={classes.BNprimaryText}>Voltage & Temperature</Typography>
                                                        } />
                                                    </ListItem>
                                                    <Grid container spacing={1}>
                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNpurpleAvatar}>
                                                                        <AcUnit />
                                                                    </Avatar>
                                                                </ListItemAvatar>
                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Min Voltage</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={
                                                                                    BatteryProMeta.data[0]["min_cell_voltage_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_voltage_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                                {/* {newStr} 
                                                                        &nbsp;-&nbsp;*/}
                                                                                {validateKeyData(BatteryProMeta.data[0]["min_voltage_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["min_voltage"])}&nbsp;V&nbsp;
                                                                            </Typography>

                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>

                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNpinkAvatar}>
                                                                        <AllInclusive />
                                                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Max Voltage</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={BatteryProMeta.data[0]["max_cell_voltage_color"] === "green" ? classes.voltageG : BatteryProMeta.data[0]["max_cell_voltage_color"] === "amber" ? classes.voltageY : classes.voltageR}>
                                                                                {/* {newStr} 
                                                                        &nbsp;-&nbsp;*/}
                                                                                {validateKeyData(BatteryProMeta.data[0]["max_voltage_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["max_voltage"])}&nbsp;V
                                                                            </Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>

                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNgreenAvatar}>
                                                                        <Adb /></Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Min Temperature</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={
                                                                                    BatteryProMeta.data[0]["min_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["min_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                                {/* {newStr2} 
                                                                        &nbsp;-&nbsp;*/}
                                                                                {validateKeyData(BatteryProMeta.data[0]["min_temperature_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["min_temperature"])}&nbsp;ºC
                                                                            </Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>

                                                        <Grid xs={12} lg={6}>
                                                            <ListItem>
                                                                <ListItemAvatar>
                                                                    <Avatar className={classes.BNorangeAvatar}>
                                                                        <AssistantPhoto />
                                                                    </Avatar>
                                                                </ListItemAvatar>

                                                                <ListItemText primary={
                                                                    <Typography className={classes.BNprimaryText}>Max Temperature</Typography>
                                                                }
                                                                    secondary={
                                                                        <React.Fragment>
                                                                            <Typography
                                                                                className={
                                                                                    BatteryProMeta.data[0]["max_cell_temp_color"] === "amber" ? classes.voltageY : BatteryProMeta.data[0]["max_cell_temp_color"] === "green" ? classes.voltageG : classes.voltageR}>
                                                                                {/* {newStr3} 
                                                                        &nbsp;-&nbsp;*/}
                                                                                {validateKeyData(BatteryProMeta.data[0]["max_temperature_cell"])}&nbsp;:&nbsp;{validateKeyData(BatteryProMeta.data[0]["max_temperature"])}&nbsp;ºC
                                                                            </Typography>
                                                                        </React.Fragment>

                                                                    }
                                                                />
                                                            </ListItem>
                                                        </Grid>
                                                    </Grid>
                                                </Paper>

                                            </Grid>
                                            <Grid item xs={12} lg={6}>
                                                <Paper className={classes.BNmap} variant="outlined" >
                                                    <SimpleMap
                                                        zoom={10} bmsid={bmsid}
                                                    /></Paper>
                                            </Grid>
                                        </Grid>
                                    </TabContainer>}
                                {value === 1 && <TabContainer><br />

                                    <><Grid item container spacing={2}>
                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.paper}><br /> <BatteryVoltage
                                                bmsid={bmsid}
                                                dataIndex={chartOneVal} /></Paper>
                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.paper}><br /><SOC bmsid={bmsid} dataIndex={chartOneVal} /></Paper>

                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.paper}><br /><TodayTripDistance bmsid={bmsid} dataIndex={chartOneVal} /></Paper>

                                        </Grid>

                                        <Grid item xs={12} lg={6}>
                                            <Paper className={classes.paper}><br /><BatteryCurrent bmsid={bmsid} dataIndex={chartOneVal} /></Paper>
                                        </Grid>
                                    </Grid></>
                                </TabContainer>}
                                {value === 2 && <TabContainer><br />
                                    <TreeTable bmsid={bmsid} />
                                </TabContainer>}



                            </>
                        )

                        : MyBatteryFetching ?
                            <Loading /> :
                            MyBatteryResponsecode === 500 ?

                                <ErrorWrap /> : <Loading />



                }

                {/* Add Battery */}
                <Dialog
                    fullScreen={fullScreen}
                    open={openAddBattery}
                    maxWidth={"lg"}
                    onClose={() => setOpenAddBattery(false)}
                    aria-labelledby="responsive-dialog-title"
                    className={!fullScreen ? classes.dialog : null}
                >
                    <DialogTitle id="responsive-dialog-title">{"Onboarding Battery"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            <Grid container spacing={2}>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Battery Model</Typography>
                                    {/* <TextField size="small" id="outlined" placeholder="eg: Battery Model" className={classes.textField} /> */}
                                    <Select onChange={(e) => {
                                        setBatteryAddFormArray(e, 'battery_model_id')
                                    }}
                                        error={addBatteryErrors && batteryAddForm.battery_model_id === ""}
                                        value={batteryAddForm.battery_model_id}
                                        className={classes.textField}>

                                        <MenuItem value="">Select Battery Model</MenuItem>
                                        {allModels.map((model) => {
                                            return (
                                                <MenuItem value={model[5]}>{model[0]}</MenuItem>

                                            )
                                        }
                                        )}
                                    </Select>
                                    {/* <TextField
                                    onChange={(e) => {
                                        setBatteryAddFormArray(e, 'battery_model')
                                    }}
                                    size="small" id="outlined" value={batteryAddForm.battery_model} placeholder="eg: Battery Model" className={classes.textField} /> */}
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Serial Number</Typography>
                                    <TextField error={addBatteryErrors && batteryAddForm.serial_number === ""}
                                        onChange={(e) => {
                                            setBatteryAddFormArray(e, 'serial_number')
                                        }}
                                        size="small" id="outlined" value={batteryAddForm.serial_number} placeholder="eg: Serial Number" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                                    <TextField error={addBatteryErrors && batteryAddForm.bms_unique_id === ""}
                                        onChange={(e) => {
                                            setBatteryAddFormArray(e, 'bms_unique_id')
                                        }}
                                        size="small" id="outlined" value={batteryAddForm.bms_unique_id} placeholder="eg: Unique Identifier" className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Battery Owner/Investor</Typography>
                                    <TextField error={addBatteryErrors && batteryAddForm.investor === ""}
                                        onChange={(e) => {
                                            setBatteryAddFormArray(e, 'investor')
                                        }}
                                        size="small" id="outlined" value={batteryAddForm.investor} placeholder="eg: Owner/Investor" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Battery Operation owner</Typography>
                                    <TextField error={addBatteryErrors && batteryAddForm.operation_owner === ""}
                                        onChange={(e) => {
                                            setBatteryAddFormArray(e, 'operation_owner')
                                        }}
                                        size="small" id="outlined" value={batteryAddForm.operation_owner} placeholder="eg: Operation owner" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Software Version</Typography>
                                    <TextField error={addBatteryErrors && batteryAddForm.sw_version === ""}
                                        onChange={(e) => {
                                            setBatteryAddFormArray(e, 'sw_version')
                                        }}
                                        size="small" id="outlined"
                                        value={batteryAddForm.sw_version}
                                        placeholder="eg: Software Version" className={classes.textField} />
                                </Grid>


                            </Grid>
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button autoFocus
                            onClick={() => setOpenAddBattery(false)}
                            color="primary">
                            Cancel
                        </Button>
                        <Button
                            onClick={() => {
                                handleSubmiAddBattery()
                            }}
                            color="secondary" autoFocus>
                            Submit
                        </Button>
                    </DialogActions>
                </Dialog>
                {/* Add Model */}
                <Dialog
                    fullScreen={fullScreen}
                    open={openAddModel}
                    maxWidth={"lg"}
                    style={{
                        height: '80%'
                    }}
                    onClose={() => setOpenAddModel(false)}
                    aria-labelledby="responsive-dialog-title"
                    className={!fullScreen ? classes.dialog : null}
                >
                    <DialogTitle id="responsive-dialog-title">{"Onboarding Model"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            {/* <AddModel /> */}
                            <Grid container spacing={2}>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>BMS Model</Typography>
                                    <Select 
                                    onChange={(e) => {
                                        setModelAddFormArray(e, 'bms_model_id')

                                    }}
                                    //     error={addBatteryErrors && modelAddForm.bms_model_id === ""}
                                    //     value={modelAddForm.bms_model_id}
                                        className={classes.textField}>

                                        <MenuItem value="">Select BMS Model</MenuItem>
                                        {allBMSData.map((bms) => {
                                            return (
                                                <MenuItem onClick={() => {
                                                   bms[0] !== 0 ? allHV(bms[0]) :null
                                                }} value={bms[3]}>{bms[0]}</MenuItem>

                                            )
                                        }
                                        )}
                                    </Select>
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Hardware Version</Typography>
                                    <Select
                                        onChange={(e) => {
                                            setModelAddFormArray(e, 'hw_version');
                                        }}
                                        // error={addBatteryErrors && modelAddForm.hw_version === ""}
                                        // value={modelAddForm.hw_version}
                                        className={classes.textField}>

                                        <MenuItem value="">Select Hardware Version</MenuItem>
                                        {modelHardware&&modelHardware.map((bms) => {
                                            return (
                                                <MenuItem onClick={() => {
                                                    // bms[0] !== 0 ?
                                                    allHW(bms)
                                                    //  :null 
                                                    
                                                }}
                                                value={bms}>{bms}</MenuItem>

                                            )
                                        }
                                        )}
                                        
                                    </Select>
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>OEM</Typography>
                                    <Select 
                                    // onChange={(e) => {
                                    //     setModelAddFormArray(e, 'oem')
                                    // }}
                                    //     error={addBatteryErrors && modelAddForm.oem === ""}
                                    //     value={modelAddForm.oem}
                                        className={classes.textField}>

                                        <MenuItem value="">Select OEM</MenuItem>
                                        {modelOem&&modelOem.map((bms) => {
                                            return (
                                                <MenuItem onClick={() => {
                                                    allOEM(bms)
                                                    
                                                }}value={bms}>{bms}</MenuItem>

                                            )
                                        }
                                        )}
                                    </Select>
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Model</Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setModelAddFormArray(e, 'model_info')
                                        }} error={addBatteryErrors && modelAddForm.model_info === ""}
                                        size="small" id="outlined" value={modelAddForm.model_info} placeholder="eg: Model" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12} >
                                    <Typography className={classes.tabHelp}>Voltage</Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'nominal_voltage')
                                    }}
                                        error={addBatteryErrors && modelAddForm.nominal_voltage === ""}
                                        size="small" id="outlined" value={modelAddForm.nominal_voltage} placeholder="eg: Voltage" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12} >
                                    <Typography className={classes.tabHelp}>Capacity</Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'capacity_mah')
                                    }}
                                        error={addBatteryErrors && modelAddForm.capacity_mah === ""}

                                        size="small" id="outlined" value={modelAddForm.capacity_mah} placeholder="eg: Capacity" className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Power</Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'power')
                                    }}
                                        error={addBatteryErrors && modelAddForm.power === ""}

                                        size="small" id="outlined" value={modelAddForm.power} placeholder="eg: Power" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Manufacturer </Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'cell_maufacturer')
                                    }}
                                        error={addBatteryErrors && modelAddForm.cell_maufacturer === ""}

                                        size="small" id="outlined" value={modelAddForm.cell_maufacturer} placeholder="eg: Manufacturer " className={classes.textField} />
                                </Grid>

                                {/* <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>OEM </Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'oem')
                                    }}
                                        error={addBatteryErrors && modelAddForm.oem === ""}

                                        size="small" id="outlined" value={modelAddForm.oem} placeholder="eg: OEM " className={classes.textField} />
                                </Grid> */}

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'number_of_cells_series')
                                    }}
                                        error={addBatteryErrors && modelAddForm.number_of_cells_series === ""}

                                        size="small" id="outlined" value={modelAddForm.number_of_cells_series} placeholder="eg: Number of Cells Series" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'number_of_cells_parallel')
                                    }}
                                        error={addBatteryErrors && modelAddForm.number_of_cells_parallel === ""}

                                        size="small" id="outlined" value={modelAddForm.number_of_cells_parallel} placeholder="eg: Number of Cells Parallel" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'cell_chemisty')
                                    }}
                                        error={addBatteryErrors && modelAddForm.cell_chemisty === ""}

                                        size="small" id="outlined" value={modelAddForm.cell_chemisty} placeholder="eg: Cell Chemistry" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Cell Type</Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'cell_type')
                                    }}
                                        error={addBatteryErrors && modelAddForm.cell_type === ""}

                                        size="small" id="outlined" value={modelAddForm.cell_type} placeholder="eg: Cell Type" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Length </Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'length')
                                    }}
                                        error={addBatteryErrors && modelAddForm.length === ""}

                                        size="small" id="outlined" value={modelAddForm.length} placeholder="eg: Length " className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Width </Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'width')
                                    }}
                                        error={addBatteryErrors && modelAddForm.width === ""}

                                        size="small" id="outlined" value={modelAddForm.width} placeholder="eg: Width " className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Height </Typography>
                                    <TextField onChange={(e) => {
                                        setModelAddFormArray(e, 'height')
                                    }}
                                        error={addBatteryErrors && modelAddForm.height === ""}

                                        size="small" id="outlined" value={modelAddForm.height} placeholder="eg: Height " className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Thermistor </Typography>
                                    <TextField
                                        error={addBatteryErrors && modelAddForm.thermistor === ""}

                                        onChange={(e) => {
                                            setModelAddFormArray(e, 'thermistor')
                                        }}
                                        size="small" id="outlined"
                                        value={modelAddForm.thermistor}
                                        placeholder="eg: thermistor " className={classes.textField} />
                                </Grid>
                                {/* <DialogTitle id="responsive-dialog-title">{"BMS Model"}</DialogTitle>
                                <Grid item lg={6} xs={12}></Grid>


                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>BMS Model </Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setModelAddFormArray(e, 'bms_model_id', 'bms')
                                        }}
                                        error={addBatteryErrors && modelAddForm.bms.bms_model_id === ""}

                                        size="small" id="outlined"
                                        value={modelAddForm.bms.bms_model_id}
                                        placeholder="eg: BMS Model " className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Hardware </Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setModelAddFormArray(e, 'hw_version', 'bms')
                                        }}
                                        error={addBatteryErrors && modelAddForm.bms.hw_version === ""}

                                        size="small" id="outlined"
                                        value={modelAddForm.bms.hw_version}
                                        placeholder="eg: Hardware " className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>OEM </Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setModelAddFormArray(e, 'oem', 'bms')
                                        }}
                                        error={addBatteryErrors && modelAddForm.bms.oem === ""}

                                        size="small" id="outlined"
                                        value={modelAddForm.bms.oem}
                                        placeholder="eg: OEM " className={classes.textField} />
                                </Grid> */}
                            </Grid>
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button autoFocus
                            onClick={() => setOpenAddModel(false)}
                            color="primary">
                            Cancel
                        </Button>
                        <Button
                            onClick={() => {
                                submitModel()
                            }}
                            color="secondary" autoFocus>
                            Submit
                        </Button>
                    </DialogActions>
                </Dialog>
                {/* Edit Model */}
                <Dialog
                    fullScreen={fullScreen}
                    open={openEditModel}
                    maxWidth={"lg"}
                    style={{
                        height: '80%'
                    }}
                    // data={BatteryModelDataRaw}
                    onClose={() => setOpenEditModel(false)}
                    aria-labelledby="responsive-dialog-title"
                    className={!fullScreen ? classes.dialog : null}
                >
                    <DialogTitle id="responsive-dialog-title">{"Edit Model"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            <Grid container spacing={2}>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>BMS Model</Typography>
                                    <TextField
                                        // onChange={(e) => {
                                        //     setModelEditFormArray(e, 'model_info')
                                        // }}
                                        // error={addBatteryErrors && editArray.model_info === ""}

                                        size="small" id="outlined"
                                        // value={editArray.model_info} 
                                        className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Model</Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setModelEditFormArray(e, 'model_info')
                                        }}
                                        error={addBatteryErrors && editArray.model_info === ""}

                                        size="small" id="outlined"
                                        value={editArray.model_info} className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12} >
                                    <Typography className={classes.tabHelp}>Voltage</Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'nominal_voltage')
                                    }}
                                        error={addBatteryErrors && editArray.nominal_voltage === ""}

                                        size="small" id="outlined" value={editArray.nominal_voltage} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12} >
                                    <Typography className={classes.tabHelp}>Capacity</Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'capacity_mah')
                                    }}
                                        error={addBatteryErrors && editArray.capacity_mah === ""}

                                        size="small" id="outlined" value={editArray.capacity_mah} className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Power</Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'power')
                                    }}
                                        error={addBatteryErrors && editArray.power === ""}

                                        size="small" id="outlined" value={editArray.power} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Manufacturer </Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'cell_maufacturer')
                                    }}
                                        error={addBatteryErrors && editArray.cell_maufacturer === ""}

                                        size="small" id="outlined" value={editArray.cell_maufacturer} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>OEM </Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'oem')
                                    }}
                                        error={addBatteryErrors && editArray.oem === ""}

                                        size="small" id="outlined" value={editArray.oem} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Number of Cells Series</Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'number_of_cells_series')
                                    }}
                                        error={addBatteryErrors && editArray.number_of_cells_series === ""}

                                        size="small" id="outlined" value={editArray.number_of_cells_series} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'number_of_cells_parallel')
                                    }}
                                        error={addBatteryErrors && editArray.number_of_cells_parallel === ""}

                                        size="small" id="outlined" value={editArray.number_of_cells_parallel} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Cell Chemistry</Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'cell_chemisty')
                                    }}
                                        error={addBatteryErrors && editArray.cell_chemisty === ""}

                                        size="small" id="outlined" value={editArray.cell_chemisty} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Cell Type</Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'cell_type')
                                    }}
                                        error={addBatteryErrors && editArray.cell_type === ""}

                                        size="small" id="outlined" value={editArray.cell_type} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Length </Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'length')
                                    }}
                                        error={addBatteryErrors && editArray.length === ""}

                                        size="small" id="outlined" value={editArray.length} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Width </Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'width')
                                    }}
                                        error={addBatteryErrors && editArray.width === ""}

                                        size="small" id="outlined" value={editArray.width} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Height </Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'height')
                                    }}
                                        error={addBatteryErrors && editArray.height === ""}

                                        size="small" id="outlined" value={editArray.height} className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Thermistor </Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setModelEditFormArray(e, 'thermistor')
                                        }}
                                        error={addBatteryErrors && editArray.thermistor === ""}

                                        size="small" id="outlined"
                                        value={editArray.thermistor}
                                        className={classes.textField} />
                                </Grid>
                                {/* <DialogTitle id="responsive-dialog-title">{"BMS Model"}</DialogTitle>
                                <Grid item lg={6} xs={12}></Grid>


                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>BMS Model </Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'bms_model_id','bms')
                                    }}
                                    error={addBatteryErrors && editArray.bms_model_id === ""}
                                    // error={addBatteryErrors && editArray.bms.bms_model_id === ""}
                                    
                                    size="small" id="outlined" 
                                    value={editArray.bms_model_id} 
                                    // value={editArray.bms.bms_model_id} 
                                    className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Hardware </Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'hw_version','bms')
                                    }}
                                    error={addBatteryErrors && editArray.hw_version === ""}
                                    // error={addBatteryErrors && editArray.bms.hw_version === ""}
                                    
                                    size="small" id="outlined" 
                                    value={editArray.hw_version}
                                    // value={editArray.bms.hw_version}
                                     className={classes.textField} />
                                </Grid>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>OEM </Typography>
                                    <TextField onChange={(e) => {
                                        setModelEditFormArray(e, 'oem','bms')
                                    }} 
                                    error={addBatteryErrors && editArray.oem === ""}
                                    // error={addBatteryErrors && editArray.bms.oem === ""}
                                    
                                    size="small" id="outlined" 
                                    value={editArray.oem}
                                    // value={editArray.bms.oem}
                                     className={classes.textField} />
                                </Grid> */}
                            </Grid>
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button autoFocus onClick={() => setOpenEditModel(false)}
                            color="primary">
                            Cancel
                        </Button>
                        <Button onClick={() => {
                            submitModelEdit(true)
                        }}
                            color="secondary" autoFocus>
                            Submit
                        </Button>
                    </DialogActions>
                </Dialog>
                {/* Edit Battery */}
                <Dialog
                    fullScreen={fullScreen}
                    open={openEditBattery}
                    maxWidth={"lg"}
                    // data={BatteryModelDataRaw}
                    onClose={() => setOpenEditBattery(false)}
                    aria-labelledby="responsive-dialog-title"
                    className={!fullScreen ? classes.dialog : null}
                >
                    <DialogTitle id="responsive-dialog-title">{"Edit Battery"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            <Grid container spacing={2}>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Battery Model</Typography>
                                    {/* <Select
                                    onChange={(e) => { setEditBatteryFormArray(e, 'battery_model_id') }}
                                    value={editBatArray.battery_model_id}
                                    className={classes.textField}>

                                    <MenuItem value="">Select Battery Model</MenuItem>
                                   {allEditModel.map((model) => {
                                    return (
                                        <MenuItem value={model[0]}>{model[0]}</MenuItem>

                                    )
                                }
                                )} 
                                </Select> */}
                                    <TextField disabled size="small" id="outlined" value={editBatArray.battery_model}
                                        // onChange={(e) => { setEditBatteryFormArray(e, 'battery_model') }}
                                        className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Serial Number</Typography>
                                    <TextField error={addBatteryErrors && editBatArray.serial_number === ""} size="small" id="outlined" value={editBatArray.serial_number}
                                        onChange={(e) => { setEditBatteryFormArray(e, 'serial_number') }}
                                        className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                                    <TextField error={addBatteryErrors && editBatArray.bms_unique_id === ""} size="small" id="outlined" value={editBatArray.bms_unique_id}
                                        onChange={(e) => { setEditBatteryFormArray(e, 'bms_unique_id') }} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Battery Owner/Investor</Typography>
                                    <TextField size="small" id="outlined" value={editBatArray.investor} error={addBatteryErrors && editBatArray.investor === ""}
                                        onChange={(e) => { setEditBatteryFormArray(e, 'investor') }} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Battery Operation owner</Typography>
                                    <TextField size="small" id="outlined" value={editBatArray.operation_owner} error={addBatteryErrors && editBatArray.operation_owner === ""}
                                        onChange={(e) => { setEditBatteryFormArray(e, 'operation_owner') }} className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>Software Version</Typography>
                                    <TextField size="small" id="outlined" value={editBatArray.software_version} error={addBatteryErrors && editBatArray.sw_version === ""}
                                        onChange={(e) => { setEditBatteryFormArray(e, 'software_version') }} className={classes.textField} />
                                </Grid>


                            </Grid>
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button autoFocus onClick={() => setOpenEditBattery(false)}
                            color="primary">
                            Cancel
                        </Button>
                        <Button onClick={() => {
                            handleSubmitEditBattery()
                        }
                        }
                            color="secondary" autoFocus>
                            Submit
                        </Button>
                    </DialogActions>
                </Dialog>
                {/* Add BMS */}
                <Dialog
                    fullScreen={fullScreen}
                    open={openAddBMS}
                    maxWidth={"lg"}
                    style={{
                        height: '80%'
                    }}
                    onClose={() => setOpenAddBMS(false)}
                    aria-labelledby="responsive-dialog-title"
                    className={!fullScreen ? classes.dialog : null}
                >
                    <DialogTitle id="responsive-dialog-title">{"Onboarding BMS Model"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            {/* <AddModel /> */}
                            <Grid container spacing={2}>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>BMS Model Info</Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setBMSAddFormArray(e, 'model_info')
                                        }} error={addBatteryErrors && bmsAddForm.model_info === ""}
                                        size="small" id="outlined"
                                        value={bmsAddForm.model_info}
                                        placeholder="eg: BMS Model" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12} >
                                    <Typography className={classes.tabHelp}>Hardware Version</Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setBMSAddFormArray(e, 'hw_version')
                                        }} error={addBatteryErrors && bmsAddForm.hw_version === ""}
                                        size="small" id="outlined"
                                        value={bmsAddForm.hw_version}
                                        placeholder="eg: Version" className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12} >
                                    <Typography className={classes.tabHelp}>OEM</Typography>
                                    <TextField
                                        onChange={(e) => {
                                            setBMSAddFormArray(e, 'oem')
                                        }} error={addBatteryErrors && bmsAddForm.oem === ""}
                                        size="small" id="outlined"
                                        value={bmsAddForm.oem}
                                        placeholder="eg: OEM" className={classes.textField} />
                                </Grid>
                            </Grid>
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button autoFocus
                            onClick={() => setOpenAddBMS(false)}
                            color="primary">
                            Cancel
                        </Button>
                        <Button
                            onClick={() => {
                                submitBMS()
                                // setOpenAddBMS(false)
                            }}
                            color="secondary" autoFocus>
                            Submit
                        </Button>
                    </DialogActions>
                </Dialog>
                {/* Edit BMS */}
                <Dialog
                    fullScreen={fullScreen}
                    open={openEditBMS}
                    maxWidth={"lg"}
                    style={{
                        height: '80%'
                    }}
                    onClose={() => setOpenEditBMS(false)}
                    aria-labelledby="responsive-dialog-title"
                    className={!fullScreen ? classes.dialog : null}
                >
                    <DialogTitle id="responsive-dialog-title">{"Edit BMS Model"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            {/* <AddModel /> */}
                            <Grid container spacing={2}>
                                <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>BMS Model Info</Typography>
                                    <TextField error={addBatteryErrors && editBMSArray.model_info === ""}
                                        size="small" id="outlined" value={editBMSArray.model_info}
                                        onChange={(e) => { setEditBmsFormArray(e, 'model_info') }}
                                        className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12} >
                                    <Typography className={classes.tabHelp}>Hardware Version</Typography>
                                    <TextField error={addBatteryErrors && editBMSArray.hw_version === ""}
                                        size="small" id="outlined" value={editBMSArray.hw_version}
                                        onChange={(e) => { setEditBmsFormArray(e, 'hw_version') }}
                                        className={classes.textField} />
                                </Grid>

                                <Grid item lg={6} xs={12} >
                                    <Typography className={classes.tabHelp}>OEM</Typography>
                                    <TextField error={addBatteryErrors && editBMSArray.oem === ""}
                                        size="small" id="outlined" value={editBMSArray.oem}
                                        onChange={(e) => { setEditBmsFormArray(e, 'oem') }}
                                        className={classes.textField} />
                                </Grid>
                            </Grid>
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button autoFocus
                            onClick={() => setOpenEditBMS(false)}
                            color="primary">
                            Cancel
                        </Button>
                        <Button
                            onClick={() => {
                                submitEditBMS()
                            }}
                            color="secondary" autoFocus>
                            Submit
                        </Button>
                    </DialogActions>
                </Dialog>
                <br /><br />
                <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
            </div>
        );



    } else {
        return (
            <Loading />
        )
    }


}
