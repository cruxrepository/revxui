import React from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import { createTheme, withStyles } from '@material-ui/core/styles';
import ThemePallete from 'enl-api/palette/themePalette';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  CartesianAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { data4 } from './sampleData';
import { Typography } from '@material-ui/core';
import endpoints from '../../../endpoints/endpoints';
const theme = createTheme(ThemePallete.magentaTheme);
const color = ({
  primary: "#68A724",
  secondary: theme.palette.secondary.main,
});

const CustomizedLabel = props => {
  const {
    x,
    y,
    stroke,
    value
  } = props;
  return (
    <text x={x} y={y} dy={-4} fill={stroke} fillOpacity="0.8" fontSize={10} textAnchor="middle">
      {value}
    </text>
  );
};

CustomizedLabel.propTypes = {
  x: PropTypes.number,
  y: PropTypes.number,
  value: PropTypes.number,
  stroke: PropTypes.string,
};

CustomizedLabel.defaultProps = {
  x: 0,
  y: 0,
  value: 0,
  stroke: '#000'
};
const CustomizedLabelnew = (props) => {
  const { text } = props;
  return (
    <Typography>{text} </Typography>
  )
}

function Chart1(props) {
  const { imei } = props;
  const [graphData, setGraphData] = React.useState([]);

  React.useEffect(() => {
    let Url = endpoints.baseUrl + `/battery/dashboard/` + imei;
    axios.get(Url).then((response) => {
      setGraphData(response.data.data[2].temp)
    }).catch((error) => { })

  }, [])
  console.log('graphData', graphData)
  console.log('graphData.temp', graphData.temp)
  const data = [
    {
      time: "06 56 AM",
      cell_temp_1: 10,
      cell_temp_2: 20,
      cell_temp_3: 30,
      cell_temp_4: 10,
      cell_temp_5: 20,
      cell_temp_6: 40,
      cell_temp_7: 70,
      cell_temp_8: 50,
      cell_temp_9: 90
    },
    {
      time: "07 26 AM",
      cell_temp_1: 31,
      cell_temp_2: 31,
      cell_temp_3: 31,
      cell_temp_4: 31,
      cell_temp_5: 31,
      cell_temp_6: 31,
      cell_temp_7: 31,
      cell_temp_8: 31,
      cell_temp_9: 31
    },
    // add more data objects here...
  ];
  const lines = Object.keys(data[0]).filter(key => key !== 'time');
  return (
    <div>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart
          width="100%"
          height={250}
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 15,
            bottom: 5
          }}
        >
          <XAxis dataKey="time" tickLine={false} />
          <YAxis label={{ className: 'yaxix-value', value: 'Cell Temperature', angle: -90, position: 'insideLeft', marginLeft: '-10px' }} axisLine={false} tickSize={3} tickLine={false} tickFormatter={tick => `  ${tick}°C `} tick={{ stroke: 'none' }} />
          <Tooltip />
          {/* <Line dot={false} type="monotone" dataKey="battery_current" strokeWidth={3} stroke={color.primary} label={<CustomizedLabel stroke={color.primary} />} /> */}
          {lines.map((line, index) => (
            <Line
              key={index}
              dataKey={line}
              name={line}
              stroke={`#${Math.floor(Math.random() * 16777215).toString(16)}`}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// Chart1.propTypes = {
//   classes: PropTypes.object.isRequired,
// };

export default Chart1;