import React from "react";
import axios from 'axios';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { withStyles, makeStyles, useTheme, styled, useStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import AddModel from './AddModel';
import AddBattery from './AddBattery';
import { Icon } from '@iconify/react';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import classNames from 'classnames';
import { getBatteryModelBulk, getMyBatteryBulk } from '../../../redux/actions/asyncActions';
import { useDispatch, useSelector } from 'react-redux'; 
import endpoints from '../../../endpoints/endpoints';

export default function CustomToolbar() {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const [openAddBattery, setOpenAddBattery] = React.useState(false);

  const handleClick = () => {
  }
  const useStyles = makeStyles((theme) => ({
    IconButton: {
      '&:hover': {
        color: '#9ccc65'
      },
      transform: !fullScreen ? "translateX(-12em)" : null
    },
    textField: {
      width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
      'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    IconButton1: {
      '&:hover': {
        color: '#9ccc65'
      },
      transform: !fullScreen ? "translateX(-14em)" : null
    },
    dialog: {
      // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
      position: 'relative', marginLeft: '680px'
    }
  }));

  const MyBatteryData = useSelector((store) => store.myBattery)
  const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
  let MyBatteryMeta = useSelector((store) => store.myBattery)
  let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
  let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
  let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)

  const BatteryModelData = useSelector((store) => store.batteryModel)
  const BatteryModelDataRaw = useSelector((store) => store.batteryModel.rawData)
  let BatteryModelMeta = useSelector((store) => store.batteryModel)
  let BatteryModelFetching = useSelector((store) => store.batteryModel.fetching)
  let BatteryModelResponsecode = useSelector((store) => store.batteryModel.responseStatus)
  let BatteryModelMetaPresent = useSelector((store) => store.batteryModel.dataPresent)
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getMyBatteryBulk()); 
}, [dispatch, MyBatteryMetaPresent]);
  React.useEffect(() => {
    dispatch(getBatteryModelBulk());
}, [dispatch, BatteryModelMetaPresent]);

  let allModel = BatteryModelMeta.data
  const [batteryAddForm, setBatteryAddForm] = React.useState(
    {
      battery_model_id: "",
      serial_number: "",
      bms_unique_id: "", 
      investor: "",
      operation_owner: "" ,
      sw_version: ""       
    }
  ) 
  const submitBattery = () =>{
    const postBattery = endpoints.baseUrl + `/battery/post`;
    axios
    .post(postBattery, batteryAddForm)
    .then((response) => { 
        dispatch(getMyBatteryBulk());
  
    });
  }
   const setBatteryAddFormArray = (e, key) => {
    setBatteryAddForm((state) => ({ ...state, [key]: e.target.value }));
  
    }

  
  const classes = useStyles();
  // const [value, setValue] = React.useState(0);
  // const [valuee, setValuee] = React.useState(0);
  const [hardware, setHardware] = React.useState('');
  const [software, setSoftware] = React.useState('');
  const [cellmanufact, setCellmanufact] = React.useState('');
 

   
  const handleChange1 = (event) => {
    setHardware(event.target.value);
  };
  const handleChange2 = (event) => {
    setSoftware(event.target.value);
  };
  const handleChange3 = (event) => {
    setCellmanufact(event.target.value);
  };
  
  return (
    <React.Fragment>
      <Tooltip style={{ flex: 'left' }} title={"Onboarding Battery"}>
      <IconButton className={classes.IconButton} onClick={() => setOpenAddBattery(true)}>
      <Icon icon="fluent:phone-add-24-regular" />
        </IconButton>
      </Tooltip>
      
      <Dialog
        fullScreen={fullScreen}
        open={openAddBattery}
        maxWidth={"lg"}
        onClose={() => setOpenAddBattery(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Onboarding Battery"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
           <Grid container spacing={2}>
                <Grid item lg={6} xs={12}>
                    <Typography className={classes.tabHelp}>Battery Model</Typography>
                    {/* <TextField size="small" id="outlined" placeholder="eg: Battery Model" className={classes.textField} /> */}
                    <Select onChange={(e) => {
                      setBatteryAddFormArray(e,'battery_model_id')}}
                     value={batteryAddForm.battery_model_id} 
                  className={classes.textField}>

                  <MenuItem value="">Select Battery Model</MenuItem>
                  {/* {allModel.map((model) => { 
                    return (
                      <MenuItem value={model[0]}>{model[0]}</MenuItem>

                    )
                  }
                  )} */}
                </Select>
                </Grid>

                <Grid item lg={6} xs={12}>
                    <Typography className={classes.tabHelp}>Serial Number</Typography>
                    <TextField
                  onChange={(e) => {
                    setBatteryAddFormArray(e, 'serial_number')
                  }}
                  size="small" id="outlined" value={batteryAddForm.serial_number} placeholder="eg: Serial Number" className={classes.textField} /> 
                </Grid>

                <Grid item lg={6} xs={12}>
                    <Typography className={classes.tabHelp}>Battery Unique Identifier</Typography>
                    <TextField
                  onChange={(e) => {
                    setBatteryAddFormArray(e, 'bms_unique_id')
                  }}
                  size="small" id="outlined" value={batteryAddForm.bms_unique_id} placeholder="eg: Unique Identifier" className={classes.textField} /> 
                </Grid>
                <Grid item lg={6} xs={12}>
                    <Typography className={classes.tabHelp}>Battery Owner/Investor</Typography>
                    <TextField
                  onChange={(e) => {
                    setBatteryAddFormArray(e, 'investor')
                  }}
                  size="small" id="outlined" value={batteryAddForm.investor} placeholder="eg: Owner/Investor" className={classes.textField} /> 
                </Grid>

                <Grid item lg={6} xs={12}>
                    <Typography className={classes.tabHelp}>Battery Operation owner</Typography>
                    <TextField
                  onChange={(e) => {
                    setBatteryAddFormArray(e, 'operation_owner')
                  }}
                  size="small" id="outlined" value={batteryAddForm.operation_owner} placeholder="eg: Operation owner" className={classes.textField} />
                </Grid>

                <Grid item lg={6} xs={12}>
                    <Typography className={classes.tabHelp}>Software Version</Typography>
                    <TextField
                  onChange={(e) => {
                    setBatteryAddFormArray(e, 'sw_version')
                  }}
                  size="small" id="outlined" 
                  value={batteryAddForm.sw_version} 
                  placeholder="eg: Software Version" className={classes.textField} />
                </Grid>
               

            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenAddBattery(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            onClick={() => {
              submitBattery(true)
              setOpenAddBattery(false) 
            }} 
            color="secondary" autoFocus>
            Submit
          </Button>
        </DialogActions>
      </Dialog>
 
    </React.Fragment>

  );


}

// export default withStyles(CustomToolbar, defaultToolbarStyles, { name: "CustomToolbar" });
