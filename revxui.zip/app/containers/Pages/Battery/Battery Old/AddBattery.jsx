// import React from 'react';
// import PropTypes from 'prop-types';
// import { withStyles, useTheme } from '@material-ui/core/styles';
// import useMediaQuery from '@material-ui/core/useMediaQuery';
// import Grid from '@material-ui/core/Grid';
// import Typography from '@material-ui/core/Typography';
// import FormControl from '@material-ui/core/FormControl';
// import Select from '@material-ui/core/Select';
// import MenuItem from '@material-ui/core/MenuItem';
// import TextField from '@material-ui/core/TextField';
// import Box from '@material-ui/core/Box';
// import classNames from 'classnames';

// const styles = theme => ({
//     root: {
//         flexGrow: 1,
//     },
//     paper: {
//         padding: theme.spacing(2),
//         textAlign: 'center',
//         color: theme.palette.secondary.dark,
//         backgroundColor: theme.palette.secondary.light
//     },
//     textField: {
//         width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
//         'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
//     },
//     tabHelp: {
//         fontSize: '15px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
//     },
//     formControl: {
//         width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
//     },
//     autoComplete: {
//         '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
//     },
//     box: {
//         width:'500px'
//     },
//     box1: {
//         width:'300px'
//     },
// });

// function FullWidthGrid(props) {
//     const theme = useTheme();
//     const { classes } = props;
//     const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
//     const [value, setValue] = React.useState(0);
//     const [hardware, setHardware] = React.useState('');
//     const [software, setSoftware] = React.useState('');
//     const [cellmanufact, setCellmanufact] = React.useState('');

//     const handleChange1 = (event) => {
//         setHardware(event.target.value);
//     };
//     const handleChange2 = (event) => {
//         setSoftware(event.target.value);
//     };
//     const handleChange3 = (event) => {
//         setCellmanufact(event.target.value);
//     };
//     return (
//         <div className={classes.root}>
//             {/* <Box className={!fullScreen ? classes.box : classes.box1}> */}
//                 <Grid container spacing={2}>
//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Battery OEM</Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Battery OEM" className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12} >
//                     <Typography className={classes.tabHelp}>Battery Model Info</Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Battery Model Info" className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Hardware Version</Typography>
//                     <FormControl className={classNames(classes.formControl, classes.autoComplete)} size="small">
//                         <Select
//                             displayEmpty
//                             value={hardware}
//                             onChange={handleChange1}
//                         >
//                             <MenuItem value=""> Select Hardware Version</MenuItem>
//                             <MenuItem value={10}>Version 1.0</MenuItem>
//                             <MenuItem value={20}>Version 2.0</MenuItem>
//                             <MenuItem value={30}>Version 3.0</MenuItem>
//                         </Select>
//                     </FormControl>
//                 </Grid>

//                 <Grid item lg={6} xs={12} >
//                     <Typography className={classes.tabHelp}>Software Version</Typography>
//                     <FormControl className={classNames(classes.formControl, classes.autoComplete)} size="small">
//                         <Select
//                             displayEmpty
//                             value={software}
//                             onChange={handleChange2}
//                         >
//                             <MenuItem value=""> Select Software Version</MenuItem>
//                             <MenuItem value={10}>Version 1.0</MenuItem>
//                             <MenuItem value={20}>Version 2.0</MenuItem>
//                             <MenuItem value={30}>Version 3.0</MenuItem>
//                         </Select>
//                     </FormControl>
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Nominal Voltage</Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Nominal Voltage" className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Capacity </Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Capacity " className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Power </Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Power " className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Number of Cells Series</Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Number of Cells Series" className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Number of Cells Parallel</Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Number of Cells Parallel" className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Cell Manufacturer</Typography>
//                     <FormControl className={classNames(classes.formControl, classes.autoComplete)} size="small">
//                         <Select
//                             displayEmpty
//                             value={cellmanufact}
//                             onChange={handleChange3}
//                         >
//                             <MenuItem value=""> Select Cell Manufacturer</MenuItem>
//                             <MenuItem value={10}>Version 1.0</MenuItem>
//                             <MenuItem value={20}>Version 2.0</MenuItem>
//                             <MenuItem value={30}>Version 3.0</MenuItem>
//                         </Select>
//                     </FormControl>
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Cell Chemistry</Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Cell Chemistry" className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Cell Type</Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Cell Type" className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Length </Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Length " className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Width </Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Width " className={classes.textField} />
//                 </Grid>

//                 <Grid item lg={6} xs={12}>
//                     <Typography className={classes.tabHelp}>Height </Typography>
//                     <TextField size="small" id="outlined" placeholder="eg: Height " className={classes.textField} />
//                 </Grid>

                

//             </Grid>
//             {/* </Box> */}
//         </div>
//     );
// }

// FullWidthGrid.propTypes = {
//     classes: PropTypes.object.isRequired,
// };

// export default withStyles(styles)(FullWidthGrid);
