export const data1 = [
  {
    name: "9 AM",

    percentage: 10,
  },
  {
    name: "10 AM",

    percentage: 18,
  },
  {
    name: "11 AM",

    percentage: 35,
  },
  {
    name: "12 AM",

    percentage: 40,
  },
  {
    name: "1 PM",

    percentage: 57,
  },
  {
    name: "2 PM",

    percentage: 70,
  },
  {
    name: "3 PM",

    percentage: 80,
  },
  {
    name: "4 PM",

    percentage: 100,
  },
];
export const data2 = [
  {
    name: "9 AM",

    percentage: 10,
  },
  {
    name: "10 AM",

    percentage: 18,
  },
  {
    name: "11 AM",

    percentage: 35,
  },
  {
    name: "12 AM",

    percentage: 40,
  },
  {
    name: "1 PM",

    percentage: 57,
  },
  {
    name: "2 PM",

    percentage: 70,
  },
  {
    name: "3 PM",

    percentage: 80,
  },
  {
    name: "4 PM",

    percentage: 100,
  },
];
export const data3 = [
  {
    name: "9 AM",

    percentage: 10,
  },
  {
    name: "10 AM",

    percentage: 18,
  },
  {
    name: "11 AM",

    percentage: 35,
  },
  {
    name: "12 AM",

    percentage: 40,
  },
  {
    name: "1 PM",

    percentage: 57,
  },
  {
    name: "2 PM",

    percentage: 70,
  },
  {
    name: "3 PM",

    percentage: 80,
  },
  {
    name: "4 PM",

    percentage: 100,
  },
];
export const data4 = [
  {
    name: "9 AM",

    percentage: 10,
  },
  {
    name: "10 AM",

    percentage: 18,
  },
  {
    name: "11 AM",

    percentage: 35,
  },
  {
    name: "12 AM",

    percentage: 40,
  },
  {
    name: "1 PM",

    percentage: 57,
  },
  {
    name: "2 PM",

    percentage: 70,
  },
  {
    name: "3 PM",

    percentage: 80,
  },
  {
    name: "4 PM",

    percentage: 100,
  },
];