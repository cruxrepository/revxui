const styles = {
  chartFluid: {
    width: '100%',
    // boxShadow:'2px 2px 2px #cfcfcf',
    fontSize:16,
    // minWidth: 400,
    maxWidth: 800,
    height: 430,
    color: '#9A9F9C'
  }
};

export default styles;
