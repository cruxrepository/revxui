import React from "react";
// import GoogleMapReact from "google-map-react";
import { GoogleMap,LoadScript, Marker } from '@react-google-maps/api';
import { Link } from "react-router-dom";
import endpoints from "../../../endpoints/endpoints";
export default function MyComponent(props) {

const markerStyle = {
  position: "absolute",
  top: "100%",
   left: "50%",
  transform: "translate(-50%, -100%)"
};
const containerStyle = {
  width: '100%',
  height: '100%'
};
  let  defaultProps = {
    center: {
      lat:11.004556,
      lng:76.961632
      
    },
    zoom:10
  };

  
   
  const [newLat, setNewLat] = React.useState(26.772);
  const [newLan, setNewLan] = React.useState(80.214);

  // const map = useGoogleMap()

  // React.useEffect(() => {
  //   if (map) {
  //     map.panTo(center)
  //   }
  // }, [map])

  const center = {
    lat: newLat,
    lng: newLan
    // lat: 26.772,
    // lng: 80.214
  };
    return (
      // Important! Always set the container height explicitly
      // <div style={{ height: "100%", width: "100%" }}>
        <LoadScript
      googleMapsApiKey="AIzaSyDTqXNwhdiuyeCvRCvFkbPj8NxXpTTHsJU"
    >
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        // panTo={center}
        zoom={10}
      // onClick={(ev) => {
      //     setLattitude(ev.latLng.lat())
      //     setLongitude(ev.latLng.lng())
      //   }}
      />


     

       
    </LoadScript>
      // </div>
    );
  }
 

