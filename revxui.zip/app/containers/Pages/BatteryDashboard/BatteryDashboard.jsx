import React from "react";
import axios from 'axios';
import { makeStyles, useTheme, styled } from '@material-ui/core/styles';
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import CloseIcon from '@material-ui/icons/Close';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField } from "@material-ui/core/";
import InputAdornment from '@material-ui/core/InputAdornment';
import SearchIcon from '@material-ui/icons/Search';
import { IconButton } from "@material-ui/core/";
import colorfull from 'enl-api/palette/colorfull';
import classNames from 'classnames';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Divider from '@material-ui/core/Divider';
import Avatar from '@material-ui/core/Avatar';
import SimpleMap from "./BasicMap";
import Chart from './Chart';
// import RemoveCircleOutlinedIcon from '@material-ui/icons/RemoveCircleOutlined';
// import AccountCircle from '@material-ui/icons/AccountCircle';
import Brightness1Icon from '@material-ui/icons/Brightness1';
import endpoints from '../../../endpoints/endpoints';
import { setLiveTrackerList, setLiveTrackerSelected } from "../../../redux/actions/normalActions";
import { useDispatch, useSelector } from "react-redux";
import { Icon } from "@iconify/react";
import { LocalLibrary, Style } from "@material-ui/icons";

const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'left',
    color: theme.palette.text.secondary,
}));

export default function BatteryDashboard() {
    const dispatch = useDispatch()
    const logged_user = useSelector((store) => store.login.result);
    let enty = logged_user.entity_id
    const [currIndex, setCurrIndex] = React.useState({ asset_linkage_id: 14 });
    const [trackerSearch, setTrackerSearch] = React.useState("");
    const [zoomVar, setZoomVar] = React.useState(0);
    const theme = useTheme();
    const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

    const [trackerData, setTrackerData] = React.useState([]);
    const [trackerDetailData, setTrackerDetailData] = React.useState([]);
    const searchDriver = (e, asset_linkage_id) => {
        const getTrackerUrl = endpoints.baseUrl + `/driver/livetrackDetailViewNew/` + asset_linkage_id;
        axios.get(getTrackerUrl, { headers: { 'Authorization': 'bearer aeyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTMsIm1vYmlsZSI6OTg2NTkyNDk1NCwiZXhwIjoxNjUyODY0Nzc4fQ.qe8BWTkJ95KSFr9C0qfwlG3TiVuSFfJ83FBiAcjwIVM' } }).then((response) => {
            setCurrIndex(response.data.data)
            dispatch(setLiveTrackerSelected(response.data.data))
            dispatch(setLiveTrackerSelected(response.data.data))
        })
    }
    const [refreshRate, setRefreshRate] = React.useState(false);
    setTimeout(() => {
        setRefreshRate(!refreshRate)
    }, 60000)
    React.useEffect(() => {
        let alltrackerData = null;
        let enty1 = enty;

        const getTrackerUrl = endpoints.baseUrl + `/driver/livetracknew/` + enty1 + `?search=` + trackerSearch;
        axios.get(getTrackerUrl, { headers: { 'Authorization': 'bearer aeyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTMsIm1vYmlsZSI6OTg2NTkyNDk1NCwiZXhwIjoxNjUyODY0Nzc4fQ.qe8BWTkJ95KSFr9C0qfwlG3TiVuSFfJ83FBiAcjwIVM' } }).then((response) => {
            setTrackerData(response.data.data)
            alltrackerData = response.data;

            dispatch(setLiveTrackerList(trackerData, enty));

        }).catch((error) => {
            let status = null;
            let data = null;
            //If no response from server
            if (!error.response) {
                status = 500;
                data = "No response from server";
            } else {
                status = error.response.status;
                data = error.response.data;
            }
            // dispatch({
            //   type: "GET_ALL_ATTRIBUTE_DATA_OVERVIEW_FAILED",
            //   payload: { status, data },
            // });
        });


    }

        , [trackerSearch, refreshRate])


    const [zoom, setZoom] = React.useState(10);



    // const toNormCase = (word) => {

    //     return word ? word.substr(0, 1).toUpperCase() + word.substr(1) : null
    // }
    const validateKeyData = (key) => {
        return key ? key : "-";
    };
    const currDate = new Date().toLocaleDateString();
    const currTime = new Date().toLocaleTimeString();
    return (
        <>

            <Grid container spacing={2}>
                <Grid item xs={12} lg={3}>
                    <Item style={{ backgroundColor: '#1c1f2420' }}>
                        <Typography style={{ fontSize: '16px', margin: 3, fontWeight: 600 }}>SoH</Typography>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <Typography variant="h2" style={{ fontWeight: 700, color: '#32ab9f' }}>9.65</Typography>
                            <br />
                            <Typography style={{ fontSize: '12px', margin: 3, fontWeight: 600 }}>At: 17-02-23 12:46:12</Typography></div>
                    </Item>
                </Grid>
                <Grid item xs={12} lg={3}>
                    <Item style={{ backgroundColor: '#1c1f2420' }}>
                        <Typography style={{ fontSize: '16px', margin: 3, fontWeight: 600 }}>SoP</Typography>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <Typography variant="h2" style={{ fontWeight: 700, color: '#32ab9f' }}>9.69</Typography>
                            <br />
                            <Typography style={{ fontSize: '12px', margin: 3, fontWeight: 600 }}>At: 17-02-23 12:46:12</Typography></div>
                    </Item>
                </Grid>
                <Grid item xs={12} lg={3}>
                    <Item style={{ backgroundColor: '#1c1f2420' }}>
                        <Typography style={{ fontSize: '16px', margin: 3, fontWeight: 600 }}>Available Energy</Typography>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <Typography variant="h2" style={{ fontWeight: 700, color: '#32ab9f' }}>2439</Typography>
                            <br />
                            <Typography style={{ fontSize: '12px', margin: 3, fontWeight: 600 }}>At: 17-02-23 12:46:12</Typography></div>
                    </Item>
                </Grid>
                <Grid item xs={12} lg={3}>
                    <Item style={{ backgroundColor: '#1c1f2420' }}>
                        <Typography style={{ fontSize: '16px', margin: 3, fontWeight: 600 }}>Consumed Energy</Typography>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <Typography variant="h2" style={{ fontWeight: 700, color: '#32ab9f' }}>2975</Typography>
                            <br />
                            <Typography style={{ fontSize: '12px', margin: 3, fontWeight: 600 }}>At: 17-02-23 12:46:12</Typography></div>
                    </Item>
                </Grid>
                <Grid item xs={12} lg={3}>
                    <Item style={{ backgroundColor: '#1c1f2420' }}>
                        <Typography style={{ fontSize: '16px', margin: 3, fontWeight: 600 }}>Temepratures</Typography>
                        <Chart/>
                    </Item>
                </Grid>
                <Grid item xs={12} lg={4}>
                    <Item style={{ backgroundColor: '#1c1f2420' }}>
                        <Typography style={{ fontSize: '16px', margin: 3, fontWeight: 600 }}>Cell temperatures</Typography>
                        <Chart/>
                    </Item>
                </Grid>
                <Grid item xs={12} lg={5}>
                    <Item style={{ backgroundColor: '#1c1f2420' }}>
                        <Typography style={{ fontSize: '16px', margin: 3, fontWeight: 600 }}>Cell Voltage</Typography>
                        <Chart/>
                    </Item>
                </Grid>
            </Grid>



            <br />
            <Typography align="center" style={{ fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap' }} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
        </>
    )
};