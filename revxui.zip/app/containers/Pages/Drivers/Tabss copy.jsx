import * as React from 'react';
import PropTypes from 'prop-types';
import SwipeableViews from 'react-swipeable-views';
import { styled, useTheme, makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
// import Autocomplete from '@material-ui/core/Autocomplete';
import next from './imgs/next.svg';
import Button from '@material-ui/core/Button';
import back from './imgs/back.svg';
import logo28 from './imgs/cam.svg';
import InputBase from '@material-ui/core/InputBase';
import Paper from '@material-ui/core/Paper';
import IconButton from '@material-ui/core/IconButton';
import useMediaQuery from "@material-ui/core/useMediaQuery";
import logox from './imgs/x.svg';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import SimpleSnackbar from '../Users/SimpleSnackbar';

import Select from '@material-ui/core/Select';
import './App.css';

import axios from 'axios';
import endpoints from '../../../endpoints/endpoints';
import { getDriverBulk } from "../../../redux/actions/asyncActions";
import { useDispatch, useSelector, useState } from 'react-redux';


// import getDriverData from "../../../containers/Pages/Drivers/DriversTab";


const driver = [
    {
        value: 'CV Drivers',
        label: 'CV Drivers',
    },
    {
        value: 'Erick Drivers',
        label: 'Erick Drivers',
    },
];
const useStyles = makeStyles((theme) => ({
    tabBox: {
        backgroundColor: '#FFFFFF', border: 1, color: '#68A724', width: '95%'
    },
    addNew: {
        fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', marginLeft: 5, marginTop: 1
    },
    upload: {
        fontSize: '20px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#929191'
    },
    iconPad: {
        padding: '8px'
    },
    appBar: {
        backgroundColor: '#FFFFFF', boxShadow: '0px 0px 0px 0px'
    },
    tabS: {
        margin: 1, '.Mui-selected': { backgroundColor: '#68A72480', color: '#fff', border: 0 },
        // 'MuiTabs-root':{borderRadius:'10px solid'}
    },
    tabone: {
        border: '1px solid #F1F1F1', fontFamily: ' Maven Pro', borderColor: '#00000033', borderRadius: '10px 10px 0px 0px', color: '#000000'
    },
    taboneM: {
        border: '1px solid #F1F1F1', fontFamily: ' Maven Pro', borderColor: '#00000033', borderRadius: '10px 10px 0px 0px', color: '#000000',
        fontSize: '10px'
    },
    taboneMd: {
        border: '1px solid #F1F1F1', fontFamily: ' Maven Pro', borderColor: '#00000033', borderRadius: '10px 10px 0px 0px', color: '#000000',
        fontSize: '9px'
    },
    tabHelp: {
        fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
    },
    formControl: {
        width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
    },
    textField: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
        'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    textFieldUpload: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px'
    },
    addressPaper: {
        padding: '2px 4px', display: 'flex', alignItems: 'center', width: '100%', height: '70px',
        boxShadow: '0px 0px 0px 0px', border: '1px solid', color: '#C4C4C4', borderRadius: '9px'
    },
    back: {
        textTransform: 'capitalize', fontFamily: ' Maven Pro', fontSize: '22px', fontWeight: 400, color: '#7A7A7D'
    },
    backM: {
        textTransform: 'capitalize', fontFamily: ' Maven Pro', fontSize: '16px', fontWeight: 400, color: '#7A7A7D'
    },
    next: {
        textTransform: 'capitalize', fontFamily: ' Maven Pro', width: '110px', height: '40px', backgroundColor: '#4CAF50 !important',
        fontSize: '22px', color: '#FFFFFF', fontWeight: 700, fontFamily: ' Maven Pro', ":hover": { backgroundColor: '#4CAF50' }
    },
    nextM: {
        textTransform: 'capitalize', fontFamily: ' Maven Pro', width: '90px', height: '30px', backgroundColor: '#4CAF50',
        fontSize: '16px', color: '#FFFFFF', fontWeight: 700, ":hover": { backgroundColor: '#4CAF50' }
    },
    paperRoot: {
        '.MuiPaper-root.MuiPaper-elevation': { minWidth: '150px !important' }
    },
    select: {
        '.MuiSelect-select.MuiSelect-outlined.MuiOutlinedInput-input.MuiInputBase-input':
            { fontSize: '15px !important', marginLeft: '40px', color: '#C4C4C4' }
    },
    autoComplete: {
        '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
    },
    iconM: {
        marginLeft: '230px', marginTop: '-55px'
    },
    selected: {
        '.Mui-selected': { color: '#fff' }
    },
    marginLR: {
        marginLeft: '8px', marginRight: '8px'
    }

}));

function TabPanel(props) {
    const { setOpen, open, children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`full-width-tabpanel-${index}`}
            aria-labelledby={`full-width-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `full-width-tab-${index}`,
        'aria-controls': `full-width-tabpanel-${index}`,
    };
}

export default function FullWidthTabs(props) {

    // Add Driver
    const [stateC, setStateC] = React.useState(false);
    const [stateD, setStateD] = React.useState(false);
    const [stateE, setStateE] = React.useState(false);

    const [typeVar, setTypeVar] = React.useState([]);

    const handleChangeCheck = (event) => {
        let stateArr = typeVar;
        if (stateC === false) { stateArr.push("2W") } else {
            const index = stateArr.indexOf("2W");
            if (index > -1) {
                stateArr.splice(index, 1);
            }
        }

        setStateC(!stateC);
        setTypeVar(stateArr)

    };
    const handleChangeChecks = (event) => {
        let stateArr = typeVar;
        if (stateD === false) { stateArr.push("Eauto") } else {
            const index = stateArr.indexOf("Eauto");
            if (index > -1) {
                stateArr.splice(index, 1);
            }
        }
        setStateD(!stateD);

        setTypeVar(stateArr)
    };
    const handleChangeCheckss = (event) => {
        let stateArr = typeVar;
        if (stateE === false) { stateArr.push("L5com") } else {
            const index = stateArr.indexOf("L5com");
            if (index > -1) {
                stateArr.splice(index, 1);
            }
        }

        setStateE(!stateE);
        setTypeVar(stateArr)

        // stateE === true ? typeVar.push('L5-com') :  typeVar.pop('L5-com')
    };
    React.useEffect(() => {
        let stateArr = typeVar;
        let newVar = stateArr.toString()
        setDrivesrAddForm((state) => ({
            ...state,
            type: `${newVar}`
        }))
    }, [stateC, stateE, stateD])

    //  const [typeVarstr, setTypeVarstr] = React.useState("");
    const [driversAddForm, setDrivesrAddForm] = React.useState(
        {
            mobile: "",
            name: "",
            location_id: "2",
            role_id: "2",
            otp: "1234",
            type: "",
            language_id: "2",
            email: "",
            language: "",
            shift_time: "",
            primary_address: "",
            country: "",
            state: "",
            city: "",
            secondary_address: "",
            aadhar_number: "",
            pan_number: "",
            driving_license_number: "",
            aadhar: "",
            pan: "",
            driver_license: "",
            profile_pic: "",
            user_name: "dummy"
        }
    );


    let totaldrivers = useSelector((store) => store.driverAll.totalRecords)

    let drivers = useSelector((store) => store.driverAll.data.data)


    let driverPresent = useSelector((store) => store.driverAll.dataPresent)

    const [addResponse, setAddResponce] = React.useState("")
    const [addDriverErrors, setAddDriverErrors] = React.useState(false)
    const [countryList, setCountryList] = React.useState({});
    const [stateList, setStateList] = React.useState({});
    const [cityList, setCityList] = React.useState({});
    const [shiftList, setShiftList] = React.useState([]);
    const [languageList, setLanguageList] = React.useState([]);
    const dispatch = useDispatch();
    React.useEffect(() => {
        const getCountries = endpoints.baseUrl + `/country/list`;
        const getShifts = endpoints.baseUrl + `/driver/shift`;
        const getLang = endpoints.baseUrl + `/driver/getLanguage`;
        axios
            .get(getCountries)
            .then((response) => {
                // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
                setCountryList(response.data.data)
              
            }).catch((er) => {


            });
            axios
            .get(getShifts)
            .then((response) => {
                // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
                setShiftList(response.data.data)
              
            }).catch((er) => {


            });
            axios
            .get(getLang)
            .then((response) => {
                // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
                // console.log("response",response)
                setLanguageList(response.data)
              
            }).catch((er) => {


            });
        dispatch(getDriverBulk());
    }, [driverPresent]);

    const getStates = (cId) => {
        const getCountries = endpoints.baseUrl + `/state/list?country_id=` + cId;
        axios
            .get(getCountries)
            .then((response) => {
                // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
                setStateList(response.data.data)

            }).catch((er) => {


            });
    }

    const getCities = (sId) => {
        const getCountries = endpoints.baseUrl + `/city/list?state_id=` + sId;
        axios
            .get(getCountries)
            .then((response) => {
                // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
                setCityList(response.data.data)

            }).catch((er) => {


            });
    }
    const submitDriver = () => {
        if (driversAddForm.mobile && driversAddForm.name && driversAddForm.location_id && driversAddForm.role_id
            && driversAddForm.type && driversAddForm.language_id && driversAddForm.email
            && driversAddForm.language && driversAddForm.shift_time && driversAddForm.primary_address && driversAddForm.country
            && driversAddForm.state && driversAddForm.city && driversAddForm.secondary_address && driversAddForm.aadhar_number
            && driversAddForm.pan_number && driversAddForm.driving_license_number
            //  && driversAddForm.aadhar && driversAddForm.pan
            // && driversAddForm.driver_license && driversAddForm.profile_pic
        ) {
            const postDriver = endpoints.baseUrl + `/driver/add`;
            axios
                .post(postDriver, driversAddForm)
                .then((response) => {
                    // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
                    setAddDriverErrors(true);
                    dispatch(getDriverBulk());
                    response.status === 201 ? setAddResponce("New Driver Added Successfully") : setAddResponce("Something went wrong, Please try again..")
                    setDrivesrAddForm({
                        mobile: "",
                        name: "",
                        location_id: "2",
                        role_id: "2",
                        otp: "",
                        type: "",
                        language_id: "2",
                        email: "",
                        language: "",
                        shift_time: "",
                        primary_address: "",
                        country: "",
                        state: "",
                        city: "",
                        secondary_address: "",
                        aadhar_number: "",
                        pan_number: "",
                        driving_license_number: "",
                        aadhar: "",
                        pan: "",
                        driver_license: "",
                        profile_pic: "",
                        user_name: "dummy"
                    })
                    handleClose()

                });
            // setOpenAddBattery(false)

        } else {
            setAddDriverErrors(true);

            setAddResponce("Please fill the required fields")

        }

    }
    const setDriverAddFormArray = (e, key) => {
        setDrivesrAddForm((state) => ({ ...state, [key]: e.target.value }));

    }

    //

    const classes = useStyles();
    const { setOpen, open } = props;
    const theme = useTheme();
    const [value, setValue] = React.useState(0);
    const isMdUp = useMediaQuery(theme.breakpoints.up("md"));
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const handleChangeIndex = (index) => {

        if (index === 1) {
            if (driversAddForm.mobile && driversAddForm.name && driversAddForm.type && driversAddForm.email && driversAddForm.language && driversAddForm.shift_time) {
                setValue(index);
                scrollToTop()
            } else {
                setAddDriverErrors(true);
                setAddResponce("Please Fill the Required Fields")
            }
        } else if (index === 2) {
            if (driversAddForm.primary_address && driversAddForm.country
                && driversAddForm.state && driversAddForm.city && driversAddForm.secondary_address) {
                setValue(index);
                scrollToTop()
            } else {
                setAddDriverErrors(true);
                setAddResponce("Please Fill the Required Fields")
            }
        } else if (index === 3) {
            if (driversAddForm.aadhar_number
                && driversAddForm.pan_number && driversAddForm.driving_license_number
                // && driversAddForm.aadhar && driversAddForm.pan
                // && driversAddForm.driver_license && driversAddForm.profile_pic
            ) {
                // setValue(index);
                scrollToTop()
                submitDriver()
            } else {

                setAddDriverErrors(true);
                setAddResponce("Please Fill the Required Fields")
            }
        }
    }

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth' // for smoothly scrolling
        });
    };

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };


    const [driver, setDriver] = React.useState('');
    const [language, setLanguage] = React.useState('');
    const [shift, setShift] = React.useState('');
    const [country, setCountry] = React.useState('');
    const [state, setState] = React.useState('');
    const [city, setCity] = React.useState('');
    const [country1, setCountry1] = React.useState('');
    const [state1, setState1] = React.useState('');
    const [city1, setCity1] = React.useState('');

    const handleChange1 = (event) => {
        setDriver(event.target.value);
    };
    const handleChange2 = (event) => {
        setLanguage(event.target.value);
    };
    const handleChange3 = (event) => {
        setShift(event.target.value);
    };
    const handleChange4 = (event) => {
        setCountry(event.target.value);
    };
    const handleChange5 = (event) => {
        setState(event.target.value);
    };
    const handleChange6 = (event) => {
        setCity(event.target.value);
    };
    const handleChange7 = (event) => {
        setCountry1(event.target.value);
    };
    const handleChange8 = (event) => {
        setState1(event.target.value);
    };
    const handleChange9 = (event) => {
        setCity1(event.target.value);
    };

    const [file, setFile] = React.useState()

    function handleChangeProfile(event) {
        setFile(event.target.files[0])
      
        
        event.preventDefault()
        const url = endpoints.baseUrl +  '/upload';
        const formData = new FormData();
        formData.append('file', event.target.files[0]);
        formData.append('fileName', event.target.files[0].name);
        const config = {
          headers: {
            'content-type': 'multipart/form-data',
          },
        };
        axios.post(url, formData, config).then((response) => {
        //   console.log(response.data);
          setDrivesrAddForm((state) => ({ ...state, profile_pic : response.data }));
      
        });
      
      }
      function handleChangeAdhaar(event) {
        setFile(event.target.files[0])
      
        
        event.preventDefault()
        const url = endpoints.baseUrl +  '/upload';
        const formData = new FormData();
        formData.append('file', event.target.files[0]);
        formData.append('fileName', event.target.files[0].name);
        const config = {
          headers: {
            'content-type': 'multipart/form-data',
          },
        };
        axios.post(url, formData, config).then((response) => {
        //   console.log(response.data);
          setDrivesrAddForm((state) => ({ ...state, aadhar : response.data }));
      
        });
      
      }
      function handleChangePAN(event) {
        setFile(event.target.files[0])
      
        
        event.preventDefault()
        const url = endpoints.baseUrl +  '/upload';
        const formData = new FormData();
        formData.append('file', event.target.files[0]);
        formData.append('fileName', event.target.files[0].name);
        const config = {
          headers: {
            'content-type': 'multipart/form-data',
          },
        };
        axios.post(url, formData, config).then((response) => {
        //   console.log(response.data);
          setDrivesrAddForm((state) => ({ ...state, pan : response.data }));
      
        });
      
      }
      function handleChangeLicense(event) {
        setFile(event.target.files[0])
      
        
        event.preventDefault()
        const url = endpoints.baseUrl +  '/upload';
        const formData = new FormData();
        formData.append('file', event.target.files[0]);
        formData.append('fileName', event.target.files[0].name);
        const config = {
          headers: {
            'content-type': 'multipart/form-data',
          },
        };
        axios.post(url, formData, config).then((response) => {
        //   console.log(response.data);
          setDrivesrAddForm((state) => ({ ...state, driver_license : response.data }));
      
        });
      
      }
// console.log("driversAddForm",driversAddForm)
    return (
        <Box className={classes.tabBox} >
            <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={6000} setLoginSucess={setAddDriverErrors} loginSuccess={addDriverErrors} />

            <Typography align="top" className={classes.addNew} >Add New Driver</Typography>
            {isMdUp === true ? null : <IconButton className={isMdUp === false ? classes.iconM : null}
                onClick={handleClose} ><img src={logox} style={{ border: 1, borderRadius: '30px', backgroundColor: '#FFFFFF' }} /></IconButton>}

            <Typography align="center" className={classes.upload} >Upload Profile (Max 100KB)</Typography>
            <div align="center"><IconButton className={classes.iconPad} >
                <input onchange={handleChangeProfile}
                    // onChange={(e) => {
                    //     setDriverAddFormArray(e, 'profile_pic')
                    // }}
                    // value={driversAddForm.profile_pic}
                    type="file" style={{ opacity: 0, position: 'absolute' }} /><img src={logo28} /></IconButton></div>
            <Box className={classes.marginLR}><div><AppBar position="static" className={classes.appBar} >
                <Tabs setOpen={setOpen}
                    value={value}
                    onChange={handleChange}
                    indicatorColor="#000000"
                    color="#000000"
                    variant="fullWidth"
                    aria-label="full width tabs example"
                    className={classes.tabS}
                // className={classNames(classes.tabS, classes.selected)}
                >
                    <Tab className={isMdUp === false ? classes.taboneMd : classes.tabone}
                        label="PERSONAL INFORMATION" {...a11yProps(0)} />
                    <Tab className={isMdUp === false ? classes.taboneM : classes.tabone}
                        label="ADDRESS" {...a11yProps(1)} />
                    <Tab className={isMdUp === false ? classes.taboneM : classes.tabone}
                        label="KYC DOCUMENT" {...a11yProps(2)} />
                </Tabs>
            </AppBar></div></Box>


            <SwipeableViews
                axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
                index={value}
                onChangeIndex={handleChangeIndex}
            >

                <TabPanel setOpen={setOpen} value={value} index={0} dir={theme.direction}>
                    <Grid container spacing={2}>
                        <Grid item lg={12} xs={12}>
                            <Typography className={classes.tabHelp} >License Type</Typography>
                            {/*<FormControl className={classNames(classes.formControl, classes.autoComplete)} size="small">
                                <Select
                                    displayEmpty
                                    value={driversAddForm.type}
                                    // onChange={handleChange1}
                                    onChange={(e) => { handleChange1
                                        setDriverAddFormArray(e, 'type')
                                      }}

                                >
                                    <MenuItem value=""> Select your Driver </MenuItem>
                                    <MenuItem value={10}>CV 2W Driver</MenuItem>
                                    <MenuItem value={20}>CV 3W Driver</MenuItem>
                                    <MenuItem value={30}>Erick Driver</MenuItem>
                                </Select>
                            </FormControl> */}
                            <FormControlLabel
                                control={
                                    // {driversAddForm.type === "checked"?driversAddForm.type="2W": ""}
                                    <Checkbox
                                        // type="checkbox"
                                        checked={stateC}
                                        onChange={handleChangeCheck}
                                        name="2W"
                                        color="primary"
                                    // value={driversAddForm.type}

                                    />
                                }
                                label="2W"
                            />
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        // type="checkbox"
                                        checked={stateD}
                                        onChange={handleChangeChecks}
                                        name="Eauto"
                                        color="primary"
                                    // value={driversAddForm.type}
                                    />
                                }
                                label="Eauto"
                            />
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        // type="checkbox"
                                        checked={stateE}
                                        onChange={handleChangeCheckss}
                                        name="L5 Commericial Vehicle"
                                        color="primary"
                                    // value= {driversAddForm.type}
                                    />
                                }
                                label="L5 Commericial Vehicle"
                            />
                        </Grid>
                        <Grid item lg={6} xs={12} >
                            <Typography className={classes.tabHelp}>Driver Name</Typography>
                            <TextField
                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'name')
                                }}
                                error={addDriverErrors && driversAddForm.name === ""}
                                value={driversAddForm.name} required size="small" id="outlined" placeholder="eg: John smith" className={classes.textField} />

                        </Grid>

                        {/* <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>User Name</Typography>
                            <TextField
                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'user_name')
                                }}
                                value={driversAddForm.user_name} size="small" id="outlined" placeholder="eg: John smith" className={classes.textField} />
                        </Grid> */}

                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>Mobile Number</Typography>
                            <TextField
                                type='number'
                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'mobile')
                                }}
                                error={addDriverErrors && driversAddForm.mobile === ""}
                                value={driversAddForm.mobile} size="small" id="outlined" className={classes.textField} />
                        </Grid>



                        <Grid item lg={12} xs={12}>
                            <Typography className={classes.tabHelp}>Email</Typography>
                            <TextField
                                type='email'

                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'email')
                                }}
                                error={addDriverErrors && driversAddForm.email === ""}

                                value={driversAddForm.email} size="small" id="outlined" placeholder="eg: johnsmith781@gmail.com" className={classes.textField} />
                        </Grid>



                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>Language</Typography>
                            <FormControl className={classes.formControl} size="small">
                                <Select
                                    value={driversAddForm.language}
                                    // onChange={handleChange2}
                                    displayEmpty
                                    onChange={(e) => {
                                        handleChange2
                                        setDriverAddFormArray(e, 'language')
                                    }}
                                    error={addDriverErrors && driversAddForm.language === ""}

                                >
                                    <MenuItem value="">Select your language</MenuItem>
                                    {languageList && languageList.map((lang)=>{
                                    return(
                                        <MenuItem key={lang.language_id} value={lang.language_id}>{lang.language}</MenuItem>
                                    )
                                   })}
                                </Select>
                            </FormControl></Grid>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>Shift Time</Typography>
                            <FormControl className={classes.formControl} size="small">
                                <Select
                                    error={addDriverErrors && driversAddForm.shift_time === ""}
                                    value={driversAddForm.shift_time}
                                    // onChange={handleChange3}
                                    onChange={(e) => {
                                        handleChange3
                                        setDriverAddFormArray(e, 'shift_time')
                                    }}
                                    displayEmpty
                                >
                                    <MenuItem value="">Select your shift</MenuItem>
                                    {
                                                                    shiftList && shiftList.map((sh,i)=>{
                                                                    return(
<MenuItem value={sh.shift_id} key={i}>{sh.time}</MenuItem>
                                                                    )}
                                                                    )
                                                                   }
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                    <br />
                    <div style={{
                        display: 'flex', flexDirection: 'row', flexWrap: 'nowrap', alignContent: 'center',
                        justifyContent: 'space-around', alignItems: 'center'
                    }}>
                        <Button onClick={handleClose} className={isMdUp === true ? classes.back : classes.backM} >Cancel</Button>
                        <Button onClick={() => {
                            handleChangeIndex(1)
                        }} className={isMdUp === true ? classes.next : classes.nextM}>Next
                            <img src={next} style={{ marginLeft: 10 }} /></Button></div>
                </TabPanel>



                <TabPanel setOpen={setOpen} value={value} index={1} dir={theme.direction} >
                    <Grid container spacing={2}>
                        <Grid item lg={12} xs={12}  >
                            <Typography className={classes.tabHelp}>Primary Address</Typography>
                            <Paper
                                component="form" className={classes.addressPaper}>
                                <InputBase
                                    onChange={(e) => {
                                        setDriverAddFormArray(e, 'primary_address')
                                    }}
                                    error={addDriverErrors && driversAddForm.primary_address === ""}
                                    value={driversAddForm.primary_address}
                                    fullWidth={true} />

                            </Paper>
                        </Grid>




                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>Country</Typography>
                            <Select
                                style={{ minWidth: '100%' }}
                                error={addDriverErrors && driversAddForm.country === ""}
                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'country');
                                    getStates(e.target.value)
                                }}
                                
                                value={driversAddForm.country}  
                                displayEmpty
                                >
                                   <MenuItem
                                       value=""
                                   >Select Country</MenuItem>
                                {
                                    countryList.length && countryList.map((el, i) => {

                                        return (
                                            <MenuItem
                                                key={i}
                                                value={el.country_id}
                                            >
                                                {el.country_name}
                                            </MenuItem>
                                        )
                                    })
                                }
                            </Select>
                            {/* <FormControl className={classes.formControl} size="small">
                                <Select
                                    value={driversAddForm.country}
                                    // onChange={handleChange4}
                                    displayEmpty
                                    onChange={(e) => {
                                        handleChange4
                                        setDriverAddFormArray(e, 'country')
                                    }}
                                >
                                    <MenuItem value="">Select your country</MenuItem>
                                    <MenuItem value={10}>India</MenuItem>
                                    <MenuItem value={20}>Afghanistan</MenuItem>
                                </Select>
                            </FormControl> */}
                        </Grid>

                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>State</Typography>
                            <FormControl className={classes.formControl} size="small">
                                <Select
                                    style={{ minWidth: '100%' }}
                                    error={addDriverErrors && driversAddForm.state === ""}
                                    value={driversAddForm.state}
                                    // onChange={handleChange5}
                                    onChange={(e) => {
                                        getCities(e.target.value)

                                        handleChange5
                                        setDriverAddFormArray(e, 'state')
                                    }} displayEmpty
                                     >
                                        <MenuItem
                                            value=""
                                        >Select State</MenuItem>
                                    {
                                        stateList.length && stateList.map((el, i) => {
                                            return (
                                                <MenuItem
                                                    key={i}
                                                    value={el.state_id}
                                                >
                                                    {el.state_name}
                                                </MenuItem>
                                            )
                                        })
                                    }
                                </Select>


                            </FormControl></Grid>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>City</Typography>
                            <FormControl className={classes.formControl} size="small">
                                <Select
                                    error={addDriverErrors && driversAddForm.city === ""}
                                    value={driversAddForm.city}
                                    // onChange={handleChange6}
                                    onChange={(e) => {
                                        handleChange6
                                        setDriverAddFormArray(e, 'city')
                                    }}
                                    displayEmpty
                                     >
                                        <MenuItem
                                            value=""
                                        >Select City</MenuItem>
                                    {
                                        cityList.length ? cityList.map((el, i) => {
                                            return (
                                                <MenuItem
                                                    key={i}
                                                    value={el.city_id}
                                                >
                                                    {el.city_name}
                                                </MenuItem>
                                            )
                                        }) : "Loading..."
                                    }

                                </Select>
                            </FormControl></Grid>



                        <Grid item lg={12} xs={12}>
                            <Typography className={classes.tabHelp}>Secondary Address</Typography>
                            <Paper
                                component="form" className={classes.addressPaper}>
                                <InputBase
                                    onChange={(e) => {
                                        setDriverAddFormArray(e, 'secondary_address')
                                    }}
                                    error={addDriverErrors && driversAddForm.secondary_address === ""}
                                    value={driversAddForm.secondary_address} fullWidth={true} />

                            </Paper>
                        </Grid>


                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>Country</Typography>
                            <Select
                                style={{ minWidth: '100%' }}
                                error={addDriverErrors && driversAddForm.country === ""}
                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'country');
                                    getStates(e.target.value)
                                }}
                                
                                value={driversAddForm.country}  
                                // defaultValue={0}

displayEmpty>
                                   <MenuItem
                                       value=""
                                   >Select Country</MenuItem>
                                {
                                    countryList.length && countryList.map((el, i) => {

                                        return (
                                            <MenuItem
                                                key={i}
                                                value={el.country_id}
                                            >
                                                {el.country_name}
                                            </MenuItem>
                                        )
                                    })
                                }
                            </Select>
                            {/* <FormControl className={classes.formControl} size="small">
                                <Select
                                    value={driversAddForm.country}
                                    // onChange={handleChange4}
                                    displayEmpty
                                    onChange={(e) => {
                                        handleChange4
                                        setDriverAddFormArray(e, 'country')
                                    }}
                                >
                                    <MenuItem value="">Select your country</MenuItem>
                                    <MenuItem value={10}>India</MenuItem>
                                    <MenuItem value={20}>Afghanistan</MenuItem>
                                </Select>
                            </FormControl> */}
                        </Grid>

                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>State</Typography>
                            <FormControl className={classes.formControl} size="small">
                                <Select
                                    style={{ minWidth: '100%' }}
                                    error={addDriverErrors && driversAddForm.state === ""}
                                    value={driversAddForm.state}
                                    // onChange={handleChange5}
                                    onChange={(e) => {
                                        getCities(e.target.value)

                                        handleChange5
                                        setDriverAddFormArray(e, 'state')
                                    }} displayEmpty
                                     >
                                        <MenuItem
                                            value=""
                                        >Select State</MenuItem>
                                    {
                                        stateList.length && stateList.map((el, i) => {
                                            return (
                                                <MenuItem
                                                    key={i}
                                                    value={el.state_id}
                                                >
                                                    {el.state_name}
                                                </MenuItem>
                                            )
                                        })
                                    }
                                </Select>


                            </FormControl></Grid>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>City</Typography>
                            <FormControl className={classes.formControl} size="small">
                                <Select
                                    error={addDriverErrors && driversAddForm.city === ""}
                                    value={driversAddForm.city}
                                    // onChange={handleChange6}
                                    onChange={(e) => {
                                        handleChange6
                                        setDriverAddFormArray(e, 'city')
                                    }}
                                    displayEmpty
                                     >
                                        <MenuItem
                                            value=""
                                        >Select City</MenuItem>
                                    {
                                        cityList.length ? cityList.map((el, i) => {
                                            return (
                                                <MenuItem
                                                    key={i}
                                                    value={el.city_id}
                                                >
                                                    {el.city_name}
                                                </MenuItem>
                                            )
                                        }) : "Loading..."
                                    }

                                </Select>
                            </FormControl></Grid>
                    </Grid>
                    <br />
                    <div style={{
                        display: 'flex', flexDirection: 'row', flexWrap: 'nowrap', alignContent: 'center',
                        justifyContent: 'space-around', alignItems: 'center'
                    }}>
                        <Button onClick={() => {
                            handleChangeIndex(0)
                        }} className={isMdUp === true ? classes.back : classes.backM}>
                            <img src={back} style={{ marginRight: '15px' }} /> Back</Button>
                        <Button onClick={() => {
                            handleChangeIndex(2)
                        }} className={isMdUp === true ? classes.next : classes.nextM}>Next
                            <img src={next} style={{ marginLeft: 20 }} /></Button></div>
                </TabPanel>




                <TabPanel setOpen={setOpen} value={value} index={2} dir={theme.direction}>
                    <Grid container spacing={2}>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>Aadhar Number</Typography>
                            <TextField
                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'aadhar_number')
                                }}
                                error={addDriverErrors && driversAddForm.aadhar_number === ""}
                                value={driversAddForm.aadhar_number} size="small" id="outlined" className={classes.textFieldUpload} />
                                 <FormControlLabel
                                  control={
                                    // {driversAddForm.type === "checked"?driversAddForm.type="2W": ""}
                                    <Checkbox
                                      // type="checkbox"
                                      checked={
                                        driversAddForm.address_proof === "aadhar"
                                      }
                                      onClick={() => {
                                        setDrivesrAddForm((state) => ({
                                          ...state,
                                          address_proof: "aadhar",
                                        }));
                                      }}
                                      // name="2W"
                                      // color="primary"
                                      // value={driversAddForm.type}
                                    />
                                  }
                                  label="Use aadhar as primary proof"
                                />
                        </Grid>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>Aadhar Image</Typography>
                            <Button sx={{ ":hover": { backgroundColor: '#fff' } }}>
                            <input onchange={handleChangeAdhaar}
                                    // onChange={(e) => {
                                    //     setDriverAddFormArray(e, 'aadhar')
                                    // }}
                                    // error={addDriverErrors && driversAddForm.aadhar === ""}
                                    // value={driversAddForm.aadhar}
                                    type="file" style={{ color: '#C1C1C1' }} /></Button>
                        </Grid>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>PAN Number</Typography>
                            <TextField
                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'pan_number')
                                }}
                                error={addDriverErrors && driversAddForm.pan_number === ""}
                                value={driversAddForm.pan_number} size="small" id="outlined" className={classes.textFieldUpload} />
                        </Grid>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>PAN Image</Typography>
                            <Button sx={{ ":hover": { backgroundColor: '#fff' } }}>
                            <input onchange={handleChangePAN}
                                    // onChange={(e) => {
                                    //     setDriverAddFormArray(e, 'pan')
                                    // }}
                                    // error={addDriverErrors && driversAddForm.pan === ""}
                                    // value={driversAddForm.pan}
                                    type="file" style={{ color: '#C1C1C1' }} /></Button>
                        </Grid>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>Driving License Number</Typography>
                            <TextField
                                onChange={(e) => {
                                    setDriverAddFormArray(e, 'driving_license_number')
                                }}
                                error={addDriverErrors && driversAddForm.driving_license_number === ""}
                                value={driversAddForm.driving_license_number} size="small" id="outlined" className={classes.textFieldUpload} />
                                  <FormControlLabel
                                  control={
                                    // {driversAddForm.type === "checked"?driversAddForm.type="2W": ""}
                                    <Checkbox
                                      // type="checkbox"
                                      checked={driversAddForm.address_proof === "dl"}
                                      onClick={() => {
                                        setDrivesrAddForm((state) => ({
                                          ...state,
                                          address_proof: "dl",
                                        }));
                                      }}
                                      // name="2W"
                                      // color="primary"
                                      // value={driversAddForm.type}
                                    />
                                  }
                                  label="Use DL as primary proof"
                                />
                        </Grid>
                        <Grid item lg={6} xs={12}>
                            <Typography className={classes.tabHelp}>License Image</Typography>
                            <Button sx={{ ":hover": { backgroundColor: '#fff' } }}>
                            <input onchange={handleChangeLicense}
                                    // onChange={(e) => {
                                    //     setDriverAddFormArray(e, 'driver_license')
                                    // }}
                                    // error={addDriverErrors && driversAddForm.driver_license === ""}
                                    // value={driversAddForm.driver_license}
                                    type="file" style={{ color: '#C1C1C1' }} /></Button>
                        </Grid>
                    </Grid>
                    <br />
                    <div style={{
                        display: 'flex', flexDirection: 'row', flexWrap: 'nowrap', alignContent: 'center',
                        justifyContent: 'space-around', alignItems: 'center'
                    }}>
                        <Button onClick={() => {
                            handleChangeIndex(1)
                        }} className={isMdUp === true ? classes.back : classes.backM}>
                            <img src={back} style={{ marginRight: '15px' }} />Back</Button>

                        <Button
                            // onClick={() => { handleClose() }} 
                            onClick={() => {
                                handleChangeIndex(3)
                                // handleClose()
                                // submitDriver(true)
                            }}
                            type="submit" className={isMdUp === true ? classes.next : classes.nextM}>
                            Submit</Button></div>
                </TabPanel>
            </SwipeableViews>
        </Box>
    );


}
