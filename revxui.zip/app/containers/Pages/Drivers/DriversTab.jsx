import React from "react";
import axios from "axios";
import DefaultProfile from './defaultImg/profile.png';
import { styled, useTheme, makeStyles } from "@material-ui/core/styles";
import useMediaQuery from "@material-ui/core/useMediaQuery";
// import CssBaseline from "@material-ui/core/CssBaseline";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Pagination from '@material-ui/lab/Pagination';
import Avatar from "@material-ui/core/Avatar";
import ListItemAvatar from "@material-ui/core/ListItemAvatar";
import logodr1 from "./imgs/dr1.svg";
import logodr2 from "./imgs/dr2.svg";
import logodr3 from "./imgs/dr3.svg";
import logodr4 from "./imgs/dr4.svg";
import IconButton from "@material-ui/core/IconButton";
import SearchIcon from "@material-ui/icons/Search";
import logox from "./imgs/x.svg";
import logofil from "./imgs/filter.svg";
import edit from "./imgs/edit.svg";
import menu from "./imgs/menu.svg";
import Button from "@material-ui/core/Button";
import Tabss from "./Tabss";
import profile from "./imgs/profile.svg";
import down from "./imgs/down.svg";
import { useNavigate } from "react-router-dom";
import Dialog from "@material-ui/core/Dialog";
import InputAdornment from "@material-ui/core/InputAdornment";
import TextField from "@material-ui/core/TextField";
import PropTypes from "prop-types";
import SwipeableViews from "react-swipeable-views";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import next from "./imgs/next.svg";
import back from "./imgs/back.svg";
import logo28 from "./imgs/cam.svg";
import InputBase from "@material-ui/core/InputBase";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Divider from "@material-ui/core/Divider";
import Select from "@material-ui/core/Select";
import classNames from "classnames";
import "./App.css";
import { Icon } from "@iconify/react";

import EditDriver from "./imgs/editdriver.svg";
import EditName from "./imgs/editname.svg";
import EditUser from "./imgs/edituser.svg";
import MobNum from "./imgs/mobNum.svg";
import EditMail from "./imgs/editMail.svg";
import EditLang from "./imgs/editLang.svg";
import EditTime from "./imgs/editTime.svg";
import Prime from "./imgs/editPrim.svg";
import Secondary from "./imgs/editSecon.svg";
import SimpleMap from "./SimpleMap";
// import Stepper from "./Stepper";
import Brightness1Icon from "@material-ui/icons/Brightness1";

import Timeline from "@material-ui/lab/Timeline";
import TimelineItem from "@material-ui/lab/TimelineItem";
import TimelineSeparator from "@material-ui/lab/TimelineSeparator";
import TimelineConnector from "@material-ui/lab/TimelineConnector";
import TimelineContent from "@material-ui/lab/TimelineContent";
import TimelineDot from "@material-ui/lab/TimelineDot";
import LocationOnOutlinedIcon from "@material-ui/icons/LocationOnOutlined";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { useDispatch, useSelector } from "react-redux";
import Loading from "../../../components/Loading";
import ErrorWrap from "../../../components/Error/ErrorWrap";
import { getDriverBulk } from "../../../redux/actions/asyncActions";
// import { getRolePerBulk } from "../../../redux/actions/asyncActions";
import SimpleSnackbar from "../Users/SimpleSnackbar";
import endpoints from "../../../endpoints/endpoints";
import { CircularProgress, DialogActions, DialogContent, DialogContentText, DialogTitle, Tooltip } from "@material-ui/core";
import Skeleton from '@material-ui/lab/Skeleton';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import { CloudDownload } from "@material-ui/icons";

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#ffffff" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "left",
  color: theme.palette.text.secondary,
}));

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  map: {
    height: 370,
    overflowY: "hidden",
    borderRadius: 2,
    position: "relative",
  },
  gridBG: {
    backgroundColor: "#F1F1F1",
    height: "670px",
  },
  lists: {
    color: "rgba(122, 122, 125, 1)",
    fontFamily: " Maven Pro",
  },
  txtField: {
    width: "22ch",
    borderRadius: "8px",
  },
  sevenDrive: {
    fontSize: "16px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#7A7A7D",
    marginLeft: "90px",
    marginTop: '10px',
    marginBottom: '5px',
  },
  primarytxt: {
    display: "inline",
    fontSize: "16px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#6C6C6C",
    marginLeft: "15px",
    textTransform: 'capitalize'
  },
  primarytxt2: {
    display: "inline",
    fontSize: "18px",
    fontFamily: "Roboto !important",
    fontWeight: 700,
    color: "#0000000",
    marginLeft: "10px",
  },
  secondarytxt: {
    display: "inline",
    fontSize: "14px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#7A7A7D",
    marginLeft: "15px",
  },
  secondarytxt1: {
    display: "inline",
    fontSize: "14px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#7A7A7D",
    marginLeft: "10px",
  },
  secondarytxt2: {
    display: "inline",
    fontSize: "14px",
    fontFamily: "Roboto",
    fontWeight: 500,
    color: "#828282",
    marginLeft: "10px",
  },
  mobile: {
    display: "inline",
    fontSize: "14px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#68A724",
    marginLeft: "10px",
  },
  colorYes: {
    width: "100%",
    height: "100%",
    backgroundColor: "#C4C4C4",
  },
  colorNo: {
    width: "100%",
    height: "100%",
    backgroundColor: "#F1F1F1",
  },
  mt: {
    height: "785px",
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  style1: {
    backgroundColor: "#FFFFFF",
    border: 1,
    color: "#68A724",
    width: "90%",
    borderRadius: '10px'
  },
  style2: {
    backgroundColor: "#FFFFFF",
    boxShadow: "0px 0px 0px 0px",
  },
  style3: {
    margin: 1,
    ".Mui-selected": { backgroundColor: "#68A72480", color: "#fff", border: 0 },
  },
  style4: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
  },
  style4M: {
    fontSize: "8px",
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
  },
  style5: {
    width: "100%",
    bgcolor: "#ffffff",
  },
  style6: {
    marginTop: "2px",
  },
  style6M: {
    fontSize: "12px",
  },
  style7: {
    display: "inline",
    fontSize: "16px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#6C6C6C",
    marginLeft: 2,
  },
  style7M: {
    display: "inline",
    fontSize: "12px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#6C6C6C",
    marginLeft: 2,
  },
  style8: {
    display: "inline",
    fontSize: "15px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#7A7A7D",
    marginLeft: 2,
  },
  style9: {
    fontSize: "15px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#68a724",
  },
  style9M: {
    fontSize: "12px",
    fontFamily: "Maven Pro",
    fontWeight: 700,
    color: "#6C6C6C",
  },
  style10: {
    display: "inline-block",
    fontSize: "15px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#68a724",
    width: '150px'
  },
  style10M: {
    display: "inline",
    fontSize: "12px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#68a724",
  },
  style11: {
    display: "inline",
    fontSize: "17px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#A7A7A7",
  },
  style11M: {
    display: "inline",
    fontSize: "14px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#A7A7A7",
  },
  style13: {
    display: "inline",
    color: "#A7A7A7",
  },
  style12: {
    color: "#000000",
  },
  style14: {
    border: 1,
    width: 80,
    height: 27,
    backgroundColor: "#AFB4AB",
    color: "#FFFDFD",
    ".MuiButtonBase-root": {
      ":hover": { backgroundColor: "#AFB4AB !important" },
    },
  },
  marginLR: {
    marginLeft: "8px",
    marginRight: "8px",
  },
  styleA: {
    backgroundColor: "#FFFFFF",
    border: 1,
    color: "#68A724",
    width: "90%",
    borderRadius: '10px'
  },
  styleB: {
    fontSize: "22px",
    fontFamily: " Maven Pro",
    fontWeight: 700,
    color: "#68A724",
    marginLeft: '10px',
    marginTop: '5px',
  },
  styleD: {
    fontSize: '18px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#929191'
  },
  styleE: {
    padding: "8px",
  },
  styleG: {
    backgroundColor: "#FFFFFF",
    boxShadow: "0px 0px 0px 0px",
  },
  styleH: {
    margin: 1,
    ".Mui-selected": { backgroundColor: "#68A72480", color: "#fff", border: 0 },
  },
  styleJ: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
  },
  styleK: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
    fontSize: "10px",
  },
  styleIM: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
    fontSize: "9px",
  },
  styleL: {
    fontSize: "16px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#A7A7A7",
  },
  styleM: {
    width: "100%",
    borderRadius: "9px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#7A7A7D  !important",
    },
  },
  styleO: {
    width: "100%",
    color: "#7A7A7D",
    borderRadius: "9px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#C4C4C4  !important",
    },
    "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
  },
  styleS: {
    width: "100%",
    color: "#7A7A7D",
    borderRadius: "9px",
  },
  styleR: {
    padding: "2px 4px",
    display: "flex",
    alignItems: "center",
    width: "100%",
    height: "70px",
    boxShadow: "0px 0px 0px 0px",
    border: "1px solid",
    color: "#C4C4C4",
    borderRadius: "9px",
  },
  styleP: {
    textTransform: "capitalize",
    fontFamily: " Maven Pro",
    fontSize: "22px",
    fontWeight: 400,
    color: "#7A7A7D",
  },
  stylePM: {
    textTransform: "capitalize",
    fontFamily: " Maven Pro",
    fontSize: "16px",
    fontWeight: 400,
    color: "#7A7A7D",
  },
  styleQ: {
    textTransform: "capitalize",
    fontFamily: " Maven Pro",
    width: "110px",
    height: "40px",
    backgroundColor: "#4CAF50 !important",
    fontSize: "22px",
    color: "#FFFFFF",
    fontWeight: 700,
    fontFamily: " Maven Pro",
    ":hover": { backgroundColor: "#4CAF50" },
  },
  styleQM: {
    textTransform: "capitalize",
    fontFamily: " Maven Pro",
    width: "90px",
    height: "30px",
    backgroundColor: "#4CAF50",
    fontSize: "16px",
    color: "#FFFFFF",
    fontWeight: 700,
    ":hover": { backgroundColor: "#4CAF50" },
  },
  paperRoot: {
    ".MuiPaper-root.MuiPaper-elevation": { minWidth: "150px !important" },
  },
  select: {
    ".MuiSelect-select.MuiSelect-outlined.MuiOutlinedInput-input.MuiInputBase-input": {
      fontSize: "15px !important",
      marginLeft: "40px",
      color: "#C4C4C4",
    },
  },
  styleN: {
    ".MuiPaper-root": { width: "80% !important", marginLeft: "60px" },
  },
  styleC: {
    marginLeft: "230px",
    marginTop: "-55px",
  },
  styleF: {
    marginLeft: "8px",
    marginRight: "8px",
  },
  tabBoxMM: {
    backgroundColor: "#FFFFFF",
    border: 1,
    color: "#68A724",
    width: "95%",
  },
  taboneMd: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
    fontSize: "9px",
  },
  GridPaper: {
    backgroundColor: "#FFFFFF",
  },
  tripText: {
    fontSize: "14px",
    color: "#000000",
    fontWeight: 600,
    marginLeft: 10,
  },
  primaryText: {
    fontFamily: "Open Sans",
    fontSize: "14px",
    fontWeight: 600,
    color: "primary",
    width: "300px",
  },
  secondaryText: {
    fontFamily: "Roboto",
    fontSize: "12px",
    fontWeight: 400,
    color: "#7A7A7D",
    width: "100%",
  },
  driving: {
    color: "#82E219",
    width: "5rem",
    fontSize: "20px",
  },
  secondaryTextG: {
    fontFamily: "Roboto",
    fontSize: "14px",
    fontWeight: 400,
    color: "#68A724",
    width: "100%",
  },
  secondaryTail: {
    backgroundColor: theme.palette.secondary.main,
  },
  time: {
    backgroundColor: "#F51919",
  },
  loc: {
    marginLeft: "-8px",
  },
  timetxt: {
    display: "inline",
    fontSize: "18px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#0000000",
  },
  timetxt1: {
    display: "inline",
    fontSize: "14px",
    fontFamily: " Maven Pro",
    fontWeight: 700,
    color: "#808080",
  },
  hover: {
    ":hover": { backgroundColor: "#000000 !important" },
  },
}));
function changeBackground(e) {
  e.target.style.background = "#68A72450";
}
function changeBackground1(e) {
  e.target.style.background = "#F1F1F1";
}
function changeBackground2(e) {
  e.target.style.background = "#fff";
}
function TabPanel(props) {
  const {
    setOpen2,
    open2,
    setOpenA,
    openA,
    children,
    value,
    index,
    ...other
  } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `full-width-tab-${index}`,
    "aria-controls": `full-width-tabpanel-${index}`,
  };
}

export default function DriversTab(props) {
  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

  // list drivers
  const totaldrivers = useSelector((store) => store.driverAll.totalRecords);
  const Fetching = useSelector((store) => store.driverAll)
  const driver = useSelector((store) => store.driverAll.data.data);
  const DriverPage = useSelector((store) => store.driverAll.page_number)
  const DriverCount = Math.ceil(useSelector((store) => store.driverAll.totalRecords) / 10)
  const [page, setPage] = React.useState(1);
  const onDownload = () => {
    const headerRow = ["Name", "License Type", "Mobile Number", "Vehicle Number", "Email", "Language", "Shift Time",
      "Driver Assign Status", "Primary Address", "Country", "State", "City", "Aadhar Number", "PAN Number",
      "Driving License Number", "Address Proof"];
    const bodyRows = driver.length && driver.map((col) => {
      return [
        col['name'],
        col['type'],
        col['mobile'],
        col['vehicle_number'],
        col['email'],
        col['language'],
        col['shift_time'],
        col['driverassign_status'],
        col['primary_address'],
        col['country'],
        col['state'],
        col['city'],
        col['aadhar_number'],
        col['pan_number'],
        col['driving_license_number'],
        col['address_proof'],
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }
  const changePage = (event, newValue) => {
    setPage(newValue);
  };
  const [delete1, setDelete1] = React.useState(false);
  const [addResponse, setAddResponce] = React.useState("");
  const [addDriverErrors, setAddDriverErrors] = React.useState(false);
  const [resetType, setResetType] = React.useState(true);
  const [selectedDriver, setSelectedDriver] = React.useState({
    mobile: "",
    name: "",
    type: "",
    email: "",
    shift_id: "",
    primary_address: "",
    country: "",
    state: "",
    city: "",
    secondary_address: "",
    aadhar_number: "",
    pan_number: "",
    driving_license_number: "",
    aadhar: "",
    pan: "",
    driver_license: "",
    profile_pic: "",
    address_proof: "",
    entity_id: "1",
    language_id: "",
    location: {
      country: "",
      state: "",
      city: ""
    },
    driverassign_status: "",
    vehicle_number: ""

  });

  const driverPresent = useSelector((store) => store.driverAll.dataPresent);
  const dispatch = useDispatch();
  const [password1, setPassword1] = React.useState("");
  React.useEffect(() => {
    dispatch(getDriverBulk(enty));
    const getCountries = endpoints.baseUrl + `/country/list`;
    axios
      .get(getCountries)
      .then((response) => {
        setCountryList(response.data.data);
      })
      .catch((er) => { });
  }, [editArray && editArray.country]);
  React.useEffect(() => {
    const getCountries = endpoints.baseUrl + `/country/list`;
    const getSCountries = endpoints.baseUrl + `/country/list`;
    const getShifts = endpoints.baseUrl + `/driver/shift`;
    const getLang = endpoints.baseUrl + `/driver/getLanguage`;
    axios
      .get(getCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setCountryList(response.data.data);
      })
      .catch((er) => { });
    axios
      .get(getSCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setCountrySList(response.data.data);
      })
      .catch((er) => { });
    axios
      .get(getShifts)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setShiftList(response.data.data);
      })
      .catch((er) => { });
    axios
      .get(getLang)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        // console.log("response", response);
        setLanguageList(response.data);
      })
      .catch((er) => { });
    dispatch(getDriverBulk(enty));
  }, []);

  React.useEffect(() => {
    if (selectedDriver && selectedDriver.country) {
      const getCountries1 =
        endpoints.baseUrl + `/state/list?country_id=` + selectedDriver.country;

      axios
        .get(getCountries1)
        .then((response) => {
          // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
          setStateList(response.data.data);
        })
        .catch((er) => { });
    }
  }, [selectedDriver]);
  React.useEffect(() => {
    if (selectedDriver && selectedDriver.secondary_country) {
      const getSCountries1 =
        endpoints.baseUrl + `/state/list?country_id=` + selectedDriver.secondary_country;

      axios
        .get(getSCountries1)
        .then((response) => {
          // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
          setStateSList(response.data.data);
        })
        .catch((er) => { });
    }
  }, [selectedDriver]);

  React.useEffect(() => {
    if (selectedDriver && selectedDriver.state) {
      const getCountries1 =
        endpoints.baseUrl + `/city/list?state_id=` + selectedDriver.state;

      axios
        .get(getCountries1)
        .then((response) => {
          // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
          setCityList(response.data.data);
        })
        .catch((er) => { });
    }
  }, [selectedDriver && selectedDriver.state]);
  React.useEffect(() => {
    if (selectedDriver && selectedDriver.secondary_state) {
      const getSCountries1 =
        endpoints.baseUrl + `/city/list?state_id=` + selectedDriver.secondary_state;

      axios
        .get(getSCountries1)
        .then((response) => {
          // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
          setCitySList(response.data.data);
        })
        .catch((er) => { });
    }
  }, [selectedDriver && selectedDriver.secondary_state]);

  const getStates = (cId) => {
    const getCountries = endpoints.baseUrl + `/state/list?country_id=` + cId;
    axios
      .get(getCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setStateList(response.data.data);
      })
      .catch((er) => { });
  };

  const getSStates = (cId) => {
    const getSCountries = endpoints.baseUrl + `/state/list?country_id=` + cId;
    axios
      .get(getSCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setStateSList(response.data.data);
      })
      .catch((er) => { });
  };

  const getCities = (sId) => {
    const getCountries = endpoints.baseUrl + `/city/list?state_id=` + sId;
    axios
      .get(getCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setCityList(response.data.data);
      })
      .catch((er) => { });
  };
  const getSCities = (sId) => {
    const getSCountries = endpoints.baseUrl + `/city/list?state_id=` + sId;
    axios
      .get(getSCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setCitySList(response.data.data);
      })
      .catch((er) => { });
  };
  React.useEffect(() => {
    setSelectedDriver(driver && driver[0]);
  }, [driver]);
  //    edit driver
  const [editArray, setEditArray] = React.useState({});
  // console.log("editArray,",editArray)
  const setDriverEditArray = (driver_id) => {
    let allDrivers = driver;
    let findArray = allDrivers.find((el) => el.driver_id === driver_id);
    setEditArray(findArray);
    setResetType(true);
  };
  const submitDriverEdit = () => {
    let newEditArray = editArray;
    newEditArray.location = {
      country: editArray.secondary_country,
      state: editArray.secondary_state,
      city: editArray.secondary_city,
    }
    setEditArray((state) => ({ ...state }))
    if (
      /^[0-9]{10}$/.test(editArray.mobile) && (editArray.updated_by = UserName)
      // editArray.name &&
      // editArray.language_id &&
      // editArray.email &&
      // editArray.primary_address &&
      // editArray.country &&
      // editArray.state &&
      // editArray.city &&
      // editArray.secondary_address &&
      // editArray.aadhar_number &&
      // editArray.pan_number &&
      // editArray.driving_license_number
    ) {
      const putDriver =
        endpoints.baseUrl + `/driver/edit/` + editArray.driver_id;
      axios
        .put(putDriver, editArray)
        .then((response) => {
          // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
          document.getElementById("full-width-tab-0").click();
          handleChangeAIndex(0);

          if (response.status === 200) {
            handleClick4(true)
            setDdd4("Driver details edited successfully!");
          }
          dispatch(getDriverBulk(enty));
          handleClosee();
        })
        .catch((er) => {
          handleClick5(true)
          setDdd5("Something went wrong, Try again");
        });
    } else {
      handleClick5(true)
      setDdd5("Please fill the required fields");
    }
  };
  const setDriverEditFormArray = (e, key, array) => {
    if (array) {
      setEditArray((state) => ({
        ...state, [array]: {
          ...state[array],
          [key]: e.target.value
        }
      }));
    } else {
      setEditArray((state) => ({ ...state, [key]: e.target.value }));

    }
  };

  const classes = useStyles();
  const theme = useTheme();

  // const nav = useNavigate();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));
  const isSmUp = useMediaQuery(theme.breakpoints.down('sm'));
  const { setOpenA, openA } = props;
  const [value, setValue] = React.useState(0);

  const [open, setOpen] = React.useState(false);
  const [open1, setOpen1] = React.useState(false);
  const [openn, setOpenn] = React.useState(false);
  const [openedit, setOpenedit] = React.useState(false);
  // const [open2, setOpen2] = React.useState(false);
  const [index, setIndex] = React.useState(0);
  const [active, setActive] = React.useState("");

  const handleClickOpenedit = () => {
    setOpenedit(true);
    // setEditArray(selectedDriver)
  };

  const handleCloseedit = () => {
    setOpenedit(false);
  };
  const handleChange = (event) => {
    setActive(event.target.value);
  };
  const handleChangeA = (event, newValue) => {
    setValue(newValue);
  };
  const handleChangeAIndex = (index) => {
    if (index === 1) {
      if (
        /^[0-9]{10}$/.test(editArray.mobile) &&
        editArray.name &&
        editArray.type &&
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editArray.email) &&
        editArray.language_id
      ) {
        setValue(index);
        scrollToTop();
      } else {
        handleClick5(true)
        setDdd5("Please Fill the Required Fields");
      }
    } else if (index === 2) {
      if (
        editArray.primary_address &&
        editArray.country &&
        editArray.state &&
        editArray.city &&
        editArray.secondary_address
      ) {
        setValue(index);
        scrollToTop();
      } else {
        handleClick5(true)
        setDdd5("Please Fill the Required Fields");
      }
    } else if (index === 3) {
      if (
        editArray.aadhar_number &&
        editArray.pan_number &&
        editArray.driving_license_number
        // && driversAddForm.aadhar && driversAddForm.pan
        // && driversAddForm.driver_license && driversAddForm.profile_pic
      ) {
        // setValue(index);
        scrollToTop();
        submitDriverEdit();
      } else {
        handleClick5(true)
        setDdd5("Please Fill the Required Fields");
      }
    }
  };

  const scrollToRef = (ref) => window.scrollTo(0, ref.current.offsetTop);
  const myRef = React.useRef(null);
  const executeScroll = () => scrollToRef(myRef);
  const { setOpen2, open2 } = props;
  const [opentrip, setOpentrip] = React.useState(false);
  // const [value, setValue] = React.useState(0);
  const handleChangee = (event, newValue) => {
    setValue(newValue);
  };

  const handleClickOpen = () => {
    setOpen(true);
    handleClickOpenn(false);
    setOpenn(false);
    // setEditArray(selectedDriver);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleClickOpen1 = () => {
    setOpen1(true);
  };

  const handleClose1 = () => {
    setOpen1(false);
  };
  const handleClickOpenn = () => {
    setOpenn(true);
    // setEditArray(selectedDriver);
  };

  const handleClosee = () => {
    setOpenn(false);
  };

  const handleChangeeIndex = (index) => {
    setValue(index);
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth", // for smoothly scrolling
    });
  };

  const handleClickOpentrip = () => {
    setOpentrip(true);
  };

  const handleClosetrip = () => {
    setOpentrip(false);
  };

  const setDriverSelected = (array) => {
    setSelectedDriver(array);
  };
  const [stateC, setStateC] = React.useState(
    selectedDriver && selectedDriver.type.includes("2W")
  );
  const [stateD, setStateD] = React.useState(
    selectedDriver && selectedDriver.type.includes("E-Auto")
  );
  const [stateE, setStateE] = React.useState(
    selectedDriver && selectedDriver.type.includes("l5n")
  );
  const [stateF, setStateF] = React.useState(
    selectedDriver && selectedDriver.type.includes("Erickshaw")
  );
  const logged_user = useSelector((store) => store.login.result);
  let driversEditAccess = logged_user.drivers === "edit"
  let enty = logged_user.entity_id
  let userPassword = logged_user.password
  const UserName = useSelector((store) => store.login.result.username);

  const [typeVar, setTypeVar] = React.useState([]);
  const [countryList, setCountryList] = React.useState([]);
  const [stateList, setStateList] = React.useState([]);
  const [cityList, setCityList] = React.useState([]);
  const [countrySList, setCountrySList] = React.useState({});
  const [stateSList, setStateSList] = React.useState({});
  const [citySList, setCitySList] = React.useState({});
  const [shiftList, setShiftList] = React.useState([]);
  const [languageList, setLanguageList] = React.useState([]);

  const handleChangeCheck = (event) => {
    let stateArr = typeVar;

    setStateC(!stateC);
    if (stateC === false) {
      const index = stateArr.indexOf("2W");
      if (index === -1) {
        stateArr.push("2W");
      }
    } else {
      const index = stateArr.indexOf("2W");
      if (index > -1) {
        stateArr.splice(index, 1);
      }
    }
    let newVar = stateArr.toString();

    setTypeVar(stateArr);
    setSelectedDriver((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    setEditArray((state) => ({
      ...state,
      type: `${newVar}`,
    }));
  };
  const handleChangeChecks = (event) => {
    let stateArr = typeVar;
    if (stateD === false) {
      const index = stateArr.indexOf("E-Auto");
      if (index === -1) {
        stateArr.push("E-Auto");
      }
    } else {
      const index = stateArr.indexOf("E-Auto");
      if (index > -1) {
        stateArr.splice(index, 1);
      }
    }
    setStateD(!stateD);
    let newVar = stateArr.toString();

    setTypeVar(stateArr);
    setSelectedDriver((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    setEditArray((state) => ({
      ...state,
      type: `${newVar}`,
    }));
  };
  const handleChangeCheckss = (event) => {
    let stateArr = typeVar;
    if (stateE === false) {
      const index = stateArr.indexOf("l5n");
      if (index === -1) {
        stateArr.push("l5n");
      }
    } else {
      const index = stateArr.indexOf("l5n");
      if (index > -1) {
        stateArr.splice(index, 1);
      }
    }
    let newVar = stateArr.toString();

    setStateE(!stateE);
    setTypeVar(stateArr);
    setSelectedDriver((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    setEditArray((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    // stateE === true ? typeVar.push('L5-com') :  typeVar.pop('L5-com')
  };
  const handleChangeChecksss = (event) => {
    let stateArr = typeVar;
    if (stateF === false) {
      const index = stateArr.indexOf("Erickshaw");
      if (index === -1) {
        stateArr.push("Erickshaw");
      }
    } else {
      const index = stateArr.indexOf("Erickshaw");
      if (index > -1) {
        stateArr.splice(index, 1);
      }
    }
    let newVar = stateArr.toString();

    setStateF(!stateF);
    setTypeVar(stateArr);
    setSelectedDriver((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    setEditArray((state) => ({
      ...state,
      type: `${newVar}`,
    }));
  };

  const [searchTerm, setSearchTerm] = React.useState("");
  const [searchTerm1, setSearchTerm1] = React.useState("");
  const filteredList = driver && driver.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredList1 = driver && driver.filter((item) =>
    item.type.toLowerCase().includes(searchTerm1.toLowerCase())
  );

  const [file, setFile] = React.useState()

  function handleChangeProfile(event) {
    setFile(event.target.files[0])


    event.preventDefault()
    const url = endpoints.baseUrl + '/upload';
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('fileName', event.target.files[0].name);
    const config = {
      headers: {
        'content-type': 'multipart/form-data',
      },
    };
    axios.post(url, formData, config).then((response) => {
      //   console.log(response.data);
      setEditArray((state) => ({ ...state, profile_pic: response.data }));

    });

  }

  function handleChangeAdhaar(event) {
    setFile(event.target.files[0])


    event.preventDefault()
    const url = endpoints.baseUrl + '/upload';
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('fileName', event.target.files[0].name);
    const config = {
      headers: {
        'content-type': 'multipart/form-data',
      },
    };
    axios.post(url, formData, config).then((response) => {
      //   console.log(response.data);
      setEditArray((state) => ({ ...state, aadhar: response.data }));

    });

  }
  function handleChangePAN(event) {
    setFile(event.target.files[0])


    event.preventDefault()
    const url = endpoints.baseUrl + '/upload';
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('fileName', event.target.files[0].name);
    const config = {
      headers: {
        'content-type': 'multipart/form-data',
      },
    };
    axios.post(url, formData, config).then((response) => {
      //   console.log(response.data);
      setEditArray((state) => ({ ...state, pan: response.data }));

    });

  }
  function handleChangeLicense(event) {
    setFile(event.target.files[0])


    event.preventDefault()
    const url = endpoints.baseUrl + '/upload';
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('fileName', event.target.files[0].name);
    const config = {
      headers: {
        'content-type': 'multipart/form-data',
      },
    };
    axios.post(url, formData, config).then((response) => {
      //   console.log(response.data);
      setEditArray((state) => ({ ...state, driver_license: response.data }));

    });

  }

  const deleteDriver = (driver_id) => {
    const deleteD = endpoints.baseUrl + `/driver/SoftDelete/` + driver_id;
    axios
      .delete(deleteD)
      .then((response) => {
        handleClick4(true)
        response.status === 200 ? setDdd4("Driver offboarded successfully!") : setDdd4(response.message)
        setDelete1(false)
        setPassword1()
        dispatch(getDriverBulk(enty));
      });
  }


  const [open3, setOpen3] = React.useState(false);
  const [ddd, setDdd] = React.useState(false);

  const handleClick3 = () => {
    setOpen3(true);
  };

  const handleClose3 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen3(false);
  };
  const [open4, setOpen4] = React.useState(false);
  const [ddd4, setDdd4] = React.useState(false);

  const handleClick4 = () => {
    setOpen4(true);
  };

  const handleClose4 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen4(false);
  };
  const [open5, setOpen5] = React.useState(false);
  const [ddd5, setDdd5] = React.useState(false);

  const handleClick5 = () => {
    setOpen5(true);
  };

  const handleClose5 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen5(false);
  };
  if (driverPresent && selectedDriver) {
    return (

      <>
        <Snackbar open={open3} autoHideDuration={3000} onClose={handleClose3}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'center',
          }}
          style={{ marginTop: '300px', marginLeft: '450px' }}
        >
          <Alert onClose={handleClose3} severity="warning">
            This driver assigned to {ddd}
          </Alert>
        </Snackbar>
        <Snackbar open={open4} autoHideDuration={3000} onClose={handleClose4}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'center',
          }}
          style={{ marginTop: '300px', marginLeft: '450px' }}
        >
          <Alert onClose={handleClose4} severity="success">
            {ddd4}
          </Alert>
        </Snackbar>
        <Snackbar open={open5} autoHideDuration={3000} onClose={handleClose5}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'center',
          }}
          style={{ marginTop: '300px', marginLeft: '450px' }}
        >
          <Alert onClose={handleClose5} severity="warning">
            {ddd5}
          </Alert>
        </Snackbar>
        <div className={classes.root}>
          <SimpleSnackbar
            logInMessage={addResponse}
            notificationTimeOut={6000}
            setLoginSucess={setAddDriverErrors}
            loginSuccess={addDriverErrors}
          />
          {opentrip === true ? (
            <Grid open={opentrip} container spacing={2}>
              <Grid item xs={12} lg={4}>
                <Paper className={classes.GridPaper}>
                  <List className={classes.style5}>
                    {/* {driver.map((text, i) => {
                            if (i === index) {
                                return ( */}

                    <div>
                      <Typography className={classes.tripText}>
                        Current Trips
                      </Typography>
                      <ListItem style={{ display: 'flex' }}>
                        <div style={{ display: 'flex' }}>
                          <div style={{ display: 'flex', alignItems: 'center' }}>
                            <Avatar>
                              {/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(selectedDriver.profile_pic) === false ?
                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmtF4VdOl8_m-1FayEemKpgZvDuvgHOqAhFQ&usqp=CAU" />
                                : <img src={selectedDriver.profile_pic} />
                              }
                            </Avatar>
                            <div style={{ display: 'flex', flexDirection: 'column' }}> <Typography
                              style={{
                                display: "inline",
                                fontSize: "16px",
                                fontFamily: "Maven Pro !important",
                                fontWeight: 600,
                                color: "#0000000",
                                marginLeft: "10px",
                                textTransform: 'capitalize'
                              }}
                              component="span"
                            >
                              {selectedDriver.name}
                            </Typography>
                              <Typography
                                className={classes.secondarytxt1}
                                component="span"
                              >
                                {selectedDriver.type}
                                <br />{selectedDriver.mobile}
                              </Typography></div></div>
                          <IconButton
                            onClick={() => {
                              if (selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "") {
                                handleClosetrip();
                              }
                              else {
                                handleClosetrip();
                              }
                            }}
                          >
                            <Icon
                              icon={selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "" ?
                                "bi:person-fill-check" : "bi:person-fill-x"}
                              color={selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "" ? "#68a724" : "#C4C4C4"}
                              width="24"
                              height="24"
                            />
                          </IconButton>
                        </div>


                      </ListItem>
                    </div>

                  </List>
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <ListItemText
                        primary={
                          <Typography
                            style={{ marginTop: "10px !important" }}
                            className={classes.primarytxt2}
                            component="span"
                          >
                            26 days
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              className={classes.secondarytxt2}
                              component="span"
                            >
                              Month Attandance
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <ListItemText
                        primary={
                          <Typography
                            style={{ marginTop: "10px !important" }}
                            className={classes.primarytxt2}
                            component="span"
                          >
                            50%
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              className={classes.secondarytxt2}
                              component="span"
                            >
                              Efficiency Score
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <ListItemText
                        primary={
                          <Typography
                            style={{ marginTop: "10px !important" }}
                            className={classes.primarytxt2}
                            component="span"
                          >
                            60 Km/h
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              className={classes.secondarytxt2}
                              component="span"
                            >
                              Speed
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <ListItemText
                        primary={
                          <Typography
                            style={{ marginTop: "10px !important" }}
                            className={classes.primarytxt2}
                            component="span"
                          >
                            MYLAMPATTI
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              className={classes.secondarytxt2}
                              component="span"
                            >
                              Location
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <ListItemText
                        primary={
                          <Typography
                            style={{ marginTop: "10px !important" }}
                            className={classes.primarytxt2}
                            component="span"
                          >
                            5.5km
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              className={classes.secondarytxt2}
                              component="span"
                            >
                              Distance Travelled Today
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <ListItemText
                        primary={
                          <Typography
                            style={{ marginTop: "10px !important" }}
                            className={classes.primarytxt2}
                            component="span"
                          >
                            Unsuccessfull
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              className={classes.secondarytxt2}
                              component="span"
                            >
                              Delivery Status
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>

              <Grid item xs={12} lg={8}>
                <Paper className={classes.map}>
                  <SimpleMap />
                </Paper>
              </Grid>

              <Grid item xs={12} lg={4}>
                <Paper style={{ height: "253px" }}>
                  <Timeline>
                    <TimelineItem>
                      <TimelineSeparator>
                        <TimelineDot className={classes.time} />
                        <TimelineConnector className={classes.time} />
                      </TimelineSeparator>
                      <TimelineContent>
                        <Typography className={classes.timetxt}>10.00</Typography>
                        &nbsp;&nbsp;
                        <Typography className={classes.timetxt1}>
                          Pudhukkuttai Thottam
                        </Typography>
                      </TimelineContent>
                    </TimelineItem>

                    <TimelineItem>
                      <TimelineSeparator>
                        <Icon
                          icon="mdi:map-marker-outline"
                          color="#f51919"
                          width="30"
                          height="30"
                          className={classes.loc}
                        />
                      </TimelineSeparator>
                      <TimelineContent>
                        <Typography
                          className={classes.timetxt}
                          style={{ marginLeft: "-9px" }}
                        >
                          10.55
                        </Typography>
                        &nbsp;&nbsp;
                        <Typography className={classes.timetxt1}>
                          SRI Sakthi University
                        </Typography>
                      </TimelineContent>
                    </TimelineItem>
                  </Timeline>
                  <Divider />
                  <Timeline>
                    <TimelineItem>
                      <TimelineSeparator>
                        <TimelineDot className={classes.time} />
                        <TimelineConnector className={classes.time} />
                      </TimelineSeparator>
                      <TimelineContent>
                        <Typography className={classes.timetxt}>10.00</Typography>
                        &nbsp;&nbsp;
                        <Typography className={classes.timetxt1}>
                          Pudhukkuttai Thottam
                        </Typography>
                      </TimelineContent>
                    </TimelineItem>

                    <TimelineItem>
                      {/* <TimelineSeparator> */}
                      <Icon
                        icon="mdi:map-marker-outline"
                        color="#f51919"
                        width="30"
                        height="30"
                        className={classes.loc}
                      />
                      {/* </TimelineSeparator> */}
                      <TimelineContent>
                        <Typography
                          className={classes.timetxt}
                          style={{ marginLeft: "-9px" }}
                        >
                          10.55
                        </Typography>
                        &nbsp;&nbsp;
                        <Typography className={classes.timetxt1}>
                          SRI Sakthi University
                        </Typography>
                      </TimelineContent>
                    </TimelineItem>
                  </Timeline>
                  {/* <Divider /> */}
                </Paper>
              </Grid>

              <Grid item xs={12} lg={4}>
                <Paper variant="outlined" elevation={2}>
                  <div style={{ margin: 10 }}>
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Vehicle Type
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        2 W
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Vehicle Model
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        Mahindra
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Vehicle No
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        TN88 C1234
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Driver Name
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        Nithish
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Fleet Operator
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        TTN Logistics
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Client Name
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        Bigbasket
                      </Typography>
                    </div>
                  </div>
                </Paper>
              </Grid>

              <Grid item xs={12} lg={4}>
                <Paper variant="outlined" elevation={2}>
                  <div style={{ margin: 10 }}>
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Status
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        Driving
                        <Brightness1Icon className={classes.driving} />
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Location
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        GOLD
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Km Remaining
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        13 KM
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>SOC</Typography>
                      <Typography className={classes.secondaryText}>
                        Driving
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Delivery Status
                      </Typography>
                      <Typography className={classes.secondaryTextG}>
                        Completed
                      </Typography>
                    </div>
                    <Divider />
                    <div style={{ display: "flex", margin: 10 }}>
                      <Typography className={classes.primaryText}>
                        Today Trip Distance
                      </Typography>
                      <Typography className={classes.secondaryText}>
                        50 KM
                      </Typography>
                    </div>
                  </div>
                </Paper>
              </Grid>
            </Grid>
          ) : (
            <Box style={{ height: '720px', width: '100%', backgroundColor: '#f1f1f1', borderRadius: '10px' }}>

              <Grid container spacing={0} >
                <Grid lg={3} xs={12} style={{ height: '650px', overflowY: 'scroll', fontFamily: " Maven Pro" }}>
                  <Item style={{ backgroundColor: "#f1f1f1" }}>
                    <div
                      style={{ display: "flex", alignItems: 'center', justifyContent: 'space-around', marginTop: '10px' }}
                    >
                      <Paper
                        style={{ p: '2px 4px', display: 'flex', alignItems: 'center', height: '40px', width: '210px' }}
                      >
                        <IconButton sx={{ p: '10px' }} aria-label="menu">
                          <SearchIcon style={{ marginBottom: '4px' }} />
                        </IconButton>
                        <InputBase
                          sx={{ ml: 1, flex: 1 }}
                          placeholder="Search"
                          className={classes.txtField}
                          value={searchTerm1 != "" ? searchTerm1 : searchTerm}
                          onChange={(event) =>
                            setSearchTerm != "" ?
                              setSearchTerm(event.target.value) :
                              setSearchTerm1(event.target.value)}
                        />
                        {searchTerm || searchTerm1 != '' ? <IconButton type="button" sx={{ p: '10px' }} aria-label="search"
                          onClick={() => {
                            setSearchTerm("")
                            setSearchTerm1("")
                          }} >
                          <Icon icon="material-symbols:close" width="22" height="22" />
                        </IconButton> : null}

                      </Paper>
                      <>
                        {driversEditAccess === true ?
                          (open === false ? (
                            <Avatar onClick={handleClickOpen} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                              <Icon
                                icon="material-symbols:add"
                                color="#68a724"
                                width="26"
                                height="26"
                              />
                            </Avatar >
                          ) : (
                            <Avatar onClick={handleClose} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                              <Icon
                                icon="ion:close"
                                color="#68a724"
                                width="22"
                                height="22"
                              />
                            </Avatar >
                          ))
                          : null}
                      </>

                      <Avatar style={{ backgroundColor: '#fff', width: '33px', height: '33px' }} onClick={() => {
                        onDownload()
                      }}>
                        <CloudDownload style={{ color: '#68a724' }} />
                      </Avatar>
                    </div>

                    {searchTerm1 === "" ? <Typography className={classes.sevenDrive}>
                      {filteredList && filteredList.length} Drivers
                    </Typography> :
                      <Typography className={classes.sevenDrive}>
                        {filteredList1 && filteredList1.length} Drivers
                      </Typography>}

                    {isMdUp === true ? null : (
                      <Dialog open={open} onClose={handleClose}>
                        <Tabss open={open} setOpen={setOpen}
                          logInMessage={addResponse}
                          notificationTimeOut={6000}
                          setLoginSucess={setAddDriverErrors}
                          loginSuccess={addDriverErrors} />
                      </Dialog>
                    )}
                    {isMdUp === true ? null : (
                      <Dialog open={openedit} onClose={handleCloseedit}>
                        <List
                          open={openedit}
                          onClose={handleCloseedit}
                          className={classes.lists}
                        >
                          {/* {driver.map((text, i) => {
                                  if (i === index) {
                                      return ( */}
                          {/* customBodyRender: (value) => {   */}
                          <Box className={classes.styleA}>
                            <Typography align="top" className={classes.styleB}>
                              Driver Induction
                            </Typography>
                            {isMdUp === true ? null : (
                              <IconButton
                                className={isMdUp === false ? classes.styleC : null}
                                onClick={handleCloseedit}
                              >
                                <img
                                  src={logox}
                                  style={{
                                    border: 1,
                                    borderRadius: "30px",
                                    backgroundColor: "#FFFFFF",
                                  }}
                                />
                              </IconButton>
                            )}

                            <Typography align="center" className={classes.styleD}>
                              Upload Profile (Max 100KB)
                            </Typography>
                            <div align="center">
                              <IconButton className={classes.styleE}>
                                <Avatar>

                                  <input
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "profile_pic");
                                    }}
                                    // error={
                                    //   addDriverErrors &&
                                    //   editArray.profile_pic === ""
                                    // }
                                    type="file"
                                    style={{ opacity: 0, position: "absolute" }}
                                  />
                                  {/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(selectedDriver.profile_pic) === false ?
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmtF4VdOl8_m-1FayEemKpgZvDuvgHOqAhFQ&usqp=CAU" />
                                    : <img src={selectedDriver.profile_pic} />
                                  }
                                </Avatar>
                              </IconButton>
                            </div>
                            <Box className={classes.styleF}>
                              <div>
                                <AppBar
                                  position="static"
                                  className={classes.styleG}
                                >
                                  <Tabs
                                    setOpenA={setOpenA}
                                    value={value}
                                    onChange={handleChangeA}
                                    indicatorColor="#000000"
                                    color="#000000"
                                    variant="fullWidth"
                                    aria-label="full width tabs example"
                                    className={classes.styleH}
                                  >
                                    <Tab
                                      className={
                                        isMdUp === false
                                          ? classes.styleIM
                                          : classes.styleJ
                                      }
                                      label="PERSONAL INFORMATION"
                                      {...a11yProps(0)}
                                    />
                                    <Tab
                                      className={
                                        isMdUp === false
                                          ? classes.styleK
                                          : classes.styleJ
                                      }
                                      label="ADDRESS"
                                      {...a11yProps(1)}
                                    />
                                    <Tab
                                      className={
                                        isMdUp === false
                                          ? classes.styleK
                                          : classes.styleJ
                                      }
                                      label="KYC DOCUMENT"
                                      {...a11yProps(2)}
                                    />
                                  </Tabs>
                                </AppBar>
                              </div>
                            </Box>

                            <SwipeableViews
                              axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                              index={value}
                              onChangeIndex={handleChangeAIndex}
                            >
                              <TabPanel
                                setOpenA={setOpenA}
                                value={value}
                                index={0}
                                dir={theme.direction}
                              >
                                <Grid container spacing={2}>
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      License Type
                                    </Typography>
                                    <FormControlLabel
                                      control={
                                        <Checkbox
                                          disabled={resetType}
                                          checked={
                                            selectedDriver.type &&
                                            selectedDriver.type.includes("2W")
                                          }
                                          // onChange={handleChangeCheck}
                                          name="checkedA"
                                          color="primary"
                                        />
                                      }
                                      label="2W"
                                    />
                                    <FormControlLabel
                                      control={
                                        <Checkbox
                                          disabled={resetType}
                                          checked={
                                            selectedDriver.type &&
                                            selectedDriver.type.includes("E-Auto")
                                          }
                                          // onChange={handleChangeChecks}
                                          name="checkedB"
                                          color="primary"
                                        />
                                      }
                                      label="E-Auto"
                                    />
                                    <FormControlLabel
                                      control={
                                        <Checkbox
                                          disabled={resetType}
                                          checked={
                                            selectedDriver.type &&
                                            selectedDriver.type.includes("l5n")
                                          }
                                          // onChange={handleChangeCheckss}
                                          name="checkedC"
                                          color="primary"
                                        />
                                      }
                                      label="L5 Commericial Vehicle"
                                    />
                                    {/* <Button
                                    variant="danger"
                                    onClick={() => {
                                      setStateC(true);

                                      setStateD(true);
                                      setStateE(true);
                                      setResetType(false);
                                      setSelectedDriver((state) => ({
                                        ...state,
                                        type: "",
                                      }));
                                      setEditArray((state) => ({
                                        ...state,
                                        type: "",
                                      }));
                                      setTypeVar([]);
                                    }}
                                  >
                                    Reset
                                  </Button> */}
                                  </Grid>
                                  <input
                                    type="hidden"
                                    name="driver_id"
                                    value={selectedDriver.driver_id}
                                  />
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Driver Name
                                    </Typography>
                                    <TextField
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "name");
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors && editArray.name === ""
                                      }
                                      value={selectedDriver.name}
                                    />
                                  </Grid>

                                  {/* <Grid item lg={6} xs={12}>
                                                          <Typography className={classes.styleL}>User Name</Typography>
                                                          <TextField
                                                              onChange={(e) => { setDriverEditFormArray(e, 'user_name') }}
                                                              size="small" id="outlined" className={classes.styleO} 
                                                  error={addDriverErrors && editArray.user_name === ""}
                                                  value={`` || editArray.user_name} />                                                </Grid> */}

                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Mobile Number
                                    </Typography>
                                    <TextField
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "mobile");
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors && !/^[0-9]{10}$/.test(editArray.mobile)
                                      }
                                      value={`` || editArray.mobile}
                                    />
                                  </Grid>

                                  <Grid item lg={12} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Email
                                    </Typography>
                                    <TextField
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "email");
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editArray.email)
                                      }
                                      helperText={!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editArray.email) ? 'Enter Valid Email Id' : null}
                                      value={`` || editArray.email}
                                    />
                                  </Grid>

                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Language
                                    </Typography>
                                    <Select
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "language_id");
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors && editArray.language_id === ""
                                      }
                                      value={`` || editArray.language_id}
                                    >
                                      <MenuItem value="">
                                        Select your language
                                      </MenuItem>
                                      {languageList &&
                                        languageList.map((lang) => {
                                          return (
                                            <MenuItem
                                              key={lang.language_id}
                                              value={lang.language_id}
                                            >
                                              {lang.language}
                                            </MenuItem>
                                          );
                                        })}
                                    </Select>
                                  </Grid>
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.tabHelp}>
                                      Shift Time
                                    </Typography>
                                    <FormControl
                                      className={classes.formControl}
                                      size="small"
                                    >
                                      <Select
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "shift_time");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors &&
                                          editArray.shift_time === ""
                                        }
                                        value={`` || editArray.shift_time}
                                      >
                                        <MenuItem value="">
                                          Select your shift
                                        </MenuItem>
                                        {shiftList &&
                                          shiftList.map((sh, i) => {
                                            return (
                                              <MenuItem value={sh.shift_id} key={i}>
                                                {sh.time}
                                              </MenuItem>
                                            );
                                          })}
                                      </Select>
                                    </FormControl>
                                  </Grid>
                                </Grid>
                                <br />
                                <div
                                  style={{
                                    display: "flex",
                                    flexDirection: "row",
                                    flexWrap: "nowrap",
                                    alignContent: "center",
                                    justifyContent: "space-around",
                                    alignItems: "center",
                                  }}
                                >
                                  <Button
                                    onClick={handleCloseedit}
                                    // onClick={() => setOpenn(false)}
                                    className={
                                      isMdUp === true
                                        ? classes.styleP
                                        : classes.stylePM
                                    }
                                  >
                                    Cancel
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      handleChangeAIndex(1);
                                      scrollToTop();
                                    }}
                                    className={
                                      isMdUp === true
                                        ? classes.styleQ
                                        : classes.styleQM
                                    }
                                  >
                                    Next
                                    <img src={next} style={{ marginLeft: 10 }} />
                                  </Button>
                                </div>
                              </TabPanel>

                              <TabPanel
                                setOpenA={setOpenA}
                                value={value}
                                index={1}
                                dir={theme.direction}
                              >
                                <Grid container spacing={2}>
                                  <Grid item lg={12} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Primary Address
                                    </Typography>
                                    <Paper
                                      component="form"
                                      className={classes.styleR}
                                    >
                                      <InputBase
                                        onChange={(e) => {
                                          setDriverEditFormArray(
                                            e,
                                            "primary_address"
                                          );
                                        }}
                                        fullWidth={true}
                                        error={
                                          addDriverErrors &&
                                          editArray.primary_address === ""
                                        }
                                        value={`` || editArray.primary_address}
                                      />
                                    </Paper>
                                  </Grid>

                                  <Grid item lg={4} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Country
                                    </Typography>
                                    {countryList.length && (
                                      <Select
                                        style={{ minWidth: "100%" }}
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "country");
                                          getStates(e.target.value);
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors &&
                                          editArray.country === ""
                                        }
                                        value={`` || editArray.country}
                                        displayEmpty
                                      >
                                        <MenuItem value="">Select Country</MenuItem>
                                        {countryList.length &&
                                          countryList.map((el, i) => {
                                            return (
                                              <MenuItem
                                                key={i}
                                                value={el.country_id}
                                              >
                                                {el.country_name}
                                              </MenuItem>
                                            );
                                          })}
                                      </Select>
                                    )}
                                  </Grid>

                                  <Grid item lg={4} xs={12}>
                                    <Typography className={classes.styleL}>
                                      State
                                    </Typography>
                                    <Select
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "state");
                                        getCities(e.target.value);
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors && editArray.state === ""
                                      }
                                      value={editArray.state || ""}
                                    >
                                      <MenuItem value="">Select City</MenuItem>
                                      {stateList.length &&
                                        stateList.map((el, i) => {
                                          return (
                                            <MenuItem key={i} value={el.state_id}>
                                              {el.state_name}
                                            </MenuItem>
                                          );
                                        })}
                                    </Select>
                                  </Grid>
                                  <Grid item lg={4} xs={12}>
                                    <Typography className={classes.styleL}>
                                      City
                                    </Typography>
                                    <Select
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "state");
                                        getCities(e.target.value);
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors && editArray.state === ""
                                      }
                                      value={editArray.state || ""}
                                    >
                                      <MenuItem value="">Select City</MenuItem>
                                      {stateList.length &&
                                        stateList.map((el, i) => {
                                          return (
                                            <MenuItem key={i} value={el.state_id}>
                                              {el.state_name}
                                            </MenuItem>
                                          );
                                        })}
                                    </Select>
                                  </Grid>

                                  <Grid item lg={12} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Secondary Address
                                    </Typography>
                                    <Paper
                                      component="form"
                                      className={classes.styleR}
                                    >
                                      <InputBase
                                        onChange={(e) => {
                                          setDriverEditFormArray(
                                            e,
                                            "secondary_address"
                                          );
                                        }}
                                        fullWidth={true}
                                        error={
                                          addDriverErrors &&
                                          editArray.secondary_address === ""
                                        }
                                        value={`` || editArray.secondary_address}
                                      />
                                    </Paper>
                                  </Grid>

                                  <Grid item lg={4} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Country
                                    </Typography>
                                    {countryList.length && (
                                      <Select
                                        style={{ minWidth: "100%" }}
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "country");
                                          getStates(e.target.value);
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors &&
                                          editArray.country === ""
                                        }
                                        value={`` || editArray.country}
                                        // defaultValue={0}

                                        displayEmpty
                                      >
                                        <MenuItem value="">Select Country</MenuItem>
                                        {countryList.length &&
                                          countryList.map((el, i) => {
                                            return (
                                              <MenuItem
                                                key={i}
                                                value={el.country_id}
                                              >
                                                {el.country_name}
                                              </MenuItem>
                                            );
                                          })}
                                      </Select>
                                    )}
                                  </Grid>

                                  <Grid item lg={4} xs={12}>
                                    <Typography className={classes.styleL}>
                                      State
                                    </Typography>
                                    <Select
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "state");
                                        getCities(e.target.value);
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors && editArray.state === ""
                                      }
                                      value={editArray.state || ""}
                                    >
                                      <MenuItem value="">Select City</MenuItem>
                                      {stateList.length &&
                                        stateList.map((el, i) => {
                                          return (
                                            <MenuItem key={i} value={el.state_id}>
                                              {el.state_name}
                                            </MenuItem>
                                          );
                                        })}
                                    </Select>
                                  </Grid>
                                  <Grid item lg={4} xs={12}>
                                    <Typography className={classes.styleL}>
                                      City
                                    </Typography>
                                    <Select
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "state");
                                        getCities(e.target.value);
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors && editArray.state === ""
                                      }
                                      value={editArray.state || ""}
                                    >
                                      <MenuItem value="">Select City</MenuItem>
                                      {stateList.length &&
                                        stateList.map((el, i) => {
                                          return (
                                            <MenuItem key={i} value={el.state_id}>
                                              {el.state_name}
                                            </MenuItem>
                                          );
                                        })}
                                    </Select>
                                  </Grid>
                                </Grid>
                                <br />
                                <div
                                  style={{
                                    display: "flex",
                                    flexDirection: "row",
                                    flexWrap: "nowrap",
                                    alignContent: "center",
                                    justifyContent: "space-around",
                                    alignItems: "center",
                                  }}
                                >
                                  <Button
                                    onClick={() => {
                                      handleChangeAIndex(0);
                                      scrollToTop();
                                    }}
                                    className={
                                      isMdUp === true
                                        ? classes.styleP
                                        : classes.stylePM
                                    }
                                  >
                                    <img
                                      src={back}
                                      style={{ marginRight: "15px" }}
                                    />
                                    Back
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      handleChangeAIndex(2);
                                      scrollToTop();
                                    }}
                                    className={
                                      isMdUp === true
                                        ? classes.styleQ
                                        : classes.styleQM
                                    }
                                  >
                                    Next
                                    <img src={next} style={{ marginLeft: 20 }} />
                                  </Button>
                                </div>
                              </TabPanel>

                              <TabPanel
                                setOpenA={setOpenA}
                                value={value}
                                index={2}
                                dir={theme.direction}
                              >
                                <Grid container spacing={2}>
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Aadhar Number
                                    </Typography>
                                    <TextField
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "aadhar_number");
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors &&
                                        editArray.aadhar_number === ""
                                      }
                                      value={`` || editArray.aadhar_number}
                                    />
                                  </Grid>
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Aadhar Image
                                    </Typography>
                                    <Button
                                      sx={{ ":hover": { backgroundColor: "#fff" } }}
                                    >
                                      <input
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "aadhar");
                                        }}
                                        error={
                                          addDriverErrors && editArray.aadhar === ""
                                        }
                                        value={`` || editArray.aadhar}
                                        type="file"
                                        style={{ color: "#C1C1C1" }}
                                      />
                                    </Button>
                                  </Grid>
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      PAN Number
                                    </Typography>
                                    <TextField
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "pan_number");
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors &&
                                        editArray.pan_number === ""
                                      }
                                      value={`` || editArray.pan_number}
                                    />
                                  </Grid>
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      PAN Image
                                    </Typography>
                                    <Button
                                      sx={{ ":hover": { backgroundColor: "#fff" } }}
                                    >
                                      <input
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "pan");
                                        }}
                                        error={
                                          addDriverErrors && editArray.pan === ""
                                        }
                                        value={`` || editArray.pan}
                                        type="file"
                                        style={{ color: "#C1C1C1" }}
                                      />
                                    </Button>
                                  </Grid>
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      Driving License Number
                                    </Typography>
                                    <TextField
                                      onChange={(e) => {
                                        setDriverEditFormArray(
                                          e,
                                          "driving_license_number"
                                        );
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors &&
                                        editArray.driving_license_number === ""
                                      }
                                      value={`` || editArray.driving_license_number}
                                    />
                                  </Grid>
                                  <Grid item lg={6} xs={12}>
                                    <Typography className={classes.styleL}>
                                      License Image
                                    </Typography>
                                    <Button
                                      sx={{ ":hover": { backgroundColor: "#fff" } }}
                                    >
                                      <input
                                        onChange={(e) => {
                                          setDriverEditFormArray(
                                            e,
                                            "driver_license"
                                          );
                                        }}
                                        error={
                                          addDriverErrors &&
                                          editArray.driver_license === ""
                                        }
                                        value={`` || editArray.driver_license}
                                        type="file"
                                        style={{ color: "#C1C1C1" }}
                                      />
                                    </Button>
                                  </Grid>
                                </Grid>
                                <br />
                                <div
                                  style={{
                                    display: "flex",
                                    flexDirection: "row",
                                    flexWrap: "nowrap",
                                    alignContent: "center",
                                    justifyContent: "space-around",
                                    alignItems: "center",
                                  }}
                                >
                                  <Button
                                    onClick={() => {
                                      handleChangeAIndex(1);
                                      scrollToTop();
                                    }}
                                    className={
                                      isMdUp === true
                                        ? classes.styleP
                                        : classes.stylePM
                                    }
                                  >
                                    <img
                                      src={back}
                                      style={{ marginRight: "15px" }}
                                    />
                                    Back
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      // submitDriverEdit(true)
                                      handleChangeAIndex(3);
                                    }}
                                    type="submit"
                                    className={
                                      isMdUp === true
                                        ? classes.styleQ
                                        : classes.styleQM
                                    }
                                  >
                                    Save
                                  </Button>
                                </div>
                              </TabPanel>
                            </SwipeableViews>
                          </Box>
                          {/* )
                                  }
                              })}  */}
                        </List>
                      </Dialog>
                    )}

                    {isMdUp === true ? null : (
                      <Dialog
                        open={openn}
                      // onClose={handleClosee}
                      >
                        <div className={classes.root}>
                          {/* <CssBaseline /> */}
                          {/* <DrawerList /> */}

                          <List className={classes.lists}>
                            {/* {driver.map((text, i) => {
                                      if (i === index) {
                                          return ( */}

                            <Box className={classes.tabBoxMM}>
                              <Box className={classes.marginLR}>
                                <div
                                  style={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                  }}
                                >
                                  <IconButton
                                    onClick={() => {
                                      handleClickOpentrip();
                                    }}
                                  >
                                    <Icon
                                      icon="material-symbols:info-outline"
                                      color="#68a724"
                                      width="24"
                                      height="24"
                                    />
                                  </IconButton>
                                  {driversEditAccess === true ?
                                    <IconButton onClick={handleClickOpenedit}>
                                      <Icon
                                        icon="clarity:note-edit-line"
                                        color="#68a724"
                                        width="30"
                                        height="30"
                                      />
                                    </IconButton> : null}
                                  <IconButton onClick={handleClosee}>
                                    <Icon
                                      icon="cil:x"
                                      color="#68a724"
                                      width="30"
                                      height="30"
                                    />
                                  </IconButton>
                                </div>
                                <AppBar
                                  position="static"
                                  className={classes.style2}
                                >
                                  <Tabs
                                    // setOpen2={setOpen2}
                                    value={value}
                                    onChange={handleChangee}
                                    indicatorColor="#000000"
                                    color="#000000"
                                    variant="fullWidth"
                                    aria-label="full width tabs example"
                                    className={classes.style3}
                                  >
                                    <Tab
                                      className={
                                        isMdUp === false
                                          ? classes.style4M
                                          : classes.style4
                                      }
                                      label="PERSONAL INFORMATION"
                                      {...a11yProps(0)}
                                    />
                                    <Tab
                                      className={
                                        isMdUp === false
                                          ? classes.style4M
                                          : classes.style4
                                      }
                                      label="ADDRESS"
                                      {...a11yProps(1)}
                                    />
                                    <Tab
                                      className={
                                        isMdUp === false
                                          ? classes.style4M
                                          : classes.style4
                                      }
                                      label="KYC DOCUMENT"
                                      {...a11yProps(2)}
                                    />
                                  </Tabs>
                                </AppBar>
                              </Box>
                              {/* {driver.map((text, i) => {
                                                                  if (i === index) {
                                                                      return ( */}

                              <SwipeableViews
                                axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                                index={value}
                                onChangeIndex={handleChangeeIndex}
                              >
                                <TabPanel
                                  // setOpen2={setopen2}
                                  value={value}
                                  index={0}
                                  dir={theme.direction}
                                >
                                  <List className={classes.style5}>
                                    <div>
                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <Avatar>
                                          <img src={EditDriver} />
                                        </Avatar>
                                        <ListItemText
                                          className={classes.style6M}
                                          primary={
                                            <Typography
                                              className={classes.style7M}
                                              component="span"
                                            >
                                              {selectedDriver.type}
                                            </Typography>
                                          }
                                          secondary={
                                            <React.Fragment>
                                              <Typography
                                                className={classes.style8}
                                                component="span"
                                              >
                                                {selectedDriver.type}
                                              </Typography>
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                      <Divider />

                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <Avatar>
                                          <img src={EditName} />
                                        </Avatar>
                                        <ListItemText
                                          className={classes.style6M}
                                          primary={
                                            <Typography
                                              className={classes.style7M}
                                              component="span"
                                            >
                                              {selectedDriver.name}
                                            </Typography>
                                          }
                                          secondary={
                                            <React.Fragment>
                                              <Typography
                                                className={classes.style8}
                                                component="span"
                                              >
                                                {selectedDriver.name}
                                              </Typography>
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                      <Divider />

                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <Avatar>
                                          <img src={EditUser} />
                                        </Avatar>
                                        <ListItemText
                                          className={classes.style6M}
                                          primary={
                                            <Typography
                                              className={classes.style7M}
                                              component="span"
                                            >
                                              {selectedDriver.user_name}
                                            </Typography>
                                          }
                                          secondary={
                                            <React.Fragment>
                                              <Typography
                                                className={classes.style8}
                                                component="span"
                                              >
                                                {selectedDriver.type}
                                              </Typography>
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                      <Divider />

                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <Avatar>
                                          <img src={MobNum} />
                                        </Avatar>
                                        <ListItemText
                                          className={classes.style6M}
                                          primary={
                                            <Typography
                                              className={classes.style7M}
                                              component="span"
                                            >
                                              {selectedDriver.mobile}
                                            </Typography>
                                          }
                                          secondary={
                                            <React.Fragment>
                                              <Typography
                                                className={classes.style8}
                                                component="span"
                                              >
                                                {selectedDriver.mobile}
                                              </Typography>
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                      <Divider />

                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <Avatar>
                                          <img src={EditMail} />
                                        </Avatar>
                                        <ListItemText
                                          className={classes.style6M}
                                          primary={
                                            <Typography
                                              className={classes.style7M}
                                              component="span"
                                            >
                                              {selectedDriver.email}
                                            </Typography>
                                          }
                                          secondary={
                                            <React.Fragment>
                                              <Typography
                                                className={classes.style8}
                                                component="span"
                                              >
                                                {selectedDriver.email}
                                              </Typography>
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                      <Divider />

                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <Avatar>
                                          <img src={EditLang} />
                                        </Avatar>
                                        <ListItemText
                                          className={classes.style6M}
                                          primary={
                                            <Select
                                              disabled={true}
                                              onChange={(e) => {
                                                setDriverEditFormArray(
                                                  e,
                                                  "language_id"
                                                );
                                              }}
                                              size="small"
                                              id="outlined"
                                              className={classes.styleO}
                                              error={
                                                addDriverErrors &&
                                                editArray.language_id === ""
                                              }
                                              value={"" || selectedDriver.language_id}
                                            >
                                              <MenuItem value="">
                                                Select your language
                                              </MenuItem>
                                              {languageList &&
                                                languageList.map((lang) => {
                                                  return (
                                                    <MenuItem
                                                      key={lang.language_id}
                                                      value={lang.language_id}
                                                    >
                                                      {lang.language}
                                                    </MenuItem>
                                                  );
                                                })}
                                            </Select>
                                          }
                                        />
                                      </ListItem>
                                      <Divider />

                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <Avatar>
                                          <img src={EditTime} />
                                        </Avatar>
                                        <ListItemText
                                          className={classes.style6M}
                                          primary={
                                            <Typography
                                              className={classes.style7M}
                                              component="span"
                                            >
                                              {selectedDriver.shift_time}
                                            </Typography>
                                          }
                                          secondary={
                                            <React.Fragment>
                                              <Typography
                                                className={classes.style8}
                                                component="span"
                                              >
                                                {selectedDriver.shift_time}
                                              </Typography>
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                    </div>
                                  </List>
                                </TabPanel>

                                <TabPanel
                                  // setOpen2={setOpen2}
                                  value={value}
                                  index={1}
                                  dir={theme.direction}
                                >
                                  <List className={classes.style5}>
                                    {/* {driver.map((text, i) => {
                                                                  if (i === index) {
                                                                  return ( */}
                                    <div>
                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <Avatar>
                                          <img src={Prime} />
                                        </Avatar>
                                        <ListItemText
                                          className={classes.style6}
                                          primary={
                                            <div
                                              style={{
                                                "white-space": "pre-wrap",
                                                "overflow-wrap": "break-word",
                                              }}
                                            >
                                              <Typography
                                                className={classes.style9M}
                                                component="span"
                                              >
                                                {"Primary Address"} <br />
                                                {selectedDriver.primary_address}
                                              </Typography>
                                            </div>
                                          }
                                          secondary={
                                            <React.Fragment>
                                              <Typography
                                                className={classes.style10M}
                                                component="span"
                                              >
                                                City:{selectedDriver.city}
                                                <br />
                                                State:{selectedDriver.state}
                                                <br />
                                                Country:{selectedDriver.country}
                                              </Typography>
                                              <br />
                                              <Typography
                                                className={classes.style11M}
                                                component="span"
                                              >
                                                Primary Address
                                              </Typography>
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                      <Divider />
                                    </div>
                                    {/* )
                                                                              }
                                                              })} */}
                                  </List>
                                </TabPanel>

                                <TabPanel
                                  // setOpen2={setOpen2}
                                  value={value}
                                  index={2}
                                  dir={theme.direction}
                                >
                                  <List className={classes.style5}>
                                    <ListItem alignItems="flex-start">
                                      <ListItemText
                                        className={classes.style12}
                                        primary={selectedDriver.aadhar_number}
                                        secondary={
                                          <React.Fragment>
                                            <Typography
                                              className={classes.style13}
                                              component="span"
                                              variant="body2"
                                              color="text.primary"
                                              float="left"
                                            >
                                              Aadhar Number
                                            </Typography>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem>
                                    <ListItem alignItems="flex-start">
                                      <ListItemText
                                        className={classes.style13}
                                        primary="Aadhar Card"
                                        secondary={
                                          <React.Fragment>
                                            <Button className={classes.style14}>
                                              View
                                            </Button>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem>
                                    <Divider />
                                    <ListItem alignItems="flex-start">
                                      <ListItemText
                                        className={classes.style12}
                                        primary={selectedDriver.pan_number}
                                        secondary={
                                          <React.Fragment>
                                            <Typography
                                              className={classes.style13}
                                              component="span"
                                              variant="body2"
                                              color="text.primary"
                                              float="left"
                                            >
                                              PAN Number
                                            </Typography>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem>
                                    <ListItem alignItems="flex-start">
                                      <ListItemText
                                        className={classes.style13}
                                        primary="PAN Card"
                                        secondary={
                                          <React.Fragment>
                                            <Button className={classes.style14}>
                                              View
                                            </Button>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem>
                                    <Divider />
                                    <ListItem alignItems="flex-start">
                                      <ListItemText
                                        className={classes.style12}
                                        primary={
                                          selectedDriver.driving_license_number
                                        }
                                        secondary={
                                          <React.Fragment>
                                            <Typography
                                              className={classes.style13}
                                              component="span"
                                              variant="body2"
                                              color="text.primary"
                                              float="left"
                                            >
                                              Driving License Number
                                            </Typography>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem>
                                    <ListItem alignItems="flex-start">
                                      <ListItemText
                                        className={classes.style13}
                                        primary="License Card"
                                        secondary={
                                          <React.Fragment>
                                            <Button className={classes.style14}>
                                              View
                                            </Button>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem>
                                  </List>
                                </TabPanel>
                              </SwipeableViews>
                            </Box>
                            {/* )
                                              }
                                          })} */}
                          </List>
                        </div>
                      </Dialog>
                    )}

                    {/* {openn === false ?  */}
                    {searchTerm1 === "" ?
                      <List>
                        {filteredList.length && filteredList.map((singleDriver) => {
                          return (
                            <IconButton style={{
                              width: '100%',
                              borderRadius: '10px',
                              cursor: 'pointer',
                              height: '60px', backgroundColor:
                                selectedDriver.driver_id ===
                                  singleDriver.driver_id
                                  ? "#68A72480"
                                  : null, height: '60px', borderRadius: '10px',
                            }}
                              onClick={() => {
                                handleClosee();
                                setDriverSelected(singleDriver);
                                isMdUp === false ? handleClickOpenn() : null;
                              }}>
                              <ListItem>
                                <Avatar>
                                  {/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(singleDriver.profile_pic) === false ?
                                    <img src={DefaultProfile} />
                                    : <img src={singleDriver.profile_pic} />
                                  }

                                </Avatar>
                                <ListItemText
                                  primary={
                                    <Typography
                                      className={classes.primarytxt}
                                      component="span"
                                    >
                                      {singleDriver.name}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.secondarytxt}
                                        component="span"
                                      >
                                        {singleDriver.type}
                                      </Typography>
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                            </IconButton>

                          );
                        })}
                      </List> :
                      <List>
                        {filteredList1.length && filteredList1.map((singleDriver) => {
                          return (
                            <IconButton style={{
                              width: '100%',
                              borderRadius: '10px',
                              cursor: 'pointer',
                              height: '60px'
                            }}
                              onClick={() => {
                                handleClosee();
                                setDriverSelected(singleDriver);
                                isMdUp === false ? handleClickOpenn() : null;
                              }}>
                              <ListItem
                                style={{
                                  backgroundColor:
                                    selectedDriver.driver_id ===
                                      singleDriver.driver_id
                                      ? "#68A72480"
                                      : null,
                                  borderRadius: '10px',
                                  ":hover": { backgroundColor: '#4CAF50' },
                                  height: '60px',

                                }}
                              >
                                <Avatar>
                                  {/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(singleDriver.profile_pic) === false ?
                                    <img src={DefaultProfile} />
                                    : <img src={singleDriver.profile_pic} />
                                  }

                                </Avatar>
                                <ListItemText
                                  primary={
                                    <Typography
                                      className={classes.primarytxt}
                                      component="span"
                                    >
                                      {singleDriver.name}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.secondarytxt}
                                        component="span"
                                      >
                                        {singleDriver.type}
                                      </Typography>
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                            </IconButton>

                          );
                        })}
                      </List>
                    }

                    {/* <Pagination count={DriverCount} page={DriverPage} onChange={changePage} /> */}

                    {/*  : <Edit />} */}
                  </Item>
                </Grid>
                {isMdUp === true ? (
                  <Grid item lg={9} xs={12} className={classes.gridBG}>
                    <Item
                      className={classes.colorNo}
                    >
                      {open === false ? (
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div style={{ display: 'flex', alignItems: 'center', marginLeft: '15px' }}>
                            <><Avatar>
                              {/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(selectedDriver.profile_pic) === false ?
                                <img src={DefaultProfile} />
                                : <img src={selectedDriver.profile_pic} />
                              }
                            </Avatar>
                              <ListItemText
                                primary={
                                  <Typography
                                    style={{ fontSize: "16px", textTransform: 'capitalize', fontFamily: "Maven Pro !important", fontWeight: 700, color: "#6C6C6C", marginLeft: "15px" }}
                                  >
                                    {selectedDriver.name}
                                  </Typography>
                                }
                                secondary={
                                  <React.Fragment>
                                    <Typography
                                      style={{ fontSize: "12px", fontFamily: " Maven Pro", fontWeight: 500, color: "#7A7A7D", marginLeft: "15px" }}
                                    >
                                      {selectedDriver.type}
                                    </Typography>
                                  </React.Fragment>
                                }
                              /></>



                          </div>
                          <div>{driversEditAccess === true ?
                            (openn === true ?
                              <><IconButton
                                onClick={() => {
                                  handleClosee(true)
                                }}>
                                <Icon icon="material-symbols:edit" color="black" width="22" height="22" rotate={2} hFlip={true} vFlip={true} />
                              </IconButton>

                                <IconButton
                                  onClick={() => {
                                    if (selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "") {
                                      handleClosetrip();
                                    }
                                    else {
                                      handleClosetrip();
                                    }
                                  }}
                                >
                                  <Icon
                                    icon={selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "" ?
                                      "bi:person-fill-check" : "bi:person-fill-x"}
                                    color={selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "" ? "#68a724" : "#C4C4C4"}
                                    width="24"
                                    height="24"
                                  />
                                </IconButton>
                                <IconButton
                                  onClick={() => {
                                    if (selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "") {
                                      handleClick3(true);
                                      setDdd(selectedDriver.vehicle_number)
                                    }
                                    else {
                                      setDelete1(true)
                                    }

                                  }}
                                ><Icon icon="ic:baseline-delete" color="#fa5d41" width="24" height="24" />
                                </IconButton>

                              </>
                              :
                              <><IconButton
                                onClick={() => {
                                  handleClickOpenn(true)
                                  setDriverEditArray(selectedDriver.driver_id);
                                }}>
                                <Icon icon="material-symbols:edit" color="black" width="22" height="22" rotate={2} hFlip={true} vFlip={true} />
                              </IconButton>
                                <IconButton
                                  onClick={() => {
                                    if (selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "") {
                                      handleClickOpentrip();
                                    }
                                    else {
                                      handleClickOpentrip();
                                    }
                                  }}
                                >
                                  <Icon
                                    icon={selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "" ? "bi:person-fill-check" : "bi:person-fill-x"}
                                    color={selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "" ? "#68a724" : "#c4c4c4"}
                                    width="24"
                                    height="24"
                                  />
                                </IconButton>

                                <IconButton
                                  onClick={() => {
                                    if (selectedDriver.driverassign_status === 'assign' && selectedDriver.vehicle_number != "") {
                                      handleClick3(true);
                                      setDdd(selectedDriver.vehicle_number)
                                    } else {
                                      setDelete1(true)
                                    }

                                  }}
                                ><Icon icon="ic:baseline-delete" color="#fa5d41" width="24" height="24" /></IconButton>
                              </>
                              // :
                              //   <IconButton
                              //     onClick={() => setDelete1(false)}
                              //   ><Icon icon="bi:person-fill-x" width="26" height="26" /></IconButton>}
                              //   </>
                            )
                            : null}</div>
                        </div>

                      ) : null}


                      {open === true ? (
                        <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}><Tabss open={open} setOpen={setOpen}
                          addResponse={addResponse}
                          notificationTimeOut={6000}
                          setLoginSucess={setAddDriverErrors}
                          loginSuccess={addDriverErrors} /></div>
                      ) : openn === true ? (
                        <List className={classes.lists}>
                          <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}>
                            <Box className={classes.styleA}>
                              <Typography align="top" className={classes.styleB}>
                                Driver Induction
                              </Typography>
                              {isMdUp === true ? null : (
                                <IconButton
                                  className={isMdUp === false ? classes.styleC : null}
                                  onClick={handleClose}
                                >
                                  <img
                                    src={logox}
                                    style={{
                                      border: 1,
                                      borderRadius: "30px",
                                      backgroundColor: "#FFFFFF",
                                    }}
                                  />
                                </IconButton>
                              )}

                              <Typography align="center" className={classes.styleD}>
                                Upload Profile (Max 100KB)
                              </Typography>
                              <div align="center">
                                <IconButton className={classes.styleE}>
                                  <Avatar>
                                    {editArray.profile_pic === '' ?
                                      <><input
                                        onInput={handleChangeProfile}
                                        type="file"
                                        style={{ opacity: 0, position: "absolute" }}
                                      />

                                        <Icon icon="material-symbols:photo-camera-outline" color="#7a7a7d" width="24" height="24" /></> :
                                      <img src={selectedDriver.profile_pic} />}
                                  </Avatar>
                                </IconButton>
                              </div>
                              <Box className={classes.styleF}>
                                <div>
                                  <AppBar
                                    position="static"
                                    className={classes.styleG}
                                  >
                                    <Tabs
                                      setOpenA={setOpenA}
                                      value={value}
                                      onChange={handleChangeA}
                                      indicatorColor="#000000"
                                      color="#000000"
                                      variant="fullWidth"
                                      aria-label="full width tabs example"
                                      className={classes.styleH}
                                    >
                                      <Tab
                                        className={
                                          isMdUp === false
                                            ? classes.styleIM
                                            : classes.styleJ
                                        }
                                        label="PERSONAL INFORMATION"
                                        {...a11yProps(0)}
                                      />
                                      <Tab
                                        className={
                                          isMdUp === false
                                            ? classes.styleK
                                            : classes.styleJ
                                        }
                                        label="ADDRESS"
                                        {...a11yProps(1)}
                                      />
                                      <Tab
                                        className={
                                          isMdUp === false
                                            ? classes.styleK
                                            : classes.styleJ
                                        }
                                        label="KYC DOCUMENT"
                                        {...a11yProps(2)}
                                      />
                                    </Tabs>
                                  </AppBar>
                                </div>
                              </Box>

                              <SwipeableViews
                                axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                                index={value}
                                onChangeIndex={handleChangeAIndex}
                              >
                                <TabPanel
                                  setOpenA={setOpenA}
                                  value={value}
                                  index={0}
                                  dir={theme.direction}
                                >
                                  <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        License Type
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <FormControlLabel
                                        control={
                                          <Checkbox
                                            disabled={resetType}
                                            checked={
                                              editArray.type &&
                                              editArray.type.includes("2W")
                                            }
                                            // onChange={handleChangeCheck}
                                            name="checkedA"
                                            color="primary"
                                          />
                                        }
                                        label="2W"
                                      />
                                      <FormControlLabel
                                        control={
                                          <Checkbox
                                            disabled={resetType}
                                            checked={
                                              editArray.type &&
                                              editArray.type.includes("E-Auto")
                                            }
                                            // onChange={handleChangeChecks}
                                            name="checkedB"
                                            color="primary"
                                          />
                                        }
                                        label="E-Auto"
                                      />
                                      <FormControlLabel
                                        control={
                                          <Checkbox
                                            disabled={resetType}
                                            checked={
                                              editArray.type &&
                                              editArray.type.includes("l5n")
                                            }
                                            // onChange={handleChangeCheckss}
                                            name="checkedC"
                                            color="primary"
                                          />
                                        }
                                        label="L5 Commericial Vehicle"
                                      />
                                      <FormControlLabel
                                        control={
                                          <Checkbox
                                            disabled={resetType}
                                            checked={
                                              editArray.type &&
                                              editArray.type.includes("Erickshaw")
                                            }
                                            // onChange={handleChangeCheckss}
                                            name="checkedC"
                                            color="primary"
                                          />
                                        }
                                        label="Erickshaw"
                                      />
                                      {/* <Button
                                      variant="danger"
                                      onClick={() => {
                                        setStateC(true);

                                        setStateD(true);
                                        setStateE(true);
                                        setResetType(false);
                                        setSelectedDriver((state) => ({
                                          ...state,
                                          type: "",
                                        }));
                                        setEditArray((state) => ({
                                          ...state,
                                          type: "",
                                        }));
                                        setTypeVar([]);
                                      }}
                                    >
                                      Reset
                                    </Button> */}
                                    </Grid>
                                    <Grid item lg={6} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Driver Name
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <TextField
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "name");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors && editArray.name === ""
                                        }
                                        value={`` || editArray.name}
                                      />
                                      <input
                                        type="hidden"
                                        name="driver_id"
                                        value={selectedDriver.driver_id}
                                      />
                                    </Grid>
                                    <Grid item lg={6} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Email
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <TextField
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "email");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editArray.email)
                                        }
                                        helperText={!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editArray.email) ? 'Enter Valid Email Id' : null}
                                        value={`` || editArray.email}
                                      />
                                    </Grid>
                                    <Grid item lg={4} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Mobile Number
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <TextField
                                        type="number"
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "mobile");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        helperText={!/^[0-9]{10}$/.test(editArray.mobile) ? 'Mobile number must be 10 digits' : null}
                                        error={
                                          addDriverErrors && !/^[0-9]{10}$/.test(editArray.mobile)
                                        }
                                        value={`` || editArray.mobile}
                                      />
                                    </Grid>
                                    <Grid item lg={4} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Language
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                                      <Select
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "language_id");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors && editArray.language_id === ""
                                        }
                                        value={`` || editArray.language_id}
                                      >
                                        <MenuItem value="">
                                          Select your language
                                        </MenuItem>
                                        {languageList &&
                                          languageList.map((lang) => {
                                            return (
                                              <MenuItem
                                                key={lang.language_id}
                                                value={lang.language_id}
                                              >
                                                {lang.language}
                                              </MenuItem>
                                            );
                                          })}
                                      </Select>
                                    </Grid>
                                    <Grid item lg={4} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Shift Time
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <Select
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "shift_id");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors &&
                                          editArray.shift_id === ""
                                        }
                                        value={`` || editArray.shift_id}
                                      >
                                        <MenuItem value="">
                                          Select your shift
                                        </MenuItem>
                                        {shiftList &&
                                          shiftList.map((sh, i) => {
                                            return (
                                              <MenuItem value={sh.shift_id} key={i}>
                                                {sh.time}
                                              </MenuItem>
                                            );
                                          })}
                                      </Select>
                                    </Grid>
                                  </Grid>
                                  <br /><br />
                                  <div
                                    style={{
                                      display: "flex",
                                      flexDirection: "row",
                                      flexWrap: "nowrap",
                                      alignContent: "center",
                                      justifyContent: "space-around",
                                      alignItems: "center",
                                    }}
                                  >
                                    <Button
                                      onClick={() => setOpenn(false)} style={{ fontSize: '12px' }}>Cancel</Button>
                                    <Button
                                      onClick={() => {
                                        handleChangeAIndex(1);
                                        scrollToTop();
                                      }}
                                      variant="contained" style={{ backgroundColor: '#4caf50', color: '#fff', fontSize: '12px' }}>Next
                                      <Icon icon="material-symbols:arrow-right-alt" color="white" width="16" height="16" />
                                    </Button>
                                  </div>
                                </TabPanel>

                                <TabPanel
                                  setOpenA={setOpenA}
                                  value={value}
                                  index={1}
                                  dir={theme.direction}
                                >
                                  <Grid container spacing={2}>
                                    <Grid item lg={6} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Primary Address
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <Paper
                                        component="form"
                                        className={classes.styleR}
                                      >
                                        <InputBase
                                          onChange={(e) => {
                                            setDriverEditFormArray(
                                              e,
                                              "primary_address"
                                            );
                                          }}
                                          fullWidth={true}
                                          error={
                                            addDriverErrors &&
                                            editArray.primary_address === ""
                                          }
                                          value={`` || editArray.primary_address}
                                        />
                                      </Paper>
                                    </Grid>
                                    <Grid item lg={6} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Secondary Address
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <Paper
                                        component="form"
                                        className={classes.styleR}
                                      >
                                        <InputBase
                                          onChange={(e) => {
                                            setDriverEditFormArray(
                                              e,
                                              "secondary_address"
                                            );
                                          }}
                                          fullWidth={true}
                                          error={
                                            addDriverErrors &&
                                            editArray.secondary_address === ""
                                          }
                                          value={`` || editArray.secondary_address}
                                        />
                                      </Paper>
                                    </Grid>

                                    <Grid item lg={3} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Primary Country
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      {countryList.length && (
                                        <Select
                                          style={{ minWidth: "100%" }}
                                          onChange={(e) => {
                                            setDriverEditFormArray(e, "country");
                                            getStates(e.target.value);
                                          }}
                                          size="small"
                                          id="outlined"
                                          className={classes.styleO}
                                          error={
                                            addDriverErrors &&
                                            editArray.country === ""
                                          }
                                          value={`` || editArray.country}
                                          // defaultValue={0}

                                          displayEmpty
                                        >
                                          <MenuItem value="">Select Country</MenuItem>
                                          {countryList.length &&
                                            countryList.map((el, i) => {
                                              return (
                                                <MenuItem
                                                  key={i}
                                                  value={el.country_id}
                                                >
                                                  {el.country_name}
                                                </MenuItem>
                                              );
                                            })}
                                        </Select>
                                      )}
                                    </Grid>

                                    <Grid item lg={3} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Primary  State
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <Select
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "state");
                                          getCities(e.target.value);
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors && editArray.state === ""
                                        }
                                        value={editArray.state || ""}
                                      >
                                        <MenuItem value="">Select City</MenuItem>
                                        {stateList.length &&
                                          stateList.map((el, i) => {
                                            return (
                                              <MenuItem key={i} value={el.state_id}>
                                                {el.state_name}
                                              </MenuItem>
                                            );
                                          })}
                                      </Select>
                                    </Grid>
                                    <Grid item lg={3} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Country
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      {countrySList.length && (
                                        <Select
                                          style={{ minWidth: "100%" }}
                                          onChange={(e) => {
                                            setDriverEditFormArray(e, "secondary_country");
                                            getSStates(e.target.value);
                                          }}
                                          size="small"
                                          id="outlined"
                                          className={classes.styleO}
                                          // error={
                                          //   addDriverErrors &&
                                          //   editArray.country === ""
                                          // }
                                          value={editArray && editArray.secondary_country}
                                        >
                                          <MenuItem value="">Select Country</MenuItem>
                                          {countrySList.length &&
                                            countrySList.map((el, i) => {
                                              return (
                                                <MenuItem
                                                  key={i}
                                                  value={el.country_id}
                                                >
                                                  {el.country_name}
                                                </MenuItem>
                                              );
                                            })}
                                        </Select>
                                      )}
                                    </Grid>
                                    <Grid item lg={3} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        State
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                                      <Select
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "secondary_state");
                                          getSCities(e.target.value);
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        // error={
                                        //   addDriverErrors && editArray.state === ""
                                        // }
                                        value={editArray && editArray.secondary_state}
                                      >
                                        <MenuItem value="">Select City</MenuItem>
                                        {stateSList.length &&
                                          stateSList.map((el, i) => {
                                            return (
                                              <MenuItem key={i} value={el.state_id}>
                                                {el.state_name}
                                              </MenuItem>
                                            );
                                          })}
                                      </Select>
                                    </Grid>
                                    <Grid item lg={3} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        Primary   City
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                                      <Select
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "city");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors && editArray.city === ""
                                        }
                                        value={`` || editArray.city}
                                        displayEmpty
                                      >
                                        <MenuItem value="">Select City</MenuItem>
                                        {cityList.length
                                          ? cityList.map((el, i) => {
                                            return (
                                              <MenuItem key={i} value={el.city_id}>
                                                {el.city_name}
                                              </MenuItem>
                                            );
                                          })
                                          : "Loading..."}
                                      </Select>
                                    </Grid><Grid item lg={3} xs={12} />
                                    <Grid item lg={3} xs={12}>
                                      <div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                        City
                                      </Typography>
                                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                                      <Select
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "secondary_city");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        value={editArray && editArray.secondary_city}
                                      // displayEmpty
                                      >
                                        <MenuItem value="">Select City</MenuItem>
                                        {citySList.length
                                          ? citySList.map((el, i) => {
                                            return (
                                              <MenuItem key={i} value={el.city_id}>
                                                {el.city_name}
                                              </MenuItem>
                                            );
                                          })
                                          : "Loading..."}
                                      </Select>
                                    </Grid>
                                  </Grid>
                                  <br /><br />
                                  <div
                                    style={{
                                      display: "flex",
                                      flexDirection: "row",
                                      flexWrap: "nowrap",
                                      alignContent: "center",
                                      justifyContent: "space-around",
                                      alignItems: "center",
                                    }}
                                  >
                                    <Button
                                      onClick={() => {
                                        handleChangeAIndex(0);
                                        scrollToTop();
                                      }}
                                      style={{ color: '#7A7A7D', fontSize: '12px' }}>
                                      <Icon icon="material-symbols:arrow-right-alt" color="#7A7A7D" width="16" height="16" rotate={2} />Back</Button>
                                    <Button
                                      onClick={() => {
                                        handleChangeAIndex(2);
                                        scrollToTop();
                                      }}
                                      variant="contained" style={{ backgroundColor: '#4caf50', color: '#fff', fontSize: '12px' }}>Next
                                      <Icon icon="material-symbols:arrow-right-alt" color="white" width="16" height="16" />
                                    </Button>
                                  </div>
                                </TabPanel>

                                <TabPanel
                                  setOpenA={setOpenA}
                                  value={value}
                                  index={2}
                                  dir={theme.direction}
                                >
                                  <Grid container spacing={2} >
                                    <Grid item lg={4} xs={12}>
                                      <ListItem alignItems="flex-start">
                                        <ListItemText
                                          primary={<div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                            Aadhar Number
                                          </Typography>
                                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>}
                                          secondary={
                                            <React.Fragment>
                                              <TextField
                                                onChange={(e) => {
                                                  setDriverEditFormArray(e, "aadhar_number");
                                                }}
                                                size="small"
                                                id="outlined"
                                                className={classes.styleO}
                                                error={
                                                  addDriverErrors &&
                                                  editArray.aadhar_number === ""
                                                }
                                                value={`` || editArray.aadhar_number}
                                              />
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                      <FormControlLabel style={{ marginLeft: '10px' }}
                                        control={
                                          // {driversAddForm.type === "checked"?driversAddForm.type="2W": ""}
                                          <Checkbox
                                            // type="checkbox"
                                            checked={
                                              editArray.address_proof === "aadhar"
                                            }
                                            onClick={() => {
                                              setEditArray((state) => ({
                                                ...state,
                                                address_proof: "aadhar",
                                              }));
                                            }}
                                          // name="2W"
                                          // color="primary"
                                          // value={driversAddForm.type}
                                          />
                                        }
                                        label={<Typography style={{ fontSize: '12px' }}>Use aadhar as primary proof</Typography>}
                                      />
                                    </Grid>
                                    <Grid item lg={2} xs={12}>
                                      <ListItem alignItems="flex-start">
                                        <ListItemText
                                          className={classes.style13}
                                          primary={<Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                            Aadhar Card
                                          </Typography>}
                                          secondary={
                                            <React.Fragment>
                                              {/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.aadhar) === false ?
                                                <IconButton variant="contained" component="label" style={{ backgroundColor: !/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.aadhar) && /fakepath/.test(editArray.aadhar) ? '#accc8a' : null }}  >
                                                  <input onInput={handleChangeAdhaar} hidden type="file" />
                                                  <Icon icon="material-symbols:cloud-upload" width="24" height="24" />
                                                </IconButton>
                                                : /fakepath/.test(editArray.aadhar) ? <IconButton variant="contained" component="label" style={{ backgroundColor: !/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.aadhar) && /fakepath/.test(editArray.aadhar) ? '#accc8a' : null }}  >
                                                  <input onInput={handleChangeAdhaar} hidden type="file" />
                                                  <Icon icon="material-symbols:cloud-upload" width="24" height="24" />
                                                </IconButton>
                                                  : <img src={editArray.aadhar} style={{ width: '130px', height: '100px' }} />
                                              }
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                    </Grid>
                                    <Grid item lg={4} xs={12}>
                                      <ListItem alignItems="flex-start">
                                        <ListItemText
                                          primary={<div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                            PAN Number
                                          </Typography>
                                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>}
                                          secondary={
                                            <React.Fragment>
                                              <TextField
                                                onChange={(e) => {
                                                  setDriverEditFormArray(e, "pan_number");
                                                }}
                                                size="small"
                                                id="outlined"
                                                className={classes.styleO}
                                                error={
                                                  addDriverErrors && editArray.aadhar === ""
                                                }
                                                value={`` || editArray.pan_number}
                                              />
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                    </Grid>
                                    <Grid item lg={2} xs={12}>
                                      <ListItem alignItems="flex-start">
                                        <ListItemText
                                          className={classes.style13}
                                          primary={<Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                            PAN Card
                                          </Typography>}
                                          secondary={
                                            <React.Fragment>
                                              {/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.pan) === false ?
                                                <IconButton variant="contained" component="label" style={{ backgroundColor: !/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.pan) && /fakepath/.test(editArray.pan) ? '#accc8a' : null }}  >
                                                  <input onInput={handleChangePAN} hidden type="file" />
                                                  <Icon icon="material-symbols:cloud-upload" width="24" height="24" />
                                                </IconButton>
                                                : /fakepath/.test(editArray.aadhar) ? <IconButton variant="contained" component="label" style={{ backgroundColor: !/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.pan) && /fakepath/.test(editArray.pan) ? '#accc8a' : null }}  >
                                                  <input onInput={handleChangePAN} hidden type="file" />
                                                  <Icon icon="material-symbols:cloud-upload" width="24" height="24" />
                                                </IconButton>
                                                  : <img src={editArray.pan} style={{ width: '130px', height: '100px' }} />
                                              }
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                    </Grid>
                                    <Grid item lg={4} xs={12}>
                                      <ListItem alignItems="flex-start">
                                        <ListItemText
                                          primary={<div style={{ display: 'flex' }}><Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                            Driving License Number
                                          </Typography>
                                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>}
                                          secondary={
                                            <React.Fragment>
                                              <TextField
                                                onChange={(e) => {
                                                  setDriverEditFormArray(
                                                    e,
                                                    "driving_license_number"
                                                  );
                                                }}
                                                size="small"
                                                id="outlined"
                                                className={classes.styleO}
                                                error={
                                                  addDriverErrors &&
                                                  editArray.driving_license_number === ""
                                                }
                                                value={`` || editArray.driving_license_number}
                                              />
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                      <FormControlLabel style={{ marginLeft: '10px' }}
                                        control={
                                          <Checkbox
                                            checked={editArray.address_proof === "dl"}
                                            onClick={() => {
                                              setEditArray((state) => ({
                                                ...state,
                                                address_proof: "dl",
                                              }));
                                            }}
                                          // name="2W"
                                          // color="primary"
                                          // value={driversAddForm.type}
                                          />
                                        }
                                        label={<Typography style={{ fontSize: '12px' }}>Use DL as primary proof</Typography>}
                                      />
                                    </Grid>
                                    <Grid item lg={2} xs={12}>
                                      <ListItem alignItems="flex-start">
                                        <ListItemText
                                          className={classes.style13}
                                          primary={<Typography style={{ fontSize: '16px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}>
                                            Driver License
                                          </Typography>}
                                          secondary={
                                            <React.Fragment>
                                              {/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.driver_license) === false ?
                                                <IconButton variant="contained" component="label" style={{ backgroundColor: !/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.driver_license) && /fakepath/.test(editArray.driver_license) ? '#accc8a' : null }}  >
                                                  <input onInput={handleChangeLicense} hidden type="file" />
                                                  <Icon icon="material-symbols:cloud-upload" width="24" height="24" />
                                                </IconButton>
                                                : /fakepath/.test(editArray.aadhar) ? <IconButton variant="contained" component="label" style={{ backgroundColor: !/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(editArray.driver_license) && /fakepath/.test(editArray.driver_license) ? '#accc8a' : null }}  >
                                                  <input onInput={handleChangeLicense} hidden type="file" />
                                                  <Icon icon="material-symbols:cloud-upload" width="24" height="24" />
                                                </IconButton>
                                                  : <img src={editArray.driver_license} style={{ width: '130px', height: '100px' }} />
                                              }
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                    </Grid><br />
                                    <Grid item xs={12} lg={12}>
                                      <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center' }}>
                                        <Button
                                          onClick={() => {
                                            handleChangeAIndex(1);
                                            scrollToTop();
                                          }}
                                          style={{ color: '#7A7A7D', fontSize: '12px' }}>
                                          <Icon icon="material-symbols:arrow-right-alt" color="#7A7A7D" width="16" height="16" rotate={2} />Back</Button>
                                        <Button
                                          onClick={() => {
                                            handleClose();
                                            handleChangeAIndex(3);

                                            // submitDriverEdit(true)
                                          }}
                                          variant="contained"
                                          type="submit" style={{ backgroundColor: '#4caf50', color: '#fff', fontSize: '12px' }}>Submit
                                        </Button>
                                      </div>

                                    </Grid>
                                  </Grid>

                                </TabPanel>
                              </SwipeableViews>
                            </Box></div>

                        </List>
                      ) : (
                        <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}>
                          <Box className={classes.style1}>
                            <br />

                            <Box className={classes.marginLR}>
                              <AppBar position="static" className={classes.style2}>
                                <Tabs
                                  // setOpen2={setOpen2}
                                  value={value}
                                  onChange={handleChangee}
                                  indicatorColor="#000000"
                                  color="#000000"
                                  variant="fullWidth"
                                  aria-label="full width tabs example"
                                  className={classes.style3}
                                >
                                  <Tab
                                    className={
                                      isMdUp === false
                                        ? classes.style4M
                                        : classes.style4
                                    }
                                    label="PERSONAL INFORMATION"
                                    {...a11yProps(0)}
                                  />
                                  <Tab
                                    className={
                                      isMdUp === false
                                        ? classes.style4M
                                        : classes.style4
                                    }
                                    label="ADDRESS"
                                    {...a11yProps(1)}
                                  />
                                  <Tab
                                    className={
                                      isMdUp === false
                                        ? classes.style4M
                                        : classes.style4
                                    }
                                    label="KYC DOCUMENT"
                                    {...a11yProps(2)}
                                  />
                                </Tabs>
                              </AppBar>
                            </Box>

                            <SwipeableViews
                              axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                              index={value}
                              onChangeIndex={handleChangeeIndex}
                            >
                              <TabPanel
                                // setOpen2={setopen2}
                                value={value}
                                index={0}
                                dir={theme.direction}
                              >
                                <List className={classes.style5}>
                                  <Grid container spacing={2}>
                                    <Grid item xs={12} lg={12}>
                                      <ListItem
                                        alignItems="flex-start"
                                        sx={{ userSelect: "none" }}
                                      >
                                        <ListItemAvatar>
                                          <img src={EditDriver} />
                                        </ListItemAvatar>
                                        <ListItemText
                                          className={classes.style6}
                                          primary={
                                            <>
                                              <FormControlLabel
                                                control={
                                                  <Checkbox
                                                    disabled={true}
                                                    checked={
                                                      selectedDriver.type &&
                                                      selectedDriver.type.includes("2W")
                                                    }
                                                    onChange={handleChangeCheck}
                                                    name="checkedA"
                                                    color="primary"
                                                  />
                                                }
                                                label="2W"
                                              />
                                              <FormControlLabel
                                                control={
                                                  <Checkbox
                                                    checked={
                                                      selectedDriver.type &&
                                                      selectedDriver.type.includes(
                                                        "E-Auto"
                                                      )
                                                    }
                                                    onChange={handleChangeChecks}
                                                    name="checkedB"
                                                    disabled={true}
                                                    color="primary"
                                                  />
                                                }
                                                label="E-Auto"
                                              />
                                              <FormControlLabel
                                                control={
                                                  <Checkbox
                                                    checked={
                                                      selectedDriver.type &&
                                                      selectedDriver.type.includes(
                                                        "l5n"
                                                      )
                                                    }
                                                    onChange={handleChangeCheckss}
                                                    name="checkedC"
                                                    disabled={true}
                                                    color="primary"
                                                  />
                                                }
                                                label="L5 Commericial Vehicle"
                                              />
                                              <FormControlLabel
                                                control={
                                                  <Checkbox
                                                    checked={
                                                      selectedDriver.type &&
                                                      selectedDriver.type.includes(
                                                        "Erickshaw"
                                                      )
                                                    }
                                                    onChange={handleChangeChecksss}
                                                    name="checkedC"
                                                    disabled={true}
                                                    color="primary"
                                                  />
                                                }
                                                label="Erickshaw"
                                              />
                                            </>
                                          }
                                          secondary={
                                            <React.Fragment>
                                              <Typography
                                                style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                                component="span"
                                              >
                                                License Type
                                              </Typography>
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem><Divider />
                                    </Grid>

                                    <Grid item xs={12} lg={6}> <ListItem
                                      alignItems="flex-start"
                                    >
                                      <ListItemAvatar>
                                        <img src={MobNum} />
                                      </ListItemAvatar>
                                      <ListItemText
                                        className={classes.style6}
                                        primary={
                                          <Typography
                                            className={classes.style7}
                                            component="span"
                                          >
                                            {selectedDriver.mobile}
                                          </Typography>
                                        }
                                        secondary={
                                          <React.Fragment>
                                            <Typography
                                              style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                              component="span"
                                            >
                                              Mobile Number
                                            </Typography>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem><Divider /></Grid>
                                    <Grid item xs={12} lg={6}><ListItem
                                      alignItems="flex-start"
                                    >
                                      <ListItemAvatar>
                                        <img src={EditMail} />
                                      </ListItemAvatar>
                                      <ListItemText
                                        className={classes.style6}
                                        primary={
                                          <Typography
                                            className={classes.style7}
                                            component="span"
                                          >
                                            {selectedDriver.email}
                                          </Typography>
                                        }
                                        secondary={
                                          <React.Fragment>
                                            <Typography
                                              style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                              component="span"
                                            >
                                              Email
                                            </Typography>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem><Divider /></Grid>
                                    <Grid item xs={12} lg={6}><ListItem
                                      alignItems="flex-start"
                                    >
                                      <ListItemAvatar>
                                        <img src={EditLang} />
                                      </ListItemAvatar>
                                      <ListItemText
                                        className={classes.style6}
                                        primary={
                                          <Typography
                                            className={classes.style7}
                                            component="span"
                                          >
                                            {selectedDriver.language}
                                          </Typography>
                                        }
                                        secondary={
                                          <React.Fragment>
                                            <Typography
                                              style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                              component="span"
                                            >
                                              Language
                                            </Typography>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem><Divider /></Grid>
                                    <Grid item xs={12} lg={6}><ListItem
                                      alignItems="flex-start"
                                    >
                                      <ListItemAvatar>
                                        <img src={EditTime} />
                                      </ListItemAvatar>
                                      <ListItemText
                                        className={classes.style6}
                                        primary={
                                          <Typography className={classes.style7}

                                            component="span"
                                          >
                                            {selectedDriver.shift_time}
                                          </Typography>
                                        }
                                        secondary={
                                          <React.Fragment>
                                            <Typography
                                              style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                              component="span"
                                            >
                                              Shift Time
                                            </Typography>
                                          </React.Fragment>
                                        }
                                      />
                                    </ListItem><Divider /></Grid></Grid>
                                </List>
                              </TabPanel>

                              <TabPanel
                                // setOpen2={setOpen2}
                                value={value}
                                index={1}
                                dir={theme.direction}
                              >
                                <List className={classes.style5}>
                                  <Grid container spacing={2}>
                                    <Grid item xs={12} lg={6} style={{ borderRight: '2px solid #f1f1f1' }}>
                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <ListItemAvatar>
                                          <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px', marginTop: 1 }}>
                                            <Icon
                                              icon="ic:baseline-location-on"
                                              color="#fff"
                                              width="22"
                                              height="22"
                                            />
                                          </Avatar>
                                        </ListItemAvatar>
                                        <ListItemText
                                          primary={
                                            <div>
                                              <Typography
                                                style={{
                                                  fontSize: "15px",
                                                  fontFamily: "Maven Pro !important",
                                                  fontWeight: 700,
                                                  color: "#68a724", whiteSpace: 'wrap'
                                                }}
                                              >Primary Address</Typography>
                                              <Typography style={{ fontWeight: 600, color: '#989898', fontSize: "15px", whiteSpace: 'normal' }}>
                                                {selectedDriver.primary_address}</Typography>
                                            </div>
                                          }
                                          secondary={
                                            <React.Fragment><br />
                                              <Typography
                                                className={classes.style10}
                                              >
                                                Country:
                                              </Typography>
                                              {countryList.length &&
                                                countryList.map((el) => {
                                                  if (
                                                    el.country_id ==
                                                    selectedDriver.country
                                                  ) {
                                                    return (
                                                      <b
                                                        style={{ fontSize: "inherit" }}
                                                      >
                                                        &nbsp;&nbsp;{el.country_name}
                                                      </b>
                                                    );
                                                  }
                                                })}
                                              <br /> <br />
                                              <Typography
                                                className={classes.style10}
                                                component="span"
                                              >
                                                State:
                                              </Typography>
                                              {stateList.length &&
                                                stateList.map((el) => {
                                                  if (
                                                    el.state_id == selectedDriver.state
                                                  ) {
                                                    return (
                                                      <b
                                                        style={{ fontSize: "inherit" }}
                                                      >
                                                        &nbsp;&nbsp;{el.state_name}
                                                      </b>
                                                    );
                                                  }
                                                })}
                                              <br /> <br />
                                              <Typography
                                                className={classes.style10}
                                                component="span"
                                              >
                                                City:
                                              </Typography>

                                              {cityList.length &&
                                                cityList.map((el) => {
                                                  if (
                                                    el.city_id == selectedDriver.city
                                                  ) {
                                                    return (
                                                      <b
                                                        style={{ fontSize: "inherit" }}
                                                      >
                                                        &nbsp;&nbsp;{el.city_name}
                                                      </b>
                                                    );
                                                  }
                                                })}
                                              <br />
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                    </Grid>
                                    <Grid item xs={12} lg={6} >
                                      <ListItem
                                        alignItems="flex-start"
                                      >
                                        <ListItemAvatar>
                                          <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px', marginTop: 1 }}>
                                            <Icon
                                              icon="ic:baseline-location-on"
                                              color="#fff"
                                              width="22"
                                              height="22"
                                            />
                                          </Avatar>
                                        </ListItemAvatar>
                                        <ListItemText
                                          primary={
                                            <div><Typography
                                              style={{
                                                fontSize: "15px",
                                                fontFamily: "Maven Pro !important",
                                                fontWeight: 700,
                                                color: "#68a724", whiteSpace: 'wrap'
                                              }}
                                              component="span"
                                            >Secondary Address&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;</Typography>
                                              <Typography style={{ fontWeight: 600, color: '#989898', fontSize: "15px", whiteSpace: 'normal' }}>{selectedDriver.secondary_address}</Typography></div>
                                          }
                                          secondary={
                                            <React.Fragment><br />
                                              <Typography
                                                className={classes.style10}
                                                component="span"
                                              >
                                                Country:
                                              </Typography>
                                              {countrySList.length &&
                                                countrySList.map((el) => {
                                                  if (
                                                    el.country_id ==
                                                    selectedDriver.secondary_country
                                                  ) {
                                                    return (
                                                      <b
                                                        style={{ fontSize: "inherit" }}
                                                      >
                                                        &nbsp;&nbsp;{el.country_name}
                                                      </b>
                                                    );
                                                  }
                                                })}
                                              <br /> <br />
                                              <Typography
                                                className={classes.style10}
                                                component="span"
                                              >
                                                State:
                                              </Typography>
                                              {stateSList.length &&
                                                stateSList.map((el) => {
                                                  if (
                                                    el.state_id == selectedDriver.secondary_state
                                                  ) {
                                                    return (
                                                      <b
                                                        style={{ fontSize: "inherit" }}
                                                      >
                                                        &nbsp;&nbsp;{el.state_name}
                                                      </b>
                                                    );
                                                  }
                                                })}
                                              <br /> <br />
                                              <Typography
                                                className={classes.style10}
                                                component="span"
                                              >
                                                City:
                                              </Typography>

                                              {citySList.length &&
                                                citySList.map((el) => {
                                                  if (
                                                    el.city_id == selectedDriver.secondary_city
                                                  ) {
                                                    return (
                                                      <b
                                                        style={{ fontSize: "inherit" }}
                                                      >
                                                        &nbsp;&nbsp;{el.city_name}
                                                      </b>
                                                    );
                                                  }
                                                })}
                                              <br />
                                            </React.Fragment>
                                          }
                                        />
                                      </ListItem>
                                    </Grid>
                                  </Grid>
                                </List>
                              </TabPanel>

                              <TabPanel
                                value={value}
                                index={2}
                                dir={theme.direction}
                              >
                                <List className={classes.style5}>
                                  <Grid container spacing={2}>
                                    <Grid item xs={12} lg={1} />
                                    <Grid item xs={12} lg={5}>
                                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                                        <ListItem alignItems="flex-start">
                                          <ListItemText
                                            style={{ color: '#000000', width: '150px' }}
                                            primary={selectedDriver.aadhar_number}
                                            secondary={
                                              <React.Fragment>
                                                <Typography
                                                  className={classes.style10}
                                                >
                                                  Aadhar Number
                                                </Typography>
                                              </React.Fragment>
                                            }
                                          />
                                        </ListItem>
                                        <ListItem alignItems="flex-start">
                                          <ListItemText
                                            className={classes.style13}
                                            primary={/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(selectedDriver.aadhar) === false ?
                                              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmtF4VdOl8_m-1FayEemKpgZvDuvgHOqAhFQ&usqp=CAU" style={{ width: '130px', height: '100px' }} />
                                              : /fakepath/.test(selectedDriver.aadhar) ? <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmtF4VdOl8_m-1FayEemKpgZvDuvgHOqAhFQ&usqp=CAU" style={{ width: '130px', height: '100px' }} />
                                                : <img src={selectedDriver.aadhar} style={{ width: '130px', height: '100px' }} />
                                            }
                                            secondary={<React.Fragment><Typography style={{
                                              float: 'left',
                                              fontSize: "15px",
                                              fontFamily: " Maven Pro",
                                              fontWeight: 500,
                                              color: "#68a724"
                                            }}
                                            >Aadhar</Typography>
                                            </React.Fragment>}
                                          />
                                        </ListItem>
                                      </div>
                                    </Grid>
                                    <Grid item xs={12} lg={5}>
                                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                                        <ListItem alignItems="flex-start">
                                          <ListItemText
                                            style={{ color: '#000000', width: '150px' }}
                                            primary={selectedDriver.pan_number}
                                            secondary={
                                              <React.Fragment>
                                                <Typography
                                                  className={classes.style10}
                                                >
                                                  PAN Number
                                                </Typography>
                                              </React.Fragment>
                                            }
                                          />
                                        </ListItem>
                                        <ListItem alignItems="flex-start">
                                          <ListItemText
                                            className={classes.style13}
                                            primary={/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(selectedDriver.pan) === false ?
                                              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmtF4VdOl8_m-1FayEemKpgZvDuvgHOqAhFQ&usqp=CAU" style={{ width: '130px', height: '100px' }} />
                                              : /fakepath/.test(selectedDriver.pan) ? <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmtF4VdOl8_m-1FayEemKpgZvDuvgHOqAhFQ&usqp=CAU" style={{ width: '130px', height: '100px' }} />
                                                : <img src={selectedDriver.pan} style={{ width: '130px', height: '100px' }} />
                                            }
                                            secondary={<React.Fragment><Typography style={{
                                              float: 'left',
                                              fontSize: "15px",
                                              fontFamily: " Maven Pro",
                                              fontWeight: 500,
                                              color: "#68a724"
                                            }}
                                            >PAN</Typography>
                                            </React.Fragment>}
                                          />
                                        </ListItem></div>
                                    </Grid>
                                    <Grid item xs={12} lg={1} /><Grid item xs={12} lg={1} />
                                    <Grid item xs={12} lg={5}>
                                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                                        <ListItem alignItems="flex-start">
                                          <ListItemText
                                            style={{ color: '#000000', width: '150px' }}
                                            primary={
                                              selectedDriver.driving_license_number
                                            }
                                            secondary={
                                              <React.Fragment>
                                                <Typography
                                                  style={{
                                                    fontSize: "15px",
                                                    fontFamily: " Maven Pro",
                                                    fontWeight: 500,
                                                    color: "#68a724"
                                                  }}
                                                >
                                                  License Number
                                                </Typography>
                                              </React.Fragment>
                                            }
                                          />
                                        </ListItem>
                                        <ListItem alignItems="flex-start">
                                          <ListItemText
                                            className={classes.style13}
                                            primary={/\.(jpeg|jpg|png|gif|bmp|jfif)$/i.test(selectedDriver.driver_license) === false ?
                                              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmtF4VdOl8_m-1FayEemKpgZvDuvgHOqAhFQ&usqp=CAU" style={{ width: '130px', height: '100px' }} />
                                              : /fakepath/.test(selectedDriver.driver_license) ? <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmtF4VdOl8_m-1FayEemKpgZvDuvgHOqAhFQ&usqp=CAU" style={{ width: '130px', height: '100px' }} />
                                                : <img src={selectedDriver.driver_license} style={{ width: '130px', height: '100px' }} />
                                            }
                                            secondary={<React.Fragment><Typography style={{
                                              display: "inline-block",
                                              fontSize: "15px",
                                              fontFamily: " Maven Pro",
                                              fontWeight: 500,
                                              color: "#68a724"
                                            }}
                                            >License</Typography>
                                            </React.Fragment>}
                                          />
                                        </ListItem></div>
                                    </Grid>
                                  </Grid>

                                </List>
                              </TabPanel>
                            </SwipeableViews>
                          </Box>
                        </div>

                      )}
                    </Item>
                  </Grid>
                ) : null}
              </Grid>
              <div style={{ display: 'flex', marginLeft: '20px', width: '300px', justifyContent: 'space-between', marginTop: '-15px' }}>
                {searchTerm1 === "2W" ? <Tooltip title={"2 Wheeler"} placement="top">
                  <IconButton onClick={() => { setSearchTerm1("") }}>
                    <Icon icon="mdi:motorbike" color={searchTerm1 === "2W" ? "#68a724" : null} width="24" height="24" />
                  </IconButton></Tooltip> :
                  <Tooltip title={"2 Wheeler"} placement="top">
                    <IconButton onClick={() => { setSearchTerm1("2W") }}>
                      <Icon icon="mdi:motorbike" color={searchTerm1 === "2W" ? "#68a724" : null} width="24" height="24" />
                    </IconButton></Tooltip>}

                {searchTerm1 === "E-Auto" ? <Tooltip title={"E-Auto"} placement="top">
                  <IconButton onClick={() => { setSearchTerm1("") }}>
                    <Icon icon="fluent-emoji-high-contrast:auto-rickshaw" color={searchTerm1 === "E-Auto" ? "#68a724" : null} width="24" height="24" />
                  </IconButton></Tooltip> :
                  <Tooltip title={"E-Auto"} placement="top">
                    <IconButton onClick={() => { setSearchTerm1("E-Auto") }}>
                      <Icon icon="fluent-emoji-high-contrast:auto-rickshaw" color={searchTerm1 === "E-Auto" ? "#68a724" : null} width="24" height="24" />
                    </IconButton></Tooltip>}

                {searchTerm1 === "l5n" ? <Tooltip title={"L5com"} placement="top">
                  <IconButton onClick={() => { setSearchTerm1("") }}>
                    <Icon icon="fa-solid:truck-pickup" color={searchTerm1 === "l5n" ? "#68a724" : null} width="24" height="24" />
                  </IconButton></Tooltip> :
                  <Tooltip title={"L5com"} placement="top">
                    <IconButton onClick={() => { setSearchTerm1("l5n") }}>
                      <Icon icon="fa-solid:truck-pickup" color={searchTerm1 === "l5n" ? "#68a724" : null} width="24" height="24" />
                    </IconButton></Tooltip>}

                {searchTerm1 === "Erickshaw" ? <Tooltip title={"Erickshaw"} placement="top">
                  <IconButton onClick={() => { setSearchTerm1("") }}>
                    <Icon icon="material-symbols:electric-rickshaw" color={searchTerm1 === "Erickshaw" ? "#68a724" : null} width="24" height="24" />
                  </IconButton></Tooltip> :
                  <Tooltip title={"Erickshaw"} placement="top">
                    <IconButton onClick={() => { setSearchTerm1("Erickshaw") }}>
                      <Icon icon="material-symbols:electric-rickshaw" color={searchTerm1 === "Erickshaw" ? "#68a724" : null} width="24" height="24" />
                    </IconButton></Tooltip>}


                {/* Delete Driver */}
                <Dialog
                  fullScreen={isSmUp}
                  open={delete1}
                  maxWidth={"lg"}
                  onClose={() => setDelete1(false)}
                  aria-labelledby="responsive-dialog-title"
                  style={{ width: '1200px', position: 'relative', marginLeft: '680px', marginTop: '250px' }}
                >
                  <DialogTitle id="responsive-dialog-title">{"Offboarding Driver"}</DialogTitle>
                  <DialogContent>
                    <DialogContentText>
                      {/* {selectedDriver.driverassign_status === 'assign' ? 
                      <b style={{ fontSize: '14px', color: '#00000070' }}>This Driver assigned to {selectedDriver.vehicle_number}</b>
                      : */}
                      <Grid container spacing={2}>
                        <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                        <Grid item lg={12} xs={12}>
                          <TextField style={{
                            width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
                            'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
                          }}
                            onChange={(e) => { setPassword1(e.target.value) }}
                          />

                        </Grid>
                      </Grid>
                      {/* } */}
                    </DialogContentText>
                  </DialogContent>
                  <DialogActions>
                    <Button
                      onClick={() => setDelete1(false)}
                      color="primary">
                      Cancel
                    </Button>
                    <Button
                      disabled={password1 !== userPassword}
                      onClick={() => {
                        deleteDriver(selectedDriver.driver_id);
                      }}
                      color="secondary">
                      Offboarding
                    </Button>
                  </DialogActions>
                </Dialog>


              </div>

            </Box>

          )}
        </div><br />
        <Typography align="center" style={{
          fontSize: '16px', color: '#68A724', fontWeight: 700,
          fontStyle: 'Bold', whiteSpace: 'nowrap'
        }}> Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography></>

    );
  } else {
    return <>
      <Box sx={{ display: 'flex', justifyContent: 'space-around' }}>
        <CircularProgress style={{ height: '100px', width: '100px' }} />
      </Box><br /><br /><br />
      <Typography align="center" style={{ fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap' }}> Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography></>
  }
}
