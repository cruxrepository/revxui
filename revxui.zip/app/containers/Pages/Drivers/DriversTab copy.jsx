import React from "react";
import axios from "axios";

// import "./../Drivers/";
import { styled, useTheme, makeStyles } from "@material-ui/core/styles";
import useMediaQuery from "@material-ui/core/useMediaQuery";
// import CssBaseline from "@material-ui/core/CssBaseline";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Avatar from "@material-ui/core/Avatar";
import ListItemAvatar from "@material-ui/core/ListItemAvatar";
import logodr1 from "./imgs/dr1.svg";
import logodr2 from "./imgs/dr2.svg";
import logodr3 from "./imgs/dr3.svg";
import logodr4 from "./imgs/dr4.svg";
import IconButton from "@material-ui/core/IconButton";
import SearchIcon from "@material-ui/icons/Search";
import logox from "./imgs/x.svg";
import logofil from "./imgs/filter.svg";
import edit from "./imgs/edit.svg";
import menu from "./imgs/menu.svg";
import Button from "@material-ui/core/Button";
import Tabss from "./Tabss";
import profile from "./imgs/profile.svg";
import down from "./imgs/down.svg";
import { useNavigate } from "react-router-dom";
import Dialog from "@material-ui/core/Dialog";
import InputAdornment from "@material-ui/core/InputAdornment";
import TextField from "@material-ui/core/TextField";
import PropTypes from "prop-types";
import SwipeableViews from "react-swipeable-views";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import next from "./imgs/next.svg";
import back from "./imgs/back.svg";
import logo28 from "./imgs/cam.svg";
import InputBase from "@material-ui/core/InputBase";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Divider from "@material-ui/core/Divider";
import Select from "@material-ui/core/Select";
import classNames from "classnames";
import "./App.css";
import { Icon } from "@iconify/react";

import EditDriver from "./imgs/editdriver.svg";
import EditName from "./imgs/editname.svg";
import EditUser from "./imgs/edituser.svg";
import MobNum from "./imgs/mobNum.svg";
import EditMail from "./imgs/editMail.svg";
import EditLang from "./imgs/editLang.svg";
import EditTime from "./imgs/editTime.svg";
import Prime from "./imgs/editPrim.svg";
import Secondary from "./imgs/editSecon.svg";
import SimpleMap from "./SimpleMap";
// import Stepper from "./Stepper";
import Brightness1Icon from "@material-ui/icons/Brightness1";

import Timeline from "@material-ui/lab/Timeline";
import TimelineItem from "@material-ui/lab/TimelineItem";
import TimelineSeparator from "@material-ui/lab/TimelineSeparator";
import TimelineConnector from "@material-ui/lab/TimelineConnector";
import TimelineContent from "@material-ui/lab/TimelineContent";
import TimelineDot from "@material-ui/lab/TimelineDot";
import LocationOnOutlinedIcon from "@material-ui/icons/LocationOnOutlined";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { useDispatch, useSelector } from "react-redux";
import Loading from "../../../components/Loading";
import ErrorWrap from "../../../components/Error/ErrorWrap";
import { getDriverBulk } from "../../../redux/actions/asyncActions";
// import { getRolePerBulk } from "../../../redux/actions/asyncActions";
import SimpleSnackbar from "../Users/SimpleSnackbar";

import endpoints from "../../../endpoints/endpoints";
// import { useEffect, useState } from "react";

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#ffffff" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "left",
  color: theme.palette.text.secondary,
}));

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  map: {
    height: 370,
    overflowY: "hidden",
    borderRadius: 2,
    position: "relative",
  },
  gridBG: {
    backgroundColor: "#F1F1F1",
    height: "986px",
  },
  lists: {
    color: "rgba(122, 122, 125, 1)",
    p: 1,
    fontFamily: " Maven Pro",
  },
  txtField: {
    m: 1,
    width: "22ch",
    backgroundColor: "#fff",
    marginLeft: "40px",
    borderRadius: "8px",
    // , '.MuiOutlinedInput-notchedOutline': { borderColor: '#fff !important', borderRadius: '9px !important' },
    // '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#fff  !important' }
  },
  sevenDrive: {
    fontSize: "20px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#7A7A7D",
    marginLeft: "90px",
  },
  txtBoxS: {
    width: "90%",
    color: "#FFFFFF",
    borderRadius: "10px",
    marginLeft: "2px",
    marginRight: 3,
    backgroundColor: "#fff",
    height: "80px",
  },
  txtBoxN: {
    width: "90%",
    color: "#FFFFFF",
    borderRadius: 2,
    marginLeft: "2px",
    marginRight: 3,
    backgroundColor: "#F1F1F1",
    height: "80px",
  },
  pointer: {
    cursor: "pointer",
  },
  primarytxt: {
    display: "inline",
    fontSize: "20px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#6C6C6C",
    marginLeft: "15px",
  },
  primarytxt1: {
    display: "inline",
    fontSize: "16px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#0000000",
    marginLeft: "10px",
  },
  primarytxt2: {
    display: "inline",
    fontSize: "18px",
    fontFamily: "Roboto !important",
    fontWeight: 700,
    color: "#0000000",
    marginLeft: "10px",
  },
  secondarytxt: {
    display: "inline",
    fontSize: "18px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#7A7A7D",
    marginLeft: "15px",
  },
  secondarytxt1: {
    display: "inline",
    fontSize: "14px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#7A7A7D",
    marginLeft: "10px",
  },
  secondarytxt2: {
    display: "inline",
    fontSize: "14px",
    fontFamily: "Roboto",
    fontWeight: 500,
    color: "#828282",
    marginLeft: "10px",
  },
  mobile: {
    display: "inline",
    fontSize: "14px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#68A724",
    marginLeft: "10px",
  },
  colorYes: {
    width: "100%",
    height: "100%",
    backgroundColor: "#C4C4C4",
  },
  colorNo: {
    width: "100%",
    height: "100%",
    backgroundColor: "#F1F1F1",
  },
  mt: {
    marginTop: "-7px",
    height: "1000px",
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  style1: {
    backgroundColor: "#FFFFFF",
    border: 1,
    color: "#68A724",
    width: "100%",
  },
  style2: {
    backgroundColor: "#FFFFFF",
    boxShadow: "0px 0px 0px 0px",
  },
  style3: {
    margin: 1,
    ".Mui-selected": { backgroundColor: "#68A72480", color: "#fff", border: 0 },
  },
  style4: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
  },
  style4M: {
    fontSize: "8px",
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
  },
  style5: {
    width: "100%",
    bgcolor: "#ffffff",
  },
  style6: {
    marginTop: "2px",
  },
  style6M: {
    fontSize: "12px",
  },
  style7: {
    display: "inline",
    fontSize: "18px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#6C6C6C",
    marginLeft: 2,
  },
  style7M: {
    display: "inline",
    fontSize: "12px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#6C6C6C",
    marginLeft: 2,
  },
  style8: {
    display: "inline",
    fontSize: "15px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#7A7A7D",
    marginLeft: 2,
  },
  style9: {
    display: "inline",
    fontSize: "15px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#6C6C6C",
    whiteSpace: "wrap",
  },
  style9M: {
    fontSize: "12px",
    fontFamily: "Maven Pro",
    fontWeight: 700,
    color: "#6C6C6C",
  },
  style10: {
    display: "inline-block",
    fontSize: "15px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#7A7A7D",
    width:'150px'
  },
  style10M: {
    display: "inline",
    fontSize: "12px",
    fontFamily: " Maven Pro",
    fontWeight: 500,
    color: "#7A7A7D",
  },
  style11: {
    display: "inline",
    fontSize: "17px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#A7A7A7",
  },
  style11M: {
    display: "inline",
    fontSize: "14px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#A7A7A7",
  },
  style13: {
    display: "inline",
    color: "#A7A7A7",
  },
  style12: {
    color: "#000000",
  },
  style14: {
    border: 1,
    width: 80,
    height: 27,
    backgroundColor: "#AFB4AB",
    color: "#FFFDFD",
    ".MuiButtonBase-root": {
      ":hover": { backgroundColor: "#AFB4AB !important" },
    },
  },
  marginLR: {
    marginLeft: "8px",
    marginRight: "8px",
  },
  styleA: {
    backgroundColor: "#FFFFFF",
    border: 1,
    color: "#68A724",
    width: "95%",
  },
  styleB: {
    fontSize: "22px",
    fontFamily: " Maven Pro",
    fontWeight: 700,
    color: "#68A724",
    marginLeft: 5,
    marginTop: 1,
  },
  styleD: {
    fontSize: "20px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#929191",
  },
  styleE: {
    padding: "8px",
  },
  styleG: {
    backgroundColor: "#FFFFFF",
    boxShadow: "0px 0px 0px 0px",
  },
  styleH: {
    margin: 1,
    ".Mui-selected": { backgroundColor: "#68A72480", color: "#fff", border: 0 },
  },
  styleJ: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
  },
  styleK: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
    fontSize: "10px",
  },
  styleIM: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
    fontSize: "9px",
  },
  styleL: {
    fontSize: "17px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#A7A7A7",
  },
  styleM: {
    width: "100%",
    borderRadius: "9px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#7A7A7D  !important",
    },
  },
  styleO: {
    width: "100%",
    color: "#7A7A7D",
    borderRadius: "9px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#C4C4C4  !important",
    },
    "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
  },
  styleS: {
    width: "100%",
    color: "#7A7A7D",
    borderRadius: "9px",
  },
  styleR: {
    padding: "2px 4px",
    display: "flex",
    alignItems: "center",
    width: "100%",
    height: "70px",
    boxShadow: "0px 0px 0px 0px",
    border: "1px solid",
    color: "#C4C4C4",
    borderRadius: "9px",
  },
  styleP: {
    textTransform: "capitalize",
    fontFamily: " Maven Pro",
    fontSize: "22px",
    fontWeight: 400,
    color: "#7A7A7D",
  },
  stylePM: {
    textTransform: "capitalize",
    fontFamily: " Maven Pro",
    fontSize: "16px",
    fontWeight: 400,
    color: "#7A7A7D",
  },
  styleQ: {
    textTransform: "capitalize",
    fontFamily: " Maven Pro",
    width: "110px",
    height: "40px",
    backgroundColor: "#4CAF50 !important",
    fontSize: "22px",
    color: "#FFFFFF",
    fontWeight: 700,
    fontFamily: " Maven Pro",
    ":hover": { backgroundColor: "#4CAF50" },
  },
  styleQM: {
    textTransform: "capitalize",
    fontFamily: " Maven Pro",
    width: "90px",
    height: "30px",
    backgroundColor: "#4CAF50",
    fontSize: "16px",
    color: "#FFFFFF",
    fontWeight: 700,
    ":hover": { backgroundColor: "#4CAF50" },
  },
  paperRoot: {
    ".MuiPaper-root.MuiPaper-elevation": { minWidth: "150px !important" },
  },
  select: {
    ".MuiSelect-select.MuiSelect-outlined.MuiOutlinedInput-input.MuiInputBase-input": {
      fontSize: "15px !important",
      marginLeft: "40px",
      color: "#C4C4C4",
    },
  },
  styleN: {
    ".MuiPaper-root": { width: "80% !important", marginLeft: "60px" },
  },
  styleC: {
    marginLeft: "230px",
    marginTop: "-55px",
  },
  styleF: {
    marginLeft: "8px",
    marginRight: "8px",
  },
  tabBoxMM: {
    backgroundColor: "#FFFFFF",
    border: 1,
    color: "#68A724",
    width: "95%",
  },
  taboneMd: {
    border: "1px solid #F1F1F1",
    fontFamily: " Maven Pro",
    borderColor: "#00000033",
    borderRadius: "10px 10px 0px 0px",
    color: "#000000",
    fontSize: "9px",
  },
  GridPaper: {
    backgroundColor: "#FFFFFF",
  },
  tripText: {
    fontSize: "14px",
    color: "#000000",
    fontWeight: 600,
    marginLeft: 10,
  },
  primaryText: {
    fontFamily: "Open Sans",
    fontSize: "14px",
    fontWeight: 600,
    color: "primary",
    width: "300px",
  },
  secondaryText: {
    fontFamily: "Roboto",
    fontSize: "12px",
    fontWeight: 400,
    color: "#7A7A7D",
    width: "100%",
  },
  driving: {
    color: "#82E219",
    width: "5rem",
    fontSize: "20px",
  },
  secondaryTextG: {
    fontFamily: "Roboto",
    fontSize: "14px",
    fontWeight: 400,
    color: "#68A724",
    width: "100%",
  },
  secondaryTail: {
    backgroundColor: theme.palette.secondary.main,
  },
  time: {
    backgroundColor: "#F51919",
  },
  loc: {
    marginLeft: "-8px",
  },
  timetxt: {
    display: "inline",
    fontSize: "18px",
    fontFamily: "Maven Pro !important",
    fontWeight: 700,
    color: "#0000000",
  },
  timetxt1: {
    display: "inline",
    fontSize: "14px",
    fontFamily: " Maven Pro",
    fontWeight: 700,
    color: "#808080",
  },
  hover: {
    ":hover": { backgroundColor: "#000000 !important" },
  },
}));
function changeBackground(e) {
  e.target.style.background = "#68A72450";
}
function changeBackground1(e) {
  e.target.style.background = "#F1F1F1";
}
function changeBackground2(e) {
  e.target.style.background = "#fff";
}
function TabPanel(props) {
  const {
    setOpen2,
    open2,
    setOpenA,
    openA,
    children,
    value,
    index,
    ...other
  } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `full-width-tab-${index}`,
    "aria-controls": `full-width-tabpanel-${index}`,
  };
}

export default function DriversTab(props) {
  // list drivers
  const totaldrivers = useSelector((store) => store.driverAll.totalRecords);
  // const driverPresent = useSelector((store) => store.driverAll.dataPresent)

  const driver = useSelector((store) => store.driverAll.data.data);

  const [addResponse, setAddResponce] = React.useState("");
  const [addDriverErrors, setAddDriverErrors] = React.useState(false);
  const [resetType, setResetType] = React.useState(true);
  const [selectedDriver, setSelectedDriver] = React.useState({
    mobile: "",
    name: "",
    location_id: "2",
    role_id: "2",
    otp: "1234",
    type: "2W",
    language_id: "2",
    email: "",
    language: "",
    shift_time: "",
    primary_address: "",
    country: "",
    state: "",
    city: "",
    secondary_address: "",
    aadhar_number: "",
    pan_number: "",
    driving_license_number: "",
    aadhar: "",
    pan: "",
    driver_license: "",
    profile_pic: "",
    user_name: "dummy",
  });

  const driverPresent = useSelector((store) => store.driverAll.dataPresent);
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getDriverBulk());
    const getCountries = endpoints.baseUrl + `/country/list`;
    axios
      .get(getCountries)
      .then((response) => {
        setCountryList(response.data.data);
      })
      .catch((er) => {});
  }, [editArray && editArray.country]);
  React.useEffect(() => {
    const getCountries = endpoints.baseUrl + `/country/list`;
    const getShifts = endpoints.baseUrl + `/driver/shift`;
    const getLang = endpoints.baseUrl + `/driver/getLanguage`;
    axios
      .get(getCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setCountryList(response.data.data);
      })
      .catch((er) => {});
    axios
      .get(getShifts)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setShiftList(response.data.data);
      })
      .catch((er) => {});
    axios
      .get(getLang)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        // console.log("response", response);
        setLanguageList(response.data);
      })
      .catch((er) => {});
    dispatch(getDriverBulk());
  }, []);

  React.useEffect(() => {
    if (selectedDriver && selectedDriver.country) {
      const getCountries1 =
        endpoints.baseUrl + `/state/list?country_id=` + selectedDriver.country;

      axios
        .get(getCountries1)
        .then((response) => {
          // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
          setStateList(response.data.data);
        })
        .catch((er) => {});
    }
  }, [selectedDriver]);

  React.useEffect(() => {
    if (selectedDriver && selectedDriver.state) {
      const getCountries1 =
        endpoints.baseUrl + `/city/list?state_id=` + selectedDriver.state;

      axios
        .get(getCountries1)
        .then((response) => {
          // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
          setCityList(response.data.data);
        })
        .catch((er) => {});
    }
  }, [selectedDriver && selectedDriver.state]);

  const getStates = (cId) => {
    const getCountries = endpoints.baseUrl + `/state/list?country_id=` + cId;
    axios
      .get(getCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setStateList(response.data.data);
      })
      .catch((er) => {});
  };
  const getCities = (sId) => {
    const getCountries = endpoints.baseUrl + `/city/list?state_id=` + sId;
    axios
      .get(getCountries)
      .then((response) => {
        // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
        setCityList(response.data.data);
      })
      .catch((er) => {});
  };
  React.useEffect(() => {
    setSelectedDriver(driver && driver[0]);
  }, [driver]);
  //    edit driver
  const [editArray, setEditArray] = React.useState({});
  const setDriverEditArray = (driver_id) => {
    let allDrivers = driver;
    let findArray = allDrivers.find((el) => el.driver_id === driver_id);
    setEditArray(findArray);
    setResetType(true);
  };
  const submitDriverEdit = () => {
    setAddDriverErrors(true);

    if (
      editArray.mobile &&
      editArray.name &&
      editArray.role_id &&
      editArray.type &&
      editArray.language &&
      editArray.email &&
      editArray.language &&
      editArray.shift_time &&
      editArray.primary_address &&
      editArray.country &&
      editArray.state &&
      editArray.city &&
      editArray.secondary_address &&
      editArray.aadhar_number &&
      editArray.pan_number &&
      editArray.driving_license_number
      //  && editArray.aadhar && editArray.pan
      // && editArray.driver_license && editArray.profile_pic
    ) {
      const putDriver =
        endpoints.baseUrl + `/driver/edit/` + editArray.driver_id;
      axios
        .put(putDriver, editArray)
        .then((response) => {
          // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;
          document.getElementById("full-width-tab-0").click();
          handleClosee();
          handleChangeAIndex(0);
          dispatch(getDriverBulk());
          setAddDriverErrors(true);

          if (response.status === 200) {
            setAddResponce("Driver Edited Successfully");
          }

          setEditArray({});
        })
        .catch((er) => {
          setAddDriverErrors(true);
          setAddResponce("Something went wrong, Try again");
        });
    } else {
      setAddDriverErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  const setDriverEditFormArray = (e, key) => {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));
  };
  //   const deleteUser = (user_id) => {
  //     const deleteUser = endpoints.baseUrl + `/bo/usersoftdelete/` + user_id;
  //     axios
  //       .delete(deleteUser)
  //       .then((response) => {
  //         // allUser.find((el) => el.includes(user)).user = !allUser.find((el) => el.includes(user)).user;

  //         dispatch(getUserBulk());
  //       });
  //   }

  const classes = useStyles();
  const theme = useTheme();

  // const nav = useNavigate();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));
  const { setOpenA, openA } = props;
  const [value, setValue] = React.useState(0);

  const [open, setOpen] = React.useState(false);
  const [open1, setOpen1] = React.useState(false);
  const [openn, setOpenn] = React.useState(false);
  const [openedit, setOpenedit] = React.useState(false);
  // const [open2, setOpen2] = React.useState(false);
  const [index, setIndex] = React.useState(0);
  const [active, setActive] = React.useState("");

  const handleClickOpenedit = () => {
    setOpenedit(true);
    // setEditArray(selectedDriver)
  };

  const handleCloseedit = () => {
    setOpenedit(false);
  };
  const handleChange = (event) => {
    setActive(event.target.value);
  };
  const handleChangeA = (event, newValue) => {
    setValue(newValue);
  };
  const handleChangeAIndex = (index) => {
    setAddDriverErrors(true);
    if (index === 1) {
      if (
        editArray.mobile &&
        editArray.name &&
        editArray.type &&
        editArray.email &&
        editArray.language &&
        editArray.shift_time
      ) {
        setValue(index);
        scrollToTop();
        setAddDriverErrors(false);
      } else {
        setAddDriverErrors(true);
        setAddResponce("Please Fill the Required Fields");
      }
    } else if (index === 2) {
      if (
        editArray.primary_address &&
        editArray.country &&
        editArray.state &&
        editArray.city &&
        editArray.secondary_address
      ) {
        setValue(index);
        setAddDriverErrors(false);
        scrollToTop();
      } else {
        setAddDriverErrors(true);
        setAddResponce("Please Fill the Required Fields");
      }
    } else if (index === 3) {
      if (
        editArray.aadhar_number &&
        editArray.pan_number &&
        editArray.driving_license_number
        // && driversAddForm.aadhar && driversAddForm.pan
        // && driversAddForm.driver_license && driversAddForm.profile_pic
      ) {
        // setValue(index);
        setAddDriverErrors(false);
        scrollToTop();
        submitDriverEdit();
      } else {
        setAddDriverErrors(true);
        setAddResponce("Please Fill the Required Fields");
      }
    }
  };

  const scrollToRef = (ref) => window.scrollTo(0, ref.current.offsetTop);
  const myRef = React.useRef(null);
  const executeScroll = () => scrollToRef(myRef);
  const { setOpen2, open2 } = props;
  const [opentrip, setOpentrip] = React.useState(false);
  // const [value, setValue] = React.useState(0);
  const handleChangee = (event, newValue) => {
    setValue(newValue);
  };

  const handleClickOpen = () => {
    setOpen(true);
    handleClickOpenn(false);
    setOpenn(false);
    // setEditArray(selectedDriver);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleClickOpen1 = () => {
    setOpen1(true);
  };

  const handleClose1 = () => {
    setOpen1(false);
  };
  const handleClickOpenn = () => {
    setOpenn(true);
    // setEditArray(selectedDriver);
  };

  const handleClosee = () => {
    setOpenn(false);
  };

  const handleChangeeIndex = (index) => {
    setValue(index);
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth", // for smoothly scrolling
    });
  };

  const handleClickOpentrip = () => {
    setOpentrip(true);
  };

  const handleClosetrip = () => {
    setOpentrip(false);
  };

  const setDriverSelected = (array) => {
    setSelectedDriver(array);
  };
  const [stateC, setStateC] = React.useState(
    selectedDriver && selectedDriver.type.includes("2W")
  );
  const [stateD, setStateD] = React.useState(
    selectedDriver && selectedDriver.type.includes("Eauto")
  );
  const [stateE, setStateE] = React.useState(
    selectedDriver && selectedDriver.type.includes("L5com")
  );
  const logged_user = useSelector((store) => store.user.loggeduser);
  let driversEditAccess = logged_user.drivers === "edit"
  const [typeVar, setTypeVar] = React.useState([]);
  const [countryList, setCountryList] = React.useState([]);
  const [stateList, setStateList] = React.useState([]);
  const [cityList, setCityList] = React.useState([]);
  const [shiftList, setShiftList] = React.useState([]);
  const [languageList, setLanguageList] = React.useState([]);

  const handleChangeCheck = (event) => {
    let stateArr = typeVar;

    setStateC(!stateC);
    if (stateC === false) {
      const index = stateArr.indexOf("2W");
      if (index === -1) {
        stateArr.push("2W");
      }
    } else {
      const index = stateArr.indexOf("2W");
      if (index > -1) {
        stateArr.splice(index, 1);
      }
    }
    let newVar = stateArr.toString();

    setTypeVar(stateArr);
    setSelectedDriver((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    setEditArray((state) => ({
      ...state,
      type: `${newVar}`,
    }));
  };
  const handleChangeChecks = (event) => {
    let stateArr = typeVar;
    if (stateD === false) {
      const index = stateArr.indexOf("Eauto");
      if (index === -1) {
        stateArr.push("Eauto");
      }
    } else {
      const index = stateArr.indexOf("Eauto");
      if (index > -1) {
        stateArr.splice(index, 1);
      }
    }
    setStateD(!stateD);
    let newVar = stateArr.toString();

    setTypeVar(stateArr);
    setSelectedDriver((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    setEditArray((state) => ({
      ...state,
      type: `${newVar}`,
    }));
  };
  const handleChangeCheckss = (event) => {
    let stateArr = typeVar;
    if (stateE === false) {
      const index = stateArr.indexOf("L5com");
      if (index === -1) {
        stateArr.push("L5com");
      }
    } else {
      const index = stateArr.indexOf("L5com");
      if (index > -1) {
        stateArr.splice(index, 1);
      }
    }
    let newVar = stateArr.toString();

    setStateE(!stateE);
    setTypeVar(stateArr);
    setSelectedDriver((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    setEditArray((state) => ({
      ...state,
      type: `${newVar}`,
    }));
    // stateE === true ? typeVar.push('L5-com') :  typeVar.pop('L5-com')
  };
  // React.useEffect(() => {
  //     let stateArr = typeVar;
  //     let newVar = stateArr.toString()
  //     setEditArray((state) => ({
  //         ...state,
  //         type: `${newVar}`
  //     }))

  // }, [stateC, stateE, stateD])
  // console.log("editArray", editArray);
  // console.log("selectedDriver", selectedDriver);
  if (driverPresent && selectedDriver) {
    return (
      //     <>
      //       {
      //         driver.map((singleDriver) => {
      //             return(
      //                <Typography onClick={() =>{ setDriverSelected(singleDriver)
      //             alert(selectedDriver.name)
      //             }} >{singleDriver.name}</Typography>
      //             )
      //         })
      //       }
      //       <Typography variant="h3">{selectedDriver.name}</Typography>
      //         <br />
      //         <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt.Ltd. </Typography>
      //     </>

      <div className={classes.root}>
        <SimpleSnackbar
          logInMessage={addResponse}
          notificationTimeOut={6000}
          setLoginSucess={setAddDriverErrors}
          loginSuccess={addDriverErrors}
        />

        {opentrip === true ? (
          <Grid open={opentrip} container spacing={2}>
            <Grid item xs={12} lg={4}>
              <Paper className={classes.GridPaper}>
                <List className={classes.style5}>
                  {/* {driver.map((text, i) => {
                                if (i === index) {
                                    return ( */}

                  <div>
                    <Typography className={classes.tripText}>
                      Current Trips
                    </Typography>
                    <ListItem alignItems="flex-start">
                      <Avatar>
                        <img src={selectedDriver.profile_pic} />
                      </Avatar>
                      <ListItemText
                        primary={
                          <Typography
                            style={{ marginTop: "10px !important" }}
                            className={classes.primarytxt1}
                            component="span"
                          >
                            {selectedDriver.name}&nbsp;&nbsp;
                            <IconButton
                              onClick={() => {
                                handleClosetrip();
                              }}
                              onMouseOver={changeBackground}
                              onMouseOut={changeBackground2}
                            >
                              <Icon
                                icon="bx:edit"
                                color="#68a724"
                                width="23"
                                height="23"
                                rotate={2}
                              />
                            </IconButton>
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              className={classes.secondarytxt1}
                              component="span"
                            >
                              {selectedDriver.type}
                            </Typography>
                            <br />
                            <Typography
                              className={classes.mobile}
                              component="span"
                            >
                              {selectedDriver.mobile}
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                  </div>
                  {/* )
                                }
                            })} */}
                </List>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <ListItemText
                      primary={
                        <Typography
                          style={{ marginTop: "10px !important" }}
                          className={classes.primarytxt2}
                          component="span"
                        >
                          26 days
                        </Typography>
                      }
                      secondary={
                        <React.Fragment>
                          <Typography
                            className={classes.secondarytxt2}
                            component="span"
                          >
                            Month Attandance
                          </Typography>
                        </React.Fragment>
                      }
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <ListItemText
                      primary={
                        <Typography
                          style={{ marginTop: "10px !important" }}
                          className={classes.primarytxt2}
                          component="span"
                        >
                          50%
                        </Typography>
                      }
                      secondary={
                        <React.Fragment>
                          <Typography
                            className={classes.secondarytxt2}
                            component="span"
                          >
                            Efficiency Score
                          </Typography>
                        </React.Fragment>
                      }
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <ListItemText
                      primary={
                        <Typography
                          style={{ marginTop: "10px !important" }}
                          className={classes.primarytxt2}
                          component="span"
                        >
                          60 Km/h
                        </Typography>
                      }
                      secondary={
                        <React.Fragment>
                          <Typography
                            className={classes.secondarytxt2}
                            component="span"
                          >
                            Speed
                          </Typography>
                        </React.Fragment>
                      }
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <ListItemText
                      primary={
                        <Typography
                          style={{ marginTop: "10px !important" }}
                          className={classes.primarytxt2}
                          component="span"
                        >
                          MYLAMPATTI
                        </Typography>
                      }
                      secondary={
                        <React.Fragment>
                          <Typography
                            className={classes.secondarytxt2}
                            component="span"
                          >
                            Location
                          </Typography>
                        </React.Fragment>
                      }
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <ListItemText
                      primary={
                        <Typography
                          style={{ marginTop: "10px !important" }}
                          className={classes.primarytxt2}
                          component="span"
                        >
                          5.5km
                        </Typography>
                      }
                      secondary={
                        <React.Fragment>
                          <Typography
                            className={classes.secondarytxt2}
                            component="span"
                          >
                            Distance Travelled Today
                          </Typography>
                        </React.Fragment>
                      }
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <ListItemText
                      primary={
                        <Typography
                          style={{ marginTop: "10px !important" }}
                          className={classes.primarytxt2}
                          component="span"
                        >
                          Unsuccessfull
                        </Typography>
                      }
                      secondary={
                        <React.Fragment>
                          <Typography
                            className={classes.secondarytxt2}
                            component="span"
                          >
                            Delivery Status
                          </Typography>
                        </React.Fragment>
                      }
                    />
                  </Grid>
                </Grid>
              </Paper>
            </Grid>

            <Grid item xs={12} lg={8}>
              <Paper className={classes.map}>
                <SimpleMap />
              </Paper>
            </Grid>

            <Grid item xs={12} lg={4}>
              <Paper style={{ height: "253px" }}>
                <Timeline>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot className={classes.time} />
                      <TimelineConnector className={classes.time} />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography className={classes.timetxt}>10.00</Typography>
                      &nbsp;&nbsp;
                      <Typography className={classes.timetxt1}>
                        Pudhukkuttai Thottam
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>

                  <TimelineItem>
                    <TimelineSeparator>
                      <Icon
                        icon="mdi:map-marker-outline"
                        color="#f51919"
                        width="30"
                        height="30"
                        className={classes.loc}
                      />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography
                        className={classes.timetxt}
                        style={{ marginLeft: "-9px" }}
                      >
                        10.55
                      </Typography>
                      &nbsp;&nbsp;
                      <Typography className={classes.timetxt1}>
                        SRI Sakthi University
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>
                </Timeline>
                <Divider />
                <Timeline>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot className={classes.time} />
                      <TimelineConnector className={classes.time} />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography className={classes.timetxt}>10.00</Typography>
                      &nbsp;&nbsp;
                      <Typography className={classes.timetxt1}>
                        Pudhukkuttai Thottam
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>

                  <TimelineItem>
                    {/* <TimelineSeparator> */}
                    <Icon
                      icon="mdi:map-marker-outline"
                      color="#f51919"
                      width="30"
                      height="30"
                      className={classes.loc}
                    />
                    {/* </TimelineSeparator> */}
                    <TimelineContent>
                      <Typography
                        className={classes.timetxt}
                        style={{ marginLeft: "-9px" }}
                      >
                        10.55
                      </Typography>
                      &nbsp;&nbsp;
                      <Typography className={classes.timetxt1}>
                        SRI Sakthi University
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>
                </Timeline>
                {/* <Divider /> */}
              </Paper>
            </Grid>

            <Grid item xs={12} lg={4}>
              <Paper variant="outlined" elevation={2}>
                <div style={{ margin: 10 }}>
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Vehicle Type
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      2 W
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Vehicle Model
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      Mahindra
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Vehicle No
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      TN88 C1234
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Driver Name
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      Nithish
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Fleet Operator
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      TTN Logistics
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Client Name
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      Bigbasket
                    </Typography>
                  </div>
                </div>
              </Paper>
            </Grid>

            <Grid item xs={12} lg={4}>
              <Paper variant="outlined" elevation={2}>
                <div style={{ margin: 10 }}>
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Status
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      Driving
                      <Brightness1Icon className={classes.driving} />
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Location
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      GOLD
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Km Remaining
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      13 KM
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>SOC</Typography>
                    <Typography className={classes.secondaryText}>
                      Driving
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Delivery Status
                    </Typography>
                    <Typography className={classes.secondaryTextG}>
                      Completed
                    </Typography>
                  </div>
                  <Divider />
                  <div style={{ display: "flex", margin: 10 }}>
                    <Typography className={classes.primaryText}>
                      Today Trip Distance
                    </Typography>
                    <Typography className={classes.secondaryText}>
                      50 KM
                    </Typography>
                  </div>
                </div>
              </Paper>
            </Grid>
          </Grid>
        ) : (
          <Grid container spacing={2}>
            <Grid lg={4} xs={12}>
              <Item className={classes.gridBG}>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "nowrap",
                    alignContent: "center",
                    justifyContent: "space-between",
                    alignItems: "stretch",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      flexWrap: "nowrap",
                      alignContent: "stretch",
                      justifyContent: "space-evenly",
                      alignItems: "stretch",
                    }}
                  >
                    <TextField
                      placeholder="Search"
                      size="small"
                      className={classes.txtField}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            &nbsp;
                            <SearchIcon className={classes.icon} />
                          </InputAdornment>
                        ),
                      }}
                    />
                    <Typography className={classes.sevenDrive}>
                      {totaldrivers} Drivers
                    </Typography>
                  </div>

                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      flexWrap: "nowrap",
                      alignContent: "center",
                      justifyContent: "space-around",
                      alignItems: "stretch",
                    }}
                  >
                    {driversEditAccess === true ?
                     (open === false ? (
                      <IconButton onClick={handleClickOpen}>
                        <img
                          src={logox}
                          style={{
                            transform:
                              open === false ? "rotate(47deg)" : "rotate(0deg)",
                            border: 1,
                            borderRadius: "30px",
                            backgroundColor: "#FFFFFF",
                          }}
                        />
                      </IconButton>
                    ) : (
                      <IconButton onClick={handleClose}>
                        <img
                          src={logox}
                          style={{
                            border: 1,
                            borderRadius: "30px",
                            backgroundColor: "#FFFFFF",
                          }}
                        />
                      </IconButton>
                    ))  
                    : null }
                   

                    <IconButton>
                      <img src={logofil} />
                    </IconButton>
                  </div>
                </div>
                {isMdUp === true ? null : (
                  <Dialog open={open} onClose={handleClose}>
                    <Tabss open={open} setOpen={setOpen} />
                  </Dialog>
                )}
                {isMdUp === true ? null : (
                  <Dialog open={openedit} onClose={handleCloseedit}>
                    <List
                      open={openedit}
                      onClose={handleCloseedit}
                      className={classes.lists}
                    >
                      {/* {driver.map((text, i) => {
                                    if (i === index) {
                                        return ( */}
                      {/* customBodyRender: (value) => {   */}
                      <Box className={classes.styleA}>
                        <Typography align="top" className={classes.styleB}>
                          Edit Driver
                        </Typography>
                        {isMdUp === true ? null : (
                          <IconButton
                            className={isMdUp === false ? classes.styleC : null}
                            onClick={handleCloseedit}
                          >
                            <img
                              src={logox}
                              style={{
                                border: 1,
                                borderRadius: "30px",
                                backgroundColor: "#FFFFFF",
                              }}
                            />
                          </IconButton>
                        )}

                        <Typography align="center" className={classes.styleD}>
                          Upload Profile (Max 100KB)
                        </Typography>
                        <div align="center">
                          <IconButton className={classes.styleE}>
                            <Avatar>
                              
                              <input
                                onChange={(e) => {
                                  setDriverEditFormArray(e, "profile_pic");
                                }}
                                error={
                                  addDriverErrors &&
                                  editArray.profile_pic === ""
                                }
                                type="file"
                                style={{ opacity: 0, position: "absolute" }}
                              />
                              <img src={selectedDriver.profile_pic} />
                            </Avatar>
                          </IconButton>
                        </div>
                        <Box className={classes.styleF}>
                          <div>
                            <AppBar
                              position="static"
                              className={classes.styleG}
                            >
                              <Tabs
                                setOpenA={setOpenA}
                                value={value}
                                onChange={handleChangeA}
                                indicatorColor="#000000"
                                color="#000000"
                                variant="fullWidth"
                                aria-label="full width tabs example"
                                className={classes.styleH}
                              >
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.styleIM
                                      : classes.styleJ
                                  }
                                  label="PERSONAL INFORMATION"
                                  {...a11yProps(0)}
                                />
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.styleK
                                      : classes.styleJ
                                  }
                                  label="ADDRESS"
                                  {...a11yProps(1)}
                                />
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.styleK
                                      : classes.styleJ
                                  }
                                  label="KYC DOCUMENT"
                                  {...a11yProps(2)}
                                />
                              </Tabs>
                            </AppBar>
                          </div>
                        </Box>

                        <SwipeableViews
                          axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                          index={value}
                          onChangeIndex={handleChangeAIndex}
                        >
                          <TabPanel
                            setOpenA={setOpenA}
                            value={value}
                            index={0}
                            dir={theme.direction}
                          >
                            <Grid container spacing={2}>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  License Type
                                </Typography>
                                {/* <TextField 
                                                                 onChange={(e) => { setDriverEditFormArray(e, 'type') }}
                                                                size="small" id="outlined" className={classes.styleO} value={`` || editArray.type} /> */}
                                <FormControlLabel
                                  control={
                                    <Checkbox
                                      disabled={resetType}
                                      checked={
                                        selectedDriver.type &&
                                        selectedDriver.type.includes("2W")
                                      }
                                      onChange={handleChangeCheck}
                                      name="checkedA"
                                      color="primary"
                                    />
                                  }
                                  label="2W"
                                />
                                <FormControlLabel
                                  control={
                                    <Checkbox
                                      disabled={resetType}
                                      checked={
                                        selectedDriver.type &&
                                        selectedDriver.type.includes("Eauto")
                                      }
                                      onChange={handleChangeChecks}
                                      name="checkedB"
                                      color="primary"
                                    />
                                  }
                                  label="Eauto"
                                />
                                <FormControlLabel
                                  control={
                                    <Checkbox
                                      disabled={resetType}
                                      checked={
                                        selectedDriver.type &&
                                        selectedDriver.type.includes("L5com")
                                      }
                                      onChange={handleChangeCheckss}
                                      name="checkedC"
                                      color="primary"
                                    />
                                  }
                                  label="L5 Commericial Vehicle"
                                />
                                <Button
                                  variant="danger"
                                  onClick={() => {
                                    setStateC(true);

                                    setStateD(true);
                                    setStateE(true);
                                    setResetType(false);
                                    setSelectedDriver((state) => ({
                                      ...state,
                                      type: "",
                                    }));
                                    setEditArray((state) => ({
                                      ...state,
                                      type: "",
                                    }));
                                    setTypeVar([]);
                                  }}
                                >
                                  Reset
                                </Button>
                              </Grid>
                              <input
                                type="hidden"
                                name="driver_id"
                                value={selectedDriver.driver_id}
                              />
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Driver Name
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "name");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.name === ""
                                  }
                                  value={selectedDriver.name}
                                />
                              </Grid>

                              {/* <Grid item lg={6} xs={12}>
                                                            <Typography className={classes.styleL}>User Name</Typography>
                                                            <TextField
                                                                onChange={(e) => { setDriverEditFormArray(e, 'user_name') }}
                                                                size="small" id="outlined" className={classes.styleO} 
                                                    error={addDriverErrors && editArray.user_name === ""}
                                                    value={`` || editArray.user_name} />                                                </Grid> */}

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Mobile Number
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "mobile");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.mobile === ""
                                  }
                                  value={`` || editArray.mobile}
                                />
                              </Grid>

                              <Grid item lg={12} xs={12}>
                                <Typography className={classes.styleL}>
                                  Email
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "email");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.email === ""
                                  }
                                  value={`` || editArray.email}
                                />
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Language
                                </Typography>
                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "language");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.language === ""
                                  }
                                  value={`` || editArray.language}
                                >
                                  <MenuItem value="">
                                    Select your language
                                  </MenuItem>
                                  {languageList &&
                                    languageList.map((lang) => {
                                      return (
                                        <MenuItem
                                          key={lang.language_id}
                                          value={lang.language_id}
                                        >
                                          {lang.language}
                                        </MenuItem>
                                      );
                                    })}
                                </Select>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>
                                  Shift Time
                                </Typography>
                                <FormControl
                                  className={classes.formControl}
                                  size="small"
                                >
                                  <Select
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "shift_time");
                                    }}
                                    size="small"
                                    id="outlined"
                                    className={classes.styleO}
                                    error={
                                      addDriverErrors &&
                                      editArray.shift_time === ""
                                    }
                                    value={`` || editArray.shift_time}
                                  >
                                    <MenuItem value="">
                                      Select your shift
                                    </MenuItem>
                                    {shiftList &&
                                      shiftList.map((sh, i) => {
                                        return (
                                          <MenuItem value={sh.shift_id} key={i}>
                                            {sh.time}
                                          </MenuItem>
                                        );
                                      })}
                                  </Select>
                                </FormControl>
                              </Grid>
                            </Grid>
                            <br />
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "row",
                                flexWrap: "nowrap",
                                alignContent: "center",
                                justifyContent: "space-around",
                                alignItems: "center",
                              }}
                            >
                              <Button
                                onClick={handleCloseedit}
                                // onClick={() => setOpenn(false)}
                                className={
                                  isMdUp === true
                                    ? classes.styleP
                                    : classes.stylePM
                                }
                              >
                                Cancel
                              </Button>
                              <Button
                                onClick={() => {
                                  handleChangeAIndex(1);
                                  scrollToTop();
                                }}
                                className={
                                  isMdUp === true
                                    ? classes.styleQ
                                    : classes.styleQM
                                }
                              >
                                Next
                                <img src={next} style={{ marginLeft: 10 }} />
                              </Button>
                            </div>
                          </TabPanel>

                          <TabPanel
                            setOpenA={setOpenA}
                            value={value}
                            index={1}
                            dir={theme.direction}
                          >
                            <Grid container spacing={2}>
                              <Grid item lg={12} xs={12}>
                                <Typography className={classes.styleL}>
                                  Primary Address
                                </Typography>
                                <Paper
                                  component="form"
                                  className={classes.styleR}
                                >
                                  <InputBase
                                    onChange={(e) => {
                                      setDriverEditFormArray(
                                        e,
                                        "primary_address"
                                      );
                                    }}
                                    fullWidth={true}
                                    error={
                                      addDriverErrors &&
                                      editArray.primary_address === ""
                                    }
                                    value={`` || editArray.primary_address}
                                  />
                                </Paper>
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Country
                                </Typography>
                                {countryList.length && (
                                  <Select
                                    style={{ minWidth: "100%" }}
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "country");
                                      getStates(e.target.value);
                                    }}
                                    size="small"
                                    id="outlined"
                                    className={classes.styleO}
                                    error={
                                      addDriverErrors &&
                                      editArray.country === ""
                                    }
                                    value={`` || editArray.country}
                                    displayEmpty
                                  >
                                    <MenuItem value="">Select Country</MenuItem>
                                    {countryList.length &&
                                      countryList.map((el, i) => {
                                        return (
                                          <MenuItem
                                            key={i}
                                            value={el.country_id}
                                          >
                                            {el.country_name}
                                          </MenuItem>
                                        );
                                      })}
                                  </Select>
                                )}
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  State
                                </Typography>
                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "state");
                                    getCities(e.target.value);
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.state === ""
                                  }
                                  value={editArray.state || ""}
                                >
                                  <MenuItem value="">Select City</MenuItem>
                                  {stateList.length &&
                                    stateList.map((el, i) => {
                                      return (
                                        <MenuItem key={i} value={el.state_id}>
                                          {el.state_name}
                                        </MenuItem>
                                      );
                                    })}
                                </Select>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  City
                                </Typography>
                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "state");
                                    getCities(e.target.value);
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.state === ""
                                  }
                                  value={editArray.state || ""}
                                >
                                  <MenuItem value="">Select City</MenuItem>
                                  {stateList.length &&
                                    stateList.map((el, i) => {
                                      return (
                                        <MenuItem key={i} value={el.state_id}>
                                          {el.state_name}
                                        </MenuItem>
                                      );
                                    })}
                                </Select>
                              </Grid>

                              <Grid item lg={12} xs={12}>
                                <Typography className={classes.styleL}>
                                  Secondary Address
                                </Typography>
                                <Paper
                                  component="form"
                                  className={classes.styleR}
                                >
                                  <InputBase
                                    onChange={(e) => {
                                      setDriverEditFormArray(
                                        e,
                                        "secondary_address"
                                      );
                                    }}
                                    fullWidth={true}
                                    error={
                                      addDriverErrors &&
                                      editArray.secondary_address === ""
                                    }
                                    value={`` || editArray.secondary_address}
                                  />
                                </Paper>
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Country
                                </Typography>
                                {countryList.length && (
                                  <Select
                                    style={{ minWidth: "100%" }}
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "country");
                                      getStates(e.target.value);
                                    }}
                                    size="small"
                                    id="outlined"
                                    className={classes.styleO}
                                    error={
                                      addDriverErrors &&
                                      editArray.country === ""
                                    }
                                    value={`` || editArray.country}
                                    // defaultValue={0}

                                    displayEmpty
                                  >
                                    <MenuItem value="">Select Country</MenuItem>
                                    {countryList.length &&
                                      countryList.map((el, i) => {
                                        return (
                                          <MenuItem
                                            key={i}
                                            value={el.country_id}
                                          >
                                            {el.country_name}
                                          </MenuItem>
                                        );
                                      })}
                                  </Select>
                                )}
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  State
                                </Typography>
                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "state");
                                    getCities(e.target.value);
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.state === ""
                                  }
                                  value={editArray.state || ""}
                                >
                                  <MenuItem value="">Select City</MenuItem>
                                  {stateList.length &&
                                    stateList.map((el, i) => {
                                      return (
                                        <MenuItem key={i} value={el.state_id}>
                                          {el.state_name}
                                        </MenuItem>
                                      );
                                    })}
                                </Select>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  City
                                </Typography>
                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "state");
                                    getCities(e.target.value);
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.state === ""
                                  }
                                  value={editArray.state || ""}
                                >
                                  <MenuItem value="">Select City</MenuItem>
                                  {stateList.length &&
                                    stateList.map((el, i) => {
                                      return (
                                        <MenuItem key={i} value={el.state_id}>
                                          {el.state_name}
                                        </MenuItem>
                                      );
                                    })}
                                </Select>
                              </Grid>
                            </Grid>
                            <br />
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "row",
                                flexWrap: "nowrap",
                                alignContent: "center",
                                justifyContent: "space-around",
                                alignItems: "center",
                              }}
                            >
                              <Button
                                onClick={() => {
                                  handleChangeAIndex(0);
                                  scrollToTop();
                                }}
                                className={
                                  isMdUp === true
                                    ? classes.styleP
                                    : classes.stylePM
                                }
                              >
                                <img
                                  src={back}
                                  style={{ marginRight: "15px" }}
                                />
                                Back
                              </Button>
                              <Button
                                onClick={() => {
                                  handleChangeAIndex(2);
                                  scrollToTop();
                                }}
                                className={
                                  isMdUp === true
                                    ? classes.styleQ
                                    : classes.styleQM
                                }
                              >
                                Next
                                <img src={next} style={{ marginLeft: 20 }} />
                              </Button>
                            </div>
                          </TabPanel>

                          <TabPanel
                            setOpenA={setOpenA}
                            value={value}
                            index={2}
                            dir={theme.direction}
                          >
                            <Grid container spacing={2}>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Aadhar Number
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "aadhar_number");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors &&
                                    editArray.aadhar_number === ""
                                  }
                                  value={`` || editArray.aadhar_number}
                                />
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Aadhar Image
                                </Typography>
                                <Button
                                  sx={{ ":hover": { backgroundColor: "#fff" } }}
                                >
                                  <input
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "aadhar");
                                    }}
                                    error={
                                      addDriverErrors && editArray.aadhar === ""
                                    }
                                    value={`` || editArray.aadhar}
                                    type="file"
                                    style={{ color: "#C1C1C1" }}
                                  />
                                </Button>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  PAN Number
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "pan_number");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors &&
                                    editArray.pan_number === ""
                                  }
                                  value={`` || editArray.pan_number}
                                />
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  PAN Image
                                </Typography>
                                <Button
                                  sx={{ ":hover": { backgroundColor: "#fff" } }}
                                >
                                  <input
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "pan");
                                    }}
                                    error={
                                      addDriverErrors && editArray.pan === ""
                                    }
                                    value={`` || editArray.pan}
                                    type="file"
                                    style={{ color: "#C1C1C1" }}
                                  />
                                </Button>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Driving License Number
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(
                                      e,
                                      "driving_license_number"
                                    );
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors &&
                                    editArray.driving_license_number === ""
                                  }
                                  value={`` || editArray.driving_license_number}
                                />
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  License Image
                                </Typography>
                                <Button
                                  sx={{ ":hover": { backgroundColor: "#fff" } }}
                                >
                                  <input
                                    onChange={(e) => {
                                      setDriverEditFormArray(
                                        e,
                                        "driver_license"
                                      );
                                    }}
                                    error={
                                      addDriverErrors &&
                                      editArray.driver_license === ""
                                    }
                                    value={`` || editArray.driver_license}
                                    type="file"
                                    style={{ color: "#C1C1C1" }}
                                  />
                                </Button>
                              </Grid>
                            </Grid>
                            <br />
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "row",
                                flexWrap: "nowrap",
                                alignContent: "center",
                                justifyContent: "space-around",
                                alignItems: "center",
                              }}
                            >
                              <Button
                                onClick={() => {
                                  handleChangeAIndex(1);
                                  scrollToTop();
                                }}
                                className={
                                  isMdUp === true
                                    ? classes.styleP
                                    : classes.stylePM
                                }
                              >
                                <img
                                  src={back}
                                  style={{ marginRight: "15px" }}
                                />
                                Back
                              </Button>
                              <Button
                                onClick={() => {
                                  // submitDriverEdit(true)
                                  handleChangeAIndex(3);
                                }}
                                type="submit"
                                className={
                                  isMdUp === true
                                    ? classes.styleQ
                                    : classes.styleQM
                                }
                              >
                                Save
                              </Button>
                            </div>
                          </TabPanel>
                        </SwipeableViews>
                      </Box>
                      {/* )
                                    }
                                })}  */}
                    </List>
                  </Dialog>
                )}

                {isMdUp === true ? null : (
                  <Dialog
                    open={openn}
                    // onClose={handleClosee}
                  >
                    <div className={classes.root}>
                      {/* <CssBaseline /> */}
                      {/* <DrawerList /> */}

                      <List className={classes.lists}>
                        {/* {driver.map((text, i) => {
                                        if (i === index) {
                                            return ( */}

                        <Box className={classes.tabBoxMM}>
                          <Box className={classes.marginLR}>
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "space-between",
                              }}
                            >
                              <IconButton
                                onClick={() => {
                                  handleClickOpentrip();
                                }}
                              >
                                <Icon
                                  icon="bx:edit"
                                  color="#68a724"
                                  width="30"
                                  height="30"
                                  rotate={2}
                                />
                              </IconButton>
                              {driversEditAccess === true ? 
                              <IconButton onClick={handleClickOpenedit}>
                                <Icon
                                  icon="clarity:note-edit-line"
                                  color="#68a724"
                                  width="30"
                                  height="30"
                                />
                              </IconButton> : null }
                              <IconButton onClick={handleClosee}>
                                <Icon
                                  icon="cil:x"
                                  color="#68a724"
                                  width="30"
                                  height="30"
                                />
                              </IconButton>
                            </div>
                            <AppBar
                              position="static"
                              className={classes.style2}
                            >
                              <Tabs
                                // setOpen2={setOpen2}
                                value={value}
                                onChange={handleChangee}
                                indicatorColor="#000000"
                                color="#000000"
                                variant="fullWidth"
                                aria-label="full width tabs example"
                                className={classes.style3}
                              >
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.style4M
                                      : classes.style4
                                  }
                                  label="PERSONAL INFORMATION"
                                  {...a11yProps(0)}
                                />
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.style4M
                                      : classes.style4
                                  }
                                  label="ADDRESS"
                                  {...a11yProps(1)}
                                />
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.style4M
                                      : classes.style4
                                  }
                                  label="KYC DOCUMENT"
                                  {...a11yProps(2)}
                                />
                              </Tabs>
                            </AppBar>
                          </Box>
                          {/* {driver.map((text, i) => {
                                                                    if (i === index) {
                                                                        return ( */}

                          <SwipeableViews
                            axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                            index={value}
                            onChangeIndex={handleChangeeIndex}
                          >
                            <TabPanel
                              // setOpen2={setopen2}
                              value={value}
                              index={0}
                              dir={theme.direction}
                            >
                              <List className={classes.style5}>
                                <div>
                                  <ListItem
                                    alignItems="flex-start"
                                    sx={{ cursor: "pointer" }}
                                  >
                                    <Avatar>
                                      <img src={EditDriver} />
                                    </Avatar>
                                    <ListItemText
                                      className={classes.style6M}
                                      primary={
                                        <Typography
                                          className={classes.style7M}
                                          component="span"
                                        >
                                          {selectedDriver.type}
                                        </Typography>
                                      }
                                      secondary={
                                        <React.Fragment>
                                          <Typography
                                            className={classes.style8}
                                            component="span"
                                          >
                                            {selectedDriver.type}
                                          </Typography>
                                        </React.Fragment>
                                      }
                                    />
                                  </ListItem>
                                  <Divider />

                                  <ListItem
                                    alignItems="flex-start"
                                    sx={{ cursor: "pointer" }}
                                  >
                                    <Avatar>
                                      <img src={EditName} />
                                    </Avatar>
                                    <ListItemText
                                      className={classes.style6M}
                                      primary={
                                        <Typography
                                          className={classes.style7M}
                                          component="span"
                                        >
                                          {selectedDriver.name}
                                        </Typography>
                                      }
                                      secondary={
                                        <React.Fragment>
                                          <Typography
                                            className={classes.style8}
                                            component="span"
                                          >
                                            {selectedDriver.name}
                                          </Typography>
                                        </React.Fragment>
                                      }
                                    />
                                  </ListItem>
                                  <Divider />

                                  <ListItem
                                    alignItems="flex-start"
                                    sx={{ cursor: "pointer" }}
                                  >
                                    <Avatar>
                                      <img src={EditUser} />
                                    </Avatar>
                                    <ListItemText
                                      className={classes.style6M}
                                      primary={
                                        <Typography
                                          className={classes.style7M}
                                          component="span"
                                        >
                                          {selectedDriver.user_name}
                                        </Typography>
                                      }
                                      secondary={
                                        <React.Fragment>
                                          <Typography
                                            className={classes.style8}
                                            component="span"
                                          >
                                            {selectedDriver.type}
                                          </Typography>
                                        </React.Fragment>
                                      }
                                    />
                                  </ListItem>
                                  <Divider />

                                  <ListItem
                                    alignItems="flex-start"
                                    sx={{ cursor: "pointer" }}
                                  >
                                    <Avatar>
                                      <img src={MobNum} />
                                    </Avatar>
                                    <ListItemText
                                      className={classes.style6M}
                                      primary={
                                        <Typography
                                          className={classes.style7M}
                                          component="span"
                                        >
                                          {selectedDriver.mobile}
                                        </Typography>
                                      }
                                      secondary={
                                        <React.Fragment>
                                          <Typography
                                            className={classes.style8}
                                            component="span"
                                          >
                                            {selectedDriver.mobile}
                                          </Typography>
                                        </React.Fragment>
                                      }
                                    />
                                  </ListItem>
                                  <Divider />

                                  <ListItem
                                    alignItems="flex-start"
                                    sx={{ cursor: "pointer" }}
                                  >
                                    <Avatar>
                                      <img src={EditMail} />
                                    </Avatar>
                                    <ListItemText
                                      className={classes.style6M}
                                      primary={
                                        <Typography
                                          className={classes.style7M}
                                          component="span"
                                        >
                                          {selectedDriver.email}
                                        </Typography>
                                      }
                                      secondary={
                                        <React.Fragment>
                                          <Typography
                                            className={classes.style8}
                                            component="span"
                                          >
                                            {selectedDriver.email}
                                          </Typography>
                                        </React.Fragment>
                                      }
                                    />
                                  </ListItem>
                                  <Divider />

                                  <ListItem
                                    alignItems="flex-start"
                                    sx={{ cursor: "pointer" }}
                                  >
                                    <Avatar>
                                      <img src={EditLang} />
                                    </Avatar>
                                    <ListItemText
                                      className={classes.style6M}
                                      primary={
                                        <Select
                                          disabled={true}
                                          onChange={(e) => {
                                            setDriverEditFormArray(
                                              e,
                                              "language"
                                            );
                                          }}
                                          size="small"
                                          id="outlined"
                                          className={classes.styleO}
                                          error={
                                            addDriverErrors &&
                                            editArray.language === ""
                                          }
                                          value={"" || selectedDriver.language}
                                        >
                                          <MenuItem value="">
                                            Select your language
                                          </MenuItem>
                                          {languageList &&
                                            languageList.map((lang) => {
                                              return (
                                                <MenuItem
                                                  key={lang.language_id}
                                                  value={lang.language_id}
                                                >
                                                  {lang.language}
                                                </MenuItem>
                                              );
                                            })}
                                        </Select>
                                      }
                                    />
                                  </ListItem>
                                  <Divider />

                                  <ListItem
                                    alignItems="flex-start"
                                    sx={{ cursor: "pointer" }}
                                  >
                                    <Avatar>
                                      <img src={EditTime} />
                                    </Avatar>
                                    <ListItemText
                                      className={classes.style6M}
                                      primary={
                                        <Typography
                                          className={classes.style7M}
                                          component="span"
                                        >
                                          {selectedDriver.shift_time}
                                        </Typography>
                                      }
                                      secondary={
                                        <React.Fragment>
                                          <Typography
                                            className={classes.style8}
                                            component="span"
                                          >
                                            {selectedDriver.shift_time}
                                          </Typography>
                                        </React.Fragment>
                                      }
                                    />
                                  </ListItem>
                                </div>
                              </List>
                            </TabPanel>

                            <TabPanel
                              // setOpen2={setOpen2}
                              value={value}
                              index={1}
                              dir={theme.direction}
                            >
                              <List className={classes.style5}>
                                {/* {driver.map((text, i) => {
                                                                    if (i === index) {
                                                                    return ( */}
                                <div>
                                  <ListItem
                                    alignItems="flex-start"
                                    sx={{ cursor: "pointer" }}
                                  >
                                    <Avatar>
                                      <img src={Prime} />
                                    </Avatar>
                                    <ListItemText
                                      className={classes.style6}
                                      primary={
                                        <div
                                          style={{
                                            "white-space": "pre-wrap",
                                            "overflow-wrap": "break-word",
                                          }}
                                        >
                                          <Typography
                                            className={classes.style9M}
                                            component="span"
                                          >
                                            {"Primary Address"} <br />
                                            {selectedDriver.primary_address}
                                          </Typography>
                                        </div>
                                      }
                                      secondary={
                                        <React.Fragment>
                                          <Typography
                                            className={classes.style10M}
                                            component="span"
                                          >
                                            City:{selectedDriver.city}
                                            <br />
                                            State:{selectedDriver.state}
                                            <br />
                                            Country:{selectedDriver.country}
                                          </Typography>
                                          <br />
                                          <Typography
                                            className={classes.style11M}
                                            component="span"
                                          >
                                            Primary Address
                                          </Typography>
                                        </React.Fragment>
                                      }
                                    />
                                  </ListItem>
                                  <Divider />
                                </div>
                                {/* )
                                                                                }
                                                                })} */}
                              </List>
                            </TabPanel>

                            <TabPanel
                              // setOpen2={setOpen2}
                              value={value}
                              index={2}
                              dir={theme.direction}
                            >
                              <List className={classes.style5}>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style12}
                                    primary={selectedDriver.aadhar_number}
                                    secondary={
                                      <React.Fragment>
                                        <Typography
                                          className={classes.style13}
                                          component="span"
                                          variant="body2"
                                          color="text.primary"
                                          float="left"
                                        >
                                          Aadhar Number
                                        </Typography>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style13}
                                    primary="Aadhar Card"
                                    secondary={
                                      <React.Fragment>
                                        <Button className={classes.style14}>
                                          View
                                        </Button>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                                <Divider />
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style12}
                                    primary={selectedDriver.pan_number}
                                    secondary={
                                      <React.Fragment>
                                        <Typography
                                          className={classes.style13}
                                          component="span"
                                          variant="body2"
                                          color="text.primary"
                                          float="left"
                                        >
                                          PAN Number
                                        </Typography>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style13}
                                    primary="PAN Card"
                                    secondary={
                                      <React.Fragment>
                                        <Button className={classes.style14}>
                                          View
                                        </Button>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                                <Divider />
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style12}
                                    primary={
                                      selectedDriver.driving_license_number
                                    }
                                    secondary={
                                      <React.Fragment>
                                        <Typography
                                          className={classes.style13}
                                          component="span"
                                          variant="body2"
                                          color="text.primary"
                                          float="left"
                                        >
                                          Driving License Number
                                        </Typography>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style13}
                                    primary="License Card"
                                    secondary={
                                      <React.Fragment>
                                        <Button className={classes.style14}>
                                          View
                                        </Button>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                              </List>
                            </TabPanel>
                          </SwipeableViews>
                        </Box>
                        {/* )
                                                }
                                            })} */}
                      </List>
                    </div>
                  </Dialog>
                )}

                {/* {openn === false ?  */}
                <List className={classes.lists}>
                  {driver.map((singleDriver) => {
                    return (
                      <Box
                        onClick={() => {
                          handleClosee();
                          setDriverSelected(singleDriver);
                          isMdUp === false ? handleClickOpenn() : null;
                        }}
                        className={
                          selectedDriver ? classes.txtBoxS : classes.txtBoxN
                        }
                      >
                        <ListItem
                          style={{
                            backgroundColor:
                              selectedDriver.driver_id ===
                              singleDriver.driver_id
                                ? "#68A72480"
                                : "#fff",
                            color:
                              selectedDriver.driver_id ===
                              singleDriver.driver_id
                                ? "#fff!important"
                                : "#0000008A",
                          }}
                          alignItems="flex-start"
                          className={classes.pointer}
                        >
                          <Avatar>
                            <img src={singleDriver.profile_pic} />
                          </Avatar>
                          <ListItemText
                            primary={
                              <Typography
                                className={classes.primarytxt}
                                component="span"
                              >
                                {singleDriver.name}
                              </Typography>
                            }
                            secondary={
                              <React.Fragment>
                                <Typography
                                  className={classes.secondarytxt}
                                  component="span"
                                >
                                  {singleDriver.type}
                                </Typography>
                              </React.Fragment>
                            }
                          />
                        </ListItem>
                      </Box>
                    );
                  })}
                </List>
                {/*  : <Edit />} */}
              </Item>
            </Grid>

            {isMdUp === true ? (
              <Grid item xs={8} className={classes.mt}>
                <Item
                  className={open === true ? classes.colorYes : classes.colorNo}
                >
                  <ListItem alignItems="flex-start">
                    <Avatar>
                      {open === false ? (
                        <img src={selectedDriver.profile_pic} />
                      ) : null}
                    </Avatar>
                    {open === false ? (
                      <ListItemText
                        primary={
                          <Typography
                            className={classes.primarytxt}
                            component="span"
                          >
                            {selectedDriver.name}
                            <IconButton
                              onClick={() => {
                                handleClickOpentrip();
                              }}
                              onMouseOver={changeBackground}
                              onMouseOut={changeBackground1}
                            >
                              <Icon
                                icon="bx:edit"
                                color="#68a724"
                                width="28"
                                height="28"
                                rotate={2}
                              />
                            </IconButton>
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              className={classes.secondarytxt}
                              component="span"
                            >
                              {selectedDriver.type}
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    ) : null}

            {driversEditAccess === true ? <Button
                      onClick={() => {
                        setDriverEditArray(selectedDriver.driver_id);
                      }}
                    >
                      {open === false ? (
                        <IconButton
                          onClick={
                            openn === true ? handleClosee : handleClickOpenn
                          }
                        >
                          <img src={edit} />
                        </IconButton>
                      ) : null}
                    </Button> : null}
                    <Button>
                      {open === false ? (
                        <IconButton>
                          <img src={menu} />
                        </IconButton>
                      ) : null}
                    </Button>
                  </ListItem>

                  {open === true ? (
                    <Tabss open={open} setOpen={setOpen} />
                  ) : openn === true ? (
                    <List className={classes.lists}>
                      <Box className={classes.styleA}>
                        <Typography align="top" className={classes.styleB}>
                          Edit Driver
                        </Typography>
                        {isMdUp === true ? null : (
                          <IconButton
                            className={isMdUp === false ? classes.styleC : null}
                            onClick={handleClose}
                          >
                            <img
                              src={logox}
                              style={{
                                border: 1,
                                borderRadius: "30px",
                                backgroundColor: "#FFFFFF",
                              }}
                            />
                          </IconButton>
                        )}

                        <Typography align="center" className={classes.styleD}>
                          Upload Profile (Max 100KB)
                        </Typography>
                        <div align="center">
                          <IconButton className={classes.styleE}>
                            <Avatar>
                              <input
                                onChange={(e) => {
                                  setDriverEditFormArray(e, "profile_pic");
                                }}
                                error={
                                  addDriverErrors &&
                                  editArray.profile_pic === ""
                                }
                                type="file"
                                style={{ opacity: 0, position: "absolute" }}
                              />
                              <img src={selectedDriver.profile_pic} />
                            </Avatar>
                          </IconButton>
                        </div>
                        <Box className={classes.styleF}>
                          <div>
                            <AppBar
                              position="static"
                              className={classes.styleG}
                            >
                              <Tabs
                                setOpenA={setOpenA}
                                value={value}
                                onChange={handleChangeA}
                                indicatorColor="#000000"
                                color="#000000"
                                variant="fullWidth"
                                aria-label="full width tabs example"
                                className={classes.styleH}
                              >
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.styleIM
                                      : classes.styleJ
                                  }
                                  label="PERSONAL INFORMATION"
                                  {...a11yProps(0)}
                                />
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.styleK
                                      : classes.styleJ
                                  }
                                  label="ADDRESS"
                                  {...a11yProps(1)}
                                />
                                <Tab
                                  className={
                                    isMdUp === false
                                      ? classes.styleK
                                      : classes.styleJ
                                  }
                                  label="KYC DOCUMENT"
                                  {...a11yProps(2)}
                                />
                              </Tabs>
                            </AppBar>
                          </div>
                        </Box>

                        <SwipeableViews
                          axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                          index={value}
                          onChangeIndex={handleChangeAIndex}
                        >
                          <TabPanel
                            setOpenA={setOpenA}
                            value={value}
                            index={0}
                            dir={theme.direction}
                          >
                            <Grid container spacing={2}>
                              <Grid item lg={12} xs={12}>
                                <Typography className={classes.styleL}>
                                  License Type
                                </Typography>
                                {/* <TextField
                                                                onChange={(e) => { setDriverEditFormArray(e, 'type') }}
                                                                size="small" id="outlined" className={classes.styleO} value={`` || editArray.type} /> */}
                                <FormControlLabel
                                  control={
                                    <Checkbox
                                      disabled={resetType}
                                      checked={
                                        editArray.type &&
                                        editArray.type.includes("2W")
                                      }
                                      onChange={handleChangeCheck}
                                      name="checkedA"
                                      color="primary"
                                    />
                                  }
                                  label="2W"
                                />
                                <FormControlLabel
                                  control={
                                    <Checkbox
                                      disabled={resetType}
                                      checked={
                                        editArray.type &&
                                        editArray.type.includes("Eauto")
                                      }
                                      onChange={handleChangeChecks}
                                      name="checkedB"
                                      color="primary"
                                    />
                                  }
                                  label="Eauto"
                                />
                                <FormControlLabel
                                  control={
                                    <Checkbox
                                      disabled={resetType}
                                      checked={
                                        editArray.type &&
                                        editArray.type.includes("L5com")
                                      }
                                      onChange={handleChangeCheckss}
                                      name="checkedC"
                                      color="primary"
                                    />
                                  }
                                  label="L5 Commericial Vehicle"
                                />
                                <Button
                                  variant="danger"
                                  onClick={() => {
                                    setStateC(true);

                                    setStateD(true);
                                    setStateE(true);
                                    setResetType(false);
                                    setSelectedDriver((state) => ({
                                      ...state,
                                      type: "",
                                    }));
                                    setEditArray((state) => ({
                                      ...state,
                                      type: "",
                                    }));
                                    setTypeVar([]);
                                  }}
                                >
                                  Reset
                                </Button>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Driver Name
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "name");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.name === ""
                                  }
                                  value={`` || editArray.name}
                                />
                                <input
                                  type="hidden"
                                  name="driver_id"
                                  value={selectedDriver.driver_id}
                                />
                              </Grid>

                              {/* <Grid item lg={6} xs={12}>
                                                            <Typography className={classes.styleL}>User Name</Typography>
                                                            <TextField
                                                                onChange={(e) => { setDriverEditFormArray(e, 'user_name') }}
                                                                size="small" id="outlined" className={classes.styleO} value={`` || editArray.user_name} />                                                </Grid> */}

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Mobile Number
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "mobile");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.mobile === ""
                                  }
                                  value={`` || editArray.mobile}
                                />
                              </Grid>

                              <Grid item lg={12} xs={12}>
                                <Typography className={classes.styleL}>
                                  Email
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "email");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.email === ""
                                  }
                                  value={`` || editArray.email}
                                />
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Language
                                </Typography>

                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "language");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.language === ""
                                  }
                                  value={`` || editArray.language}
                                >
                                  <MenuItem value="">
                                    Select your language
                                  </MenuItem>
                                  {languageList &&
                                    languageList.map((lang) => {
                                      return (
                                        <MenuItem
                                          key={lang.language_id}
                                          value={lang.language_id}
                                        >
                                          {lang.language}
                                        </MenuItem>
                                      );
                                    })}
                                </Select>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.tabHelp}>
                                  Shift Time
                                </Typography>
                                <FormControl
                                  className={classes.formControl}
                                  size="small"
                                >
                                  <Select
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "shift_time");
                                    }}
                                    size="small"
                                    id="outlined"
                                    className={classes.styleO}
                                    error={
                                      addDriverErrors &&
                                      editArray.shift_time === ""
                                    }
                                    value={`` || editArray.shift_time}
                                  >
                                    <MenuItem value="">
                                      Select your shift
                                    </MenuItem>
                                    {shiftList &&
                                      shiftList.map((sh, i) => {
                                        return (
                                          <MenuItem value={sh.shift_id} key={i}>
                                            {sh.time}
                                          </MenuItem>
                                        );
                                      })}
                                  </Select>
                                </FormControl>
                              </Grid>
                            </Grid>
                            <br />
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "row",
                                flexWrap: "nowrap",
                                alignContent: "center",
                                justifyContent: "space-around",
                                alignItems: "center",
                              }}
                            >
                              <Button
                                onClick={() => setOpenn(false)}
                                className={
                                  isMdUp === true
                                    ? classes.styleP
                                    : classes.stylePM
                                }
                              >
                                Cancel
                              </Button>
                              <Button
                                onClick={() => {
                                  handleChangeAIndex(1);
                                  scrollToTop();
                                }}
                                className={
                                  isMdUp === true
                                    ? classes.styleQ
                                    : classes.styleQM
                                }
                              >
                                Next
                                <img src={next} style={{ marginLeft: 10 }} />
                              </Button>
                            </div>
                          </TabPanel>

                          <TabPanel
                            setOpenA={setOpenA}
                            value={value}
                            index={1}
                            dir={theme.direction}
                          >
                            <Grid container spacing={2}>
                              <Grid item lg={12} xs={12}>
                                <Typography className={classes.styleL}>
                                  Primary Address
                                </Typography>
                                <Paper
                                  component="form"
                                  className={classes.styleR}
                                >
                                  <InputBase
                                    onChange={(e) => {
                                      setDriverEditFormArray(
                                        e,
                                        "primary_address"
                                      );
                                    }}
                                    fullWidth={true}
                                    error={
                                      addDriverErrors &&
                                      editArray.primary_address === ""
                                    }
                                    value={`` || editArray.primary_address}
                                  />
                                </Paper>
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Country
                                </Typography>
                                {countryList.length && (
                                  <Select
                                    style={{ minWidth: "100%" }}
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "country");
                                      getStates(e.target.value);
                                    }}
                                    size="small"
                                    id="outlined"
                                    className={classes.styleO}
                                    error={
                                      addDriverErrors &&
                                      editArray.country === ""
                                    }
                                    value={`` || editArray.country}
                                    // defaultValue={0}

                                    displayEmpty
                                  >
                                    <MenuItem value="">Select Country</MenuItem>
                                    {countryList.length &&
                                      countryList.map((el, i) => {
                                        return (
                                          <MenuItem
                                            key={i}
                                            value={el.country_id}
                                          >
                                            {el.country_name}
                                          </MenuItem>
                                        );
                                      })}
                                  </Select>
                                )}
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  State
                                </Typography>
                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "state");
                                    getCities(e.target.value);
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.state === ""
                                  }
                                  value={editArray.state || ""}
                                >
                                  <MenuItem value="">Select City</MenuItem>
                                  {stateList.length &&
                                    stateList.map((el, i) => {
                                      return (
                                        <MenuItem key={i} value={el.state_id}>
                                          {el.state_name}
                                        </MenuItem>
                                      );
                                    })}
                                </Select>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  City
                                </Typography>

                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "city");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.city === ""
                                  }
                                  value={`` || editArray.city}
                                  displayEmpty
                                >
                                  <MenuItem value="">Select City</MenuItem>
                                  {cityList.length
                                    ? cityList.map((el, i) => {
                                        return (
                                          <MenuItem key={i} value={el.city_id}>
                                            {el.city_name}
                                          </MenuItem>
                                        );
                                      })
                                    : "Loading..."}
                                </Select>
                              </Grid>

                              <Grid item lg={12} xs={12}>
                                <Typography className={classes.styleL}>
                                  Secondary Address
                                </Typography>
                                <Paper
                                  component="form"
                                  className={classes.styleR}
                                >
                                  <InputBase
                                    onChange={(e) => {
                                      setDriverEditFormArray(
                                        e,
                                        "secondary_address"
                                      );
                                    }}
                                    fullWidth={true}
                                    error={
                                      addDriverErrors &&
                                      editArray.secondary_address === ""
                                    }
                                    value={`` || editArray.secondary_address}
                                  />
                                </Paper>
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Country
                                </Typography>
                                {countryList.length && (
                                  <Select
                                    style={{ minWidth: "100%" }}
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "country");
                                      getStates(e.target.value);
                                    }}
                                    size="small"
                                    id="outlined"
                                    className={classes.styleO}
                                    error={
                                      addDriverErrors &&
                                      editArray.country === ""
                                    }
                                    value={`` || editArray.country}
                                    // defaultValue={0}

                                    displayEmpty
                                  >
                                    <MenuItem value="">Select Country</MenuItem>
                                    {countryList.length &&
                                      countryList.map((el, i) => {
                                        return (
                                          <MenuItem
                                            key={i}
                                            value={el.country_id}
                                          >
                                            {el.country_name}
                                          </MenuItem>
                                        );
                                      })}
                                  </Select>
                                )}
                              </Grid>

                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  State
                                </Typography>
                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "state");
                                    getCities(e.target.value);
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.state === ""
                                  }
                                  value={editArray.state || ""}
                                >
                                  <MenuItem value="">Select City</MenuItem>
                                  {stateList.length &&
                                    stateList.map((el, i) => {
                                      return (
                                        <MenuItem key={i} value={el.state_id}>
                                          {el.state_name}
                                        </MenuItem>
                                      );
                                    })}
                                </Select>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  City
                                </Typography>

                                <Select
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "city");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.city === ""
                                  }
                                  value={`` || editArray.city}
                                  displayEmpty
                                >
                                  <MenuItem value="">Select City</MenuItem>
                                  {cityList.length
                                    ? cityList.map((el, i) => {
                                        return (
                                          <MenuItem key={i} value={el.city_id}>
                                            {el.city_name}
                                          </MenuItem>
                                        );
                                      })
                                    : "Loading..."}
                                </Select>
                              </Grid>
                            </Grid>
                            <br />
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "row",
                                flexWrap: "nowrap",
                                alignContent: "center",
                                justifyContent: "space-around",
                                alignItems: "center",
                              }}
                            >
                              <Button
                                onClick={() => {
                                  handleChangeAIndex(0);
                                  scrollToTop();
                                }}
                                className={
                                  isMdUp === true
                                    ? classes.styleP
                                    : classes.stylePM
                                }
                              >
                                <img
                                  src={back}
                                  style={{ marginRight: "15px" }}
                                />
                                Back
                              </Button>
                              <Button
                                onClick={() => {
                                  handleChangeAIndex(2);
                                  scrollToTop();
                                }}
                                className={
                                  isMdUp === true
                                    ? classes.styleQ
                                    : classes.styleQM
                                }
                              >
                                Next
                                <img src={next} style={{ marginLeft: 20 }} />
                              </Button>
                            </div>
                          </TabPanel>

                          <TabPanel
                            setOpenA={setOpenA}
                            value={value}
                            index={2}
                            dir={theme.direction}
                          >
                            <Grid container spacing={2}>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Aadhar Number
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "aadhar_number");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors &&
                                    editArray.aadhar_number === ""
                                  }
                                  value={`` || editArray.aadhar_number}
                                />
                                <FormControlLabel
                                  control={
                                    // {driversAddForm.type === "checked"?driversAddForm.type="2W": ""}
                                    <Checkbox
                                      // type="checkbox"
                                      checked={
                                        editArray.address_proof === "aadhar"
                                      }
                                      onClick={() => {
                                        setEditArray((state) => ({
                                          ...state,
                                          address_proof: "aadhar",
                                        }));
                                      }}
                                      // name="2W"
                                      // color="primary"
                                      // value={driversAddForm.type}
                                    />
                                  }
                                  label="Use aadhar as primary proof"
                                />
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Aadhar Image
                                </Typography>
                                <Button
                                  sx={{ ":hover": { backgroundColor: "#fff" } }}
                                >
                                  <input
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "aadhar");
                                    }}
                                    error={
                                      addDriverErrors && editArray.aadhar === ""
                                    }
                                    type="file"
                                    style={{ color: "#C1C1C1" }}
                                  />
                                </Button>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  PAN Number
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(e, "pan_number");
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors && editArray.aadhar === ""
                                  }
                                  value={`` || editArray.pan_number}
                                />
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  PAN Image
                                </Typography>
                                <Button
                                  sx={{ ":hover": { backgroundColor: "#fff" } }}
                                >
                                  <input
                                    onChange={(e) => {
                                      setDriverEditFormArray(e, "pan");
                                    }}
                                    error={
                                      addDriverErrors && editArray.pan === ""
                                    }
                                    type="file"
                                    style={{ color: "#C1C1C1" }}
                                  />
                                </Button>
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  Driving License Number
                                </Typography>
                                <TextField
                                  onChange={(e) => {
                                    setDriverEditFormArray(
                                      e,
                                      "driving_license_number"
                                    );
                                  }}
                                  size="small"
                                  id="outlined"
                                  className={classes.styleO}
                                  error={
                                    addDriverErrors &&
                                    editArray.driving_license_number === ""
                                  }
                                  value={`` || editArray.driving_license_number}
                                />
                                <FormControlLabel
                                  control={
                                    // {driversAddForm.type === "checked"?driversAddForm.type="2W": ""}
                                    <Checkbox
                                      // type="checkbox"
                                      checked={editArray.address_proof === "dl"}
                                      onClick={() => {
                                        setEditArray((state) => ({
                                          ...state,
                                          address_proof: "dl",
                                        }));
                                      }}
                                      // name="2W"
                                      // color="primary"
                                      // value={driversAddForm.type}
                                    />
                                  }
                                  label="Use DL as primary proof"
                                />
                              </Grid>
                              <Grid item lg={6} xs={12}>
                                <Typography className={classes.styleL}>
                                  License Image
                                </Typography>
                                <Button
                                  sx={{ ":hover": { backgroundColor: "#fff" } }}
                                >
                                  <input
                                    onChange={(e) => {
                                      setDriverEditFormArray(
                                        e,
                                        "driver_license"
                                      );
                                    }}
                                    error={
                                      addDriverErrors &&
                                      editArray.driver_license === ""
                                    }
                                    type="file"
                                    style={{ color: "#C1C1C1" }}
                                  />
                                </Button>
                              </Grid>
                            </Grid>
                            <br />
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "row",
                                flexWrap: "nowrap",
                                alignContent: "center",
                                justifyContent: "space-around",
                                alignItems: "center",
                              }}
                            >
                              <Button
                                onClick={() => {
                                  handleChangeAIndex(1);
                                  scrollToTop();
                                }}
                                className={
                                  isMdUp === true
                                    ? classes.styleP
                                    : classes.stylePM
                                }
                              >
                                <img
                                  src={back}
                                  style={{ marginRight: "15px" }}
                                />
                                Back
                              </Button>
                              <Button
                                onClick={() => {
                                  handleClose();
                                  handleChangeAIndex(3);

                                  // submitDriverEdit(true)
                                }}
                                type="submit"
                                className={
                                  isMdUp === true
                                    ? classes.styleQ
                                    : classes.styleQM
                                }
                              >
                                Save
                              </Button>
                            </div>
                          </TabPanel>
                        </SwipeableViews>
                      </Box>
                    </List>
                  ) : (
                    <Box className={classes.style1}>
                      <br />

                      <Box className={classes.marginLR}>
                        <AppBar position="static" className={classes.style2}>
                          <Tabs
                            // setOpen2={setOpen2}
                            value={value}
                            onChange={handleChangee}
                            indicatorColor="#000000"
                            color="#000000"
                            variant="fullWidth"
                            aria-label="full width tabs example"
                            className={classes.style3}
                          >
                            <Tab
                              className={
                                isMdUp === false
                                  ? classes.style4M
                                  : classes.style4
                              }
                              label="PERSONAL INFORMATION"
                              {...a11yProps(0)}
                            />
                            <Tab
                              className={
                                isMdUp === false
                                  ? classes.style4M
                                  : classes.style4
                              }
                              label="ADDRESS"
                              {...a11yProps(1)}
                            />
                            <Tab
                              className={
                                isMdUp === false
                                  ? classes.style4M
                                  : classes.style4
                              }
                              label="KYC DOCUMENT"
                              {...a11yProps(2)}
                            />
                          </Tabs>
                        </AppBar>
                      </Box>

                      <SwipeableViews
                        axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                        index={value}
                        onChangeIndex={handleChangeeIndex}
                      >
                        <TabPanel
                          // setOpen2={setopen2}
                          value={value}
                          index={0}
                          dir={theme.direction}
                        >
                          <List className={classes.style5}>
                            <div>
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer", userSelect: "none" }}
                              >
                                <ListItemAvatar>
                                  <img src={EditDriver} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    // <Typography className={classes.style7}
                                    //     component="span">{selectedDriver.type}</Typography>
                                    <>
                                      <FormControlLabel
                                        control={
                                          <Checkbox
                                            disabled={true}
                                            checked={
                                              selectedDriver.type &&
                                              selectedDriver.type.includes("2W")
                                            }
                                            onChange={handleChangeCheck}
                                            name="checkedA"
                                            color="primary"
                                          />
                                        }
                                        label="2W"
                                      />
                                      <FormControlLabel
                                        control={
                                          <Checkbox
                                            checked={
                                              selectedDriver.type &&
                                              selectedDriver.type.includes(
                                                "Eauto"
                                              )
                                            }
                                            onChange={handleChangeChecks}
                                            name="checkedB"
                                            disabled={true}
                                            color="primary"
                                          />
                                        }
                                        label="Eauto"
                                      />
                                      <FormControlLabel
                                        control={
                                          <Checkbox
                                            checked={
                                              selectedDriver.type &&
                                              selectedDriver.type.includes(
                                                "L5com"
                                              )
                                            }
                                            onChange={handleChangeCheckss}
                                            name="checkedC"
                                            disabled={true}
                                            color="primary"
                                          />
                                        }
                                        label="L5 Commericial Vehicle"
                                      />
                                    </>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.style8}
                                        component="span"
                                      >
                                        License Type
                                      </Typography>
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                              <Divider />
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer" }}
                              >
                                <ListItemAvatar>
                                  <img src={EditName} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    <Typography
                                      className={classes.style7}
                                      component="span"
                                    >
                                      {selectedDriver.name}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.style8}
                                        component="span"
                                      >
                                        Driver Name
                                      </Typography>
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                              <Divider />
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer" }}
                              >
                                <ListItemAvatar>
                                  <img src={EditUser} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    <Typography
                                      className={classes.style7}
                                      component="span"
                                    >
                                      {selectedDriver.user_name}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.style8}
                                        component="span"
                                      >
                                        User Name
                                      </Typography>
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                              <Divider />
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer" }}
                              >
                                <ListItemAvatar>
                                  <img src={MobNum} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    <Typography
                                      className={classes.style7}
                                      component="span"
                                    >
                                      {selectedDriver.mobile}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.style8}
                                        component="span"
                                      >
                                        Mobile Number
                                      </Typography>
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                              <Divider />
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer" }}
                              >
                                <ListItemAvatar>
                                  <img src={EditMail} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    <Typography
                                      className={classes.style7}
                                      component="span"
                                    >
                                      {selectedDriver.email}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.style8}
                                        component="span"
                                      >
                                        Email
                                      </Typography>
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                              <Divider />
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer" }}
                              >
                                <ListItemAvatar>
                                  <img src={EditLang} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    <Select
                                      disabled={true}
                                      onChange={(e) => {
                                        setDriverEditFormArray(e, "language");
                                      }}
                                      size="small"
                                      id="outlined"
                                      className={classes.styleO}
                                      error={
                                        addDriverErrors &&
                                        editArray.language === ""
                                      }
                                      value={selectedDriver.language}
                                    >
                                      <MenuItem value="">
                                        Select your language
                                      </MenuItem>
                                      {languageList &&
                                        languageList.map((lang) => {
                                          return (
                                            <MenuItem
                                              key={lang.language_id}
                                              value={lang.language_id}
                                            >
                                              {lang.language}
                                            </MenuItem>
                                          );
                                        })}
                                    </Select>
                                  }
                                />
                              </ListItem>
                              <Divider />
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer" }}
                              >
                                <ListItemAvatar>
                                  <img src={EditTime} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    <Typography
                                      className={classes.style7}
                                      component="span"
                                    >
                                      {selectedDriver.shift_time}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.style8}
                                        component="span"
                                      >
                                        Shift Time
                                      </Typography>
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                            </div>
                          </List>
                        </TabPanel>

                        <TabPanel
                          // setOpen2={setOpen2}
                          value={value}
                          index={1}
                          dir={theme.direction}
                        >
                          <List className={classes.style5}>
                            <div>
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer" }}
                              >
                                <ListItemAvatar>
                                  <img src={Prime} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    <Typography
                                      className={classes.style9}
                                      component="span"
                                    >
                                      {"Primary Address"} <br />
                                      {selectedDriver.primary_address}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.style10}
                                        component="span"
                                      >
                                        Country:
                                      </Typography>
                                      {countryList.length &&
                                        countryList.map((el) => {
                                          if (
                                            el.country_id ==
                                            selectedDriver.country
                                          ) {
                                            return (
                                              <b
                                                style={{ fontSize: "inherit" }}
                                              >
                                                &nbsp;&nbsp;{el.country_name}
                                              </b>
                                            );
                                          }
                                        })}
                                      <br /> <br />
                                      <Typography
                                        className={classes.style10}
                                        component="span"
                                      >
                                        State:
                                      </Typography>
                                      {stateList.length &&
                                        stateList.map((el) => {
                                          if (
                                            el.state_id == selectedDriver.state
                                          ) {
                                            return (
                                              <b
                                                style={{ fontSize: "inherit" }}
                                              >
                                                &nbsp;&nbsp;{el.state_name}
                                              </b>
                                            );
                                          }
                                        })}
                                      <br /> <br />
                                      <Typography
                                        className={classes.style10}
                                        component="span"
                                      >
                                        City:
                                      </Typography>
                                    
                                      {cityList.length &&
                                        cityList.map((el) => {
                                          if (
                                            el.city_id == selectedDriver.city
                                          ) {
                                            return (
                                              <b
                                                style={{ fontSize: "inherit" }}
                                              >
                                                &nbsp;&nbsp;{el.city_name}
                                              </b>
                                            );
                                          }
                                        })}
                                      <br />
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                              <Divider />
                            </div>
                            <div>
                              <ListItem
                                alignItems="flex-start"
                                sx={{ cursor: "pointer" }}
                              >
                                <ListItemAvatar>
                                  <img src={Secondary} />
                                </ListItemAvatar>
                                <ListItemText
                                  className={classes.style6}
                                  primary={
                                    <Typography
                                      className={classes.style9}
                                      component="span"
                                    >
                                      {selectedDriver.secondary_address}
                                    </Typography>
                                  }
                                  secondary={
                                    <React.Fragment>
                                      <Typography
                                        className={classes.style10}
                                        component="span"
                                      >
                                        Country:
                                      </Typography>
                                      {countryList.length && (
                                        <Select
                                          disabled={true}
                                          style={{ width: "50%" }}
                                          onChange={(e) => {
                                            setDriverEditFormArray(
                                              e,
                                              "country"
                                            );
                                            getStates(e.target.value);
                                          }}
                                          size="small"
                                          id="outlined"
                                          className={classes.styleO}
                                          error={
                                            addDriverErrors &&
                                            editArray.country === ""
                                          }
                                          value={selectedDriver.country || ""}
                                          displayEmpty
                                        >
                                          <MenuItem value="">
                                            Select Country
                                          </MenuItem>
                                          {countryList.length &&
                                            countryList.map((el, i) => {
                                              return (
                                                <MenuItem
                                                  key={i}
                                                  value={el.country_id}
                                                >
                                                  {el.country_name}
                                                </MenuItem>
                                              );
                                            })}
                                        </Select>
                                      )}
                                      <br /> <br />
                                      <Typography
                                        className={classes.style10}
                                        component="span"
                                      >
                                        State:
                                      </Typography>
                                      <Select
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "state");
                                          getCities(e.target.value);
                                        }}
                                        style={{ width: "50%" }}
                                        disabled={true}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors &&
                                          editArray.state === ""
                                        }
                                        value={selectedDriver.state || ""}
                                      >
                                        <MenuItem value="">
                                          Select City
                                        </MenuItem>
                                        {stateList.length &&
                                          stateList.map((el, i) => {
                                            return (
                                              <MenuItem
                                                key={i}
                                                value={el.state_id}
                                              >
                                                {el.state_name}
                                              </MenuItem>
                                            );
                                          })}
                                      </Select>
                                      <br /> <br />
                                      <Typography
                                        className={classes.style10}
                                        component="span"
                                      >
                                        City:
                                      </Typography>
                                      <Select
                                        style={{ width: "50%" }}
                                        onChange={(e) => {
                                          setDriverEditFormArray(e, "city");
                                        }}
                                        size="small"
                                        id="outlined"
                                        className={classes.styleO}
                                        error={
                                          addDriverErrors &&
                                          editArray.city === ""
                                        }
                                        value={selectedDriver.city || ""}
                                        displayEmpty
                                        disabled={true}
                                      >
                                        <MenuItem value="">
                                          Select City
                                        </MenuItem>
                                        {cityList.length
                                          ? cityList.map((el, i) => {
                                              return (
                                                <MenuItem
                                                  key={i}
                                                  value={el.city_id}
                                                >
                                                  {el.city_name}
                                                </MenuItem>
                                              );
                                            })
                                          : "Loading..."}
                                      </Select>
                                      <br />
                                    </React.Fragment>
                                  }
                                />
                              </ListItem>
                              <Divider />
                            </div>
                          </List>
                        </TabPanel>

                        <TabPanel
                          // setOpen2={setOpen2}
                          value={value}
                          index={2}
                          dir={theme.direction}
                        >
                          <List className={classes.style5}>
                            {/* <div style={{ display: 'flex' }}> */}
                            {/* <div> */}
                            <Grid container spacing={3}>
                              <Grid item xs={12} lg={6}>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style12}
                                    primary={selectedDriver.aadhar_number}
                                    secondary={
                                      <React.Fragment>
                                        <Typography
                                          className={classes.style13}
                                          component="span"
                                          variant="body2"
                                          color="text.primary"
                                          float="left"
                                        >
                                          Aadhar Number
                                        </Typography>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                              </Grid>
                              <Grid item xs={12} lg={6}>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style13}
                                    primary="Aadhar Card"
                                    secondary={
                                      <React.Fragment>
                                        <Button className={classes.style14}>
                                          View
                                        </Button>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                              </Grid>
                            </Grid>

                            {/* </div> */}
                            {/* <div style={{ marginLeft: 100 }}>*/}

                            {/* </div></div> */}
                            <Divider />
                            <Grid container spacing={3}>
                              <Grid item xs={12} lg={6}>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style12}
                                    primary={selectedDriver.pan_number}
                                    secondary={
                                      <React.Fragment>
                                        <Typography
                                          className={classes.style13}
                                          component="span"
                                          variant="body2"
                                          color="text.primary"
                                          float="left"
                                        >
                                          PAN Number
                                        </Typography>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                              </Grid>
                              <Grid item xs={12} lg={6}>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style13}
                                    primary="Aadhar Card"
                                    secondary={
                                      <React.Fragment>
                                        <Button className={classes.style14}>
                                          View
                                        </Button>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                              </Grid>
                            </Grid>
                            <Divider />
                            <Grid container spacing={3}>
                              <Grid item xs={12} lg={6}>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style12}
                                    primary={
                                      selectedDriver.driving_license_number
                                    }
                                    secondary={
                                      <React.Fragment>
                                        <Typography
                                          className={classes.style13}
                                          component="span"
                                          variant="body2"
                                          color="text.primary"
                                          float="left"
                                        >
                                          License Number
                                        </Typography>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                              </Grid>
                              <Grid item xs={12} lg={6}>
                                <ListItem alignItems="flex-start">
                                  <ListItemText
                                    className={classes.style13}
                                    primary="Aadhar Card"
                                    secondary={
                                      <React.Fragment>
                                        <Button className={classes.style14}>
                                          View
                                        </Button>
                                      </React.Fragment>
                                    }
                                  />
                                </ListItem>
                              </Grid>
                            </Grid>

                            {/* <div style={{ display: 'flex' }}><div><ListItem alignItems="flex-start">
                                                        <ListItemText className={classes.style12}
                                                            primary={selectedDriver.pan_number}
                                                            secondary={
                                                                <React.Fragment>
                                                                    <Typography
                                                                        className={classes.style13}
                                                                        component="span"
                                                                        variant="body2"
                                                                        color="text.primary"
                                                                        float="left"
                                                                    >
                                                                        PAN Number
                                                                    </Typography>
                                                                </React.Fragment>
                                                            }
                                                        />
                                                    </ListItem></div>
                                                        <div style={{ marginLeft: 100 }}><ListItem alignItems="flex-start">
                                                            <ListItemText className={classes.style13}
                                                                primary="PAN Card"
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Button className={classes.style14}>View</Button>
                                                                    </React.Fragment>
                                                                }
                                                            />
                                                        </ListItem></div></div>
                                                    <Divider />
                                                    <div style={{ display: 'flex' }}><div><ListItem alignItems="flex-start">
                                                        <ListItemText className={classes.style12}
                                                            primary={selectedDriver.driving_license_number}
                                                            secondary={
                                                                <React.Fragment>
                                                                    <Typography
                                                                        className={classes.style13}
                                                                        component="span"
                                                                        variant="body2"
                                                                        color="text.primary"
                                                                        float="left"
                                                                    >
                                                                        Driving License Number
                                                                    </Typography>
                                                                </React.Fragment>
                                                            }
                                                        />
                                                    </ListItem></div>
                                                        <div style={{ marginLeft: 65 }}><ListItem alignItems="flex-start">
                                                            <ListItemText className={classes.style13}
                                                                primary="License Card"
                                                                secondary={
                                                                    <React.Fragment>
                                                                        <Button className={classes.style14}>View</Button>
                                                                    </React.Fragment>
                                                                }
                                                            />
                                                        </ListItem></div></div> */}
                          </List>
                        </TabPanel>
                      </SwipeableViews>
                    </Box>
                  )}
                </Item>
              </Grid>
            ) : null}
          </Grid>
        )}
      </div>
    );
  } else {
    return <Loading />;
  }
}
