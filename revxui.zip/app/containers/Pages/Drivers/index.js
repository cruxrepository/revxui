import React from "react";
import PropTypes from "prop-types";
import { Helmet } from "react-helmet";
import brand from "enl-api/dummy/brand";
import { PapperBlock } from "enl-components";
import { injectIntl, FormattedMessage } from "react-intl";
import messages from "./messages";
import Paper from "@material-ui/core/Paper";
import DriversTab from "./DriversTab";
import PageTitle from '../../../components/Utils/PageTitle';

function Drivers(props) {
  const title = brand.name + " - Drivers";
  const description = brand.desc;
  const { intl } = props;
  return (
    <div>
      <Helmet>
        <title> {title} </title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="twitter:title" content={title} />
        <meta property="twitter:description" content={description} />
      </Helmet> 
      <div style={{marginTop:'-25px'}}><PageTitle /> <br/>
      <DriversTab /></div>
     
    </div>
  );
}

Drivers.propTypes = {
  intl: PropTypes.object.isRequired,
};

export default injectIntl(Drivers);
