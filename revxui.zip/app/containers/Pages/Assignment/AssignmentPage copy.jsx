import React from 'react';
import axios from 'axios';
import { withStyles, makeStyles, useTheme, styled } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import LinearProgress from '@material-ui/core/LinearProgress';
import Chip from '@material-ui/core/Chip';
import MUIDataTable from 'mui-datatables';
import MenuItem from "@material-ui/core/MenuItem";
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Button from "@material-ui/core/Button"; 
import Select from "@material-ui/core/Select";
import Tooltip from '@material-ui/core/Tooltip';
import NotificationImportantIcon from '@material-ui/icons/NotificationImportant';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
// import makeAPICall from "../../reducers/batteryActions";
// import { getAllEBatteries } from '../../../actions/asyncActions';
// import getCBattery from "../../../api/batteryPage/getCBattery"
import TextField from '@material-ui/core/TextField';
import BatteryCharging30Icon from '@material-ui/icons/BatteryCharging30';
import endpoints from '../../../endpoints/endpoints';
import Dialog from '@material-ui/core/Dialog';
import Brightness1Icon from '@material-ui/icons/Brightness1';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux'; 
import { getMyBatteryBulk, getBatteryModelBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';
const useStyles = makeStyles((theme) => ({

    root: {
        margin: 10
    },
    textField: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
        'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
      },
    table: {

        '& > div': {

            '& > .MuiToolbar-regular': {
                backgroundColor: '#68A72480  !important',
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0
            },
            overflow: 'auto',
            // textAlign:'center'
        },

        '& table': {
            '& td': {
                wordBreak: 'keep-all',
                textAlign: 'center'
            },

            [theme.breakpoints.down('md')]: {
                '& td': {
                    height: 60,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                },
                '& tr:nth-child(odd)': {
                    backgroundColor: '#cfcfcf40'
                },
                '& tr:nth-child(even)': {
                    backgroundColor: '#cfcfcf20'
                },
            }
        }
    },
    graphText: {
        fontSize: 12,
        position: 'absolute',
        transform: 'rotate(270deg)',
        left: '-40px',
        top: 370,
        color: 'primary',
        fontWeight: 600
    },
    graphSelect: {
        minWidth: 150, left: '20em', marginBottom: 20
    },
    tabsSection: {
        [theme.breakpoints.up('lg')]: {
            // borderRadius:0,position:'sticky',top:0 ,width:500
            borderRadius: 0, position: 'sticky', top: 0, width: 500

        },


    },
    copyRight: {
        position: 'absolute', bottom: 0, right: 0, left: 0, fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    dialog: {
        // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
        position: 'relative', marginLeft: '680px'
    }, 
   healthy: {
        color: '#82E219', width: '5rem', fontSize: '20px'
   },
   Unhealthy: {
    color: '#FFFF00', width: '5rem', fontSize: '20px'
},
    bbase:{
        '.MUIDataTableHeadCell-toolButton': {width: '60px !important', whiteSpace: 'normal' }
    }
}));

/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function AssignmentPage() {

    const MyBatteryData = useSelector((store) => store.myBattery)
    const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
    let MyBatteryMeta = useSelector((store) => store.myBattery)
    let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
    let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
    let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)

 
    const dispatch = useDispatch();

    const [openEditModel, setOpenEditModel] = React.useState(false);
    const [openEditBattery, setOpenEditBattery] = React.useState(false);

    const theme = useTheme();
    const classes = useStyles();
    const [screen, setScreen] = React.useState(false);
    const [idleMode, setIdleMode] = React.useState(false);
    
     

     
    const [value, setValue] = React.useState(0);
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    React.useEffect(() => {
        dispatch(getMyBatteryBulk());
    }, [dispatch, MyBatteryMetaPresent]);
   

     


    

    

    const [tableMode, setTableMode] = React.useState("ericksaw");
    const handleTableChange = (event) => {
        if (tableMode === 'erickshaw') {
            setTableMode('comm');
        } else {
            setTableMode('erickshaw');
        }
    };
    const dayDropdown = [{ val: 'day', name: 'Day' }, { val: 'month', name: 'Month' }, { val: 'year', name: 'Year' }, { val: 'custom', name: 'Custom' }]




 

    const columnsBattery = [

        {
            name: 'Serial Number',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => {
                        setScreen(true);
                        setFormats('chart')
                        setBmsId(value.bms_id)
                    }}
                        style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                        &nbsp;&nbsp;{value.serial_number}
                    </Typography>

                )
            }
        },
        {
            name: 'Model',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => setScreen(true)}
                        // style={{ color: '#33a6ff', cursor: 'pointer' }} 
                        variant='subtitle2'>{value}</Typography>
                )
            }
        },
        {
            name: 'Investor',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => setScreen(true)} variant='subtitle2'>{value}</Typography>
                )
            }
        },
        {
            name: 'Operation Owner',
            options: {
                filter: true,
                customBodyRender: (value) => (
                    <Typography onClick={() => setScreen(true)} variant='subtitle2'>{value}</Typography>
                )
            }
        },
        {
            name: 'Vehicle Number',
            options: {
                filter: false,
                customBodyRender: (value) => (
                    <Typography style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>{!value ? "-" : value}</Typography>
                )
            }
        },

        {
            name: 'Status',
            options: {
                filter: true,
                customBodyRender: (value) => {
                    if (value.vehicle_number && value.battery_status === "on") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }
                    else if (value.vehicle_number && value.battery_status === "off") {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }
                    else {
                        return (
                            <>
                                <IconButton><Icon icon="mdi:motorbike" color="#c4c4c4" width="30" height="30" /></IconButton>
                                <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                            </>
                        )
                    }


                },

            },

        },
    ];
    


    
    const data = [
        ['12Amsw', 'E-Auto', 'TN 01 Z 1245','John', 12.30, '50%', 'Precharge', '100', 'healthy' , 'deactive',],
        ['EEZY FEY0','Erickshaw ','TN 01 M 5689','Nick', 12.30,  '20%', 'Cancharge', '100', 'healthy', 'assign'],
        ['1235id','2 wheeler ','TN 01 M 5689','King', 12.30,  '20%', 'Discharge', '100', 'healthy', 'assign'],
         

    ];
    
    const options = {
        filterType: 'dropdown',
        responsive: 'vertical',
        print: true,
        rowsPerPage: 10,
        page: 0,
        selectableRows: "none", 

    };
    const [chartOneVal, setChartOneVal] = React.useState("day");
    const handleChartOneVal = (e) => {
        setChartOneVal(e.target.value);

    }





    const [frame, setFrame] = React.useState(false)
    
    return (
        <div
            // onMouseMove={() => setFrame(!frame)}
            className={classes.table}>
             
            <Paper square className={classes.root}>

            </Paper>
            {(MyBatteryMetaPresent) ?
        (
            <MUIDataTable  
                checkboxSelection={false}
                title="Assignment"
                // data={CBatteryMeta.data}
                data={MyBatteryMeta.data}
                columns={columnsBattery}
                options={options}
                selectableRowsHideCheckboxes
            />
        )
        :   MyBatteryFetching ?
        <Loading /> :
        MyBatteryResponsecode === 500 ?

            <ErrorWrap /> : null

      }
           
            <br />
            <Typography align="center" style={{ fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'}} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
        </div>
    );
}
