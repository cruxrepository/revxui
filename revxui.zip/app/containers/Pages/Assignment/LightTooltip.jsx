import React from 'react';
import { withStyles, makeStyles, useTheme, styled } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';

export default function LightTooltip(props) {
    const { title, placement, arrow, style } = props;
    const LightTooltip = styled(Tooltip)(({ theme }) => ({
        tooltip: {
            backgroundColor: theme.palette.common.white,
            color: 'rgba(0, 0, 0, 0.87)',
            boxShadow: theme.shadows[1],
            fontSize: 20,
        },
        arrow: {
            arrow: {
                color: '#fff',
            },
        },
    }));
    return (
        <LightTooltip
            title={title}
            placement={placement}
            arrow
            style={style}
        />
    )

}