import React, { useState } from 'react';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import MUIDataTable from 'mui-datatables';
import Switch from '@material-ui/core/Switch';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import Pagination from '@material-ui/lab/Pagination';
import { useDispatch, useSelector } from 'react-redux';
import { getMyBatteryBulk } from '../../../redux/actions/asyncActions';

const useStyles = makeStyles((theme) => ({
    tableborder: { display: 'none' },
    root: {
        margin: 10
    },
    textField: {
        width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
        'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    dialogPaper: {
        height: "85%",
        width: "50%",
        marginLeft: '700px'
    },
    table: {

        '& > div': {

            '& > .MuiToolbar-regular': {
                backgroundColor: '#68A72480  !important',
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0
            },
            // overflow: 'auto',
            // textAlign:'center'
        },

        '& table': {
            '& td': {
                wordBreak: 'keep-all',
                textAlign: 'center'
            },

            [theme.breakpoints.down('md')]: {
                '& td': {
                    height: 60,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                },
                '& tr:nth-child(odd)': {
                    backgroundColor: '#cfcfcf40'
                },
                '& tr:nth-child(even)': {
                    backgroundColor: '#cfcfcf20'
                },
            }
        }
    },
    graphText: {
        fontSize: 12,
        position: 'absolute',
        transform: 'rotate(270deg)',
        left: '-40px',
        top: 370,
        color: 'primary',
        fontWeight: 600
    },
    graphSelect: {
        minWidth: 150, left: '20em', marginBottom: 20
    },
    tabsSection: {
        [theme.breakpoints.up('lg')]: {
            // borderRadius:0,position:'sticky',top:0 ,width:500
            borderRadius: 0, top: 0, width: 500

        },


    },
    primaryText: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
    }, primaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '300px'
    },
    secondaryTextG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724', width: '100%'
    },
    voltageG: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#68A724'
    },
    voltageY: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FFBF00'
    },
    voltageR: {
        fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#FF0000'
    },
    chart1: {
        marginLeft: '-20px', width: '120px', height: '50px', '.MuiPaper-root .MuiMenu-paper .MuiPopover-paper': { width: '120px !important' }
    },
    copyRight: {
        position: 'absolute', bottom: 0, right: 0, left: 0, fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    dialog: {
        // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
        position: 'relative', marginLeft: '680px'
    },
    healthy: {
        color: '#82E219', width: '5rem', fontSize: '20px'
    },
    Unhealthy: {
        color: '#FFFF00'
    },
    chart: {
        padding: theme.spacing(2)
    },
    dataView: {
        height: '300px',
    },
    BNavatar: { height: '60px', width: '60px', border: '1px solid #fff', backgroundColor: "#77b93e" },
    BNavatar1: { backgroundColor: '#f3efef' },
    BNgrid: { marginLeft: 20 },
    BNprimaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '16px', fontWeight: 600, color: 'primary', width: '200px',
    },
    BNstateText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '20px', fontWeight: 500, color: '#fff', width: '250px',
    },
    BNsecondaryText: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary',
    },
    BNsecondaryTextG: { color: '#00FF00' },
    BNsecondaryText1: {
        fontFamily: 'Maven Pro,sans-serif', fontSize: '14px', fontWeight: 600, color: 'primary', width: '150px',
    },
    BNIcon: {
        marginRight: 10, marginTop: 10
    },
    BNtitle: {},
    BNsubtitle: {},

    BNchip: { backgroundColor: '#4caf50b5' },
    BNchip2: { backgroundColor: '#FFBF00' },
    BNchip3: { backgroundColor: '#FF0000' },
    BNstyledPaper: {
        backgroundColor: '#a2c97d',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper2: {
        backgroundColor: '#FFBF00',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNstyledPaper3: {
        backgroundColor: '#FF0000',
        height: 95,
        padding: 10,
        '& $title, & $subtitle': {
            color: theme.palette.common.white
        }
    },
    BNprogressWidget: {
        marginTop: 20,
        background: theme.palette.secondary.dark,
        '& div': {
            background: theme.palette.primary.light,
        }
    },
    BNmap: {
        height: 200, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    BNcover: {
        '& $name, & $subheading': {
            color: theme.palette.common.white
        },
        position: 'relative',
        width: '100%',
        overflow: 'hidden',
        height: 200,
        backgroundColor: "#77b93e"
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        ,
        // backgroundColor:
        // theme.palette.type === 'dark' ? darken(theme.palette.primary.dark, 0.8) : theme.palette.primary.dark
        // ,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-end',
        backgroundSize: 'cover',
        textAlign: 'center',
        boxShadow: theme.shadows[7],
        backgroundPosition: 'bottom center',
        borderRadius: '10px 10px 0px 0px',
    },
    BNname: {
        fontSize: '24px', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400, color: '#fff'
    },
    BNopt: {
        position: 'absolute',
        top: 0,
        right: 10,
        '& button': {
            color: theme.palette.common.white
        }
    },
    BNprofileTab: {
        marginTop: 0,
        [theme.breakpoints.down('sm')]: {
            marginTop: 0,
        },
        borderRadius: '0px 0px 10px 10px',
        background:
            // alpha(theme.palette.background.paper, 0.8)
            "#dcead7",
        position: 'relative'
    },
    BNaboutTxt: {
        fontSize: '1rem', fontWeight: 600, color: '#000000'
    },

    BNaboutTxt1: {
        fontSize: '1rem', fontWeight: 400, color: '#000000'
    },
    BNdriving: {
        color: '#82E219', marginLeft: '-90px'
    },
    BNdrivingR: {
        color: '#ff0000', marginLeft: '-90px'
    },
    BNorangeAvatar: {
        backgroundColor: '#ff5722',
    },
    BNpurpleAvatar: {
        backgroundColor: '#673ab7',
    },
    BNpinkAvatar: {
        backgroundColor: '#e91e63',
    },
    BNgreenAvatar: {
        backgroundColor: '#4caf50',
    },
    BNdivider: {
        width: '92%', marginLeft: '20px'
    },
    addTab: { backgroundColor: '#b3d391', color: "#fff" },
    pageTitle: {
        textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600
    }
}));

export default function AssignmentPage() {
    const MyBatteryData = useSelector((store) => store.myBattery)
    const MyBatteryDataRaw = useSelector((store) => store.myBattery.rawData)
    const MyBatteryPage = useSelector((store) => store.myBattery.page_number)
    const MyBatteryPageCount = Math.ceil(useSelector((store) => store.myBattery.total_records) / 10)
    //   let MyBatteryMeta = useSelector((store) => store.myBattery)
    // let MyBatteryMeta =  getBatteryModelBulk()
    let MyBatteryMeta = {};
    MyBatteryMeta.data = [];
    let MyBatteryMetaa = useSelector((store) => store.myBattery)
    if (MyBatteryMetaa.data.length >= 1) {
        MyBatteryMeta.data = MyBatteryMetaa.data;
    }
    let MyBatteryFetching = useSelector((store) => store.myBattery.fetching)
    let MyBatteryResponsecode = useSelector((store) => store.myBattery.responseStatus)
    let MyBatteryMetaPresent = useSelector((store) => store.myBattery.dataPresent)

    const logged_user = useSelector((store) => store.user.loggeduser);
    let enty = logged_user.entity_id
    const dispatch = useDispatch();
    let batteryPageNum = 0;

    const theme = useTheme();
    const classes = useStyles();
    const [batPage, setBatPage] = React.useState(1);

    React.useEffect(() => {
        dispatch(getMyBatteryBulk(enty, batPage));
    }, [MyBatteryMetaPresent, batPage]);


    const changePageBat = (event, newValue) => {
        setBatPage(newValue);
    };

    const validateKeyData = (key) => {
        return key ? key : "-";
    };

  

   
        const columnsBattery = [

            {
                name: 'Serial Number',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography onClick={() => {
                            setBmsId(validateKeyData(value.bms_id))
                            setImei(validateKeyData(value.imei))
                            setSerial(validateKeyData(value.serial_number))
                            setModel(validateKeyData(value.battery_model))
                        }}
                            style={{ color: '#33a6ff', cursor: 'pointer' }} variant='subtitle2'>
                            &nbsp;&nbsp;{value.serial_number}
                        </Typography>

                    )
                }
            },
            {
                name: 'Model',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography onClick={() => {
                            setScreen(true)
                        }}
                            variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            },
            {
                name: 'Investor',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography onClick={() => setScreen(true)} variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            },
            {
                name: 'Operation Manager',
                options: {
                    filter: true,
                    customBodyRender: (value) => (
                        <Typography onClick={() => setScreen(true)} variant='subtitle2'>{validateKeyData(value)}</Typography>
                    )
                }
            },
            {
                name: 'Vehicle Number',
                options: {
                    filter: false,
                    customBodyRender: (value) => {
                        if (value.serial_number === "OFG144V380Ah_20221") {
                            return (<Typography style={{ color: '#33a6ff', cursor: 'pointer' }}
                                variant='subtitle2'>-</Typography>)
                        }
                        else {
                            return (
                                <Typography style={{ color: '#33a6ff', cursor: 'pointer' }}
                                    variant='subtitle2'>{validateKeyData(value.vehicle_number)}</Typography>
                            )
                        }
                    }

                }
            },
            {
                name: 'Active',
                options: {
                    filter: false,  //setImei(validateKeyData(value.imei))
                    customBodyRender: (value) => {
                        if (value.status === "true") {
                            return (<Switch checked={true} />)
                        }
                        else {
                            return (<Switch checked={false} />)
                        }
                    }

                }
            },
            {
                name: 'Action',
                options: {
                    filter: true,
                    customBodyRender: (value) => {

                        if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "disabled") {
                            return (
                               <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>
                            )
                        }
                        else if (value.serial_number === "OFG144V380Ah_20221" && value.battery_status === "enabled") {
                            return (
                                    <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>
                            )
                        }
                        else if (value.vehicle_status === "assign" && value.battery_status === "disabled") {
                            return (
                                <><IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" />
                                    </IconButton>
                                    <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>

                                </>
                            )
                        }
                        else if (value.vehicle_status === "assign" && value.battery_status === "enabled") {
                            return (
                                <><IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" />
                                    </IconButton>
                                    <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>

                                </>
                            )
                        }
                        else if (value.vehicle_status === "" && value.battery_status === "disabled") {
                            return (
                                <><IconButton><Icon icon="mdi:motorbike" color="#C4C4C4" width="30" height="30" /></IconButton>
                                    <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" />
                                    </IconButton>

                                </>
                            )
                        }
                        else if (value.vehicle_status === "" && value.battery_status === "enabled") {
                            return (
                                <><IconButton><Icon icon="mdi:motorbike" color="#C4C4C4" width="30" height="30" /></IconButton>
                                    <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>

                                </>
                            )
                        }
                        else {
                            return (
                                <><IconButton><Icon icon="mdi:motorbike" color="#c4c4c4" width="30" height="30" />
                                    </IconButton>
                                    <IconButton><Icon icon="mdi:car-battery" color="#c4c4c4" width="30" height="30" /> </IconButton>

                                </>
                            )
                        }


                    },

                },

            },

        ]
       
        const options = {
            filterType: 'dropdown',
            responsive: 'vertical',
            print: true,
            rowsPerPage: 100,

            selectableRows: "none",
           
        };




        const handleChangeC = (event) => {
            setState({ ...state, [event.target.name]: event.target.checked });
        };
        return (
            <div className={classes.table}>
                    
                  <MUIDataTable
                                checkboxSelection={false}
                                title="Assignment"
                                // // data={data}
                                data={MyBatteryMeta.data}
                                columns={columnsBattery}
                                options={options}
                                selectableRowsHideCheckboxes
                            /><br /><Pagination count={MyBatteryPageCount} page={MyBatteryPage} onChange={changePageBat} />

                <br />
                <Typography align="center" style={{ fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'}} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
            </div>
        );
}
