import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles, useTheme, styled, withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import SimpleMap from "./SimpleMap";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import Button from "@material-ui/core/Button";
import Slider from '@material-ui/core/Slider';
import { Icon } from '@iconify/react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import './App3.css';
import BarChart from "./BarChart";
import PaymentPieMobile from "./PaymentPieMobile";
import PaymentPie from "./PaymentPie";
import Chart from "./Chart";
let id = 0;
function createData(vtype,location, model, vnum, health, payment) {
    id += 1;
    return {
        id,vtype,location, model, vnum, health, payment
    };
}


const data = [
    createData('Erick Vehicle','CBE', 'TN02E23487000','TN 01 A 0001', 'Healthy','Success'),
    createData('CV Vehicle', 'CBE','TN02E23487000','TN 02 B 0002', 'Healthy','Success'),
    createData('CV Vehicle','CBE', 'TN02E23487000','TN 03 C 0003', 'Healthy','Pending'),
    createData('Erick Vehicle','CBE', 'TN02E23487000','TN 04 D 0004', 'Healthy','Success')
];
const colors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'left',
    color: theme.palette.text.secondary,
}));
const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.secondary.dark,
        backgroundColor: theme.palette.secondary.light,
    },
    map: {
        height: 320, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    box: {
        border: '1px solid #979797', height: '30px', borderRadius: '7px', backgroundColor: '#F3F3F3'

    },
    boxM: {
        border: '1px solid #979797', height: '15px', borderRadius: '7px', backgroundColor: '#F3F3F3'

    },
    copyRight: {
        fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    paperH: {
        height: '350px', border: '1px solid #D8D8D8'
    },
    paperH1: {
        height: 320, border: '1px solid #D8D8D8'
    },
    paperH2: {
        height: '230px', border: '1px solid #D8D8D8'
    },
    paperH3: {
        height: '200px', border: '1px solid #D8D8D8'
    },
    paperH4: {
        height: '360px', border: '1px solid #D8D8D8'
    },
    paperH5: {
        height: '360px', border: '1px solid #D8D8D8', backgroundColor: '#e5e5ed'
    },
    slide: {
        margin: 20
    },
    rootTable: {
        width: '100%', margin: 0
    },
    title: {
        backgroundColor: '#009688CC'
    },
    titleFont: {
        color: '#FFFFFF', fontSize: '15px', fontWeight: 600
    },
    titleFontM: {
        color: '#FFFFFF', fontSize: '10px', fontWeight: 600
    },
    text1: {
        fontFamily: 'Roboto', fontSize: '15px', fontWeight: 600, color: '#7A7A7D'
    },
    textH: {
        fontFamily: 'Roboto', fontSize: '17px', fontWeight: 600, color: '#68A724' 
    },
    textHM2: {
        fontFamily: 'Roboto', fontSize: '10px', fontWeight: 600, color: '#68A724'
    },
    text1M: {
        fontFamily: 'Roboto', fontSize: '11px', fontWeight: 600, color: '#7A7A7D'
    },
    text1M2: {
        fontFamily: 'Maven Pro', fontSize: '10px', fontWeight: 600, color: '#7A7A7D'
    },
    text1A: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 400, color: '#000000'
    },
    text2: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 400, color: '#FF0B0B'
    },
    barchart: {
        height: '190px'
    },
    barTxt: {
        fontFamily: 'Maven Pro', fontSize: '15px', fontWeight: 600, color: '#000000', marginLeft: '10px'
    },
    payTxt: {
        fontFamily:'Maven Pro',fontSize: '14px',fontWeight: 600
    },
    BoxpayTxt: {
        fontFamily:'Maven Pro',fontSize: '14px',fontWeight: 600, marginLeft:'75px', marginTop:'13px'
    }




}));
const PrettoSlider = withStyles({
    root: {
        color: '#68A724B2',
        height: 8,
    },
    thumb: {
        height: 24,
        width: 24,
        backgroundColor: '#fff',
        border: '2px solid currentColor',
        marginTop: -8,
        marginLeft: -12,
        '&:focus,&:hover,&$active': {
            boxShadow: 'inherit',
        },
    },
    active: {},
    valueLabel: {
        left: 'calc(-50% + 4px)',
    },
    track: {
        height: 8,
        borderRadius: 4,
        color: '#68A724B2'
    },
    rail: {
        height: 8,
        borderRadius: 4,
        color: '#FFFFFF'
    },
})(Slider);

export default function RevxAdmin() {


    const [trackerSearch, setTrackerSearch] = React.useState("");
    const [zoomVar, setZoomVar] = React.useState(0);
    const theme = useTheme();
    const classes = useStyles();
    const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

    return (
        <>

            <div className={classes.root}>
                <Grid container spacing={2}>
                    <Grid item xs={12} lg={12} > 
                    <Paper>
                        <Table className={classes.rootTable}>
                            <TableHead className={classes.title}>
                                <TableRow>
                                    <TableCell padding="normal" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Vehicle type</TableCell>
                                    <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Location</TableCell>
                                    <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Vehice Model</TableCell>
                                    <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Vehicle Number</TableCell>
                                    <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Health Status</TableCell>
                                    <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Payment Status</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {data.map(n => ([
                                    <TableRow key={n.id}>
                                        <TableCell padding="normal" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.vtype}</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.location}</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.model}</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.vnum}</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.textH : classes.textHM2}>
                                            <Box className={isMdUp === true ? classes.box : classes.boxM} >{n.health}</Box>
                                            </TableCell>
                                            <TableCell align="center" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.payment}</TableCell>
                                    </TableRow>
                                ]))}
                            </TableBody>
                        </Table></Paper>
                    </Grid>
                   



                    <Grid item xs={12} lg={6}>
                        <Paper className={classes.map} variant="outlined" >
                            <SimpleMap
                                zoom={zoomVar}
                            />

                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={6} >
                        <Paper className={classes.paperH1}>
                            <Grid container spacing={2}>
                                <Grid item xs={7} className={classes.barchart}>
                                    <Typography className={classes.barTxt}>Vehicle Efficiency</Typography><br /><br /><BarChart /></Grid>
                                <Grid item xs={5}><br /><br /><br /><br /><br /><br />
                                    <Box className={classes.barTxt}><Icon icon="akar-icons:square-fill" color="#68A724" />Healthy</Box>
                                    <Box className={classes.barTxt}><Icon icon="akar-icons:square-fill" color="#FFC130" />Unhealthy</Box>
                                    <Box className={classes.barTxt}><Icon icon="akar-icons:square-fill" color="#CDBDBC" />Deactivated</Box>
                                </Grid></Grid>
                        </Paper>
                    </Grid>

                    <Grid item xs={12} lg={6}>
                        <Paper className={classes.paperH4}>
                        <Grid container spacing={2}>
                                {isMdUp ? null : <Box className={classes.BoxpayTxt} align="center">
                                &nbsp;&nbsp;&nbsp;<Icon icon="akar-icons:square-fill" color="#009688" />&nbsp;Payment Collection till now<br />
                                        <Icon icon="akar-icons:square-fill" color="#9A9F9C" />&nbsp;Payment  Pending till now</Box> }
                                <Grid item xs={7}>
                                    
                                {isMdUp ? <PaymentPie /> : <PaymentPieMobile />}</Grid>
                                {isMdUp ? <Grid item xs={5} className={classes.payTxt}><br /><br /><br /><br />
                                <Icon icon="akar-icons:square-fill" color="#009688" />&nbsp;Payment Collection till now<br />
                                <Icon icon="akar-icons:square-fill" color="#9A9F9C" />&nbsp;Payment  Pending till now
                                </Grid> : null}</Grid>
                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={6}>
                        <Paper className={classes.paperH5}>
                            <Chart />
                        </Paper>
                    </Grid>




                </Grid>
            </div>
            <br />
            <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt.Ltd. </Typography>
        </>
    )
};
