import React, { PureComponent } from 'react';
import { BarChart, Bar,LabelList, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  {
    name: 'Healthy',
    uv: 90,
    color:'#68A724'
  },
  {
    name: 'Unhealthy',
    uv: 40,
    color:'#FFC130'
  },
  {
    name: 'Deactivated',
    uv: 47,
    color:'#CDBDBC'
  },
];

export default class Example extends PureComponent {
  static demoUrl = 'https://codesandbox.io/s/tiny-bar-chart-35meb';

  render() {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <BarChart width={150} height={40} data={data}>
          <Bar dataKey="uv" fill="color" text="label"><LabelList dataKey={"uv"}  color="#FFFFFF"/></Bar>
        </BarChart>
      </ResponsiveContainer>
    );
  }
}
