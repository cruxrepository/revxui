import React from "react";
import GoogleMapReact from "google-map-react";
import { Link } from "react-router-dom";
 
const markerStyle = {
  position: "absolute",
  top: "100%",
   left: "50%",
  transform: "translate(-50%, -100%)"
};

class SimpleMap extends React.Component {
  static defaultProps = {
    center: {
      lat:11.004556,
      lng:76.961632
      
    },
    zoom:10
  };

  
  render() {
    const locations = [
        {
          "id": 123,
          "title": "Think Company",
          "website": "www.google.com",
          "image":
            "http://thinkcompany.fi/wp-content/uploads/2014/05/hkithinkco04-1024x702.jpg",
          "address": [
            {
              "id": 1234,
              "country": "Periyanaickenpalayam",
              "city": "Coimbatore",
              "street": "Yliopistonkatu 4",
              "postcode": "00101",
              "lat": "11.158193",
              "lng": "76.9527614"
            },
            {
              "id": 1235,
              "country": "Finland",
              "city": "Helsinki",
              "street": "Ladugordsbogen 3",
              "postcode": "00790",
              "lat": "11.020986806249601", 
              "lng": "76.93761448540306"
            },
            {
              "id": 1236,
              "country": "Finland",
              "city": "Helsinki",
              "street": "Haartmansgatan 4",
              "postcode": "00290",
              "lat": "14.158193",
              "lng": "76.9527614"
            }
          ]
        },
        {
          "id": 153,
          "title": "MS Flux",
          "website": "www.google.com",
          "image": " ",
          "address": [
            {
              "id": 1237,
              "country": "Finland",
              "city": "Helsinki",
              "street": "Hogbergsgatan 35",
              "postcode": "00101",
              "lat": "60.165238",
              "lng": "24.946249"
            }
          ]
        }
      ]
    return (
      // Important! Always set the container height explicitly
      <div style={{ height: "100%", width: "100%" }}>
        <GoogleMapReact
          bootstrapURLKeys={{
            key: "AIzaSyA16d9FJFh__vK04jU1P64vnEpPc3jenec"
          }}
          defaultCenter={this.props.center}
          defaultZoom={this.props.zoom}
        >
          {locations.map(item => {
            if (item.address.length !== 0) {
              return item.address.map(i => {
                return (
                  <Link to={"/" + item.name} key={i.id} lat={i.lat} lng={i.lng}>
                    {/* <img style={markerStyle} 
                    src={vech2}
                      alt="pin" /> */}
                  </Link>
                );
              });
            }
          })}
        </GoogleMapReact>
      </div>
    );
  }
}

export default SimpleMap;
