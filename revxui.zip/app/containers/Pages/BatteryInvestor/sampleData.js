const data1 = [
  {
    // name: 'Healthy',
    hl: 80,
    uhl: 40,
    de: 50,
  },
];


export default data1;
