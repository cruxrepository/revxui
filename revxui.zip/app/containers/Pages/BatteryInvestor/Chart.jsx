import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  CartesianAxis,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
 import styles from './fluidChart-jss';
 const data1 = [
  {
    name: 'TD2151',
    pending: 100,
  },
  {
    name: 'TD2151',
    pending: 650,
  },
  {
    name: 'TD2151',
    pending: 280,
  },
  {
    name: 'TD2151',
    pending: 80,
  },
  {
    name: 'TD2151',
    pending: 150,
  },
  {
    name: 'TD2151',
    pending: 500,
  },
  {
    name: 'TD2151',
    pending: 250,
  },
];
function LineSimple(props) {
  const { classes } = props;
  return (
    <div className={classes.chartFluid}>Next Month Payment Pending
      <ResponsiveContainer width="100%" height="80%">
        <LineChart
          width={800}
          height={450}
          data={data1}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5
          }}
        >
          <XAxis dataKey="name" tickLine={false} stroke="#9A9F9C"/>
          <YAxis  tickLine={false} stroke="#9A9F9C" />
          <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#9A9F9C"/>
          <CartesianAxis vertical={false} />
          {/* <Tooltip />  */}
          <Tooltip
            wrapperStyle={{ backgroundColor: "red" }}
            labelStyle={{ color: "green"}}
            itemStyle={{ color: "black" }}
            formatter={function(name) {
              return `${name}`;
            }}
            labelFormatter={function(name) {
              return `label ID: ${name}`;
            }}
          />
          <Line dataKey="pending" strokeWidth={5} stroke="#68A724" activeDot={{ r: 8 }} />
         </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

LineSimple.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(LineSimple);
