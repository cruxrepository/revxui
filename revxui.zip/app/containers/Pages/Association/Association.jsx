import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import {
  Box, Divider, InputBase, ListItemAvatar, Avatar, List, ListItem, ListItemText, Typography,
  MenuItem, Button, Select, Paper, useMediaQuery, Grid, TextField, Tabs, Tab, IconButton,
} from "@material-ui/core";
import './style.css';
import { Icon } from '@iconify/react';
import { useDispatch, useSelector } from 'react-redux';
import { getEntityBulk, getClientBulk, getInvestorBulk, getHypoBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import endpoints from "../../../endpoints/endpoints";
import SimpleSnackbar from '../Users/SimpleSnackbar';
import SearchIcon from "@material-ui/icons/Search";
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import { CloudDownload } from "@material-ui/icons";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  tabHelp: {
    fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7', float: 'left'
  },
  textField: {
    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
  },
  tabsSection: {
    [theme.breakpoints.up('lg')]: {
      // borderRadius:0,position:'sticky',top:0 ,width:500
      borderRadius: 0, top: 0, width: 650

    },


  },
}));
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));
export default function Association() {
  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

  const theme = useTheme();
  const classes = useStyles();
  const inputRef = React.useRef();
  //   const columns = [
  const [value, setValue] = React.useState(0);
  const [openAddClient, setOpenAddClient] = React.useState(false);
  const [openAddEntity, setOpenAddEntity] = React.useState(false);
  const [openEditClient, setOpenEditClient] = React.useState(false);
  const [openEditEntity, setOpenEditEntity] = React.useState(false);
  const [openAddInvestor, setOpenAddInvestor] = React.useState(false);
  const [openEditInvestor, setOpenEditInvestor] = React.useState(false);
  const [openAddHypo, setOpenAddHypo] = React.useState(false);
  const [openEditHypo, setOpenEditHypo] = React.useState(false);
  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)
  const [addResponse, setAddResponce] = React.useState("")
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const logged_user = useSelector((store) => store.login.result);
  const UserName = useSelector((store) => store.login.result.username);
  let clientEditAccess = logged_user.client === "edit"
  const ppp = useSelector((store) => store.login.result.password);
  const EntityData = useSelector((store) => store.entityAll)
  const EntityDataRaw = useSelector((store) => store.entityAll.rawData)
  let EntityMeta = {};
  EntityMeta.data = [];
  let EntityMetaa = useSelector((store) => store.entityAll)
  if (EntityMetaa.data.length >= 1) {
    EntityMeta.data = EntityMetaa.data;
  }
  const MyEntityPage = useSelector((store) => store.entityAll.page_number)
  const MyEntityCount = Math.ceil(useSelector((store) => store.entityAll.total_records) / 10)
  const MyEntityCount1 = useSelector((store) => store.entityAll.total_records)
  let EntityFetching = useSelector((store) => store.entityAll.fetching)
  let EntityResponsecode = useSelector((store) => store.entityAll.responseStatus)
  let EntityMetaPresent = useSelector((store) => store.entityAll.dataPresent)
  const onDownloadEntity = () => {
    const headerRow = ["Operator Name", "Contact Name", "Primary Email Id", "Secondary Email Id",
      "Primary Mobile Number", "Secondary Mobile Number", "Region", "GST Number"];
    const bodyRows = EntityDataRaw.length && EntityDataRaw.map((col) => {
      return [
        col['operator_name'],
        col['contact_name'],
        col['primary_email_id'],
        col['secondary_email_id'],
        col['primary_mobile_number'],
        col['secondary_mobile_number'],
        col['region'],
        col['gst']
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }

  const ClientData = useSelector((store) => store.clientAll)
  const ClientDataRaw = useSelector((store) => store.clientAll.rawData)
  let ClientMeta = {};
  ClientMeta.data = [];
  let ClientMetaa = useSelector((store) => store.clientAll)
  if (ClientMetaa.data.length >= 1) {
    ClientMeta.data = ClientMetaa.data;
  }
  const MyClientPage = useSelector((store) => store.clientAll.page_number)
  const MyClientCount = Math.ceil(useSelector((store) => store.clientAll.total_records) / 10)
  let ClientFetching = useSelector((store) => store.clientAll.fetching)
  let ClientResponsecode = useSelector((store) => store.clientAll.responseStatus)
  let ClientMetaPresent = useSelector((store) => store.clientAll.dataPresent)
  const onDownloadClient = () => {
    const headerRow = ["Client Name", "Business Name", "Mobile Number", "Number of Hubs",
      "GST Number", "Location"];
    const bodyRows = ClientDataRaw.length && ClientDataRaw.map((col) => {
      return [
        col['name'],
        col['buisness_name'],
        col['primary_mobile_number'],
        col['number_of_hubs'],
        col['gst_number'],
        col['location']
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }
  const InvestorData = useSelector((store) => store.investorAll)
  const InvestorDataRaw = useSelector((store) => store.investorAll.rawData)
  let InvestorMeta = {};
  InvestorMeta.data = [];
  let InvestorMetaa = useSelector((store) => store.investorAll)
  if (InvestorMetaa.data.length >= 1) {
    InvestorMeta.data = InvestorMetaa.data;
  }
  const MyInvestorPage = useSelector((store) => store.investorAll.page_number)
  const MyInvestorCount = Math.ceil(useSelector((store) => store.investorAll.total_records) / 10)
  let InvestorFetching = useSelector((store) => store.investorAll.fetching)
  let InvestorResponsecode = useSelector((store) => store.investorAll.responseStatus)
  let InvestorMetaPresent = useSelector((store) => store.investorAll.dataPresent)
  const onDownloadInvestor = () => {
    const headerRow = ["Investing Asset", "Invest Company Name", "Invest Operator Name", "Primay Email Id",
      "Primary Mobile Number", "Secondary Email Id", "Secondary Mobile Number", "GST Number"];
    const bodyRows = InvestorDataRaw.length && InvestorDataRaw.map((col) => {
      return [
        col['investing_asset'],
        col['invest_company_name'],
        col['invest_operator_name'],
        col['primary_email_id'],
        col['primary_mobile_number'],
        col['secondary_email_id'],
        col['secondary_mobile_number'],
        col['gst']
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }
  const HypoData = useSelector((store) => store.hypoAll)
  const HypoDataRaw = useSelector((store) => store.hypoAll.rawData)
  let HypoMeta = {};
  HypoMeta.data = [];
  let HypoMetaa = useSelector((store) => store.hypoAll)
  if (HypoMetaa.data.length >= 1) {
    HypoMeta.data = HypoMetaa.data;
  }
  const MyHypoPage = useSelector((store) => store.hypoAll.page_number)
  const MyHypoCount = Math.ceil(useSelector((store) => store.hypoAll.total_records) / 10)
  let HypoFetching = useSelector((store) => store.hypoAll.fetching)
  let HypoResponsecode = useSelector((store) => store.hypoAll.responseStatus)
  let HypoMetaPresent = useSelector((store) => store.hypoAll.dataPresent)
  const onDownloadHypo = () => {
    const headerRow = ["Hypothetication Company Name", "Hypothetication Operator Name", "Primay Email Id", "Primary Mobile Number",
      "Secondary Email Id", "Secondary Mobile Number", "GST Number"];
    const bodyRows = HypoDataRaw.length && HypoDataRaw.map((col) => {
      return [
        col['hypo_company_name'],
        col['hypo_operator_name'],
        col['primary_email_id'],
        col['primary_mobile_number'],
        col['secondary_email_id'],
        col['secondary_mobile_number'],
        col['gst']
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }
  const dispatch = useDispatch();

  const [selectedEntity, setSelectedEntity] = React.useState({
    operator_name: "",
    contact_name: "",
    primary_email_id: "",
    secondary_email_id: "",
    primary_mobile_number: "",
    secondary_mobile_number: "",
    gst: "",
    region: "",
    location_id: "2",
    fleet_id: "1"
  });
  const [selectedClient, setSelectedClient] = React.useState({
    name: "",
    buisness_name: "",
    primary_mobile_number: "",
    number_of_hubs: "",
    gst_number: "",
    location: "",
    location_id: "1"
  });
  const [selectedInvestor, setSelectedInvestor] = React.useState({
    investor_id: 1,
    investing_asset: "",
    invest_company_name: "",
    invest_operator_name: "",
    primary_email_id: "",
    secondary_email_id: "",
    primary_mobile_number: "",
    secondary_mobile_number: "",
    gst: ""
  });
  const [selectedHypo, setSelectedHypo] = React.useState({
    hypo_id: 1,
    hypo_company_name: "",
    hypo_operator_name: "",
    primary_email_id: "",
    secondary_email_id: "",
    primary_mobile_number: "",
    secondary_mobile_number: "",
    gst: ""
  });
  React.useEffect(() => {
    setSelectedEntity(EntityDataRaw && EntityDataRaw[0]);
    setSelectedClient(ClientDataRaw && ClientDataRaw[0]);
    setSelectedInvestor(InvestorDataRaw && InvestorDataRaw[0]);
    setSelectedHypo(HypoDataRaw && HypoDataRaw[0]);
  }, [EntityDataRaw, ClientDataRaw, InvestorDataRaw, HypoDataRaw]);

  const setClientSelected = (array) => {
    setSelectedClient && setSelectedClient(array);
  };
  const setEntitySelected = (array) => {
    setSelectedEntity && setSelectedEntity(array);
  };
  const setInvestorSelected = (array) => {
    setSelectedInvestor && setSelectedInvestor(array);
  };
  const setHypoSelected = (array) => {
    setSelectedHypo && setSelectedHypo(array);
  };
  React.useEffect(() => {
    dispatch(getEntityBulk());
    dispatch(getClientBulk());
    dispatch(getInvestorBulk());
    dispatch(getHypoBulk());
  }, [EntityMetaPresent, ClientMetaPresent, InvestorMetaPresent, HypoMetaPresent]);

  const validateKeyData = (key) => {
    return key ? key : "-";
  };

  const [open, setOpen] = React.useState(false);
  const [ddd, setDdd] = React.useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };
  const [open1, setOpen1] = React.useState(false);
  const [ddd1, setDdd1] = React.useState(false);

  const handleClick1 = () => {
    setOpen1(true);
  };

  const handleClose1 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen1(false);
  };

  // Add Entity
  const [entityAddForm, setEntityAddForm] = React.useState(
    {
      operator_name: "",
      contact_name: "",
      primary_email_id: "",
      secondary_email_id: "",
      primary_mobile_number: "",
      secondary_mobile_number: "",
      gst: "",
      region: "",
      location_id: "2",
      created_by: UserName,
      updated_by: "",
      association: {
        association_type: 'Entity'
      }
    }
  )
  const submitEntity = () => {
    if (entityAddForm.operator_name && entityAddForm.contact_name && /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(entityAddForm.primary_email_id) &&
      /^(\d{3})[- ]?(\d{3})[- ]?(\d{4})$/.test(entityAddForm.primary_mobile_number) && entityAddForm.region) {
      const postEntity = endpoints.baseUrl + `/entity/add`;

      axios
        .post(postEntity, entityAddForm)
        .then((response) => {
          handleClick(true);
          response.status === 201 ? setDdd("Entity onboarding successfully") : setDdd(response.message)
          dispatch(getEntityBulk());
          setOpenAddEntity(false);
          setEntityAddForm({})
        });
    } else {
      handleClick1(true);
      setDdd1("Please fill the required fields")

    }

  }
  const setEntityAddFormArray = (e, key, array) => {
    setEntityAddForm((state) => ({ ...state, [key]: e.target.value }));

  }

  // Edit Entity
  const [editArray, setEditArray] = React.useState(
    {
    }
  )
  const setEntityEditFormArray = (e, key) => {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));

  }

  const submitEntityEdit = () => {

    if ((editArray.updated_by = UserName) && editArray.operator_name && editArray.contact_name && editArray.primary_email_id && editArray.primary_mobile_number && editArray.region) {
      const putEntity = endpoints.baseUrl + `/entity/edit/` + editArray.fleet_id;
      let newEditArray = editArray;
      axios
        .put(putEntity, newEditArray)
        .then((response) => {
          handleClick(true);
          response.status === 200 ? setDdd("Entity details edited successfully") : setDdd(response.message)
          dispatch(getEntityBulk());
          setOpenEditEntity(false)
        });

    } else {
      handleClick1(true);
      setDdd1("Please fill the required fields")

    }
  }
  const setEntityEditArray = (fleet_id) => {
    let allEntity = EntityDataRaw;
    let findArray = allEntity.find(el => el.fleet_id === fleet_id)
    setEditArray(findArray);
  }

  // Delete Entity
  const deleteEntity = (fleet_id) => {
    const deleteEntityy = endpoints.baseUrl + `/entity/SoftDelete/` + fleet_id;
    axios
      .delete(deleteEntityy)
      .then((response) => {
        handleClick(true);
        response.status === 200 ? setDdd("Entity offboarding") : setDdd(response.message)
        dispatch(getEntityBulk());
      });
  }

  //Add Investor
  const [investorAddForm, setInvestorAddForm] = React.useState(
    {
      investing_asset: "",
      invest_company_name: "",
      invest_operator_name: "",
      primary_email_id: "",
      secondary_email_id: "",
      primary_mobile_number: "",
      secondary_mobile_number: "",
      gst: "",
      created_by: UserName,
      updated_by: "",
      association: {
        association_type: 'Investor'
      }
    }
  )
  const submitInvestor = () => {
    if (investorAddForm.invest_company_name && investorAddForm.invest_operator_name &&
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(investorAddForm.primary_email_id) &&
      /^[0-9]{10}$/.test(investorAddForm.primary_mobile_number)) {
      const postInvestor = endpoints.baseUrl + `/investor/add`;

      axios
        .post(postInvestor, investorAddForm)
        .then((response) => {
          handleClick(true);
          response.status === 201 ? setDdd("Investor onboarding successfully") : setDdd(response.message)
          dispatch(getInvestorBulk());
          setOpenAddInvestor(false);
          setInvestorAddForm({})
        });
    } else {
      handleClick1(true);
      setDdd1("Please fill the required fields")

    }

  }
  const setInvestorAddFormArray = (e, key, array) => {
    if (array) {
      setInvestorAddForm((state) => ({
        ...state, [array]: {
          ...state[array],
          [key]: e.target.value
        }
      }));
    } else {
      setInvestorAddForm((state) => ({ ...state, [key]: e.target.value }));
    }
  }

  // Edit Investor
  const [editArrayInvestor, setEditArrayInvestor] = React.useState({})
  // console.log("updated_by",editArrayInvestor.updated_by)
  const setInvestorEditFormArray = (e, key, array) => {
    if (array) {
      setEditArrayInvestor((state) => ({
        ...state, [array]: {
          ...state[array],
          [key]: e.target.value
        }
      }));
    } else {
      setEditArrayInvestor((state) => ({ ...state, [key]: e.target.value }));
    }
  }

  const submitInvestorEdit = () => {

    if ((editArrayInvestor.updated_by = UserName) && editArrayInvestor.invest_company_name && editArrayInvestor.invest_operator_name &&
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(editArrayInvestor.primary_email_id) &&
      /^[0-9]{10}$/.test(editArrayInvestor.primary_mobile_number)) {
      const putInvestor = endpoints.baseUrl + `/investor/edit/` + editArrayInvestor.investor_id;
      let newEditArray = editArrayInvestor;
      axios
        .put(putInvestor, newEditArray)
        .then((response) => {
          handleClick(true);
          response.status === 200 ? setDdd("Investor details edited successfully") : setDdd(response.message)
          dispatch(getInvestorBulk());
          setOpenEditInvestor(false)
        });

    } else {
      handleClick1(true);
      setDdd1("Please fill the required fields")

    }
  }
  const setInvestorEditArray = (investor_id) => {
    let allInvestor = InvestorDataRaw;
    let findArray = allInvestor.find(el => el.investor_id === investor_id)
    setEditArrayInvestor(findArray);
  }
  // Delete Investor
  const deleteInvestor = (investor_id) => {
    const deleteInves = endpoints.baseUrl + `/investor/SoftDelete/` + investor_id;
    axios
      .delete(deleteInves)
      .then((response) => {
        handleClick(true);
        response.status === 200 ? setDdd("Investor offboarding") : setDdd(response.message)
        dispatch(getInvestorBulk());
      });
  }

  //Add Hypo
  const [hypoAddForm, setHypoAddForm] = React.useState(
    {
      hypo_company_name: "",
      hypo_operator_name: "",
      primary_email_id: "",
      secondary_email_id: "",
      primary_mobile_number: "",
      secondary_mobile_number: "",
      gst: "",
      created_by: UserName,
      updated_by: "",
      association: {
        association_type: 'Hypothetication'
      }
    }
  )
  const submitHypo = () => {
    if (hypoAddForm.hypo_company_name && hypoAddForm.hypo_operator_name &&
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(hypoAddForm.primary_email_id) &&
      /^[0-9]{10}$/.test(hypoAddForm.primary_mobile_number) && hypoAddForm.gst) {
      const postHypo = endpoints.baseUrl + `/hypo/add`;

      axios
        .post(postHypo, hypoAddForm)
        .then((response) => {
          handleClick(true);
          response.status === 201 ? setDdd("Hypothetication onboarding successfully") : setDdd(response.message)
          dispatch(getHypoBulk());
          setOpenAddHypo(false);
          setHypoAddForm({})
        });
    } else {
      handleClick1(true);
      setDdd1("Please fill the required fields")

    }

  }
  const setHypoAddFormArray = (e, key, array) => {
    if (array) {
      setHypoAddForm((state) => ({
        ...state, [array]: {
          ...state[array],
          [key]: e.target.value
        }
      }));
    } else {
      setHypoAddForm((state) => ({ ...state, [key]: e.target.value }));
    }
  }
  // Edit Hypo
  const [editArrayHypo, setEditArrayHypo] = React.useState({
  })
  const setHypoEditFormArray = (e, key, array) => {
    if (array) {
      setEditArrayHypo((state) => ({
        ...state, [array]: {
          ...state[array],
          [key]: e.target.value
        }
      }));
    } else {
      setEditArrayHypo((state) => ({ ...state, [key]: e.target.value }));
    }
  }
  const submitHypoEdit = () => {

    if ((editArrayHypo.updated_by = UserName) && editArrayHypo.hypo_company_name && editArrayHypo.hypo_operator_name &&
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(editArrayHypo.primary_email_id) &&
      /^[0-9]{10}$/.test(editArrayHypo.primary_mobile_number) && editArrayHypo.gst) {
      const putHypo = endpoints.baseUrl + `/hypo/edit/` + editArrayHypo.hypo_id;
      let newEditArray = editArrayHypo;
      axios
        .put(putHypo, newEditArray)
        .then((response) => {
          handleClick(true);
          response.status === 200 ? setDdd("Hypothetication details edited successfully") : setDdd(response.message)
          dispatch(getHypoBulk());
          setOpenEditHypo(false)
        });

    } else {
      handleClick1(true);
      setDdd1("Please fill the required fields")

    }
  }
  const setHypoEditArray = (hypo_id) => {
    let allHypo = HypoDataRaw;
    let findArray = allHypo.find(el => el.hypo_id === hypo_id)
    setEditArrayHypo(findArray);
  }

  // Delete Hypo
  const deleteHypo = (hypo_id) => {
    const deleteHyp = endpoints.baseUrl + `/hypo/SoftDelete/` + hypo_id;
    axios
      .delete(deleteHyp)
      .then((response) => {
        handleClick(true);
        response.status === 200 ? setDdd("Hypothetication offboarding") : setDdd(response.message)
        dispatch(getHypoBulk());
      });
  }
  // Add Clent
  const [clientAddForm, setClientAddForm] = React.useState(
    {
      name: "",
      buisness_name: "",
      primary_mobile_number: "",
      number_of_hubs: "",
      gst_number: "",
      location: "",
      location_id: "1",
      created_by: UserName,
      updated_by: "",
      association: {
        association_type: 'Client'
      }
    }
  )
  const submitClient = () => {
    if (clientAddForm.name && clientAddForm.buisness_name && clientAddForm.primary_mobile_number && clientAddForm.gst_number) {
      const postClient = endpoints.baseUrl + `/client/add`;

      axios
        .post(postClient, clientAddForm)
        .then((response) => {
          handleClick(true);
          response.status === 201 ? setDdd("Client onboarding successfully") : setDdd(response.message)
          dispatch(getClientBulk());
        });
      setOpenAddClient(false);
      setClientAddForm({})
    } else {
      handleClick1(true);
      setDdd1("Please fill the required fields")

    }

  }
  const setClientAddFormArray = (e, key, array) => {
    setClientAddForm((state) => ({ ...state, [key]: e.target.value }));

  }

  const handleSubmitAddClient = () => {
    submitClient(true)
  }

  //Edit Client
  const [editCArray, setEditCArray] = React.useState(
    {
    }
  )
  const setClientEditFormArray = (e, key) => {
    setEditCArray((state) => ({ ...state, [key]: e.target.value }));

  }

  const submitClientEdit = () => {

    if ((editCArray.updated_by = UserName) && editCArray.name && editCArray.buisness_name && editCArray.primary_mobile_number && editCArray.number_of_hubs
      && editCArray.gst_number && editCArray.location) {
      const putClient = endpoints.baseUrl + `/client/edit/` + editCArray.client_id;
      let newCEditArray = editCArray;
      axios
        .put(putClient, newCEditArray)
        .then((response) => {
          handleClick(true);
          response.status === 200 ? setDdd("Client details edited successfully") : setDdd(response.message)
          setOpenEditClient(false)
          dispatch(getClientBulk());
          setEditCArray({

          })
        });
      setOpenEditClient(false)

    } else {
      handleClick1(true);
      setDdd1("Please fill the required fields")

    }
  }
  const setClientEditArray = (client_id) => {
    let allClient = ClientDataRaw;
    let findArray = allClient.find(el => el.client_id === client_id)
    setEditCArray(findArray);
  }

  // Delete Client
  const deleteClient = (client_id) => {
    const deleteClientt = endpoints.baseUrl + `/client/SoftDelete/` + client_id;
    axios
      .delete(deleteClientt)
      .then((response) => {
        handleClick(true);
        response.status === 200 ? setDdd("Client offboarding") : setDdd(response.message)
        dispatch(getClientBulk());
      });
  }


  const [searchTerm, setSearchTerm] = React.useState("");
  const filteredList = EntityDataRaw.length && EntityDataRaw.filter((item) =>
    item.operator_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const [searchTerm1, setSearchTerm1] = React.useState("");
  const filteredList1 = ClientDataRaw.length && ClientDataRaw.filter((item) =>
    item.name.toLowerCase().includes(searchTerm1.toLowerCase())
  );

  const [searchTerm2, setSearchTerm2] = React.useState("");
  const filteredList2 = InvestorDataRaw.length && InvestorDataRaw.filter((item) =>
    item.invest_operator_name.toLowerCase().includes(searchTerm2.toLowerCase())
  );

  const [searchTerm3, setSearchTerm3] = React.useState("");
  const filteredList3 = HypoDataRaw.length && HypoDataRaw.filter((item) =>
    item.hypo_operator_name.toLowerCase().includes(searchTerm3.toLowerCase())
  );
  return (
    <div>
      {/* <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} /> */}
      <Snackbar open={open} autoHideDuration={3000} onClose={handleClose} notificationTimeOut={notificationTimeOut}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        style={{ marginTop: '300px', marginLeft: '450px' }}
      >
        <Alert onClose={handleClose} severity="success">
          {ddd}
        </Alert>
      </Snackbar>
      <Snackbar open={open1} autoHideDuration={3000} onClose={handleClose1} notificationTimeOut={notificationTimeOut}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        style={{ marginTop: '300px', marginLeft: '450px' }}
      >
        <Alert onClose={handleClose1} severity="warning">
          {ddd1}
        </Alert>
      </Snackbar>
      <Typography
        style={{ textTransform: 'Capitalize', color: '#68A724', fontFamily: 'Maven Pro', fontWeight: 600, marginTop: '-30px' }}
        component="h4" variant="h4">Association - {value === 0 ? 'Entity' : value === 1 ? 'Investor' :
          value === 2 ? 'Hypothetication' : 'Client'}</Typography>
      <Paper square className={classes.root} />
      <Tabs
        className={classes.tabsSection}
        value={value}
        onChange={handleChange}
        variant="fullWidth"
        indicatorColor="primary"
        aria-label="icon tabs example"
      >
        <Tab label={"ENTITY"}
          // onClick={() => {
          //   setOpenAddClient(false)
          //   setOpenEditClient(false)
          //   setOpenAddEntity(false)
          //   setOpenEditEntity(false)
          //   setOpenAddInvestor(false)
          //   setOpenEditInvestor(false)
          //   setOpenAddHypo(false)
          //   setOpenEditHypo(false)
          // }}
          icon={<Icon icon="carbon:industry" height="25" width="25" />} aria-label="favorite" />
        <Tab label="INVESTOR"
          // onClick={() => {
          //   setOpenAddClient(false)
          //   setOpenEditClient(false)
          //   setOpenAddEntity(false)
          //   setOpenEditEntity(false)
          //   setOpenAddInvestor(false)
          //   setOpenEditInvestor(false)
          //   setOpenAddHypo(false)
          //   setOpenEditHypo(false)
          // }}
          icon={<Icon icon="mdi:person-tie" height="25" width="25" />} aria-label="favorite" />
        <Tab label="HYPOTHETICATION"
          // onClick={() => {
          //   setOpenAddClient(false)
          //   setOpenEditClient(false)
          //   setOpenAddEntity(false)
          //   setOpenEditEntity(false)
          //   setOpenAddInvestor(false)
          //   setOpenEditInvestor(false)
          //   setOpenAddHypo(false)
          //   setOpenEditHypo(false)
          // }}
          icon={<Icon icon="mdi:account-credit-card" height="25" width="25" />} aria-label="phone" />
        <Tab label="CLIENT"
          // onClick={() => {
          //   setOpenAddClient(false)
          //   setOpenEditClient(false)
          //   setOpenAddEntity(false)
          //   setOpenEditEntity(false)
          //   setOpenAddInvestor(false)
          //   setOpenEditInvestor(false)
          //   setOpenAddHypo(false)
          //   setOpenEditHypo(false)
          // }}
          icon={<Icon icon="ic:baseline-perm-identity" height="25" width="25" />} aria-label="phone" />

      </Tabs>

      <br />
      {value === 2 ?
        <Grid container spacing={0}>
          <Grid item lg={3} xs={12}>
            <Item style={{ backgroundColor: '#f1f1f1', height: '650px', overflowY: 'scroll' }}>
              <div
                style={{ display: "flex", alignItems: 'center', justifyContent: 'space-around', marginTop: '10px' }}
              >
                <Paper
                  style={{ p: '2px 4px', display: 'flex', alignItems: 'center', height: '40px', width: '210px' }}
                >
                  <IconButton style={{ p: '10px' }} aria-label="menu">
                    <SearchIcon style={{ marginBottom: '4px' }} />
                  </IconButton>
                  <InputBase
                    style={{ ml: 1, flex: 1, width: '230px' }}
                    placeholder="Search"
                    value={searchTerm3} onChange={(e) => setSearchTerm3(e.target.value)}
                  />
                  {searchTerm3 != "" ?
                    <IconButton type="button" style={{ p: '10px' }} aria-label="search"
                      onClick={() => {
                        setSearchTerm3("")
                      }}
                    >
                      <Icon icon="material-symbols:close" width="22" height="22" />
                    </IconButton>
                    : null}
                </Paper>
                <>
                  {clientEditAccess === true ?
                    (openAddHypo === false ? (
                      <Avatar onClick={() => setOpenAddHypo(true)} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                        <Icon
                          icon="material-symbols:add"
                          color="#68a724"
                          width="26"
                          height="26"
                        />
                      </Avatar >
                    ) : (
                      <Avatar onClick={() => setOpenAddHypo(false)} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                        <Icon
                          icon="ion:close"
                          color="#68a724"
                          width="22"
                          height="22"
                        />
                      </Avatar >
                    ))
                    : null}
                </>
                <Avatar style={{ backgroundColor: '#fff', width: '33px', height: '33px' }} onClick={() => {
                  onDownloadHypo()
                }}>
                  <CloudDownload style={{ color: '#68a724' }} />
                </Avatar>
              </div>
              <br />
              <Typography style={{ display: 'flex', justifyContent: 'center' }}>{filteredList3 && filteredList3.length} Hypothetication</Typography>
              <List>
                {filteredList3 && filteredList3.map((hypo) => {
                  return (
                    <IconButton style={{
                      width: '100%',
                      borderRadius: '10px',
                      cursor: 'pointer',
                      height: '60px', backgroundColor:
                        selectedHypo && selectedHypo.hypo_id ===
                          hypo.hypo_id
                          ? "#68A72480"
                          : null
                    }}
                      onClick={() => {
                        setOpenAddHypo(false)
                        setHypoSelected(hypo);
                        setOpenEditHypo(false);
                      }}>
                      <ListItem>
                        <Avatar style={{ backgroundColor: selectedHypo && selectedHypo.hypo_id === hypo.hypo_id ? '#ffcb0d' : null }}>
                          <Icon icon="mdi:account-credit-card" height="20" width="20"
                            color={selectedHypo && selectedHypo.hypo_id === hypo.hypo_id ? "#68a724" : "#fff"} />
                        </Avatar>
                        <ListItemText
                          primary={
                            <Typography
                              style={{
                                display: "inline", fontSize: "14px", fontFamily: "Maven Pro !important",
                                fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                              }}
                              component="span"
                            >
                              {validateKeyData(hypo.hypo_operator_name)}
                            </Typography>
                          }
                          secondary={
                            <React.Fragment>
                              <Typography
                                style={{
                                  display: "inline", fontSize: "12px", fontFamily: " Maven Pro", fontWeight: 500,
                                  color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                }}
                                component="span"
                              >
                                {validateKeyData(hypo.hypo_company_name)}
                              </Typography>
                            </React.Fragment>
                          }
                        />
                      </ListItem>
                    </IconButton>
                  );
                })}
              </List>
            </Item>
          </Grid>
          <Grid item lg={9} xs={12}>
            {openAddHypo === true ?
              <Item style={{ backgroundColor: '#f1f1f1', height: '650px' }}><br />
                <br />
                <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                  <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                    <Grid item xs={12}><Typography style={{ fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', float: 'left' }}
                    >Onboard Hypothetication</Typography></Grid><br /><br /><br />
                    <Grid item xs={12} lg={6}>
                      <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Hypothetication Company Name</Typography>
                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                      <TextField

                        onChange={(e) => {
                          setHypoAddFormArray(e, 'hypo_company_name')
                        }}
                        size="small"
                        error={open1 && hypoAddForm.hypo_company_name === ""}
                        className={classes.textField}
                        placeholder="eg: Company Name"
                        value={hypoAddForm.hypo_company_name} />
                    </Grid>
                    <Grid item xs={12} lg={6}>
                      <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Hypothetication Operator Name</Typography>
                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                      <TextField
                        value={hypoAddForm.hypo_operator_name}
                        onChange={(e) => {
                          setHypoAddFormArray(e, 'hypo_operator_name')
                        }}
                        size="small"
                        error={open1 && hypoAddForm.hypo_operator_name === ""}
                        className={classes.textField}
                        placeholder="eg: Operator Name" />
                    </Grid>
                    <Grid item xs={12} lg={6}>
                      <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primay Email Id</Typography>
                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                      <TextField
                        value={hypoAddForm.primary_email_id}
                        onChange={(e) => {
                          setHypoAddFormArray(e, 'primary_email_id')
                        }}
                        size="small"
                        error={open1 && hypoAddForm.primary_email_id === ""}
                        helperText={open1 && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(hypoAddForm.primary_email_id) ? 'Enter Valid Email Id' : null}
                        placeholder="eg: primary_email_id"
                        className={classes.textField} />
                    </Grid>
                    <Grid item xs={12} lg={6}>
                      <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Mobile Number</Typography>
                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                      <TextField
                        onChange={(e) => {
                          setHypoAddFormArray(e, 'primary_mobile_number')
                        }}
                        size="small"
                        error={open1 && hypoAddForm.primary_mobile_number === ""}
                        value={hypoAddForm.primary_mobile_number}
                        helperText={addBatteryErrors &&
                          !/^[0-9]{10}$/.test(hypoAddForm.primary_mobile_number) ?
                          'Mobile number must be 10 digits' : null}
                        className={classes.textField}
                        type="number"
                        placeholder="eg: Mobile Number" />
                    </Grid>
                    <Grid item xs={12} lg={6}>
                      <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Email Id</Typography>
                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                      <TextField
                        onChange={(e) => {
                          setHypoAddFormArray(e, 'secondary_email_id')
                        }}
                        size="small"
                        error={hypoAddForm.secondary_email_id != "" && hypoAddForm.secondary_email_id === ""}
                        helperText={hypoAddForm.secondary_email_id != "" && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(hypoAddForm.secondary_email_id) ? 'Enter Valid Email Id' : null}
                        value={hypoAddForm.secondary_email_id}
                        placeholder="eg: secondary_email_id"
                        className={classes.textField} />
                    </Grid>
                    <Grid item xs={12} lg={6}>
                      <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Mobile Number</Typography>
                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                      <TextField
                        onChange={(e) => {
                          setHypoAddFormArray(e, 'secondary_mobile_number')
                        }}
                        size="small"
                        error={hypoAddForm.secondary_mobile_number != '' && hypoAddForm.secondary_mobile_number === ""}
                        value={hypoAddForm.secondary_mobile_number}
                        helperText={hypoAddForm.secondary_mobile_number != '' &&
                          !/^[0-9]{10}$/.test(hypoAddForm.secondary_mobile_number) ?
                          'Mobile number must be 10 digits' : null}
                        className={classes.textField}
                        type="number"
                        placeholder="eg: Mobile Number" />
                    </Grid>
                    <Grid item xs={12} lg={6}>
                      <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST</Typography>
                        &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                      <TextField
                        onChange={(e) => {
                          setHypoAddFormArray(e, 'gst')
                        }}
                        size="small"
                        value={hypoAddForm.gst}
                        error={open1 && hypoAddForm.gst === ""}
                        className={classes.textField}
                        placeholder="eg: gst" />
                    </Grid>
                    <Grid item xs={12} lg={6} /><Grid item xs={12} lg={6} /><Grid item xs={12} lg={6}>
                      <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
                        <Button
                          onClick={() => setOpenAddHypo(false)}
                          color="primary">
                          Cancel
                        </Button>
                        <Button
                          onClick={() => submitHypo()}
                          color="secondary" >
                          Submit
                        </Button></div>
                    </Grid>
                  </Grid>
                </div>
              </Item> :
              openEditHypo === true ?
                <Item style={{ backgroundColor: '#f1f1f1', height: '650px' }}>
                  <div style={{ display: 'flex' }}>
                    <ListItem>
                      <Avatar style={{ backgroundColor: '#ffcb0d' }}>
                        <Icon icon="mdi:account-credit-card" height="20" width="20" color="68a724" />
                      </Avatar>
                      <ListItemText
                        primary={
                          <Typography
                            style={{
                              display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                              fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                            }}
                            component="span"
                          >
                            {validateKeyData(selectedHypo && selectedHypo.hypo_operator_name)}
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              style={{
                                display: "inline", fontSize: "14px", fontFamily: " Maven Pro", fontWeight: 500,
                                color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                              }}
                              component="span"
                            >
                              {validateKeyData(selectedHypo && selectedHypo.hypo_company_name)}
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                    <div style={{ display: 'flex' }}>
                      {openEditHypo === true ? <IconButton
                        onClick={() => setOpenEditHypo(false)}>
                        <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                      </IconButton> :
                        <IconButton
                          onClick={() => {
                            setHypoEditArray(selectedHypo && selectedHypo.hypo_id)
                            setOpenEditHypo(true);
                          }}>
                          <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                        </IconButton>}
                      <IconButton
                        onClick={() => {
                          deleteHypo(selectedHypo && selectedHypo.hypo_id)
                        }}
                      ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /></IconButton></div>
                  </div>
                  <br />
                  <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                    <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                      <Grid item xs={12}><Typography style={{ fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', float: 'left' }}
                      >Edit Hypothetication</Typography></Grid><br /><br /><br />
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Hypothetication Company Name</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setHypoEditFormArray(e, 'hypo_company_name')
                          }}
                          size="small" value={editArrayHypo.hypo_company_name}
                          error={open1 && editArrayHypo.hypo_company_name === ""}
                          className={classes.textField}
                          placeholder="eg: Business Name" />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Hypothetication Operator Name</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setHypoEditFormArray(e, 'invest_operator_name')
                          }}
                          size="small" value={editArrayHypo.hypo_operator_name}
                          error={open1 && editArrayHypo.hypo_operator_name === ""}
                          className={classes.textField}
                          placeholder="eg: Mobile Number" />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primay Email Id</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                        <TextField
                          onChange={(e) => {
                            setHypoEditFormArray(e, 'primary_email_id')
                          }}
                          size="small" value={editArrayHypo.primary_email_id}
                          error={open1 && editArrayHypo.primary_email_id === ""}
                          className={classes.textField} />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Mobile Number</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setHypoEditFormArray(e, 'primary_mobile_number')
                          }}
                          size="small" value={editArrayHypo.primary_mobile_number}
                          error={open1 && editArrayHypo.primary_mobile_number === ""}
                          className={classes.textField}
                          type="number"
                          placeholder="eg: Mobile Number" />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Email Id</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                        <TextField
                          onChange={(e) => {
                            setHypoEditFormArray(e, 'secondary_email_id')
                          }}
                          size="small" value={editArrayHypo.secondary_email_id}
                          className={classes.textField} />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Mobile Number</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setHypoEditFormArray(e, 'secondary_mobile_number')
                          }}
                          size="small" value={editArrayHypo.secondary_mobile_number}
                          className={classes.textField}
                          type="number"
                          placeholder="eg: Mobile Number" />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                        <TextField className={classes.textField}
                          onChange={(e) => {
                            setHypoEditFormArray(e, 'gst')
                          }}
                          size="small" value={editArrayHypo.gst}
                          placeholder="eg: gst" />
                      </Grid>
                      <Grid item xs={12} lg={6} /><Grid item xs={12} lg={6} /><Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
                          <Button
                            onClick={() => setOpenEditHypo(false)}
                            color="primary">
                            Cancel
                          </Button>
                          <Button
                            onClick={() => submitHypoEdit()}
                            color="secondary" >
                            Submit
                          </Button></div>
                      </Grid>
                    </Grid>
                  </div>
                </Item>
                : <Item style={{ backgroundColor: '#f1f1f1', height: '650px' }}>
                  <div style={{ display: 'flex' }}>
                    <ListItem>
                      <Avatar style={{ backgroundColor: '#68a72490' }}>
                        <Icon icon="mdi:account-credit-card" height="22" width="22" color="#fff" />
                      </Avatar>
                      <ListItemText
                        primary={
                          <Typography
                            style={{
                              display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                              fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                            }}
                            component="span"
                          >
                            {validateKeyData(selectedHypo && selectedHypo.hypo_operator_name)}
                          </Typography>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              style={{
                                display: "inline", fontSize: "14px", fontFamily: " Maven Pro", fontWeight: 500,
                                color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                              }}
                              component="span"
                            >
                              {validateKeyData(selectedHypo && selectedHypo.hypo_company_name)}
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                    <div style={{ display: 'flex' }}>
                      {openEditHypo === true ? <IconButton
                        onClick={() => {
                          setOpenEditHypo(false);
                        }}>
                        <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                      </IconButton> :
                        <IconButton
                          onClick={() => {
                            setHypoEditArray(selectedHypo && selectedHypo.hypo_id)
                            setOpenEditHypo(true);
                          }}>
                          <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                        </IconButton>}
                      <IconButton
                        onClick={() => {
                          deleteHypo(selectedHypo && selectedHypo.hypo_id)
                        }}
                      ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /></IconButton></div>
                  </div>
                  <br />
                  <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                    <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                      <Grid item lg={6} xs={12}>
                        <ListItem>
                          <ListItemAvatar>
                            <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                              <Icon icon="material-symbols:mobile-friendly" width="22" height="22" color="68a724" />
                            </Avatar>
                          </ListItemAvatar>
                          <ListItemText primary={<Typography style={{
                            display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                            fontWeight: 700, color: "#6C6C6C"
                          }}>{validateKeyData(selectedHypo && selectedHypo.primary_mobile_number)}</Typography>}
                            secondary={<React.Fragment>
                              <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                component="span">Mobile Number</Typography></React.Fragment>}
                          />
                        </ListItem><Divider />
                      </Grid>
                      <Grid item lg={6} xs={12}>
                        <ListItem>
                          <ListItemAvatar>
                            <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                              <Icon icon="material-symbols:phone-android" width="22" height="22" color="68a724" />
                            </Avatar>
                          </ListItemAvatar>
                          <ListItemText primary={<Typography style={{
                            display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                            fontWeight: 700, color: "#6C6C6C"
                          }}>{validateKeyData(selectedHypo && selectedHypo.secondary_mobile_number)}</Typography>}
                            secondary={<React.Fragment>
                              <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                component="span">Secondary Mobile Number</Typography></React.Fragment>}
                          />
                        </ListItem><Divider />
                      </Grid>
                      <Grid item lg={6} xs={12}>
                        <ListItem>
                          <ListItemAvatar>
                            <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                              <Icon icon="tabler:mail-check" width="22" height="22" color="68a724" />
                            </Avatar>
                          </ListItemAvatar>
                          <ListItemText primary={<Typography style={{
                            display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                            fontWeight: 700, color: "#6C6C6C"
                          }}>{validateKeyData(selectedHypo && selectedHypo.primary_email_id)}</Typography>}
                            secondary={<React.Fragment>
                              <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                component="span">Email</Typography></React.Fragment>}
                          />
                        </ListItem><Divider />
                      </Grid>
                      <Grid item lg={6} xs={12}>
                        <ListItem>
                          <ListItemAvatar>
                            <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                              <Icon icon="tabler:mail" width="22" height="22" color="68a724" />
                            </Avatar>
                          </ListItemAvatar>
                          <ListItemText primary={<Typography style={{
                            display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                            fontWeight: 700, color: "#6C6C6C"
                          }}>{validateKeyData(selectedHypo && selectedHypo.secondary_email_id)}</Typography>}
                            secondary={<React.Fragment>
                              <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                component="span">Secondary Email</Typography></React.Fragment>}
                          />
                        </ListItem><Divider />
                      </Grid>
                      <Grid item lg={6} xs={12}>
                        <ListItem>
                          <ListItemAvatar>
                            <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                              <Icon icon="heroicons-solid:receipt-tax" width="22" height="22" color="68a724" />
                            </Avatar>
                          </ListItemAvatar>
                          <ListItemText primary={<Typography style={{
                            display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                            fontWeight: 700, color: "#6C6C6C"
                          }}>{validateKeyData(selectedHypo && selectedHypo.gst)}</Typography>}
                            secondary={<React.Fragment>
                              <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                component="span">GST Number</Typography></React.Fragment>}
                          />
                        </ListItem><Divider />
                      </Grid></Grid></div>
                </Item>}
          </Grid>
        </Grid> :
        InvestorMetaPresent && value === 1 ?
          <Grid container spacing={0}>
            <Grid item lg={3} xs={12}>
              <Item style={{ backgroundColor: '#f1f1f1', height: '650px', overflowY: 'scroll' }}>
                <div
                  style={{ display: "flex", alignItems: 'center', justifyContent: 'space-around', marginTop: '10px' }}
                >
                  <Paper
                    style={{ p: '2px 4px', display: 'flex', alignItems: 'center', height: '40px', width: '210px' }}
                  >
                    <IconButton style={{ p: '10px' }} aria-label="menu">
                      <SearchIcon style={{ marginBottom: '4px' }} />
                    </IconButton>
                    <InputBase
                      style={{ ml: 1, flex: 1, width: '230px' }}
                      placeholder="Search"
                      value={searchTerm2} onChange={(e) => setSearchTerm2(e.target.value)}
                    />
                    {searchTerm2 != "" ?
                      <IconButton type="button" style={{ p: '10px' }} aria-label="search"
                        onClick={() => {
                          setSearchTerm2("")
                        }}
                      >
                        <Icon icon="material-symbols:close" width="22" height="22" />
                      </IconButton>
                      : null}
                  </Paper>
                  <>
                    {clientEditAccess === true ?
                      (openAddInvestor === false ? (
                        <Avatar onClick={() => setOpenAddInvestor(true)} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                          <Icon
                            icon="material-symbols:add"
                            color="#68a724"
                            width="26"
                            height="26"
                          />
                        </Avatar >
                      ) : (
                        <Avatar onClick={() => setOpenAddInvestor(false)} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                          <Icon
                            icon="ion:close"
                            color="#68a724"
                            width="22"
                            height="22"
                          />
                        </Avatar >
                      ))
                      : null}
                  </>
                  <Avatar style={{ backgroundColor: '#fff', width: '33px', height: '33px' }} onClick={() => {
                    onDownloadInvestor()
                  }}>
                    <CloudDownload style={{ color: '#68a724' }} />
                  </Avatar>
                </div>
                <br />
                <Typography style={{ display: 'flex', justifyContent: 'center' }}>{filteredList2 && filteredList2.length} Investor</Typography>
                <List>
                  {filteredList2 && filteredList2.map((inves) => {
                    return (
                      <IconButton style={{
                        width: '100%',
                        borderRadius: '10px',
                        cursor: 'pointer',
                        height: '60px', backgroundColor:
                          selectedInvestor && selectedInvestor.investor_id ===
                            inves.investor_id
                            ? "#68A72480"
                            : null
                      }}
                        onClick={() => {
                          setOpenAddInvestor(false)
                          setInvestorSelected(inves);
                          setOpenEditInvestor(false);
                        }}>
                        <ListItem>
                          <Avatar style={{ backgroundColor: selectedInvestor && selectedInvestor.investor_id === inves.investor_id ? '#ffcb0d' : null }}>
                            <Icon icon="mdi:person-tie" height="20" width="20"
                              color={selectedInvestor && selectedInvestor.investor_id === inves.investor_id ? "#68a724" : "#fff"} />
                          </Avatar>
                          <ListItemText
                            primary={
                              <Typography
                                style={{
                                  display: "inline", fontSize: "14px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                                }}
                                component="span"
                              >
                                {validateKeyData(inves.invest_operator_name)}
                              </Typography>
                            }
                            secondary={
                              <React.Fragment>
                                <Typography
                                  style={{
                                    display: "inline", fontSize: "12px", fontFamily: " Maven Pro", fontWeight: 500,
                                    color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                  }}
                                  component="span"
                                >
                                  {validateKeyData(inves.invest_company_name)}
                                </Typography>
                              </React.Fragment>
                            }
                          />
                        </ListItem>
                      </IconButton>
                    );
                  })}
                </List>
              </Item>
            </Grid>
            <Grid item lg={9} xs={12}>
              {openAddInvestor === true ?
                <Item style={{ backgroundColor: '#f1f1f1', height: '650px' }}><br />
                  <br />
                  <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                    <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                      <Grid item xs={12}><Typography style={{ fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', float: 'left' }}
                      >Onboard Investor</Typography></Grid><br /><br /><br />
                      <Grid item xs={12} lg={4}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Investing Asset</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <Select className={classes.textField}
                          onChange={(e) => {
                            setInvestorAddFormArray(e, 'investing_asset')
                          }}
                          value={investorAddForm.investing_asset} >
                          <MenuItem value="">Select your Asset</MenuItem>
                          <MenuItem value="Vehicle">Vehicle</MenuItem>
                          <MenuItem value="Battery">Battery</MenuItem>
                          <MenuItem value="Both">Both</MenuItem>
                        </Select>
                      </Grid><Grid item xs={12} lg={8} />
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Invest Company Name</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setInvestorAddFormArray(e, 'invest_company_name')
                          }}
                          size="small"
                          error={open1 && investorAddForm.invest_company_name === ""}
                          value={investorAddForm.invest_company_name}
                          className={classes.textField}
                          placeholder="eg: Invest Company Name" />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Invest Operator Name</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setInvestorAddFormArray(e, 'invest_operator_name')
                          }}
                          size="small"
                          error={open1 && investorAddForm.invest_operator_name === ""}
                          value={investorAddForm.invest_operator_name}
                          className={classes.textField}
                          placeholder="eg: Operator Name" />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primay Email Id</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setInvestorAddFormArray(e, 'primary_email_id')
                          }}
                          size="small"
                          error={open1 && investorAddForm.primary_email_id === ""}
                          helperText={open1 && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(investorAddForm.primary_email_id) ? 'Enter Valid Email Id' : null}
                          value={investorAddForm.primary_email_id}
                          placeholder="eg: primary_email_id"
                          className={classes.textField} />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Mobile Number</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setInvestorAddFormArray(e, 'primary_mobile_number')
                          }}
                          size="small"
                          error={open1 && investorAddForm.primary_mobile_number === ""}
                          value={investorAddForm.primary_mobile_number}
                          helperText={open1 &&
                            !/^[0-9]{10}$/.test(investorAddForm.primary_mobile_number) ?
                            'Mobile number must be 10 digits' : null}
                          className={classes.textField}
                          type="number"
                          placeholder="eg: Mobile Number" />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Email Id</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                        <TextField
                          onChange={(e) => {
                            setInvestorAddFormArray(e, 'secondary_email_id')
                          }}
                          size="small"
                          error={investorAddForm.secondary_email_id != "" && investorAddForm.secondary_email_id === ""}
                          helperText={investorAddForm.secondary_email_id != "" && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(investorAddForm.secondary_email_id) ? 'Enter Valid Email Id' : null}
                          value={investorAddForm.secondary_email_id}
                          placeholder="eg: secondary_email_id"
                          className={classes.textField} />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Mobile Number</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setInvestorAddFormArray(e, 'secondary_mobile_number')
                          }}
                          size="small"
                          error={investorAddForm.secondary_mobile_number != '' && investorAddForm.secondary_mobile_number === ""}
                          value={investorAddForm.secondary_mobile_number}
                          helperText={investorAddForm.secondary_mobile_number != '' &&
                            !/^[0-9]{10}$/.test(investorAddForm.secondary_mobile_number) ?
                            'Mobile number must be 10 digits' : null}
                          className={classes.textField}
                          type="number"
                          placeholder="eg: Mobile Number" />
                      </Grid>
                      <Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST</Typography>
                          &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                        <TextField
                          onChange={(e) => {
                            setInvestorAddFormArray(e, 'gst')
                          }}
                          size="small"
                          value={investorAddForm.gst}
                          className={classes.textField}
                          placeholder="eg: gst" />
                      </Grid>
                      <Grid item xs={12} lg={6} /><Grid item xs={12} lg={6} /><Grid item xs={12} lg={6}>
                        <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
                          <Button
                            onClick={() => setOpenAddInvestor(false)}
                            color="primary">
                            Cancel
                          </Button>
                          <Button
                            onClick={() => submitInvestor()}
                            color="secondary" >
                            Submit
                          </Button></div>
                      </Grid>
                    </Grid>
                  </div>
                </Item> :
                openEditInvestor === true ?
                  <Item style={{ backgroundColor: '#f1f1f1', height: '650px' }}>
                    <div style={{ display: 'flex' }}>
                      <ListItem>
                        <Avatar style={{ backgroundColor: '#ffcb0d' }}>
                          <Icon icon="ic:baseline-perm-identity" height="20" width="20" color="68a724" />
                        </Avatar>
                        <ListItemText
                          primary={
                            <Typography
                              style={{
                                display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                              }}
                              component="span"
                            >
                              {validateKeyData(selectedInvestor && selectedInvestor.invest_operator_name)}
                            </Typography>
                          }
                          secondary={
                            <React.Fragment>
                              <Typography
                                style={{
                                  display: "inline", fontSize: "14px", fontFamily: " Maven Pro", fontWeight: 500,
                                  color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                }}
                                component="span"
                              >
                                {validateKeyData(selectedInvestor && selectedInvestor.invest_company_name)}
                              </Typography>
                            </React.Fragment>
                          }
                        />
                      </ListItem>
                      <div style={{ display: 'flex' }}>
                        {openEditInvestor === true ? <IconButton
                          onClick={() => setOpenEditInvestor(false)}>
                          <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                        </IconButton> :
                          <IconButton
                            onClick={() => {
                              setInvestorEditArray(selectedInvestor && selectedInvestor.investor_id)
                              setOpenEditInvestor(true);
                            }}>
                            <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                          </IconButton>}
                        <IconButton
                          onClick={() => {
                            deleteInvestor(selectedInvestor && selectedInvestor.investor_id)
                          }}
                        ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /></IconButton></div>
                    </div>
                    <br />
                    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                      <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                        <Grid item xs={12}><Typography style={{ fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', float: 'left' }}
                        >Edit Investor</Typography></Grid><br /><br /><br />
                        <Grid item xs={12} lg={4}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Investing Asset</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                          <Select className={classes.textField}
                            onChange={(e) => {
                              setInvestorEditFormArray(e, 'investing_asset')
                            }}
                            size="small" value={editArrayInvestor.investing_asset}
                            error={open1 && editArrayInvestor.investing_asset === ""}
                          >
                            <MenuItem value="">Select your Asset</MenuItem>
                            <MenuItem value="Vehicle">Vehicle</MenuItem>
                            <MenuItem value="Battery">Battery</MenuItem>
                            <MenuItem value="Both">Both</MenuItem>
                          </Select>
                        </Grid><Grid item xs={12} lg={8} />
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Invest Company Name</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                          <TextField
                            onChange={(e) => {
                              setInvestorEditFormArray(e, 'invest_company_name')
                            }}
                            size="small" value={editArrayInvestor.invest_company_name}
                            error={open1 && editArrayInvestor.invest_company_name === ""}
                            className={classes.textField}
                            placeholder="eg: Business Name" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Invest Operator Name</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                          <TextField
                            onChange={(e) => {
                              setInvestorEditFormArray(e, 'invest_operator_name')
                            }}
                            size="small" value={editArrayInvestor.invest_operator_name}
                            error={open1 && editArrayInvestor.invest_operator_name === ""}
                            className={classes.textField}
                            placeholder="eg: Mobile Number" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primay Email Id</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>

                          <TextField
                            onChange={(e) => {
                              setInvestorEditFormArray(e, 'primary_email_id')
                            }}
                            size="small" value={editArrayInvestor.primary_email_id}
                            error={open1 && editArrayInvestor.primary_email_id === ""}
                            className={classes.textField} />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Mobile Number</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                          <TextField
                            onChange={(e) => {
                              setInvestorEditFormArray(e, 'primary_mobile_number')
                            }}
                            size="small" value={editArrayInvestor.primary_mobile_number}
                            error={open1 && editArrayInvestor.primary_mobile_number === ""}
                            className={classes.textField}
                            type="number"
                            placeholder="eg: Mobile Number" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Email Id</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                          <TextField
                            onChange={(e) => {
                              setInvestorEditFormArray(e, 'secondary_email_id')
                            }}
                            size="small" value={editArrayInvestor.secondary_email_id}
                            className={classes.textField} />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Mobile Number</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                          <TextField
                            onChange={(e) => {
                              setInvestorEditFormArray(e, 'secondary_mobile_number')
                            }}
                            size="small" value={editArrayInvestor.secondary_mobile_number}
                            className={classes.textField}
                            type="number"
                            placeholder="eg: Mobile Number" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                          <TextField className={classes.textField}
                            onChange={(e) => {
                              setInvestorEditFormArray(e, 'gst')
                            }}
                            size="small" value={editArrayInvestor.gst}
                            placeholder="eg: gst" />
                        </Grid>
                        <Grid item xs={12} lg={6} /><Grid item xs={12} lg={6} /><Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
                            <Button
                              onClick={() => setOpenEditInvestor(false)}
                              color="primary">
                              Cancel
                            </Button>
                            <Button
                              onClick={() => submitInvestorEdit()}
                              color="secondary" >
                              Submit
                            </Button></div>
                        </Grid>
                      </Grid>
                    </div>
                  </Item>
                  : <Item style={{ backgroundColor: '#f1f1f1', height: '650px' }}>
                    <div style={{ display: 'flex' }}>
                      <ListItem>
                        <Avatar style={{ backgroundColor: '#68a72490' }}>
                          <Icon icon="mdi:person-tie" height="22" width="22" color="#fff" />
                        </Avatar>
                        <ListItemText
                          primary={
                            <Typography
                              style={{
                                display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                              }}
                              component="span"
                            >
                              {validateKeyData(selectedInvestor && selectedInvestor.invest_operator_name)}
                            </Typography>
                          }
                          secondary={
                            <React.Fragment>
                              <Typography
                                style={{
                                  display: "inline", fontSize: "14px", fontFamily: " Maven Pro", fontWeight: 500,
                                  color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                }}
                                component="span"
                              >
                                {validateKeyData(selectedInvestor && selectedInvestor.invest_company_name)}
                              </Typography>
                            </React.Fragment>
                          }
                        />
                      </ListItem>
                      <div style={{ display: 'flex' }}>
                        {openEditInvestor === true ? <IconButton
                          onClick={() => {
                            setOpenEditInvestor(false);
                          }}>
                          <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                        </IconButton> :
                          <IconButton
                            onClick={() => {
                              setInvestorEditArray(selectedInvestor && selectedInvestor.investor_id)
                              setOpenEditInvestor(true);
                            }}>
                            <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                          </IconButton>}
                        <IconButton
                          onClick={() => {
                            deleteInvestor(selectedInvestor && selectedInvestor.investor_id)
                          }}
                        ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /></IconButton></div>
                    </div>
                    <br />
                    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                      <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                        <Grid item lg={6} xs={12}>
                          <ListItem>
                            <ListItemAvatar>
                              <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                <Icon icon="tabler:asset" width="22" height="22" color="68a724" />
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText primary={<Typography style={{
                              display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                              fontWeight: 700, color: "#6C6C6C"
                            }}>{validateKeyData(selectedInvestor && selectedInvestor.investing_asset)}</Typography>}
                              secondary={<React.Fragment>
                                <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                  component="span">Investing Asset</Typography></React.Fragment>}
                            />
                          </ListItem><Divider />
                        </Grid>
                        <Grid item lg={6} xs={12}>
                          <ListItem>
                            <ListItemAvatar>
                              <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                <Icon icon="heroicons-solid:receipt-tax" width="22" height="22" color="68a724" />
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText primary={<Typography style={{
                              display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                              fontWeight: 700, color: "#6C6C6C"
                            }}>{validateKeyData(selectedInvestor && selectedInvestor.gst)}</Typography>}
                              secondary={<React.Fragment>
                                <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                  component="span">GST Number</Typography></React.Fragment>}
                            />
                          </ListItem><Divider />
                        </Grid>
                        <Grid item lg={6} xs={12}>
                          <ListItem>
                            <ListItemAvatar>
                              <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                <Icon icon="material-symbols:mobile-friendly" width="22" height="22" color="68a724" />
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText primary={<Typography style={{
                              display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                              fontWeight: 700, color: "#6C6C6C"
                            }}>{validateKeyData(selectedInvestor && selectedInvestor.primary_mobile_number)}</Typography>}
                              secondary={<React.Fragment>
                                <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                  component="span">Mobile Number</Typography></React.Fragment>}
                            />
                          </ListItem><Divider />
                        </Grid>
                        <Grid item lg={6} xs={12}>
                          <ListItem>
                            <ListItemAvatar>
                              <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                <Icon icon="material-symbols:phone-android" width="22" height="22" color="68a724" />
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText primary={<Typography style={{
                              display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                              fontWeight: 700, color: "#6C6C6C"
                            }}>{validateKeyData(selectedInvestor && selectedInvestor.secondary_mobile_number)}</Typography>}
                              secondary={<React.Fragment>
                                <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                  component="span">Secondary Mobile Number</Typography></React.Fragment>}
                            />
                          </ListItem><Divider />
                        </Grid>
                        <Grid item lg={6} xs={12}>
                          <ListItem>
                            <ListItemAvatar>
                              <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                <Icon icon="tabler:mail-check" width="22" height="22" color="68a724" />
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText primary={<Typography style={{
                              display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                              fontWeight: 700, color: "#6C6C6C"
                            }}>{validateKeyData(selectedInvestor && selectedInvestor.primary_email_id)}</Typography>}
                              secondary={<React.Fragment>
                                <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                  component="span">Email</Typography></React.Fragment>}
                            />
                          </ListItem><Divider />
                        </Grid>
                        <Grid item lg={6} xs={12}>
                          <ListItem>
                            <ListItemAvatar>
                              <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                <Icon icon="tabler:mail" width="22" height="22" color="68a724" />
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText primary={<Typography style={{
                              display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                              fontWeight: 700, color: "#6C6C6C"
                            }}>{validateKeyData(selectedInvestor && selectedInvestor.secondary_email_id)}</Typography>}
                              secondary={<React.Fragment>
                                <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                  component="span">Secondary Email</Typography></React.Fragment>}
                            />
                          </ListItem><Divider />
                        </Grid>
                      </Grid></div>
                  </Item>}
            </Grid>
          </Grid>
          : ClientMetaPresent && value === 3 ?
            <Grid container spacing={0}>
              <Grid item lg={3} xs={12}>
                <Item style={{ backgroundColor: '#f1f1f1', height: '480px', overflowY: 'scroll' }}>
                  <div
                    style={{ display: "flex", alignItems: 'center', justifyContent: 'space-around', marginTop: '10px' }}
                  >
                    <Paper
                      style={{ p: '2px 4px', display: 'flex', alignItems: 'center', height: '40px', width: '210px' }}
                    >
                      <IconButton style={{ p: '10px' }} aria-label="menu">
                        <SearchIcon style={{ marginBottom: '4px' }} />
                      </IconButton>
                      <InputBase
                        style={{ ml: 1, flex: 1, width: '230px' }}
                        placeholder="Search"
                        value={searchTerm1} onChange={(e) => setSearchTerm1(e.target.value)} />
                      {searchTerm1 != "" ? <IconButton type="button" style={{ p: '10px' }} aria-label="search"
                        onClick={() => {
                          setSearchTerm1("")
                        }} >
                        <Icon icon="material-symbols:close" width="22" height="22" />
                      </IconButton> : null}
                    </Paper>
                    <>
                      {clientEditAccess === true ?
                        (openAddClient === false ? (
                          <Avatar onClick={() => setOpenAddClient(true)} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                            <Icon
                              icon="material-symbols:add"
                              color="#68a724"
                              width="26"
                              height="26"
                            />
                          </Avatar >
                        ) : (
                          <Avatar onClick={() => setOpenAddClient(false)} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                            <Icon
                              icon="ion:close"
                              color="#68a724"
                              width="22"
                              height="22"
                            />
                          </Avatar >
                        ))
                        : null}
                    </>
                    <Avatar style={{ backgroundColor: '#fff', width: '33px', height: '33px' }} onClick={() => {
                      onDownloadClient()
                    }}>
                      <CloudDownload style={{ color: '#68a724' }} />
                    </Avatar>
                  </div>
                  <br />
                  <Typography style={{ display: 'flex', justifyContent: 'center' }}>{filteredList1 && filteredList1.length} Client</Typography>
                  <List>
                    {filteredList1 && filteredList1.map((cli) => {
                      return (
                        <IconButton style={{
                          width: '100%',
                          borderRadius: '10px',
                          cursor: 'pointer',
                          height: '60px', backgroundColor:
                            selectedClient && selectedClient.client_id ===
                              cli.client_id
                              ? "#68A72480"
                              : null
                        }}
                          onClick={() => {
                            setOpenAddClient(false)
                            setClientSelected(cli);
                            setOpenEditClient(false);
                          }}>
                          <ListItem>
                            <Avatar style={{ backgroundColor: selectedClient && selectedClient.client_id === cli.client_id ? '#ffcb0d' : null }}>
                              <Icon icon="ic:baseline-perm-identity" height="20" width="20"
                                color={selectedClient && selectedClient.client_id === cli.client_id ? "#68a724" : "#fff"} />
                            </Avatar>
                            <ListItemText
                              primary={
                                <Typography
                                  style={{
                                    display: "inline", fontSize: "14px", fontFamily: "Maven Pro !important",
                                    fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                                  }}
                                  component="span"
                                >
                                  {validateKeyData(cli.name)}
                                </Typography>
                              }
                              secondary={
                                <React.Fragment>
                                  <Typography
                                    style={{
                                      display: "inline", fontSize: "12px", fontFamily: " Maven Pro", fontWeight: 500,
                                      color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                    }}
                                    component="span"
                                  >
                                    {validateKeyData(cli.buisness_name)}
                                  </Typography>
                                </React.Fragment>
                              }
                            />
                          </ListItem>
                        </IconButton>
                      );
                    })}
                  </List>
                  {/* <br />
                <Pagination count={MyEntityCount} page={MyEntityPage} onChange={changePageEntity} /> */}
                </Item>
              </Grid>
              <Grid item lg={9} xs={12}>
                {openAddClient === true ?
                  <Item style={{ backgroundColor: '#f1f1f1', height: '480px' }}><br />
                    <br />
                    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                      <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                        <Grid item xs={12}><Typography style={{ fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', float: 'left' }}
                        >Onboard Client</Typography><br /></Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Client Name</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                          <TextField
                            onChange={(e) => {
                              setClientAddFormArray(e, 'name')
                            }}
                            size="small"
                            error={open1 && clientAddForm.name === ""}
                            value={clientAddForm.name}
                            className={classes.textField}
                            placeholder="eg: Name" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Business Name</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                          <TextField
                            onChange={(e) => {
                              setClientAddFormArray(e, 'buisness_name')
                            }}
                            size="small"
                            error={open1 && clientAddForm.buisness_name === ""}
                            value={clientAddForm.buisness_name}
                            className={classes.textField}
                            placeholder="eg: Business Name" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Mobile Number</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography>
                            {open1 && !clientAddForm.primary_mobile_number.match(/^\d{10}$/) ? <p style={{ color: 'red', fontSize: '12px' }}>Must contains 10 digits</p> : null}</div>
                          <TextField
                            onChange={(e) => {
                              setClientAddFormArray(e, 'primary_mobile_number')
                            }}
                            size="small"
                            error={open1 && clientAddForm.primary_mobile_number === ""}
                            value={clientAddForm.primary_mobile_number}
                            type="number"
                            className={classes.textField}
                            helperText={clientAddForm.primary_mobile_number != '' &&
                              !/^[0-9]{10}$/.test(clientAddForm.primary_mobile_number) ?
                              'Mobile number must be 10 digits' : null}
                            placeholder="eg: Mobile Number" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Hubs</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                          <TextField
                            onChange={(e) => {
                              setClientAddFormArray(e, 'number_of_hubs')
                            }}
                            size="small"
                            error={open1 && clientAddForm.number_of_hubs === ""}
                            value={clientAddForm.number_of_hubs}
                            className={classes.textField}
                            type="number"
                            placeholder="eg: Number of Hubs" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST Number</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                          <TextField
                            onChange={(e) => {
                              setClientAddFormArray(e, 'gst_number')
                            }}
                            size="small"
                            error={open1 && clientAddForm.gst_number === ""}
                            value={clientAddForm.gst_number}
                            className={classes.textField}
                            type="number"
                            placeholder="eg: GST Number" />
                        </Grid>
                        <Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Location</Typography>
                            &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                          <TextField
                            onChange={(e) => {
                              setClientAddFormArray(e, 'location')
                            }}
                            size="small"
                            error={open1 && clientAddForm.location === ""}
                            value={clientAddForm.location}
                            className={classes.textField}
                            placeholder="eg: Location" />
                        </Grid>
                        <Grid item xs={12} lg={6} /><Grid item xs={12} lg={6}>
                          <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
                            <Button
                              onClick={() => setOpenAddClient(false)}
                              color="primary">
                              Cancel
                            </Button>
                            <Button
                              onClick={() => handleSubmitAddClient(true)}
                              color="secondary" >
                              Submit
                            </Button></div>
                        </Grid>
                      </Grid>
                    </div>
                  </Item> :
                  openEditClient === true ?
                    <Item style={{ backgroundColor: '#f1f1f1', height: '480px' }}>
                      <div style={{ display: 'flex' }}>
                        <ListItem>
                          <Avatar style={{ backgroundColor: '#ffcb0d' }}>
                            <Icon icon="ic:baseline-perm-identity" height="20" width="20" color="68a724" />
                          </Avatar>
                          <ListItemText
                            primary={
                              <Typography
                                style={{
                                  display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                                }}
                                component="span"
                              >
                                {validateKeyData(selectedClient && selectedClient.name)}
                              </Typography>
                            }
                            secondary={
                              <React.Fragment>
                                <Typography
                                  style={{
                                    display: "inline", fontSize: "14px", fontFamily: " Maven Pro", fontWeight: 500,
                                    color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                  }}
                                  component="span"
                                >
                                  {validateKeyData(selectedClient && selectedClient.buisness_name)}
                                </Typography>
                              </React.Fragment>
                            }
                          />
                        </ListItem>
                        <div style={{ display: 'flex' }}>
                          {openEditClient === true ? <IconButton
                            onClick={() => {
                              setOpenEditClient(false);
                            }}>
                            <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                          </IconButton> :
                            <IconButton
                              onClick={() => {
                                setClientEditArray(selectedClient && selectedClient.client_id)
                                setOpenEditClient(true);
                              }}>
                              <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                            </IconButton>}
                          <IconButton
                            onClick={() => {
                              deleteClient(selectedClient && selectedClient.client_id)
                            }}
                          ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /></IconButton></div>
                      </div>
                      <br />
                      <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                        <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                          <Grid item xs={12}><Typography style={{ fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', float: 'left' }}
                          >Edit Client</Typography><br /></Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Client Name</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField onChange={(e) => {
                              setClientEditFormArray(e, 'name')
                            }}
                              size="small" value={editCArray.name}
                              error={open1 && editCArray.name === ""}
                              className={classes.textField} />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Business Name</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField onChange={(e) => {
                              setClientEditFormArray(e, 'buisness_name')
                            }}
                              size="small" value={editCArray.buisness_name}
                              error={open1 && editCArray.buisness_name === ""}
                              className={classes.textField} />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Mobile Number</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField onChange={(e) => {
                              setClientEditFormArray(e, 'primary_mobile_number')
                            }}
                              type="number" size="small" value={editCArray.primary_mobile_number}
                              error={open1 && editCArray.primary_mobile_number === ""}
                              helperText={editCArray.primary_mobile_number != '' &&
                                !/^[0-9]{10}$/.test(editCArray.primary_mobile_number) ?
                                'Mobile number must be 10 digits' : null}
                              className={classes.textField} />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Hubs</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                            <TextField onChange={(e) => {
                              setClientEditFormArray(e, 'number_of_hubs')
                            }}
                              type="number" size="small" value={editCArray.number_of_hubs}
                              error={open1 && editCArray.number_of_hubs === ""}
                              className={classes.textField} />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST Number</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField onChange={(e) => {
                              setClientEditFormArray(e, 'gst_number')
                            }}
                              type="number" size="small" value={editCArray.gst_number}
                              error={open1 && editCArray.gst_number === ""}
                              className={classes.textField} />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Location</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                            <TextField onChange={(e) => {
                              setClientEditFormArray(e, 'location')
                            }}
                              size="small" value={editCArray.location}
                              error={open1 && editCArray.location === ""}
                              className={classes.textField} />
                          </Grid>
                          <Grid item xs={12} lg={6} /><Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
                              <Button
                                onClick={() => setOpenEditClient(false)}
                                color="primary">
                                Cancel
                              </Button>
                              <Button
                                onClick={() => submitClientEdit(true)}
                                color="secondary" >
                                Submit
                              </Button></div>
                          </Grid>
                        </Grid>
                      </div>
                    </Item>
                    : <Item style={{ backgroundColor: '#f1f1f1', height: '480px' }}>
                      <div style={{ display: 'flex' }}>
                        <ListItem>
                          <Avatar style={{ backgroundColor: '#68a72490' }}>
                            <Icon icon="ic:baseline-perm-identity" height="22" width="22" color="#fff" />
                          </Avatar>
                          <ListItemText
                            primary={
                              <Typography
                                style={{
                                  display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                                }}
                                component="span"
                              >
                                {validateKeyData(selectedClient && selectedClient.name)}
                              </Typography>
                            }
                            secondary={
                              <React.Fragment>
                                <Typography
                                  style={{
                                    display: "inline", fontSize: "14px", fontFamily: " Maven Pro", fontWeight: 500,
                                    color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                  }}
                                  component="span"
                                >
                                  {validateKeyData(selectedClient && selectedClient.buisness_name)}
                                </Typography>
                              </React.Fragment>
                            }
                          />
                        </ListItem>
                        <div style={{ display: 'flex' }}>
                          {openEditClient === true ? <IconButton
                            onClick={() => {
                              setOpenEditClient(false);
                            }}>
                            <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                          </IconButton> :
                            <IconButton
                              onClick={() => {
                                setClientEditArray(selectedClient && selectedClient.client_id)
                                setOpenEditClient(true);
                              }}>
                              <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                            </IconButton>}
                          <IconButton
                            onClick={() => {
                              deleteClient(selectedClient && selectedClient.client_id)
                            }}
                          ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /></IconButton></div>
                      </div>
                      <br />
                      <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                        <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                          <Grid item lg={6} xs={12}>
                            <ListItem>
                              <ListItemAvatar>
                                <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                  <Icon icon="material-symbols:mobile-friendly" width="22" height="22" color="68a724" />
                                </Avatar>
                              </ListItemAvatar>
                              <ListItemText primary={<Typography style={{
                                display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                fontWeight: 700, color: "#6C6C6C"
                              }}>{validateKeyData(selectedClient && selectedClient.primary_mobile_number)}</Typography>}
                                secondary={<React.Fragment>
                                  <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                    component="span">Mobile Number</Typography></React.Fragment>}
                              />
                            </ListItem><Divider />
                          </Grid>
                          <Grid item lg={6} xs={12}>
                            <ListItem>
                              <ListItemAvatar>
                                <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                  <Icon icon="ic:twotone-hub" width="22" height="22" color="68a724" />
                                </Avatar>
                              </ListItemAvatar>
                              <ListItemText primary={<Typography style={{
                                display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                fontWeight: 700, color: "#6C6C6C"
                              }}>{validateKeyData(selectedClient && selectedClient.number_of_hubs)}</Typography>}
                                secondary={<React.Fragment>
                                  <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                    component="span">Number of Hubs</Typography></React.Fragment>}
                              />
                            </ListItem><Divider />
                          </Grid>
                          <Grid item lg={6} xs={12}>
                            <ListItem>
                              <ListItemAvatar>
                                <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                  <Icon icon="heroicons-solid:receipt-tax" width="22" height="22" color="68a724" />
                                </Avatar>
                              </ListItemAvatar>
                              <ListItemText primary={<Typography style={{
                                display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                fontWeight: 700, color: "#6C6C6C"
                              }}>{validateKeyData(selectedClient && selectedClient.gst_number)}</Typography>}
                                secondary={<React.Fragment>
                                  <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                    component="span">GST Number</Typography></React.Fragment>}
                              />
                            </ListItem><Divider />
                          </Grid>
                          <Grid item lg={6} xs={12}>
                            <ListItem>
                              <ListItemAvatar>
                                <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                  <Icon icon="ic:baseline-location-on" width="22" height="22" color="68a724" />
                                </Avatar>
                              </ListItemAvatar>
                              <ListItemText primary={<Typography style={{
                                display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                fontWeight: 700, color: "#6C6C6C"
                              }}>{validateKeyData(selectedClient && selectedClient.location)}</Typography>}
                                secondary={<React.Fragment>
                                  <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                    component="span">Location</Typography></React.Fragment>}
                              />
                            </ListItem><Divider />
                          </Grid>
                        </Grid></div>
                    </Item>}
              </Grid>
            </Grid>
            : EntityMetaPresent && value === 0 ?
              <Grid container spacing={0}>
                <Grid item lg={3} xs={12}>
                  <Item style={{ backgroundColor: '#f1f1f1', height: '550px', overflowY: 'scroll' }}>
                    <div
                      style={{ display: "flex", alignItems: 'center', justifyContent: 'space-around', marginTop: '10px' }}
                    >
                      <Paper
                        style={{ p: '2px 4px', display: 'flex', alignItems: 'center', height: '40px', width: '210px' }}
                      >
                        <IconButton style={{ p: '10px' }} aria-label="menu">
                          <SearchIcon style={{ marginBottom: '4px' }} />
                        </IconButton>
                        <InputBase
                          style={{ ml: 1, flex: 1, width: '230px' }}
                          placeholder="Search"
                          value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                        {searchTerm != "" ? <IconButton type="button" style={{ p: '10px' }} aria-label="search"
                          onClick={() => {
                            setSearchTerm("")
                          }} >
                          <Icon icon="material-symbols:close" width="22" height="22" />
                        </IconButton> : null}
                      </Paper>
                      <>
                        {clientEditAccess === true ?
                          (openAddEntity === false ? (
                            <Avatar onClick={() => setOpenAddEntity(true)} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                              <Icon
                                icon="material-symbols:add"
                                color="#68a724"
                                width="26"
                                height="26"
                              />
                            </Avatar >
                          ) : (
                            <Avatar onClick={() => setOpenAddEntity(false)} style={{ backgroundColor: '#fff', width: '30px', height: '30px' }}>
                              <Icon
                                icon="ion:close"
                                color="#68a724"
                                width="22"
                                height="22"
                              />
                            </Avatar >
                          ))
                          : null}
                      </>
                      <Avatar style={{ backgroundColor: '#fff', width: '33px', height: '33px' }} onClick={() => {
                        onDownloadEntity()
                      }}>
                        <CloudDownload style={{ color: '#68a724' }} />
                      </Avatar>
                    </div>
                    <br />
                    <Typography style={{ display: 'flex', justifyContent: 'center' }}>{filteredList && filteredList.length} Entity</Typography>
                    <List>
                      {filteredList && filteredList.map((ent) => {
                        return (
                          <IconButton style={{
                            width: '100%',
                            cursor: 'pointer',
                            backgroundColor: selectedEntity && selectedEntity.fleet_id === ent.fleet_id ? "#68A72480" : null,
                            height: '60px', borderRadius: '10px',
                          }}
                            onClick={() => {
                              setOpenAddEntity(false)
                              setEntitySelected(ent);
                              setOpenEditEntity(false);
                            }}>
                            <ListItem>
                              <Avatar style={{ backgroundColor: selectedEntity && selectedEntity.fleet_id === ent.fleet_id ? '#ffcb0d' : null }}>
                                <Icon icon="carbon:industry" height="20" width="20"
                                  color={selectedEntity && selectedEntity.fleet_id === ent.fleet_id ? "#68a724" : "#fff"} />
                              </Avatar>
                              <ListItemText
                                primary={
                                  <Typography
                                    style={{
                                      display: "inline", fontSize: "14px", fontFamily: "Maven Pro !important",
                                      fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                                    }}
                                    component="span"
                                  >
                                    {validateKeyData(ent.operator_name)}
                                  </Typography>
                                }
                                secondary={
                                  <React.Fragment>
                                    <Typography
                                      style={{
                                        display: "inline", fontSize: "12px", fontFamily: " Maven Pro", fontWeight: 500,
                                        color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                      }}
                                      component="span"
                                    >
                                      {validateKeyData(ent.contact_name)}
                                    </Typography>
                                  </React.Fragment>
                                }
                              />
                            </ListItem>
                          </IconButton>
                        );
                      })}
                    </List>
                  </Item>
                </Grid>
                <Grid item lg={9} xs={12}>
                  {openAddEntity === true ?
                    <Item style={{ backgroundColor: '#f1f1f1', height: '550px' }}><br />
                      <br />
                      <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                        <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                          <Grid item xs={12}><Typography style={{ fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', float: 'left' }}
                          >Onboard Entity</Typography><br /></Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Operator Name</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField
                              onChange={(e) => {
                                setEntityAddFormArray(e, 'operator_name')
                              }}
                              size="small"
                              error={open1 && entityAddForm.operator_name === ""}
                              value={entityAddForm.operator_name}
                              className={classes.textField}
                              placeholder="eg:  Operator Name" />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Contact Name</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField
                              onChange={(e) => {
                                setEntityAddFormArray(e, 'contact_name')
                              }}
                              size="small"
                              error={open1 && entityAddForm.contact_name === ""}
                              value={entityAddForm.contact_name}
                              className={classes.textField}
                              placeholder="eg:  Operator Name" />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Email ID</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField
                              onChange={(e) => {
                                setEntityAddFormArray(e, 'primary_email_id')
                              }}
                              size="small"
                              error={open1 && entityAddForm.primary_email_id === ""}
                              helperText={open1 && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(entityAddForm.primary_email_id) ? 'Enter Valid Email Id' : null}
                              value={entityAddForm.primary_email_id}
                              className={classes.textField}
                              placeholder="eg: primary_email_id" />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Email ID (optional)</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                            <TextField
                              onChange={(e) => {
                                setEntityAddFormArray(e, 'secondary_email_id')
                              }}
                              size="small"
                              helperText={entityAddForm.secondary_email_id != '' && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(entityAddForm.secondary_email_id) ? 'Enter Valid Email Id' :
                                entityAddForm.secondary_email_id === '' ? null : null}
                              error={open1 && entityAddForm.secondary_email_id != '' && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(entityAddForm.secondary_email_id)}
                              value={entityAddForm.secondary_email_id}
                              className={classes.textField}
                              placeholder="eg:  secondary_email_id" />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Mobile Number</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField
                              onChange={(e) => {
                                setEntityAddFormArray(e, 'primary_mobile_number')
                              }}
                              size="small"
                              error={open1 && entityAddForm.primary_mobile_number === ""}
                              value={entityAddForm.primary_mobile_number}
                              type="number"
                              helperText={entityAddForm.primary_mobile_number != '' &&
                                !/^[0-9]{10}$/.test(entityAddForm.primary_mobile_number) ?
                                'Mobile number must be 10 digits' : null}
                              className={classes.textField}
                            />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Mobile Number (optional)</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                            <TextField
                              onChange={(e) => {
                                setEntityAddFormArray(e, 'secondary_mobile_number')
                              }}
                              size="small"
                              // error={open1 && entityAddForm.secondary_mobile_number === ""}
                              value={entityAddForm.secondary_mobile_number}
                              type="number"
                              className={classes.textField}
                              placeholder="eg: secondary_mobile_number"
                              helperText={entityAddForm.secondary_mobile_number != '' &&
                                !/^[0-9]{10}$/.test(entityAddForm.secondary_mobile_number) ?
                                'Mobile number must be 10 digits' : null} />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Region</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                            <TextField
                              onChange={(e) => {
                                setEntityAddFormArray(e, 'region')
                              }}
                              size="small"
                              error={open1 && entityAddForm.region === ""}
                              value={entityAddForm.region}
                              className={classes.textField}
                              placeholder="eg: Region" />
                          </Grid>
                          <Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST Number</Typography>
                              &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>

                            <TextField
                              onChange={(e) => {
                                setEntityAddFormArray(e, 'gst')
                              }}
                              size="small"
                              value={entityAddForm.gst}
                              className={classes.textField}
                              placeholder="eg: GST Number" />
                          </Grid>
                          <Grid item xs={12} lg={6} /><Grid item xs={12} lg={6}>
                            <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
                              <Button
                                onClick={() => setOpenAddEntity(false)}
                                color="primary">
                                Cancel
                              </Button>
                              <Button
                                onClick={() => submitEntity()}
                                color="secondary" >
                                Submit
                              </Button></div>
                          </Grid>
                        </Grid>
                      </div>
                    </Item> :
                    openEditEntity === true ?
                      <Item style={{ backgroundColor: '#f1f1f1', height: '550px' }}>
                        <div style={{ display: 'flex' }}>
                          <ListItem>
                            <Avatar style={{ backgroundColor: '#ffcb0d' }}>
                              <Icon icon="carbon:industry" height="20" width="20" color="68a724" />
                            </Avatar>
                            <ListItemText
                              primary={
                                <Typography
                                  style={{
                                    display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                    fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                                  }}
                                  component="span"
                                >
                                  {validateKeyData(selectedEntity && selectedEntity.operator_name)}
                                </Typography>
                              }
                              secondary={
                                <React.Fragment>
                                  <Typography
                                    style={{
                                      display: "inline", fontSize: "14px", fontFamily: " Maven Pro", fontWeight: 500,
                                      color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                    }}
                                    component="span"
                                  >
                                    {validateKeyData(selectedEntity && selectedEntity.contact_name)}
                                  </Typography>
                                </React.Fragment>
                              }
                            />
                          </ListItem>
                          <div style={{ display: 'flex' }}>
                            {openEditEntity === true ? <IconButton
                              onClick={() => {
                                setOpenEditEntity(false);
                              }}>
                              <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                            </IconButton> :
                              <IconButton
                                onClick={() => {
                                  setEntityEditArray(selectedEntity && selectedEntity.fleet_id)
                                  setOpenEditEntity(true);
                                }}>
                                <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                              </IconButton>}
                            <IconButton
                              onClick={() => {
                                deleteClient(selectedEntity && selectedEntity.fleet_id)
                              }}
                            ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /></IconButton></div>
                        </div>
                        <br />
                        <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                          <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                            <Grid item xs={12}><Typography style={{ fontSize: '22px', fontFamily: ' Maven Pro', fontWeight: 700, color: '#68A724', float: 'left' }}
                            >Edit Entity</Typography><br /></Grid>
                            <Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Operator Name</Typography>
                                &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                              <TextField onChange={(e) => {
                                setEntityEditFormArray(e, 'operator_name')
                              }}
                                size="small" value={editArray.operator_name}
                                error={open1 && editArray.operator_name === ""}
                                className={classes.textField} />
                            </Grid>
                            <Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Contact Name</Typography>
                                &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                              <TextField onChange={(e) => {
                                setEntityEditFormArray(e, 'contact_name')
                              }}
                                size="small" value={`` || editArray.contact_name}
                                error={open1 && editArray.contact_name === ""}
                                className={classes.textField} />
                              <input
                                type="hidden"
                                name="fleet_id"
                                value={selectedEntity && selectedEntity.fleet_id}
                              />
                            </Grid>
                            <Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Email ID</Typography>
                                &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                              <TextField onChange={(e) => {
                                setEntityEditFormArray(e, 'primary_email_id')
                              }}
                                size="small" value={editArray.primary_email_id}
                                helperText={open1 && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(editArray.primary_email_id) ? 'Enter Valid Email Id' : null}
                                error={open1 && editArray.primary_email_id === ""}
                                className={classes.textField} />
                            </Grid>
                            <Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Email ID (optional)</Typography>
                                &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                              <TextField onChange={(e) => {
                                setEntityEditFormArray(e, 'secondary_email_id')
                              }}
                                helperText={editArray.secondary_email_id != '' && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(editArray.secondary_email_id) ? 'Enter Valid Email Id' :
                                  editArray.secondary_email_id === '' ? null : null}
                                error={open1 && editArray.secondary_email_id != '' && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(editArray.secondary_email_id)}
                                size="small" value={editArray.secondary_email_id} className={classes.textField} />
                            </Grid>
                            <Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Mobile Number</Typography>
                                &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                              <TextField onChange={(e) => {
                                setEntityEditFormArray(e, 'primary_mobile_number')
                              }}
                                type="number" size="small" value={editArray.primary_mobile_number}
                                helperText={editArray.primary_mobile_number != '' &&
                                  !/^[0-9]{10}$/.test(editArray.primary_mobile_number) ?
                                  'Mobile number must be 10 digits' : null}
                                className={classes.textField} />
                            </Grid>
                            <Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Mobile Number (optional)</Typography>
                                &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                              <TextField onChange={(e) => {
                                setEntityEditFormArray(e, 'secondary_mobile_number')
                              }}
                                type="number" size="small" value={editArray.secondary_mobile_number}
                                helperText={editArray.secondary_mobile_number != '' &&
                                  !/^[0-9]{10}$/.test(editArray.secondary_mobile_number) ?
                                  'Mobile number must be 10 digits' : null}
                                className={classes.textField} />
                            </Grid>
                            <Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Region</Typography>
                                &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                              <TextField onChange={(e) => {
                                setEntityEditFormArray(e, 'region')
                              }}
                                size="small" value={editArray.region} className={classes.textField} />
                            </Grid>
                            <Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST Number</Typography>
                                &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>&nbsp;</Typography></div>
                              <TextField onChange={(e) => {
                                setEntityEditFormArray(e, 'gst')
                              }}
                                type="number" size="small" value={editArray.gst} className={classes.textField} />
                            </Grid>
                            <Grid item xs={12} lg={6} /><Grid item xs={12} lg={6}>
                              <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
                                <Button
                                  onClick={() => setOpenEditEntity(false)}
                                  color="secondary">
                                  Cancel
                                </Button>
                                <Button
                                  onClick={() => submitEntityEdit(true)}
                                  color="primary" >
                                  Submit
                                </Button></div>
                            </Grid>
                          </Grid>
                        </div>
                      </Item>
                      : <Item style={{ backgroundColor: '#f1f1f1', height: '550px' }}>
                        <div style={{ display: 'flex' }}>
                          <ListItem>
                            <Avatar style={{ backgroundColor: '#68a72490' }}>
                              <Icon icon="carbon:industry" height="20" width="20" color="#fff" />
                            </Avatar>
                            <ListItemText
                              primary={
                                <Typography
                                  style={{
                                    display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                    fontWeight: 700, color: "#6C6C6C", marginLeft: "15px", textTransform: 'capitalize'
                                  }}
                                  component="span"
                                >
                                  {validateKeyData(selectedEntity && selectedEntity.operator_name)}
                                </Typography>
                              }
                              secondary={
                                <React.Fragment>
                                  <Typography
                                    style={{
                                      display: "inline", fontSize: "14px", fontFamily: " Maven Pro", fontWeight: 500,
                                      color: "#7A7A7D", marginLeft: "15px", textTransform: 'capitalize'
                                    }}
                                    component="span"
                                  >
                                    {validateKeyData(selectedEntity && selectedEntity.contact_name)}
                                  </Typography>
                                </React.Fragment>
                              }
                            />
                          </ListItem>
                          <div style={{ display: 'flex' }}>
                            {openEditEntity === true ? <IconButton
                              onClick={() => {
                                setOpenEditEntity(false);
                              }}>
                              <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                            </IconButton> :
                              <IconButton
                                onClick={() => {
                                  setEntityEditArray(selectedEntity && selectedEntity.fleet_id)
                                  setOpenEditEntity(true);
                                }}>
                                <Icon icon="material-symbols:edit" color="#33a6ff" width="20" height="20" />
                              </IconButton>}
                            <IconButton
                              onClick={() => {
                                deleteEntity(selectedEntity && selectedEntity.fleet_id)
                              }}
                            ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /></IconButton></div>
                        </div>
                        <br />
                        <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                          <Grid container spacing={2} style={{ backgroundColor: '#fff', borderRadius: '10px', width: '90%' }}>
                            <Grid item lg={6} xs={12}>
                              <ListItem>
                                <ListItemAvatar>
                                  <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                    <Icon icon="tabler:mail-check" width="22" height="22" color="68a724" />
                                  </Avatar>
                                </ListItemAvatar>
                                <ListItemText primary={<Typography style={{
                                  display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C"
                                }}>{validateKeyData(selectedEntity && selectedEntity.primary_email_id)}</Typography>}
                                  secondary={<React.Fragment>
                                    <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                      component="span">Primary Email ID</Typography></React.Fragment>}
                                />
                              </ListItem><Divider />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                              <ListItem>
                                <ListItemAvatar>
                                  <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                    <Icon icon="ri:mail-line" width="22" height="22" color="68a724" />
                                  </Avatar>
                                </ListItemAvatar>
                                <ListItemText primary={<Typography style={{
                                  display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C"
                                }}>{validateKeyData(selectedEntity && selectedEntity.secondary_email_id)}</Typography>}
                                  secondary={<React.Fragment>
                                    <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                      component="span">Secondary Email ID</Typography></React.Fragment>}
                                />
                              </ListItem><Divider />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                              <ListItem>
                                <ListItemAvatar>
                                  <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                    <Icon icon="material-symbols:mobile-friendly" width="22" height="22" color="68a724" />
                                  </Avatar>
                                </ListItemAvatar>
                                <ListItemText primary={<Typography style={{
                                  display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C"
                                }}>{validateKeyData(selectedEntity && selectedEntity.primary_mobile_number)}</Typography>}
                                  secondary={<React.Fragment>
                                    <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                      component="span">Primary Mobile Number</Typography></React.Fragment>}
                                />
                              </ListItem><Divider />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                              <ListItem>
                                <ListItemAvatar>
                                  <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                    <Icon icon="material-symbols:phone-android" width="22" height="22" color="68a724" />
                                  </Avatar>
                                </ListItemAvatar>
                                <ListItemText primary={<Typography style={{
                                  display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C"
                                }}>{validateKeyData(selectedEntity && selectedEntity.secondary_mobile_number)}</Typography>}
                                  secondary={<React.Fragment>
                                    <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                      component="span">Secondary Mobile Number</Typography></React.Fragment>}
                                />
                              </ListItem><Divider />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                              <ListItem>
                                <ListItemAvatar>
                                  <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                    <Icon icon="heroicons-solid:receipt-tax" width="22" height="22" color="68a724" />
                                  </Avatar>
                                </ListItemAvatar>
                                <ListItemText primary={<Typography style={{
                                  display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C"
                                }}>{validateKeyData(selectedEntity && selectedEntity.gst)}</Typography>}
                                  secondary={<React.Fragment>
                                    <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                      component="span">GST</Typography></React.Fragment>}
                                />
                              </ListItem><Divider />
                            </Grid>
                            <Grid item lg={6} xs={12}>
                              <ListItem>
                                <ListItemAvatar>
                                  <Avatar style={{ backgroundColor: '#F1F1F1' }}>
                                    <Icon icon="ic:baseline-location-on" width="22" height="22" color="68a724" />
                                  </Avatar>
                                </ListItemAvatar>
                                <ListItemText primary={<Typography style={{
                                  display: "inline", fontSize: "16px", fontFamily: "Maven Pro !important",
                                  fontWeight: 700, color: "#6C6C6C"
                                }}>{validateKeyData(selectedEntity && selectedEntity.region)}</Typography>}
                                  secondary={<React.Fragment>
                                    <Typography style={{ fontSize: '14px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#68a724' }}
                                      component="span">Region</Typography></React.Fragment>}
                                />
                              </ListItem><Divider />
                            </Grid>
                          </Grid></div>
                      </Item>}
                </Grid>
              </Grid> : <Loading />}
      <br />
      <Typography align="center" className={classes.copyRight}>
        Copyright© 2023 ReVx Energy Pvt.Ltd.
      </Typography>
    </div>
  );
}
