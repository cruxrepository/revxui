import React from "react";
import axios from "axios";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import { withStyles, makeStyles, useTheme, styled, useStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import { Icon } from '@iconify/react';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import classNames from 'classnames';
import './style.css';
import SimpleSnackbar from '../Users/SimpleSnackbar';
import endpoints from "../../../endpoints/endpoints";
import { getEntityBulk } from '../../../redux/actions/asyncActions';


export default function CustomToolbar(props) {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const [openAddEntity, setOpenAddEntity] = React.useState(false);

  const handleClick = () => {
  }
  const useStyles = makeStyles((theme) => ({
    Box: {
      border: '1px solid #000000'
    },
    IconButton: {
      '&:hover': {
        color: '#9ccc65'
      },
      transform: !fullScreen ? "translateX(-12em)" : null
    },
    tabHelp: {
      fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
    },
    formControl: {
      width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
    },
    textField: {
      width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
      'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    autoComplete: {
      '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
  },
  dialog: {
    position:'relative', marginLeft:'630px'
  }
  }));

  //   const theme = useTheme();
  const classes = useStyles();
  const [status, setStatus] = React.useState('');
  const [action, setAction] = React.useState('');
  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)
  const [addResponse, setAddResponce] = React.useState("")
  const handleChange1 = (event) => {
    setStatus(event.target.value);
};
const handleChange2 = (event) => {
  setAction(event.target.value);
};



  return (
    <React.Fragment>
      <Tooltip style={{ flex: 'left' }} title={"Onboard Entity"}>
        <IconButton
          className={classes.IconButton}
          onClick={() => setOpenAddEntity(true)}
        >
          <Icon icon="carbon:industry" width="26" height="26" />
        </IconButton>
      </Tooltip>
      
      

    </React.Fragment>

  );


}

// export default withStyles(CustomToolbar, defaultToolbarStyles, { name: "CustomToolbar" });
