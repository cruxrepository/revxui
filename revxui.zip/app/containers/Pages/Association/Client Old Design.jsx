import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import PropTypes from "prop-types";
import Chip from "@material-ui/core/Chip";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import Tooltip from "@material-ui/core/Tooltip";
import NotificationImportantIcon from "@material-ui/icons/NotificationImportant";
import Paper from "@material-ui/core/Paper";
import './style.css';
import CustomToolbar from './CustomToobar';
import CustomToolbarA from './CustomToobarA';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import classNames from 'classnames';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import { useDispatch, useSelector } from 'react-redux';
import { getEntityBulk, getClientBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import endpoints from "../../../endpoints/endpoints";
import ErrorWrap from '../../../components/Error/ErrorWrap';
import SimpleSnackbar from '../Users/SimpleSnackbar';
import Pagination from '@material-ui/lab/Pagination';


const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  gst: {
    color: '#4CAF50'
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  tabHelp: {
    fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
  },
  formControl: {
    width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
  },
  textField: {
    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
  },
  autoComplete: {
    '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
  },
  dialog: {
    position: 'relative', marginLeft: '630px'
  },
  tabsSection: {
    [theme.breakpoints.up('lg')]: {
      // borderRadius:0,position:'sticky',top:0 ,width:500
      borderRadius: 0, top: 0, width: 500

    },


  },
}));



/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function Client() {

  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const classes = useStyles();
  const [screen, setScreen] = React.useState(false);
  //   const columns = [
  const [value, setValue] = React.useState(0);
  const [openAddClient, setOpenAddClient] = React.useState(false);
  const [openAddEntity, setOpenAddEntity] = React.useState(false);
  const [openEditClient, setOpenEditClient] = React.useState(false);
  const [openEditEntity, setOpenEditEntity] = React.useState(false);
  const [status, setStatus] = React.useState('');
  const [state, setState] = React.useState('');
  const [action, setAction] = React.useState('');
  const [index, setIndex] = React.useState(0);
  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)
  const [addResponse, setAddResponce] = React.useState("")
  const [entityPage, setEntityPage] = React.useState(1);
  const [clientPage, setClientPage] = React.useState(1);
  const [password1, setPassword1] = React.useState("");
  const [password2, setPassword2] = React.useState("");
  const [delete1, setDelete1] = React.useState("");
  const [delete2, setDelete2] = React.useState("");
  const [selectedId1, setSelectedId1] = React.useState("");
  const [selectedId2, setSelectedId2] = React.useState("");
  const changePageEntity = (event, newValue) => {
    setEntityPage(newValue);
  };
  const changePageClient = (event, newValue) => {
    setClientPage(newValue);
  };
  const handleChange1 = (event) => {
    setStatus(event.target.value);
  };
  const handleChange2 = (event) => {
    setAction(event.target.value);
  };
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const logged_user = useSelector((store) => store.login.result);
  let clientEditAccess = logged_user.client === "edit"
  const ppp = useSelector((store) => store.login.result.password);

  const EntityData = useSelector((store) => store.entityAll)
  const EntityDataRaw = useSelector((store) => store.entityAll.rawData)
  let EntityMeta = {};
  EntityMeta.data = [];
  let EntityMetaa = useSelector((store) => store.entityAll)
  if (EntityMetaa.data.length >= 1) {
    EntityMeta.data = EntityMetaa.data;
  }
  const MyEntityPage = useSelector((store) => store.entityAll.page_number)
  const MyEntityCount = Math.ceil(useSelector((store) => store.entityAll.total_records) / 10 )
  let EntityFetching = useSelector((store) => store.entityAll.fetching)
  let EntityResponsecode = useSelector((store) => store.entityAll.responseStatus)
  let EntityMetaPresent = useSelector((store) => store.entityAll.dataPresent)

  
  const ClientData = useSelector((store) => store.clientAll)
  const ClientDataRaw = useSelector((store) => store.clientAll.rawData)
  let ClientMeta = {};
  ClientMeta.data = [];
  let ClientMetaa = useSelector((store) => store.clientAll)
  if (ClientMetaa.data.length >= 1) {
    ClientMeta.data = ClientMetaa.data;
  }
  const MyClientPage = useSelector((store) => store.clientAll.page_number)
  const MyClientCount = Math.ceil(useSelector((store) => store.clientAll.total_records) / 10 )
  let ClientFetching = useSelector((store) => store.clientAll.fetching)
  let ClientResponsecode = useSelector((store) => store.clientAll.responseStatus)
  let ClientMetaPresent = useSelector((store) => store.clientAll.dataPresent)
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getEntityBulk(entityPage));
    dispatch(getClientBulk(clientPage));
  }, [EntityMetaPresent, entityPage, ClientMetaPresent, clientPage]);

// console.log("EntityMeta.data",EntityMeta.data)
  const validateKeyData = (key) => {
    return key ? key : "-";
};

  const EntityColumn = [

    {
      label: "Operator Name", name: "name",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Contact Name", name: "contact",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Primary Email ID", name: "pemail",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Primary Mobile", name: "mobile",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Region", name: "region",
      options: {  
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "GST Number", name: "gst",
      align: "center",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" className={classes.gst} >{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Action Button", name: "action",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <><IconButton
              onClick={() => {
                setEntityEditArray(value)
                setOpenEditEntity(true);
              }}
            ><Icon icon="bxs:edit-alt" color="#33a6ff" width="30" height="30" /></IconButton>
              <IconButton
                onClick={() => { 
                  deleteEntity(value)
                 }}
              ><Icon icon="ic:baseline-delete" color="#fa5d41" width="30" height="30" /> </IconButton>
            </>
          );
        },

      },
    },
  ];
const EntityColumn1 = [

    {
      label: "Operator Name", name: "name",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Contact Name", name: "contact",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Email ID", name: "pemail",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Mobile", name: "mobile",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Region", name: "region",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "GST Number", name: "gst",
      align: "center",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" className={classes.gst} style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    }
  ];
  const ClientColumn = [

    {
      label: "Client Name", name: "name",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Business Name", name: "business",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Mobile Number", name: "mobile",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Number of Hubs", name: "hub",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Location", name: "location",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "GST Number", name: "gst",
      align: "center",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" className={classes.gst} >{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Action Button", name: "action",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <><IconButton
              onClick={() => {
                setOpenEditClient(true)
                setClientEditArray(value)
              }}
            ><Icon icon="bxs:edit-alt" color="#33a6ff" width="30" height="30" /></IconButton>
              <IconButton
                onClick={() => { 
                  deleteClient(value) }}
              ><Icon icon="ic:baseline-delete" color="#fa5d41" width="30" height="30" /> </IconButton>
            </>
          );
        },

        // customBodyRender: (value = any, meta = MUIDataTableMeta) => {
        //   return (
        //     <Select
        //       style={{ minWidth: 100, color: "#FFC130" }}
        //       value="Edit"
        //     >
        //       <MenuItem onClick={() => {
        //         setOpenEditClient(true)
        //         setIndex(meta.rowIndex)
        //       }} style={{ color: "#FFC130 !important" }} value="Edit">
        //         Edit
        //       </MenuItem>
        //       <MenuItem style={{ color: "#FF6058 !important" }} value="Delete">
        //         Delete
        //       </MenuItem>
        //     </Select>
        //   );
        // },
      },
    },
    // {
    //   label: "Status", name: "status",
    //   options: {
    //     filter: true,
    //     customBodyRender: (value) => {
    //       if (value === "INACTIVE") {
    //         return (
    //           <Icon icon="ic:baseline-perm-identity" height="25" width="25" color="#FFC130" />
    //           // <Button
    //           //   variant="contained"
    //           //   style={{ minWidth: 130, background: "#FFC130", color: "white" }}
    //           // >
    //           //   {value}
    //           // </Button>
    //         );
    //       } else {
    //         return (
    //           <Icon icon="ic:baseline-perm-identity" height="25" width="25" color="#68A724" />
    //           // <Button
    //           //   variant="contained"
    //           //   style={{ minWidth: 130, background: "#68A724", color: "white" }}
    //           // >
    //           //   {value}
    //           // </Button>
    //         );
    //       }
    //     },
    //   },
    // },

  ];
  const ClientColumn1 = [

    {
      label: "Client Name", name: "name",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Business Name", name: "business",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Mobile Number", name: "mobile",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Number of Hubs", name: "hub",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Location", name: "location",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "GST Number", name: "gst",
      align: "center",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" className={classes.gst} style={{ height:'30px', marginTop:'12px'}}>{validateKeyData(value)}</Typography>
        ),
      },
    }
  ];

  const options = {
    filterType: "dropdown",
    responsive: "vertical",
    print: false,
    rowsPerPage: 10,
    page: 0,
    downloadCsv: true,
    selectableRows: "none",
    customToolbar: () => {
      if(clientEditAccess === true){
      return (
        value === 1 ? 
        <Tooltip style={{ flex: 'left' }} title={"Onboarding Client"}>
          <IconButton onClick={() => setOpenAddClient(true)} style={{ transform: "translateX(-10em)" }}><Icon icon="mdi:account-plus" width="28" height="28" hFlip={true} /></IconButton>
          </Tooltip> :
          <Tooltip style={{ flex: 'left' }} title={"Onboarding Entity"}>
          <IconButton onClick={() => setOpenAddEntity(true)} style={{ transform: "translateX(-10em)" }}><Icon icon="carbon:industry" width="24" height="24" /></IconButton>
          </Tooltip>
      );}
      else {
        null
      }
    }
  };
  // Add Entity
  const [entityAddForm, setEntityAddForm] = React.useState(
    {
      operator_name: "",
      contact_name: "",
      primary_email_id: "",
      secondary_email_id: "",
      primary_mobile_number: "",
      secondary_mobile_number: "",
      gst: "",
      region: "",
      location_id: "2"
    }
  )
  const submitEntity = () => {
    if (entityAddForm.operator_name && entityAddForm.contact_name && /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(entityAddForm.primary_email_id) && 
    /^(\d{3})[- ]?(\d{3})[- ]?(\d{4})$/.test(entityAddForm.primary_mobile_number) && entityAddForm.region) {
      const postEntity = endpoints.baseUrl + `/entity/add`;

      axios
        .post(postEntity, entityAddForm)
        .then((response) => {
          setAddBatteryErrors(true);
          response.status === 201 ? setAddResponce("Entity Added Successfully") : setAddResponce(response.message)
          dispatch(getEntityBulk(entityPage));
      setOpenAddEntity(false);
    });
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields")

    }

  }
  const setEntityAddFormArray = (e, key, array) => {
    setEntityAddForm((state) => ({ ...state, [key]: e.target.value }));

  }

  // Edit Entity
  const [editArray, setEditArray] = React.useState(
    {
    }
  )
  const setEntityEditFormArray = (e, key) => {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));

  }

  const submitEntityEdit = () => {

    if (editArray.operator_name && editArray.contact_name && editArray.primary_email_id && editArray.primary_mobile_number && editArray.region) {
      const putEntity = endpoints.baseUrl + `/entity/edit/` + editArray.fleet_id;
      let newEditArray = editArray;
      axios
        .put(putEntity, newEditArray)
        .then((response) => {
          setAddBatteryErrors(true);
          setOpenEditEntity(false)

          dispatch(getEntityBulk(entityPage));
          response.status === 200 ? setAddResponce("Entity Edited Successfully") : setAddResponce(response.message)
      setOpenEditEntity(false)
      setEditArray({

          })
        });

    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields")

    }
  }
  const setEntityEditArray = (fleet_id) => {
    let allEntity = EntityDataRaw;
    let findArray = allEntity.find(el => el.fleet_id === fleet_id)
    setEditArray(findArray);
  }

  // Delete Entity
  const deleteEntity = (fleet_id) => {
    const deleteEntityy = endpoints.baseUrl + `/entity/SoftDelete/` + fleet_id;
    axios
      .delete(deleteEntityy)
      .then((response) => {
        setAddBatteryErrors(true);
        response.status === 200 ? setAddResponce("Entity Offboarding") : setAddResponce(response.message)
        dispatch(getEntityBulk(entityPage));
      });
  }

  // Add Clent
  const [clientAddForm, setClientAddForm] = React.useState(
    {
      name: "",
      buisness_name: "",
      primary_mobile_number: "",
      number_of_hubs: "",
      gst_number: "",
      location: "",
      location_id: "1"
    }
  )
  const submitClient = () => {
    if (clientAddForm.name && clientAddForm.buisness_name && clientAddForm.primary_mobile_number &&
      clientAddForm.number_of_hubs && clientAddForm.gst_number && clientAddForm.location) {
      const postClient = endpoints.baseUrl + `/client/add`;

      axios
        .post(postClient, clientAddForm)
        .then((response) => {
          setAddBatteryErrors(true);
          dispatch(getClientBulk(clientPage));
          response.status === 201 ? setAddResponce("Client Added Successfully") : setAddResponce(response.message)
        });
      setOpenAddClient(false);
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields")
      setOpenAddClient(true);

    }

  }
  const setClientAddFormArray = (e, key, array) => {
    setClientAddForm((state) => ({ ...state, [key]: e.target.value }));

  }

  const handleSubmitAddClient = () => {
    submitClient(true)
    // setOpenAddClient(false)
    dispatch(getClientBulk(clientPage));
  }

  //Edit Client
  const [editCArray, setEditCArray] = React.useState(
    {
    }
  )
  const setClientEditFormArray = (e, key) => {
    setEditCArray((state) => ({ ...state, [key]: e.target.value }));

  }

  const submitClientEdit = () => {

    if (editCArray.name && editCArray.buisness_name && editCArray.primary_mobile_number && editCArray.number_of_hubs
      && editCArray.gst_number && editCArray.location) {
      const putClient = endpoints.baseUrl + `/client/edit/` + editCArray.client_id;
      let newCEditArray = editCArray;
      axios
        .put(putClient, newCEditArray)
        .then((response) => {
          setAddBatteryErrors(true);
          setOpenEditClient(false)

          dispatch(getClientBulk(clientPage));
          response.status === 200 ? setAddResponce("Client Edited Successfully") : setAddResponce(response.message)
          setEditCArray({

          })
        });
      setOpenEditClient(false)

    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields")

    }
  }
  const setClientEditArray = (client_id) => {
    let allClient = ClientDataRaw;
    let findArray = allClient.find(el => el.client_id === client_id)
    setEditCArray(findArray);
  }

  // Delete Client
  const deleteClient = (client_id) => {
    const deleteClientt = endpoints.baseUrl + `/client/SoftDelete/` + client_id;
    axios
      .delete(deleteClientt)
      .then((response) => {
        setAddBatteryErrors(true);
        response.status === 200 ? setAddResponce("Client Offboarding") : setAddResponce(response.message)
        dispatch(getClientBulk(clientPage));
      });
  }

  const [frame, setFrame] = React.useState(false);

  return (
    <div onMouseEnter={() => setFrame(true)} className={classes.table}>
      <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />

      <Paper square className={classes.root} />
      {/* <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}> */}
      <Tabs
        className={classes.tabsSection}
        value={value}
        onChange={handleChange}
        variant="fullWidth"
        indicatorColor="primary"
        aria-label="icon tabs example"
      >
        <Tab label="ENTITY" onClick={() => {
          setScreen(false)
        }} icon={<Icon icon="carbon:industry" height="25" width="25" />} aria-label="favorite" />
        <Tab label="CLIENT" onClick={() => {
          setScreen(false)
        }} icon={<Icon icon="ic:baseline-perm-identity" height="25" width="25" />} aria-label="phone" />

      </Tabs>
      {/* <>{value === 0 ? <Tooltip style={{ flex: 'left' }} title={"Onboard Entity"}>
          <IconButton
            className={classes.IconButton}
            onClick={() => setOpenAddEntity(true)}
          >
            <Icon icon="carbon:industry" width="26" height="26" />
          </IconButton>
        </Tooltip> :
          <Tooltip style={{ flex: 'left' }} title={"Onboard Client"}>
            <IconButton
              className={classes.IconButton}
              onClick={() => setOpenAddClient(true)}
            >
              <Icon icon="mdi:account-plus" width="30" height="30" hFlip={true} />
            </IconButton>
          </Tooltip>}</> */}
      {/* </div> */}

      <br />
      {ClientMetaPresent && value === 1 ? 
      <><MUIDataTable
        checkboxSelection={false}
        title="CLIENT"
        // data={data}
        data={ClientMeta.data}
        columns={clientEditAccess === true ? ClientColumn : ClientColumn1}
        options={options}
        selectableRows={1}
        selectableRowsHideCheckboxes

      /><br />
      <Pagination count={MyClientCount} page={MyClientPage} onChange={changePageClient} /></>
       : EntityMetaPresent && value === 0 ?

        <><MUIDataTable
          checkboxSelection={false}
          title="ENTITY"
          data={EntityMeta.data}
          columns={clientEditAccess === true ? EntityColumn : EntityColumn1}
          options={options}
          selectableRows={1}
          selectableRowsHideCheckboxes

        />
          <br />
          <Pagination count={MyEntityCount} page={MyEntityPage} onChange={changePageEntity} />
        </> 
         : <Loading />}

      {/* Add Entity */}
      <Dialog
        fullScreen={fullScreen}
        open={openAddEntity}
        maxWidth={"lg"}
        onClose={() => setOpenAddEntity(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Onboard Entity"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Operator Name</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setEntityAddFormArray(e, 'operator_name')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && entityAddForm.operator_name === ""}
                  value={entityAddForm.operator_name}
                  className={classes.textField}
                  placeholder="eg:  Operator Name" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Contact Name</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setEntityAddFormArray(e, 'contact_name')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && entityAddForm.contact_name === ""}
                  value={entityAddForm.contact_name}
                  className={classes.textField}
                  placeholder="eg:  Operator Name" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Email ID</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography>
                  {!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(entityAddForm.primary_email_id)) ? <p style={{ color: 'red', fontSize: '14px' }}>enter valid email</p> : null}</div>
                <TextField
                  onChange={(e) => {
                    setEntityAddFormArray(e, 'primary_email_id')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && entityAddForm.primary_email_id === ""}
                  value={entityAddForm.primary_email_id}
                  className={classes.textField}
                  placeholder="eg: primary_email_id" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Email ID</Typography>
                  &nbsp;<Typography style={{ color: '#C4C4C4', fontSize: '14px' }}>(optional)</Typography></div>
                <TextField
                  onChange={(e) => {
                    setEntityAddFormArray(e, 'secondary_email_id')
                  }}
                  size="small" id="outlined"
                  // error={addBatteryErrors && entityAddForm.secondary_email_id === ""}
                  value={entityAddForm.secondary_email_id}
                  className={classes.textField}
                  placeholder="eg:  secondary_email_id" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Mobile Number</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography>
                  {!entityAddForm.primary_mobile_number.match(/^\d{10}$/) ? <p style={{ color: 'red', fontSize: '14px' }}>Must contains 10 digits</p> : null}</div>
                <TextField
                  onChange={(e) => {
                    setEntityAddFormArray(e, 'primary_mobile_number')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && entityAddForm.primary_mobile_number === ""}
                  value={entityAddForm.primary_mobile_number}
                  type="number"
                  className={classes.textField}
                   />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Mobile Number</Typography>
                  &nbsp;<Typography style={{ color: '#C4C4C4', fontSize: '14px' }}>(optional)</Typography></div>
                <TextField
                  onChange={(e) => {
                    setEntityAddFormArray(e, 'secondary_mobile_number')
                  }}
                  size="small" id="outlined"
                  // error={addBatteryErrors && entityAddForm.secondary_mobile_number === ""}
                  value={entityAddForm.secondary_mobile_number}
                  type="number"
                  className={classes.textField}
                  placeholder="eg: secondary_mobile_number" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Region</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setEntityAddFormArray(e, 'region')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && entityAddForm.region === ""}
                  value={entityAddForm.region}
                  className={classes.textField}
                  placeholder="eg: Region" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <Typography className={classes.tabHelp}>GST Number</Typography>
                <TextField
                  onChange={(e) => {
                    setEntityAddFormArray(e, 'gst')
                  }}
                  size="small" id="outlined"
                  value={entityAddForm.gst}
                  className={classes.textField}
                  placeholder="eg: GST Number" />
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenAddEntity(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            onClick={() => submitEntity()}
            color="secondary" >
            Submit
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add Client */}
      <Dialog
        fullScreen={fullScreen}
        open={openAddClient}
        maxWidth={"lg"}
        onClose={() => setOpenAddClient(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Add Client"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Client Name</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setClientAddFormArray(e, 'name')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && clientAddForm.name === ""}
                  value={clientAddForm.name}
                  className={classes.textField}
                  placeholder="eg: Name" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Business Name</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setClientAddFormArray(e, 'buisness_name')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && clientAddForm.buisness_name === ""}
                  value={clientAddForm.buisness_name}
                  className={classes.textField}
                  placeholder="eg: Business Name" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Mobile Number</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography>
                  {!clientAddForm.primary_mobile_number.match(/^\d{10}$/) ? <p style={{ color: 'red', fontSize: '14px' }}>Must contains 10 digits</p> : null}</div>
                <TextField
                  onChange={(e) => {
                    setClientAddFormArray(e, 'primary_mobile_number')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && clientAddForm.primary_mobile_number === ""}
                  value={clientAddForm.primary_mobile_number}
                  type="number"
                  className={classes.textField}
                  placeholder="eg: Mobile Number" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Hubs</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setClientAddFormArray(e, 'number_of_hubs')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && clientAddForm.number_of_hubs === ""}
                  value={clientAddForm.number_of_hubs}
                  className={classes.textField}
                  type="number"
                  placeholder="eg: Number of Hubs" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST Number</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setClientAddFormArray(e, 'gst_number')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && clientAddForm.gst_number === ""}
                  value={clientAddForm.gst_number}
                  className={classes.textField}
                  type="number"
                  placeholder="eg: GST Number" />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Location</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setClientAddFormArray(e, 'location')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && clientAddForm.location === ""}
                  value={clientAddForm.location}
                  className={classes.textField}
                  placeholder="eg: Location" />
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenAddClient(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            onClick={() => handleSubmitAddClient(true)}
            color="secondary" >
            Submit
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Entity */}
      <Dialog
        fullScreen={fullScreen}
        open={openEditEntity}
        maxWidth={"lg"}
        onClose={() => setOpenEditEntity(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Edit Entity"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Operator Name</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setEntityEditFormArray(e, 'operator_name')
                }}
                  size="small" id="outlined" value={editArray.operator_name}
                  error={addBatteryErrors && editArray.operator_name === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Contact Name</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setEntityEditFormArray(e, 'contact_name')
                }}
                  size="small" id="outlined" value={editArray.contact_name}
                  error={addBatteryErrors && editArray.contact_name === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Email ID</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setEntityEditFormArray(e, 'primary_email_id')
                }}
                  size="small" id="outlined" value={editArray.primary_email_id}
                  error={addBatteryErrors && editArray.primary_email_id === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Email ID</Typography>
                  &nbsp;<Typography style={{ color: '#C4C4C4', fontSize: '14px' }}>(optional)</Typography></div>
                <TextField onChange={(e) => {
                  setEntityEditFormArray(e, 'secondary_email_id')
                }}
                  size="small" id="outlined" value={editArray.secondary_email_id} className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Primary Mobile Number</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setEntityEditFormArray(e, 'primary_mobile_number')
                }}
                type="number" size="small" id="outlined" value={editArray.primary_mobile_number} className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Secondary Mobile Number</Typography>
                  &nbsp;<Typography style={{ color: '#C4C4C4', fontSize: '14px' }}>(optional)</Typography></div>
                <TextField onChange={(e) => {
                  setEntityEditFormArray(e, 'secondary_mobile_number')
                }}
                type="number" size="small" id="outlined" value={editArray.secondary_mobile_number} className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Region</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setEntityEditFormArray(e, 'region')
                }}
                  size="small" id="outlined" value={editArray.region} className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <Typography className={classes.tabHelp}>GST Number</Typography>
                <TextField onChange={(e) => {
                  setEntityEditFormArray(e, 'gst')
                }}
                type="number" size="small" id="outlined" value={editArray.gst} className={classes.textField} />
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenEditEntity(false)}
            color="secondary">
            Cancel
          </Button>
          <Button
            onClick={() => submitEntityEdit(true)}
            color="primary" autoFocus>
            Submit
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Client */}
      <Dialog
        fullScreen={fullScreen}
        open={openEditClient}
        maxWidth={"lg"}
        onClose={() => setOpenEditClient(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Edit Client"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Client Name</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setClientEditFormArray(e, 'name')
                }}
                  size="small" id="outlined" value={editCArray.name}
                  error={addBatteryErrors && editCArray.name === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Business Name</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setClientEditFormArray(e, 'buisness_name')
                }}
                  size="small" id="outlined" value={editCArray.buisness_name}
                  error={addBatteryErrors && editCArray.buisness_name === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Mobile Number</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setClientEditFormArray(e, 'primary_mobile_number')
                }}
                type="number" size="small" id="outlined" value={editCArray.primary_mobile_number}
                  error={addBatteryErrors && editCArray.primary_mobile_number === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Number of Hubs</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setClientEditFormArray(e, 'number_of_hubs')
                }}
                type="number" size="small" id="outlined" value={editCArray.number_of_hubs}
                  error={addBatteryErrors && editCArray.number_of_hubs === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>GST Number</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setClientEditFormArray(e, 'gst_number')
                }}
                type="number" size="small" id="outlined" value={editCArray.gst_number}
                  error={addBatteryErrors && editCArray.gst_number === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Location</Typography>
                  &nbsp;<Typography style={{ color: 'red', fontSize: '18px' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setClientEditFormArray(e, 'location')
                }}
                  size="small" id="outlined" value={editCArray.location}
                  error={addBatteryErrors && editCArray.location === ""}
                  className={classes.textField} />
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenEditClient(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            onClick={() => submitClientEdit(true)}
            color="secondary" >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
        
      <br />
      <Typography align="center" className={classes.copyRight}>
        
        Copyright© 2023 ReVx Energy Pvt.Ltd.
      </Typography>
    </div>
  );
}
