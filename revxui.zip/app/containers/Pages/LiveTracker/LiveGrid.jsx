import React from "react";
import axios from 'axios';
import { makeStyles, useTheme, styled } from '@material-ui/core/styles';
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import CloseIcon from '@material-ui/icons/Close';
import { TextField } from "@material-ui/core/";
import InputAdornment from '@material-ui/core/InputAdornment';
import SearchIcon from '@material-ui/icons/Search';
import { IconButton } from "@material-ui/core/";
import vech1 from "./imgs/vech1.svg";
import vech1_a from "./imgs/vech1_a.svg"

import vech2 from "./imgs/vech2.svg";
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Divider from '@material-ui/core/Divider';
import Avatar from '@material-ui/core/Avatar';
import SimpleMap from "./BasicMap";
// import AddCircleSharpIcon from '@material-ui/icons/AddCircleSharp';
// import RemoveCircleOutlinedIcon from '@material-ui/icons/RemoveCircleOutlined';
// import AccountCircle from '@material-ui/icons/AccountCircle';
import Brightness1Icon from '@material-ui/icons/Brightness1';
import endpoints from '../../../endpoints/endpoints';
import { setLiveTrackerList, setLiveTrackerSelected } from "../../../redux/actions/normalActions";
import { useDispatch, useSelector } from "react-redux";
const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'left',
    color: theme.palette.text.secondary,
}));
const useStyles = makeStyles((theme) => ({
    paperHeading: {
        height: 400, borderRadius: 2
    },
    green: {
        position: 'sticky', zIndex: 10, top: 0,
        backgroundColor: '#68A72480  !important', border: 'none',
        height: 60, borderBottomLeftRadius: 0, borderBottomRightRadius: 0
    },
    search: {
        marginLeft: '15px', backgroundColor: '#fff', width: '300px',
        borderRadius: '8px', '.MuiOutlinedInput-notchedOutline': {
            borderColor: '#fff !important',
            borderRadius: '9px !important'
        },
        '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#fff  !important' }
    },
    list: {
        width: '100%', backgroundColor: 'background.paper', height: '85%'
        , overflowY: 'scroll'
    },
    hover: {
         backgroundColor: theme.palette.grey.A100
    },
    map: {
        height: 400, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    primaryText: {
        fontFamily: 'Open Sans', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
    }, 
    primaryTextVV: {
        fontFamily: 'Open Sans', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px', marginTop: '8px'
    },
    secondaryTextVV: {
        fontFamily: 'Roboto', fontSize: '12px', fontWeight: 500, color: '#68A724', width: '100%', marginTop: '8px'
    },
    secondaryText: {
        fontFamily: 'Roboto', fontSize: '12px', fontWeight: 400, color: '#7A7A7D', width: '100%'
    },
    secondaryTextG: {
        fontFamily: 'Roboto', fontSize: '12px', fontWeight: 500, color: '#68A724', width: '100%'
    },
    secondaryTextGV: {
        fontFamily: 'Roboto', fontSize: '12px', fontWeight: 500, color: '#68A724', width: '100%', marginTop: '-10px'
    },
    listNum: {
        fontFamily: 'Roboto', fontSize: '16px', fontWeight: 500
    },
    listName:
    {
        fontFamily: 'Roboto', fontSize: '14px', fontWeight: 400, color: '#7A7A7D'
    },
    assets: {
        fontFamily: 'Roboto', fontSize: '22px', fontWeight: 700, color: 'primary'
    },
    icon: {
        color: '#AAAAAA', marginBottom: '3px'
    },
    driving: {
        color: '#82E219', marginLeft: '-110px'
    },
    drivingR: {
        color: '#ff0000' , marginLeft: '-110px'
    },
    copyRight: {
        fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    height: {
        marginTop:'18px', height:'40px', marginLeft: '8px'
    }

}));

export default function LiveTracker() {
    const dispatch = useDispatch()
    const logged_user = useSelector((store) => store.login.result);
    let enty = logged_user.entity_id
    let roid = logged_user.role_id
    let uId = logged_user.user_id
    const [currIndex, setCurrIndex] = React.useState({});
    const [trackerSearch, setTrackerSearch] = React.useState("");
    const [zoomVar, setZoomVar] = React.useState(0);
    const theme = useTheme();
    const classes = useStyles();
    const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

    const [trackerData, setTrackerData] = React.useState([]);
    const [trackerDetailData, setTrackerDetailData] = React.useState([]);
    const searchDriver = (e, asset_linkage_id) => {
        const getTrackerUrl = endpoints.baseUrl + `/driver/livetrackDetailViewNew/` + asset_linkage_id;
        axios.get(getTrackerUrl, { headers: { 'Authorization': 'bearer aeyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTMsIm1vYmlsZSI6OTg2NTkyNDk1NCwiZXhwIjoxNjUyODY0Nzc4fQ.qe8BWTkJ95KSFr9C0qfwlG3TiVuSFfJ83FBiAcjwIVM' } }).then((response) => {
            setCurrIndex(response.data.data)
dispatch(setLiveTrackerSelected(response.data.data))
dispatch(setLiveTrackerSelected(response.data.data))
        })
    }
 const [refreshRate, setRefreshRate ] = React.useState(false);
 setTimeout(()=>{
    setRefreshRate(!refreshRate)
 },60000)
    React.useEffect(() => {
        let alltrackerData = null;
        let enty1 = enty;

        const getTrackerUrl = endpoints.baseUrl + `/driver/livetracknew/`+ enty1 +`?user_id=`+uId+`&role_id=`+roid+`&search=` + trackerSearch;
        axios.get(getTrackerUrl, { headers: { 'Authorization': 'bearer aeyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTMsIm1vYmlsZSI6OTg2NTkyNDk1NCwiZXhwIjoxNjUyODY0Nzc4fQ.qe8BWTkJ95KSFr9C0qfwlG3TiVuSFfJ83FBiAcjwIVM' } }).then((response) => {
            setTrackerData(response.data.data)
            alltrackerData = response.data;
            
        dispatch(setLiveTrackerList(trackerData, enty));

        }).catch((error) => {
            let status = null;
            let data = null;
            //If no response from server
            if (!error.response) {
                status = 500;
                data = "No response from server";
            } else {
                status = error.response.status;
                data = error.response.data;
            }
            // dispatch({
            //   type: "GET_ALL_ATTRIBUTE_DATA_OVERVIEW_FAILED",
            //   payload: { status, data },
            // });
        });


    }

        , [trackerSearch,refreshRate])


        const [zoom, setZoom] = React.useState(10);



    // const toNormCase = (word) => {

    //     return word ? word.substr(0, 1).toUpperCase() + word.substr(1) : null
    // }
    const validateKeyData = (key) => {
        return key ? key : "-";
    };
    const currDate = new Date().toLocaleDateString();
    const currTime = new Date().toLocaleTimeString();
    return (
        <>

            <Grid container spacing={2}>
                <Grid xs={12} lg={4}>
                    <Item elevation={0}><Paper className={classes.paperHeading} elevation={2}>
                        <Paper className={classes.green} elevation={0}  >
                            <div style={{ color: '#fff', padding: 10, display: 'flex', alignItems: 'center',whiteSpace:'nowrap', justifyContent: 'space-between' }}>
                                <Typography className={classes.assets}>Assets</Typography>
                                <TextField
                                onChange={(e) => {
                                    setTrackerSearch(e.target.value);
                                }}
                                placeholder="Search Vehicle / Driver / Battery"
                                value={trackerSearch}
                                size="small"
                                className={classes.search}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            &nbsp;<SearchIcon className={classes.icon} />
                                        </InputAdornment>
                                    ),
                                }} />
                                {trackerSearch !== "" ? <IconButton onClick={(e) => setTrackerSearch("")} size='small'>
                                    <CloseIcon size='small'

                                    />
                                </IconButton > : null}
                               
                            </div>
                           
                        </Paper>
                        <List style={{width: '100%', backgroundColor: 'background.paper', height: '85%', overflowY: 'scroll'}} >
                            {trackerData.map((item, i) => {
                                // if (item.driver_name.toLowerCase().includes(trackerSearch) || item.driver_name.toLowerCase().includes(trackerSearch)
                                //     || item.vehicle_no.includes(trackerSearch) || item.vehicle_no.toLowerCase(trackerSearch).includes(trackerSearch)
                                // ) {

                                return < ListItem button
                                    onClick={ (e) => { searchDriver(e, item.asset_linkage_id); setZoom(12) } }
                                    className={currIndex.asset_linkage_id === item.asset_linkage_id ? classes.hover : null}
                                    key={i}
                                    style={{ backgroundColor: currIndex.asset_linkage_id === item.asset_linkage_id ? '#68A72480' : '#fff',
                                        }} 
                                    
                                    >

                                    <ListItemAvatar>
                                        {/* {item.driver_id} */}
                                        <Avatar>
                                            <img src={item.vehicle_type === '2 W' ? vech1_a : vech1_a} />
                                        </Avatar>
                                    </ListItemAvatar>  
                                    <ListItemText
                                        primary={
                                            <><Typography style={{fontFamily: "'Roboto', sans-serif", fontSize: '16px', fontWeight: 600, color: '#000' }}>{validateKeyData(item.vehicle_number)}</Typography>
                                            <Typography style={{fontFamily: "'Roboto', sans-serif", fontSize: '16px', fontWeight: 600, color: '#000' }}>{validateKeyData(item.serial_number)}</Typography></>
                                        }
                                        secondary={
                                            <Typography style={{fontFamily: "'Roboto', sans-serif", fontSize: '14px', fontWeight:400, color: '#7A7A7D' }}>{validateKeyData(item.driver_name)}</Typography>
                                        }
                                    />
                                </ListItem>
                                // }
                            })}
                            {/* {JSON.stringify(currIndex)} */}

                        </List>
                    </Paper></Item>
                </Grid>
                <Grid xs={12} lg={8}>
                    <Item elevation={0}><Paper className={classes.map} variant="outlined" elevation={2}>
                        <SimpleMap currIndex={currIndex}
                            zoom={zoom}
                            trackerData={trackerData}
                            searchDriver={searchDriver}
                        />

                    </Paper></Item>
                    {/* <div style={{ display: 'flex' }}>
                            <IconButton onClick={(e) => setZoomVar(zoomVar + 1)} >
                                <AddCircleSharpIcon />
                            </IconButton>
                            <IconButton onClick={(e) => setZoomVar(zoomVar - 1)} >
                                <RemoveCircleOutlinedIcon />
                            </IconButton>
                        </div> */}
                </Grid>
            </Grid>
            <br />

            <Grid container spacing={3}>
                <Grid xs={12} lg={6}>
                    <Item elevation={0}><Paper variant="outlined" elevation={2}>
                        <div style={{ margin: 10 }}>
                            <div style={{ display: 'flex', margin: 10}}>
                                <Typography className={classes.primaryText}>Vehicle Model</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.vehicle_model)}</Typography>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Vehicle Type</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.vehicle_type)}</Typography>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Vehicle Number</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.vehicle_number)}</Typography>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Driver Name</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.driver_name)}</Typography>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Time</Typography>
                                <Typography className={classes.secondaryTextG}> 
                                  {currIndex.created_at}</Typography>
                                  {/* <Typography className={classes.secondaryTextG}> {validateKeyData(currDate)}&nbsp;&nbsp;&nbsp;{validateKeyData(currTime)}</Typography> */}
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Today’s Trip Distance</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData
                                // (toNormCase
                                (currIndex.todays_trip_distance)
                                // )
                                }&nbsp;&nbsp;{"Km"}</Typography>
                            </div>
                            
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Total Odometer</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.total_odometer)}&nbsp;&nbsp;{"Km"} </Typography>
                            </div>
                            
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Distance to Empty</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.distance_to_empty)}&nbsp;&nbsp;{"Km"} </Typography>
                            </div>
                            
                        </div>

                    </Paper></Item>
                </Grid>
                <Grid xs={12} lg={6}>
                    <Item elevation={0}><Paper variant="outlined" elevation={2} >
                        <div style={{ margin: 10 }}>
                       
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Battery Model</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.battery_model)}</Typography>
                            </div>
                            <Divider />

                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Pack Voltage</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.pack_voltage)} V </Typography>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>State Of Charge</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData
                                (currIndex.soc)
                                }&nbsp;&nbsp;{"%"}
                                </Typography>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Current State</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.current_state)}</Typography>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>State Of Health</Typography>
                                <Typography className={classes.secondaryTextG}>{validateKeyData(currIndex.soh)}&nbsp;&nbsp;{"%"}</Typography>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10 }}>
                                <Typography className={classes.primaryText}>Battery Health Status</Typography>
                                <Typography>{
                                // validateKeyData(
                                    // currIndex.battery_health_status)
                                currIndex.battery_health_status === "Green" ? <Brightness1Icon className={classes.driving} /> : 
                                currIndex.battery_health_status === "Red" ? <Brightness1Icon className={classes.drivingR} /> : null
                                // )
                                }
                                {/* <Brightness1Icon className={classes.driving} />  */}
                                </Typography>
                            
                            </div>
                              <Divider />
                              <div style={{ display: 'flex', marginTop:'18px', height:'53px', marginLeft: '8px' }}>
                                <Typography className={classes.primaryText}>Location</Typography>
                                <Typography className={classes.secondaryTextGV}>{validateKeyData(currIndex.location)}</Typography>
                            </div>
                                                   
                             </div>
                    </Paper></Item>

                </Grid>

            </Grid>


            <br />
            <Typography align="center" style={{ fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'}} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
        </>
    )
};