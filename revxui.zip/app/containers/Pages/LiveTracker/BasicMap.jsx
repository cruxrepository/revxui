import React from 'react'
import { GoogleMap,LoadScript, Marker } from '@react-google-maps/api';
import vech2 from "./imgs/vech2.svg";
import vech1 from "./imgs/vech1.svg"
import vech1_a from "./imgs/vech1_a.svg"
import { Icon } from '@iconify/react';
import Badge from '@material-ui/core/Badge';



export default function MyComponent(props) {
  
const containerStyle = {
  width: '100%',
  height: '100%'
};

  const position = {
      lat: 26.772,
      lng: 80.214
    }
  const { zoom,trackerData,searchDriver, currIndex, to, staticContext, ...rest } = props;

  const [newLat, setNewLat] = React.useState(0);
  const [newLan, setNewLan] = React.useState(0);

  // const map = useGoogleMap()

  // React.useEffect(() => {
  //   if (map) {
  //     map.panTo(center)
  //   }
  // }, [map])

  const center = {
    lat: newLat,
    lng: newLan
    // lat: 26.772,
    // lng: 80.214
  };
  React.useEffect(() => {

    setNewLat(parseFloat(currIndex.current_lat)
    //  || 28.6139
     );

    setNewLan(parseFloat(currIndex.current_lan)
    //  || 77.2090
     );
   
  }, [currIndex.current_lat, currIndex.current_lan])
  // const onLoad = marker => {
  //   // var lat = marker.getPosition().lat();
  //   // var lng = marker.getPosition().lng();
  //   if(marker){
  //   setLattitude(marker.getPosition().lat())
  //   setLongitude(marker.getPosition().lng())}
  // }
  return (
    <LoadScript
      googleMapsApiKey="AIzaSyDTqXNwhdiuyeCvRCvFkbPj8NxXpTTHsJU"
    >
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        // panTo={center}
        zoom={zoom}
       // onClick={(ev) => {
      //     setLattitude(ev.latLng.lat())
      //     setLongitude(ev.latLng.lng())
      //   }}
      >


        {trackerData.length !== 1 ? trackerData.map((item, i) => {
          // let id = item.driver_id ? item.driver_id : '-';
          return (
            item.current_lat !== "" ?
            // <Badge badgeContent={item.driver_name} color="primary" >
              <Marker
              // label={item.driver_id}
              // onLoad={((marker) => {
                
              // })} 
              title={item.driver_name}
              onClick={(e)=>{searchDriver(e,item.driver_id);
                }}
                icon={(item.current_lat === currIndex.current_lat) && (item.current_lan === currIndex.current_lan) ? vech1_a : vech1}
                position={{ lat: parseFloat(item.current_lat), lng: parseFloat(item.current_lan) }}
              >


              </Marker>
              //  </Badge>

              : null
          )
        })
      :
      <Marker
      // label={item.driver_id}
      // onLoad={((marker) => {
        
      // })} 
      title={trackerData.driver_id}
      onClick={(e)=>{searchDriver(e,trackerData.driver_id);
        }}
        icon={(trackerData.current_lat === currIndex.current_lat) && (trackerData.current_lan === currIndex.current_lan) ? vech1_a : vech1}
        position={{ lat: parseFloat(trackerData.current_lat), lng: parseFloat(trackerData.current_lan) }}
      >


      </Marker>
      }

      </GoogleMap>
    </LoadScript>
  )
}

