import React from "react";
import GoogleMapReact from "google-map-react";
import { Link } from "react-router-dom";
import vech1 from "./imgs/vech1.svg";
import vech2 from "./imgs/vech2.svg";
import { func } from "prop-types";
const markerStyle = {
  position: "absolute",
  top: "100%",
  left: "50%",
  transform: "translate(-50%, -100%)"
};


export default function SimpleMap(props) {

  const { trackerData, currIndex, to, staticContext, ...rest } = props;


  const mapRef = React.useRef(null);
  const [position, setPosition] =  React.useState({
      lat: 41, 
      lng: -71
  });

  function handleLoad(map) {
    mapRef.current = map;
  }

  function handleCenter() {
    if (!mapRef.current) return;

    const newPos = mapRef.current.getCenter().toJSON();
    setPosition(newPos);
  }

  return (
    <GoogleMapReact
      zoom={4}
      onLoad={handleLoad}
      onDragEnd={handleCenter}
      center={position}
      id="map"
      mapContainerStyle={{
        height: '900px',
        width: '900px'
      }}
      bootstrapURLKeys={{
                  key: "AIzaSyDTqXNwhdiuyeCvRCvFkbPj8NxXpTTHsJU"
                }}
    >
   </GoogleMapReact>

  )














//   const mapRef = React.useRef(null);

//   const { trackerData, currIndex, to, staticContext, ...rest } = props;
//   const [centerVars, setCenterVars] = React.useState({ 
//       lat: 11.15,
//       lng: 76.95
    
//   })
//   // React.useEffect(() => {
//   //   let copy = {};
//   //   copy = centerVars;
//   //   copy.lat =  parseFloat(currIndex.current_lat) || 11.15  ;

//   //   copy.lng = parseFloat(currIndex.current_lan) || 76.95  ;

//   //   setCenterVars(copy)
//   // }, [currIndex])
//   let defaultProps = {
//     center: {
//       lat: 11.15,
//       lng: 76.95

//     },
//     zoom: 7
//   };
//   let locations = [
//     {
//       "id": 123,
//       "title": "Think Company",
//       "website": "www.google.com",
//       "image":
//         "http://thinkcompany.fi/wp-content/uploads/2014/05/hkithinkco04-1024x702.jpg",
//       "address": [


//         {
//           "id": 1236,
//           "country": "Finland",
//           "city": "Helsinki",
//           "street": "Haartmansgatan 4",
//           "postcode": "00290",
//           "lat": "14.158193",
//           "lng": "76.9527614"
//         }
//       ]
//     },
//     {
//       "id": 153,
//       "title": "MS Flux",
//       "website": "www.google.com",
//       "image": " ",
//       "address": [
//         {
//           "id": 1237,
//           "country": "Finland",
//           "city": "Helsinki",
//           "street": "Hogbergsgatan 35",
//           "postcode": "00101",
//           "lat": "60.165238",
//           "lng": "24.946249"
//         }
//       ]
//     }
//   ]
//   function handleCenter() {
//     if (!mapRef.current) return;

//     const newPos = mapRef.current.getCenter().toJSON();
//     setCenterVars(newPos);
//   }
//   function handleLoad(map) {
//     mapRef.current = map;
//   }
//   const newCenter = {
//     center: {
//       // lat:typeof currIndex.current_lan !== 'undefined' ? currIndex.current_lat : 60.165238,
//       // lng:typeof currIndex.current_lan !== 'undefined' ? currIndex.current_lat : 24.946249
//       lat: 60.165238,
//       lng: 24.946249

//     },

//   }
//   return (
//     // Important! Always set the container height explicitly
//     <div style={{ height: "100%", width: "100%" }}>
//       <GoogleMapReact
//         bootstrapURLKeys={{
//           key: "AIzaSyDTqXNwhdiuyeCvRCvFkbPj8NxXpTTHsJU"
//         }}
//         // key={'https://maps.googleapis.com/maps/api/js/AuthenticationService.Authenticate?1shttps%3A%2F%2Frevxenergy.com%2Fcontact-us.php&4sAIzaSyDTqXNwhdiuyeCvRCvFkbPj8NxXpTTHsJU&7m1&1e0&callback=_xdc_._sbhfgd&key=AIzaSyDTqXNwhdiuyeCvRCvFkbPj8NxXpTTHsJU&token=117759'}
     
//         //  defaultCenter={newCenter.center}
//         // defaultZoom={defaultProps.zoom}
//         prerender={true}
//          center={centerVars}
//         onDragEnd={handleCenter}
//         onLoad={handleLoad}
//         id="map"
//         mapContainerStyle={{
//           height: '900px',
//           width: '900px'
//         }}
//       // onMapLoad={(map)=>map.setCenter(marker.getPosition())}
//       // center={{lat:currIndex.current_lat,lan:currIndex.current_lan}}
//       // center={newCenter.center}
//       >

//         {/* <Link 
//            onClick={() => searchDriver()}
//             lat={currIndex.current_lat} lng={currIndex.current_lan}>
//                   <img style={markerStyle} 
//                      src={vech2}
//                        alt="pin" />
//                    </Link> */}
//         {trackerData.map((item, i) => {

//           return (
//             <Link key={i} lat={item.current_lat} lng={item.current_lan}>
//               <img style={markerStyle}
//                 src={vech2}
//                 alt="pin" />
//             </Link>
//           );

//         })}
//       </GoogleMapReact>
//     </div>
//   )
}