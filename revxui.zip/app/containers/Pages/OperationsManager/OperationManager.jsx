import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles, useTheme, styled, withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import SimpleMap from "./SimpleMap";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import Slider from '@material-ui/core/Slider';
import { Icon } from '@iconify/react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import './App3.css';
import logo3 from './imgs/icon-park-outline_delivery.svg';

let id = 0;
function createData(issue, fleet, vehicleNum, overdue) {
    id += 1;
    return {
      id,
      issue,
      fleet,
      vehicleNum,
      overdue
    };
  }

let id1 = 0;
function createData1(vehicleNum, vehicleType, status, location) {
    id1 += 1;
    return {
        id1,
        vehicleNum,
        vehicleType,
        status,
        location
    };
}
let id2 = 0;
function createData2(driverid, name, contact, status) {
    id2 += 1;
    return {
        id2,
        driverid, name, contact, status
    };
}

let id3 = 0;
function createData3(deliveryid, consignid, client) {
    id3 += 1;
    return {
        id3,
        deliveryid, consignid, client
    };
}
const data = [
    createData('Battery Low Soh', 'EVIFY','TN 01 A 0001', '10/06/2022'),
    createData('Motor Controller High temperature', 'EVIFY','TN 02 B 0002', '25/07/2022'),
    createData('Low Fleet Utilisation', 'Moeving','TN 03 C 0003', '27/08/2022'),
    createData('Battery Pack Short Circuit', 'Moeving','TN 04 D 0004', '8/06/2022'),
    createData('Low Fleet Utilisation', 'Moeving','TN 03 C 0003', '27/08/2022'),

  ];
  const data1 = [
    createData1('TN 01 A 0001', '2W', 'Healthy', 'CBE'),
    createData1('TN 01 A 0001', '3W', 'Unhealthy', 'CBE'),
    createData1('TN 01 A 0001', '2W', 'Healthy', 'CBE'),
    createData1('TN 01 A 0001', '3W', 'Unhealthy', 'CBE')

];

const data2 = [
    createData2('ID1589', 'Sathish', '9988776655', 'Available'),
    createData2('ID1679', 'Ram', '9876543210', 'Not Available'),
    createData2('ID1669', 'Mani', '6383536321', 'Available'),
    createData2('ID1269', 'Hari', '9944210012', 'Not Available')
];

const data3 = [
    createData3('DL1589', 'ID7456', 'Bigbasket'),
    createData3('DL1679', 'ID1256', 'TL logis'),
    createData3('DL1669', 'ID5684', 'Bigbasket'),
    createData3('DL1269', 'ID1023', 'Mss logi'),
];

const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'left',
    color: theme.palette.text.secondary,
}));
const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.secondary.dark,
        backgroundColor: theme.palette.secondary.light,
    },
    map: {
        height: 320, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    turingX: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#009688', letterSpacing: '0.03em', marginLeft: 25
    },
    box: {
        border: '1px solid #009688', height: '100px', borderRadius: '40px', backgroundColor: '#F8F8F8'

    },
    box1: {
        height: '170px', borderRadius: '23px', backgroundColor: '#E5E5E5', marginTop: 50, margin: 20

    },
    copyRight: {
        fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    drive: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#000000', margin: 35
    },
    drive1: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#00000080', marginLeft: '180px', marginTop: '-65px'
    },
    paperH: {
        height: '350px', border: '1px solid #D8D8D8'
    },
    paperH1: {
        height: '200px', border: '1px solid #D8D8D8'
    },
    paperH2: {
        height: '230px', border: '1px solid #D8D8D8'
    },
    paperH3: {
        height: '200px', border: '1px solid #D8D8D8'
    },
    slide: {
        margin: 20
    },
    slider: {
        '& > .MuiSlider-thumbColorPrimary': { opacity: '0 !important' },
        color: '#009688', borderRadius: '0px',
        '& > .MuiSlider-rail': { height: '5px', color: '#C4C4C4' }, '& > .MuiSlider-track': { height: '5px' },
        marginTop: '-5px'
    },
    sliderTxt: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 600
    },
    sliderTxt2: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 500, color: '#5F6368', marginLeft: '125px', marginTop: '-30px'
    },
    icon: {
        marginLeft: 45
    },
    iconS: {
        marginLeft: 20
    },
    iconSM: {
        marginLeft: 20
    },
    gridBG: {
        backgroundColor: '#009688CC'
    },
    gridFont: {
        fontSize: '3rem', color: '#ffffff'
    },
    gridFont2: {
        color: '#ffffff'
    },
    gridIcon: {
        float: 'right', fontSize: '3rem', marginTop: '20px', color: '#ffffff'
    },
    rootTable: {
        width: '100%', margin: 0
    },
    title: {
        backgroundColor: '#009688CC'
    },
    titleFont: {
        color: '#FFFFFF', fontSize: '15px', fontWeight: 600
    },
    titleFontM: {
        color: '#FFFFFF', fontSize: '12px', fontWeight: 600
    },
    text1: {
        fontFamily: 'Maven Pro', fontSize: '15px', fontWeight: 600, color: '#7A7A7D'
    },
    text1L: {
        fontFamily: 'Maven Pro', fontSize: '15px', fontWeight: 600, color: '#7A7A7D' 
    },
    text1M: {
        fontFamily: 'Maven Pro', fontSize: '11px', fontWeight: 600, color: '#7A7A7D'
    },
    text1M2: {
        fontFamily: 'Maven Pro', fontSize: '13px', fontWeight: 600, color: '#7A7A7D'
    },
    text1A: {
        fontFamily: 'Maven Pro',fontSize: '15px', fontWeight: 400,color:'#000000' 
        },
    text1AM: {
        fontFamily: 'Maven Pro',fontSize: '10px', fontWeight: 400,color:'#000000' 
            },
    text2: {
        fontFamily: 'Maven Pro',fontSize: '15px', fontWeight: 400,color:'#FF0B0B'
    },
    text2M: {
        fontFamily: 'Maven Pro',fontSize: '10px', fontWeight: 400,color:'#FF0B0B'}




}));
const PrettoSlider = withStyles({
    root: {
        color: '#68A724B2',
        height: 8,
    },
    thumb: {
        height: 24,
        width: 24,
        backgroundColor: '#fff',
        border: '2px solid currentColor',
        marginTop: -8,
        marginLeft: -12,
        '&:focus,&:hover,&$active': {
            boxShadow: 'inherit',
        },
    },
    active: {},
    valueLabel: {
        left: 'calc(-50% + 4px)',
    },
    track: {
        height: 8,
        borderRadius: 4,
        color: '#68A724B2'
    },
    rail: {
        height: 8,
        borderRadius: 4,
        color: '#FFFFFF'
    },
})(Slider);

export default function RevxAdmin() {


    const [trackerSearch, setTrackerSearch] = React.useState("");
    const [zoomVar, setZoomVar] = React.useState(0);
    const theme = useTheme();
    const classes = useStyles();
    const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

    return (
        <>

            <div className={classes.root}>
                <Grid container spacing={2}>
                    <Grid item xs={6} lg={3} >
                        <Item className={classes.gridBG}>
                            < Typography className={classes.gridFont}> 40
                                <Icon icon="mdi:card-account-details" color="white" className={classes.gridIcon} />
                            </Typography>
                            <Typography className={classes.gridFont2}> Available Drivers</Typography >
                        </Item>
                    </Grid>
                    <Grid item xs={6} lg={3} >
                        <Item className={classes.gridBG}>
                            < Typography className={classes.gridFont}> 40
                                <Icon icon="mdi:truck" color="white" className={classes.gridIcon} />
                            </Typography>
                            <Typography className={classes.gridFont2}>Available Vehicle</Typography >
                        </Item>
                    </Grid>
                    <Grid item xs={6} lg={3} >
                        <Item className={classes.gridBG}>
                            < Typography className={classes.gridFont}>4
                                <Icon icon="mdi:message-alert-outline" color="white" className={classes.gridIcon} />

                            </Typography>
                            <Typography className={classes.gridFont2}>Issues Card</Typography >
                        </Item>
                    </Grid>
                    <Grid item xs={6} lg={3} >
                        <Item className={classes.gridBG}>
                            < Typography className={classes.gridFont}>100
                                <img src={logo3} className={classes.gridIcon} />
                            </Typography>
                            <Typography className={classes.gridFont2}>Delivery Completed</Typography >
                        </Item>
                    </Grid>


                    <Grid item xs={12} lg={6}>
                        <Paper className={classes.map} variant="outlined" >
                            <SimpleMap
                                zoom={zoomVar}
                            />

                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={6}>
                        <Paper 
                        // className={isMdUp === true ? classes.paperH1 : classes.paperH2}
                        >
                            <Typography align="center" className={classes.turingX}>Vehicle Assignment</Typography> 
                            <Box className={classes.slide}>
                                <Typography className={classes.sliderTxt}>2 W
                                    <Icon className={classes.icon} icon="mdi:motorbike" color="#009688" width="30" height="30" hFlip={true} />
                                    <Typography className={classes.sliderTxt2}>30/100</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={30} />
                                <br /><br /> 
                                <Typography className={classes.sliderTxt}>3 W
                                    <Icon className={classes.icon} icon="mdi:rickshaw" color="#000000" width="30" height="30" hFlip={true} />
                                    <Typography className={classes.sliderTxt2}>90/200</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={45} />
                                <br /> <br />
                                <Typography className={classes.sliderTxt}>Battery
                                    <Icon className={isMdUp === true ? classes.iconS : classes.iconSM} icon="mdi:car-battery" color="#009688" width="30" height="30" hFlip={true} />
                                    <Typography className={classes.sliderTxt2}>300/700</Typography></Typography>
                                <Slider className={classes.slider} size="medium" defaultValue={43} />
                               </Box><br />
                        </Paper>
                    </Grid>

                    <Grid item xs={12} lg={7}>
                        <Paper>
                            <Table className={classes.rootTable}>
                                <TableHead className={classes.title}>
                                    <TableRow>
                                        <TableCell padding="normal" className={classes.titleFont}>Open Issue</TableCell>
                                        <TableCell padding="center" className={classes.titleFont}>Fleet Operator</TableCell>
                                        <TableCell padding="center" className={classes.titleFont}>Vehicle Number</TableCell>
                                        <TableCell align="right" className={classes.titleFont}>Overdue  Date</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {data.map(n => ([
                                        <TableRow key={n.id}>
                                            <TableCell className={isMdUp === true ? classes.text1A : classes.text1AM} >{n.issue}</TableCell>
                                            <TableCell className={isMdUp === true ? classes.text1A : classes.text1AM}>{n.fleet}</TableCell>
                                            <TableCell className={isMdUp === true ? classes.text1A : classes.text1AM}>{n.vehicleNum}</TableCell>
                                            <TableCell align="right" className={isMdUp === true ? classes.text2 : classes.text2M}>{n.overdue}</TableCell>
                                        </TableRow>
                                    ]))}
                                </TableBody>
                            </Table>
                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={5}>
                        <Paper 
                        // className={isMdUp === true ? classes.paperH2 : classes.paperH3}
                        >
                            <Table className={classes.rootTable}>
                                <TableHead className={classes.title}>
                                    <TableRow>
                                        <TableCell />
                                        <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM} >Unassigned/Pending Delivery</TableCell>
                                        <TableCell />
                                    </TableRow>
                                    <TableRow>
                                        <TableCell padding="normal" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Delivery ID</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Consignment  ID</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Client</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {data3.map(n => ([
                                        <TableRow key={n.id3}>
                                            <TableCell padding="normal" className={isMdUp === true ? classes.text1 : classes.text1M} >{n.deliveryid}</TableCell>
                                            <TableCell align="center" className={isMdUp === true ? classes.text1 : classes.text1M}>{n.consignid}</TableCell>
                                            <TableCell align="right" className={isMdUp === true ? classes.text1 : classes.text1M}>{n.client}</TableCell>
                                        </TableRow>
                                    ]))}
                                </TableBody>
                            </Table>
                        </Paper>
                    </Grid>
                   


                    <Grid item xs={12} lg={6}>
                        <Paper 
                        // className={isMdUp === true ? classes.paperH2 : classes.paperH3}
                        >
                            <Table className={classes.rootTable}>
                                <TableHead className={classes.title}>
                                    <TableRow>
                                        <TableCell />
                                        <TableCell align="right" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Unassigned</TableCell>
                                        <TableCell align="left" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Drivers</TableCell>
                                        <TableCell />
                                    </TableRow>
                                    <TableRow>
                                        <TableCell padding="normal" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Driver ID</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Drivers Name</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Contact</TableCell>
                                        <TableCell align="center" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Status</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {data2.map(n => ([
                                        <TableRow key={n.id2}> 
                                            <TableCell className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.driverid}</TableCell>
                                            <TableCell align="center" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.name}</TableCell>
                                            <TableCell align="center"className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.contact}</TableCell>
                                            <TableCell align="right" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.status}</TableCell>

                                        </TableRow>
                                    ]))}
                                </TableBody>
                            </Table>
                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={6}>
                        <Paper 
                        // className={isMdUp === true ? classes.paperH2 : classes.paperH3}
                        >
                            <Table className={classes.rootTable}>
                                <TableHead className={classes.title}>
                                    <TableRow>
                                        <TableCell />
                                        <TableCell align="right" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Unassigned</TableCell>
                                        <TableCell align="left" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Vehicle</TableCell>
                                        <TableCell />
                                    </TableRow>
                                    <TableRow>
                                        <TableCell padding="normal" className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Vehicle Number</TableCell>
                                        <TableCell align="center"className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Vehicle Type</TableCell>
                                        <TableCell align="center"className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Health Status</TableCell>
                                        <TableCell align="center"className={isMdUp === true ? classes.titleFont : classes.titleFontM}>Location</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {data1.map(n => ([
                                        <TableRow key={n.id1}>
                                            <TableCell className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.vehicleNum}</TableCell>
                                            <TableCell align="center" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.vehicleType}</TableCell>
                                            <TableCell align="center" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.status}</TableCell>
                                            <TableCell align="right" className={isMdUp === true ? classes.text1 : classes.text1M2}>{n.location}</TableCell>
                                        </TableRow>
                                    ]))}
                                </TableBody>
                            </Table>
                        </Paper>
                    </Grid> 

                </Grid>
            </div>
            <br />
            <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt.Ltd. </Typography>
        </>
    )
};
