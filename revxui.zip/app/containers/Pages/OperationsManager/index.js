import React from 'react';
import { Helmet } from 'react-helmet';
import brand from 'enl-api/dummy/brand';
import { PapperBlock } from 'enl-components';
import CompossedLineBarArea from './CompossedLineBarArea';
import StrippedTable from '../Table/StrippedTable';
import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import OperationManager from './OperationManager';
import PageTitle from '../../../components/Utils/PageTitle';
function BasicTable() {
  const title = brand.name + ' - Dashboard';
  const description = brand.desc;
  const loc = location.pathname;
  return (
    <div>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="twitter:title" content={title} />
        <meta property="twitter:description" content={description} />
      </Helmet>
      <Typography component="h4" variant="h4" 
      style={{color:'#68A724',margin:5, fontFamily:'Maven Pro', fontWeight:600}}>Operations Manager</Typography>
      <Button href="/app/pages/dashboard" variant={loc === '/app/pages/dashboard' ? "contained" : "outlined"} color="primary">
      ReVx Admin 
          </Button>&nbsp;
          <Button href="/app/pages/fleetmanager" variant={loc === '/app/pages/fleetmanager' ? "contained" : "outlined"} color="primary">
          Fleet Manager
          </Button>&nbsp;
          <Button href="/app/pages/operationsmanager" variant={loc === '/app/pages/operationsmanager' ? "contained" : "outlined"} color="primary">
          Operations Manager
          </Button>&nbsp;
          <Button href="/app/pages/vehicleinvestor" variant={loc === '/app/pages/vehicleinvestor' ? "contained" : "outlined"} color="primary">
          Vehicle Investor
          </Button>&nbsp;
          <Button href="/app/pages/batteryinvestor" variant={loc === '/app/pages/batteryinvestor' ? "contained" : "outlined"} color="primary">
          Battery Investor
          </Button>
          <br /><br />
       <Box><OperationManager /></Box>
      {/* <PapperBlock title="Statistic Chart" icon="insert_chart" desc="" overflowX>
        <div>
          <CompossedLineBarArea />
        </div>
      </PapperBlock>
      <PapperBlock title="Table" whiteBg icon="grid_on" desc="UI Table when no data to be shown">
        <div>
          <StrippedTable />
        </div>
      </PapperBlock> */}
    </div>
  );
}

export default BasicTable;
