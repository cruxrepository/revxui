import React, { PureComponent, useState } from 'react';
import {
  Label,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceArea,
  ResponsiveContainer,
} from 'recharts';
import ListItem from '@material-ui/core/ListItem';

const initialData = [
  { name: 1, CV1: 4.11, CV2: 7.11, CV3: 10, CV4: 1.11, CV5: 11.11, CV6: 20 },
  { name: 2, CV1: 2.39, CV2: 9.39, CV3: 12, CV4: 7.39, CV5: 6.39, CV6: 42 },
  { name: 3, CV1: 3.39, CV2: 6.39, CV3: 15, CV4: 6.39, CV5: 9.39, CV6: 25 },
  { name: 4, CV1: 5.39, CV2: 5.39, CV3: 18, CV4: 2.39, CV5: 2.39, CV6: 8 },
  { name: 5, CV1: 6.29, CV2: 21.29, CV3: 20, CV4: 3.29, CV5: 11.29, CV6: 30 },
  { name: 6, CV1: 3, CV2: 3.88, CV3: 19, CV4: 3, CV5: 4.88, CV6: 10 },
  { name: 7, CV1: 0.53, CV2: 5.53, CV3: 5, CV4: 2.39, CV5: 2.39, CV6: 8 },
  { name: 8, CV1: 2.52, CV2: 9.52, CV3: 10, CV4: 1.11, CV5: 11.11, CV6: 20 },
  { name: 9, CV1: 1.79, CV2: 11.79, CV3: 20, CV4: 6.39, CV5: 9.39, CV6: 25 },
  { name: 10, CV1: 2.94, CV2: 5.94, CV3: 22, CV4: 3, CV5: 4.88, CV6: 10 },
  { name: 11, CV1: 4.3, CV2: 2.3, CV3: 21, CV4: 1.11, CV5: 11.11, CV6: 20 },
  { name: 12, CV1: 4.41, CV2: 8.41, CV3: 30, CV4: 3.29, CV5: 11.29, CV6: 30 },
  { name: 13, CV1: 2.1, CV2: 0.1, CV3: 5, CV4: 6.39, CV5: 9.39, CV6: 25 },
  { name: 14, CV1: 6, CV2: 6.6, CV3: 19, CV4: 3.29, CV5: 11.29, CV6: 30 },
  { name: 15, CV1: 0, CV2: 8.0, CV3: 30, CV4: 1.11, CV5: 11.11, CV6: 20 },
  { name: 16, CV1: 6, CV2: 7.6, CV3: 40, CV4: 3, CV5: 4.88, CV6: 10 },
  { name: 17, CV1: 3, CV2: 4.3, CV3: 20, CV4: 3, CV5: 4.88, CV6: 10 },
  { name: 18, CV1: 2, CV2: 2.2, CV3: 50, CV4: 6.39, CV5: 9.39, CV6: 25 },
  { name: 19, CV1: 3, CV2: 0.3, CV3: 10, CV4: 1.11, CV5: 11.11, CV6: 20 },
  { name: 20, CV1: 7, CV2: 1.7, CV3: 10, CV4: 7.39, CV5: 6.39, CV6: 42 }
];

const getAxisYDomain = (from, to, ref, offset) => {
  const refData = initialData.slice(from - 1, to);
  let [bottom, top] = [refData[0][ref], refData[0][ref]];
  refData.forEach((d) => {
    if (d[ref] > top) top = d[ref];
    if (d[ref] < bottom) bottom = d[ref];
  });

  return [(bottom | 0) - offset, (top | 0) + offset];
};

const initialState = {
  data: initialData,
  left: 'dataMin',
  right: 'dataMax',
  refAreaLeft: '',
  refAreaRight: '',
  top: 'dataMax+1',
  bottom: 'dataMin-1',
  top2: 'dataMax+20',
  bottom2: 'dataMin-20',
  animation: true,
};

export default class Example extends PureComponent {
  static demoUrl = 'https://codesandbox.io/s/highlight-zomm-line-chart-v77bt';

  constructor(props) {
    super(props);
    this.state = initialState;
  }

  zoom() {
    let { refAreaLeft, refAreaRight } = this.state;
    const { data } = this.state;

    if (refAreaLeft === refAreaRight || refAreaRight === '') {
      this.setState(() => ({
        refAreaLeft: '',
        refAreaRight: '',
      }));
      return;
    }

    // xAxis domain
    if (refAreaLeft > refAreaRight) [refAreaLeft, refAreaRight] = [refAreaRight, refAreaLeft];

    // yAxis domain
    const [bottom, top] = getAxisYDomain(refAreaLeft, refAreaRight, 'CV1', 1);
    const [bottom2, top2] = getAxisYDomain(refAreaLeft, refAreaRight, 'CV2', 50);
    // const [checked, setChecked] = useState(['CV1', 'CV2']);

    // const handleChange = event => {
    //   setCoin(event.target.value);
    // };

    // const handleToggle = value => () => {
    //   const currentIndex = checked.indexOf(value);
    //   const newChecked = [...checked];

    //   if (currentIndex === -1) {
    //     newChecked.push(value);
    //   } else {
    //     newChecked.splice(currentIndex, 1);
    //   }

    //   setChecked(newChecked);
    // };

    this.setState(() => ({
      refAreaLeft: '',
      refAreaRight: '',
      data: data.slice(),
      left: refAreaLeft,
      right: refAreaRight,
      bottom,
      top,
      bottom2,
      top2,
    }));
  }

  zoomOut() {
    const { data } = this.state;
    this.setState(() => ({
      data: data.slice(),
      refAreaLeft: '',
      refAreaRight: '',
      left: 'dataMin',
      right: 'dataMax',
      top: 'dataMax+1',
      bottom: 'dataMin',
      top2: 'dataMax+50',
      bottom2: 'dataMin+50',
    }));
  }

  render() {
    const { data, barIndex, left, right, refAreaLeft, refAreaRight, top, bottom, top2, bottom2 } = this.state;


    return (
      <div className="highlight-bar-charts" style={{ userSelect: 'none', width: '100%' }}>
        <button type="button" className="btn update" onClick={this.zoomOut.bind(this)}>
          Zoom Out
        </button>
        {/* <ListItem
          // role={undefined}
          dense
          button
          onClick={handleToggle('CV1')}
          className={classes.listItem}
        >
          <Checkbox
            checked={checked.indexOf('CV1') !== -1}
            tabIndex={-1}
            disableRipple
          />
          <ListItemText style={{ fontSize: '12px' }}>Pack Voltage</ListItemText>
        </ListItem> */}
        <ResponsiveContainer width="100%" height={400}>
          <LineChart
            width={800}
            height={400}
            data={data}
            onMouseDown={(e) => this.setState({ refAreaLeft: e.activeLabel })}
            onMouseMove={(e) => this.state.refAreaLeft && this.setState({ refAreaRight: e.activeLabel })}
            // eslint-disable-next-line react/jsx-no-bind
            onMouseUp={this.zoom.bind(this)}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis allowDataOverflow dataKey="name" domain={[left, right]} type="number" />
            <YAxis allowDataOverflow domain={[bottom, top]} type="number" yAxisId="1" />
            <YAxis orientation="right" allowDataOverflow domain={[bottom2, top2]} type="number" yAxisId="2" />
            <Tooltip />
            {/* {checked.indexOf('CV1') > -1 && <Line yAxisId="1" type="natural" dataKey="CV1" stroke="#8884d8" animationDuration={300} dot={false} />} */}

            <Line yAxisId="1" type="natural" dataKey="CV1" stroke="#8884d8" animationDuration={300} dot={false} />
            <Line yAxisId="2" type="natural" dataKey="CV2" stroke="#82ca9d" animationDuration={300} dot={false} />

            {refAreaLeft && refAreaRight ? (
              <ReferenceArea yAxisId="1" x1={refAreaLeft} x2={refAreaRight} strokeOpacity={0.3} />
            ) : null}
          </LineChart>
        </ResponsiveContainer>
      </div>
    );
  }
}
