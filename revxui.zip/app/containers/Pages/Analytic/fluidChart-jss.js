const styles = {
  chartFluid: {
    width: '100%',
    // boxShadow:'2px 2px 2px #cfcfcf',
    fontSize:12,
    // minWidth: 400,
    maxWidth: 300,
    height: 300
  }
};

export default styles;
