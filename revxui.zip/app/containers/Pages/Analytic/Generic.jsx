import React from "react";
import Select from "@material-ui/core/Select";
import { MenuItem, Typography, Button, Box, Collapse } from "@material-ui/core";
import { Icon } from "@iconify/react";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormGroup from "@material-ui/core/FormGroup";
import Checkbox from "@material-ui/core/Checkbox";
import Highcharts from "highcharts";
import gantt from "highcharts/highcharts.src";
import HighchartsReact from "highcharts-react-official";
import axios from "axios";
import moment from "moment";
import endpoints from "../../../endpoints/endpoints";
import Loading from "../../../components/Loading";
import { cp } from "fs";
import { number } from "prop-types";
import { XAxis } from "recharts";
import { Grid } from "@material-ui/core";
export default function Example(props) {
  const { logged_user, imei } = props;
  const [loading, setLoading] = React.useState(true);
  const [chartData, setChartData] = React.useState({
    battVData: "",
    battCData: "",
    // extVoltage: "",
    soc: "",
    soh: "",
    // totOdo: "",
    cellTemps: "",
  });
  const [checkState, setCheckState] = React.useState({
    cellTemp: false,
    cellVolt: false,
  });
  const [checkData, setCheckData] = React.useState({
    batVolt: false,
    batCurr: false,
    soc: false,
    soh: false,
  });

  const [selectedImei, setSelectedImei] = React.useState("");
  const [batteryDrop, setBatteryDrop] = React.useState("");
  const [tmpT, setTmT] = React.useState(false);
  const [voltT, setVolT] = React.useState(false);
  const [timeLine, setTimeLine] = React.useState("");
  const [stepVal, setStepVal] = React.useState(100);
  // const [battVData, setBattVData ] = React.useState("");
  // const [battCData, setBattCData ] = React.useState("");
  // const [extVoltage, setExtVoltage ] = React.useState("");
  let timeData = [];
  // let entityId = logged_user.entity_id;
  let cellTempDataset = "";
  let cellVoltageDataset = "";

  //   console.log("chartData.seriesDataF", chartData.seriesDataF);

  // React.useEffect(() => {
  //   let BatteryData = endpoints.baseUrl + `/battery/get/` + entityId;
  //   axios
  //     .get(BatteryData)
  //     .then((response) => {
  //       let data = response.data.data;
  //       setBatteryDrop(data);
  //       console.log(
  //         "data.filter(word => word.imei)",
  //         data.filter((word) => word.imei !== "")
  //       );
  //       setSelectedImei(data.filter((word) => word.imei !== "")[0].imei);
  //     })
  //     .catch((error) => {});
  // }, []);

  React.useEffect(() => {
    setLoading(true);
    let battC = [];
    let battV = [];
    // let battExV = [];
    let battSoc = [];
    let battSoh = [];
    // let battTotOdo = [];
    // let newImei = selectedImei ? selectedImei : 352625695105765;
    let Url = endpoints.baseUrl + `/battery/chart?imei=` + imei;
    axios.get(Url).then((response) => {
      setChartData(response.data.data[0]);
      const finalData = response.data.data[0];
      let cellTemps = [];
      let cellVolts = [];
      //   let i = 0;
      let len = 0;
      finalData.map((element, i) => {
        len = Object.keys(element.temp).length;
        let tempRow = element.temp;
        let voltRow = element.volt;

        cellTemps.push(tempRow);
        cellVolts.push(voltRow);

        timeData.push(element.time.toString());
        battV.push(element.battery_voltage);
        battC.push(element.battery_current);
        battSoc.push(element.soc);
        battSoh.push(element.soh);
      });
      let axisData = [
        {
          name: "Battery Voltage",
          type: "spline",
          visible: checkData.batVolt ? true : false,

          yAxis: 0,
          data: battV,
          tooltip: {
            valueSuffix: " V",
          },
          marker: {
            enabled: false,
          },
        },
        {
          name: "Battery Current",
          type: "spline",
          visible: checkData.batCurr ? true : false,

          yAxis: 1,
          data: battC,
          marker: {
            enabled: false,
          },
          // dashStyle: 'shortdot',
          tooltip: {
            valueSuffix: " A",
          },
        },
        {
          name: "SOC",
          type: "spline",
          visible: checkData.soc ? true : false,

          yAxis: 2,

          data: battSoc,
          marker: {
            enabled: false,
          },
          tooltip: {
            valueSuffix: " %",
          },
        },
        {
          name: "SOH",
          type: "spline",
          yAxis: 3,
          visible: checkData.soh ? true : false,

          data: battSoh,
          marker: {
            enabled: false,
          },
          tooltip: {
            valueSuffix: " %",
          },
        },
      ];
      let seriesData = [
        {
          // Primary yAxis
          labels: {
            format: "{value} V",
            style: {
              color: Highcharts.getOptions().colors[0],
            },
          },
          showEmpty: false,
          title: {
            text: "Battery Voltage",
            style: {
              color: Highcharts.getOptions().colors[0],
            },
          },
          opposite: true,
        },
        {
          // Secondary yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "Battery Current",
            style: {
              color: Highcharts.getOptions().colors[1],
            },
          },
          labels: {
            format: "{value} A",
            style: {
              color: Highcharts.getOptions().colors[1],
            },
          },
        },
        {
          // 4 yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "SOC",
            style: {
              color: Highcharts.getOptions().colors[2],
            },
          },
          labels: {
            format: "",
            style: {
              color: Highcharts.getOptions().colors[2],
            },
          },
          // opposite: true
        },
        {
          // 5 yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "SOH",
            style: {
              color: Highcharts.getOptions().colors[3],
            },
          },
          labels: {
            format: "",
            style: {
              color: Highcharts.getOptions().colors[3],
            },
          },
          opposite: false,
        },
      ];
      let dataCellTempsAll = [];
      let dataCellVoltsAll = [];

      // if (tmpT) {
      let initState = checkData;
      for (let k = 0; k < Object.keys(cellTemps[0]).length; k++) {
        let newName = Object.keys(cellTemps[0])[k];
        // console.log("newName", newName);
        setCheckData((state) => ({ ...state, [newName]: false }));

        let dataCellTemps = {};
        dataCellTemps[Object.keys(cellTemps[0])[k]] = [];
        for (let j = 0; j < cellTemps.length; j++) {
          //   let newData = [];
          let name = Object.keys(cellTemps[0])[k];
          //   console.log("name", name);
          dataCellTemps[name].push(cellTemps[j][name]);
        }
        dataCellTempsAll.push(dataCellTemps);
      }
      cellVoltageDataset = dataCellTempsAll[0];

      for (let l = 0; l < Object.keys(cellTemps[0]).length; l++) {
        let newEntry = {};
        let newEntryS = {};
        Object.assign(newEntry, {
          name: "Cell Temp " + Number(l + 1),
          type: "spline",
          visible: false,

          yAxis: 4,
          tooltip: {
            valueSuffix: " C",
          },
          data: dataCellTempsAll[l]["cell_temp_" + Number(l + 1)],
        });
        Object.assign(newEntryS, {
          gridLineWidth: 0,
          opposite: false,
          visible: l !== 0 ? false : true,
          // zoomEnabled: false,
          showEmpty: false,

          title: {
            // text: "Cell Temperature " + Number(l + 1),
            text: "Cell Temperature",
            style: {
              color: Highcharts.getOptions().colors[Number(l + 4)],
            },
          },
          //  min:-100,
          //   max:100,
          labels: {
            enabled: l !== 0 ? false : true,

            style: {
              color: Highcharts.getOptions().colors[Number(l + 4)],
              // fontFamily:'inherit'
            },
          },
        });
        //   newEntry.marker.enabled = false;
        //   newEntry.tooltip.valueSuffix = ' V';

        axisData.push(newEntry);

        //   newEntryS.title.style.color = Highcharts.getOptions().colors[l+4];
        //   newEntryS.labels.style.color = Highcharts.getOptions().colors[l+4];
        seriesData.push(newEntryS);
      }
      // }

      // console.log(
      //   "Object.keys(cellVolts[0]).length",
      //   Object.keys(cellVolts[0]).length
      // );
      // if (voltT) {
      if (Object.keys(cellVolts[0]).length !== 0) {
        for (let k = 0; k < Object.keys(cellVolts[0]).length; k++) {
          let dataCellTemps = {};
          let newName = Object.keys(cellVolts[0])[k];
          // console.log("newName", newName);
          setCheckData((state) => ({ ...state, [newName]: false }));
          dataCellTemps[Object.keys(cellVolts[0])[k]] = [];
          for (let j = 0; j < cellVolts.length; j++) {
            //   let newData = [];
            let name = Object.keys(cellVolts[0])[k];
            //   console.log("name", name);
            dataCellTemps[name].push(cellVolts[j][name]);
          }
          dataCellVoltsAll.push(dataCellTemps);
        }
        cellTempDataset = dataCellVoltsAll[0];
        for (let l = 0; l < Object.keys(cellVolts[0]).length; l++) {
          let newEntry = {};
          let newEntryS = {};
          Object.assign(newEntry, {
            name: "Cell Volt " + Number(l + 1),
            type: "spline",
            visible: false,

            yAxis: (Object.keys(cellTemps[0]).length || 0) + 4,
            tooltip: {
              valueSuffix: " V",
            },
            data: dataCellVoltsAll[l]["cell_volt_" + Number(l + 1)],
          });
          Object.assign(newEntryS, {
            gridLineWidth: 0,
            opposite: false,
            visible: l !== 0 ? false : true,
            // zoomEnabled: false,
            showEmpty: false,

            title: {
              // text: "Cell Temperature " + Number(l + 1),
              text: "Cell Voltage",
              style: {
                color: Highcharts.getOptions().colors[
                  Number(Object.keys(cellTemps[0]).length + 4)
                ],
              },
            },
            //  min:-100,
            //   max:100,
            labels: {
              enabled: l !== 0 ? false : true,

              style: {
                color: Highcharts.getOptions().colors[
                  Number(Object.keys(cellTemps[0]).length + 4)
                ],
                // fontFamily:'inherit'
              },
            },
          });
          //   newEntry.marker.enabled = false;
          //   newEntry.tooltip.valueSuffix = ' V';

          axisData.push(newEntry);

          //   newEntryS.title.style.color = Highcharts.getOptions().colors[l+4];
          //   newEntryS.labels.style.color = Highcharts.getOptions().colors[l+4];
          seriesData.push(newEntryS);
        }
      }
      // }

      //   console.log("cellVoltageDataset", dataCellTempsAll);

      //   console.log("axisData", axisData);
      //   console.log("seriesData", seriesData);
      setTimeLine(timeData);
      setChartData((state) => ({
        ...state,
        battCData: battC,
        battVData: battV,
        //   extVoltage:battExV,
        soc: battSoc,
        soh: battSoh,
        cellTemps: cellVoltageDataset,
        axisDataF: axisData,
        seriesDataF: seriesData,
        // totOdo:battTotOdo,
      }));

      setLoading(false);
    });
  }, [tmpT, voltT]);
  // console.log("finalData", checkData);
  React.useEffect(() => {
    setLoading(true);
    let battC = [];
    let battV = [];
    // let battExV = [];
    let battSoc = [];
    let battSoh = [];
    // let battTotOdo = [];
    // let newImei = selectedImei ? selectedImei : 352625695105765;
    let Url = endpoints.baseUrl + `/battery/chart?imei=` + imei;
    axios.get(Url).then((response) => {
      setChartData(response.data.data[0]);
      const finalData = response.data.data[0];
      let cellTemps = [];
      let cellVolts = [];
      //   let i = 0;
      let len = 0;
      finalData.map((element, i) => {
        len = Object.keys(element.temp).length;
        let tempRow = element.temp;
        let voltRow = element.volt;

        cellTemps.push(tempRow);
        cellVolts.push(voltRow);

        timeData.push(element.time.toString());
        battV.push(element.battery_voltage);
        battC.push(element.battery_current);
        battSoc.push(element.soc);
        battSoh.push(element.soh);
      });
      let axisData = [
        {
          name: "Battery Voltage",
          type: "spline",
          visible: checkData.batVolt ? true : false,

          yAxis: 0,
          data: battV,
          tooltip: {
            valueSuffix: " V",
          },
          marker: {
            enabled: false,
          },
        },
        {
          name: "Battery Current",
          type: "spline",
          visible: checkData.batCurr ? true : false,

          yAxis: 1,
          data: battC,
          marker: {
            enabled: false,
          },
          // dashStyle: 'shortdot',
          tooltip: {
            valueSuffix: " A",
          },
        },
        {
          name: "SOC",
          type: "spline",
          visible: checkData.soc ? true : false,

          yAxis: 2,

          data: battSoc,
          marker: {
            enabled: false,
          },
          tooltip: {
            valueSuffix: " %",
          },
        },
        {
          name: "SOH",
          type: "spline",
          yAxis: 3,
          visible: checkData.soh ? true : false,

          data: battSoh,
          marker: {
            enabled: false,
          },
          tooltip: {
            valueSuffix: " %",
          },
        },
      ];
      let seriesData = [
        {
          // Primary yAxis
          labels: {
            format: "{value} V",
            style: {
              color: Highcharts.getOptions().colors[0],
            },
          },
          showEmpty: false,
          title: {
            text: "Battery Voltage",
            style: {
              color: Highcharts.getOptions().colors[0],
            },
          },
          opposite: true,
        },
        {
          // Secondary yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "Battery Current",
            style: {
              color: Highcharts.getOptions().colors[1],
            },
          },
          labels: {
            format: "{value} A",
            style: {
              color: Highcharts.getOptions().colors[1],
            },
          },
        },
        {
          // 4 yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "SOC",
            style: {
              color: Highcharts.getOptions().colors[2],
            },
          },
          labels: {
            format: "",
            style: {
              color: Highcharts.getOptions().colors[2],
            },
          },
          // opposite: true
        },
        {
          // 5 yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "SOH",
            style: {
              color: Highcharts.getOptions().colors[3],
            },
          },
          labels: {
            format: "",
            style: {
              color: Highcharts.getOptions().colors[3],
            },
          },
          opposite: false,
        },
      ];
      let dataCellTempsAll = [];
      let dataCellVoltsAll = [];

      // if (tmpT) {
      for (let k = 0; k < Object.keys(cellTemps[0]).length; k++) {
        let newName = Object.keys(cellTemps[0])[k];
        // console.log("newName", newName);
        // setCheckData((state) => ({ ...state, [newName]: false }));

        let dataCellTemps = {};
        dataCellTemps[Object.keys(cellTemps[0])[k]] = [];
        for (let j = 0; j < cellTemps.length; j++) {
          //   let newData = [];
          let name = Object.keys(cellTemps[0])[k];
          //   console.log("name", name);
          dataCellTemps[name].push(cellTemps[j][name]);
        }
        dataCellTempsAll.push(dataCellTemps);
      }
      cellVoltageDataset = dataCellTempsAll[0];

      for (let l = 0; l < Object.keys(cellTemps[0]).length; l++) {
        let newEntry = {};
        let newEntryS = {};
        Object.assign(newEntry, {
          name: "Cell Temp " + Number(l + 1),
          type: "spline",
          visible: checkData["cell_temp_" + Number(l + 1)] ? true : false,

          yAxis: 4,
          tooltip: {
            valueSuffix: " C",
          },
          data: dataCellTempsAll[l]["cell_temp_" + Number(l + 1)],
        });
        Object.assign(newEntryS, {
          gridLineWidth: 0,
          opposite: false,
          visible: l !== 0 ? false : true,
          // zoomEnabled: false,
          showEmpty: false,

          title: {
            // text: "Cell Temperature " + Number(l + 1),
            text: "Cell Temperature",
            style: {
              color: Highcharts.getOptions().colors[Number(l + 4)],
            },
          },
          //  min:-100,
          //   max:100,
          labels: {
            enabled: l !== 0 ? false : true,

            style: {
              color: Highcharts.getOptions().colors[Number(l + 4)],
              // fontFamily:'inherit'
            },
          },
        });
        //   newEntry.marker.enabled = false;
        //   newEntry.tooltip.valueSuffix = ' V';

        axisData.push(newEntry);

        //   newEntryS.title.style.color = Highcharts.getOptions().colors[l+4];
        //   newEntryS.labels.style.color = Highcharts.getOptions().colors[l+4];
        seriesData.push(newEntryS);
      }
      // }

      // console.log(
      //   "Object.keys(cellVolts[0]).length",
      //   Object.keys(cellVolts[0]).length
      // );
      // if (voltT) {
      if (Object.keys(cellVolts[0]).length !== 0) {
        for (let k = 0; k < Object.keys(cellVolts[0]).length; k++) {
          let dataCellTemps = {};
          let newName = Object.keys(cellVolts[0])[k];
          // console.log("newName", newName);
          // setCheckData((state) => ({ ...state, [newName]: false }));
          dataCellTemps[Object.keys(cellVolts[0])[k]] = [];
          for (let j = 0; j < cellVolts.length; j++) {
            //   let newData = [];
            let name = Object.keys(cellVolts[0])[k];
            //   console.log("name", name);
            dataCellTemps[name].push(cellVolts[j][name]);
          }
          dataCellVoltsAll.push(dataCellTemps);
        }
        cellTempDataset = dataCellVoltsAll[0];
        for (let l = 0; l < Object.keys(cellVolts[0]).length; l++) {
          let newEntry = {};
          let newEntryS = {};
          Object.assign(newEntry, {
            name: "Cell Volt " + Number(l + 1),
            type: "spline",
            visible: checkData["cell_volt_" + Number(l + 1)] ? true : false,

            yAxis: (Object.keys(cellTemps[0]).length || 0) + 4,
            tooltip: {
              valueSuffix: " V",
            },
            data: dataCellVoltsAll[l]["cell_volt_" + Number(l + 1)],
          });
          Object.assign(newEntryS, {
            gridLineWidth: 0,
            opposite: false,
            visible: l !== 0 ? false : true,
            // zoomEnabled: false,
            showEmpty: false,

            title: {
              // text: "Cell Temperature " + Number(l + 1),
              text: "Cell Voltage",
              style: {
                color: Highcharts.getOptions().colors[
                  Number(Object.keys(cellTemps[0]).length + 4)
                ],
              },
            },
            //  min:-100,
            //   max:100,
            labels: {
              enabled: l !== 0 ? false : true,

              style: {
                color: Highcharts.getOptions().colors[
                  Number(Object.keys(cellTemps[0]).length + 4)
                ],
                // fontFamily:'inherit'
              },
            },
          });
          //   newEntry.marker.enabled = false;
          //   newEntry.tooltip.valueSuffix = ' V';

          axisData.push(newEntry);

          //   newEntryS.title.style.color = Highcharts.getOptions().colors[l+4];
          //   newEntryS.labels.style.color = Highcharts.getOptions().colors[l+4];
          seriesData.push(newEntryS);
        }
      }
      // }

      //   console.log("cellVoltageDataset", dataCellTempsAll);

      //   console.log("axisData", axisData);
      //   console.log("seriesData", seriesData);
      setTimeLine(timeData);
      setChartData((state) => ({
        ...state,
        battCData: battC,
        battVData: battV,
        //   extVoltage:battExV,
        soc: battSoc,
        soh: battSoh,
        cellTemps: cellVoltageDataset,
        axisDataF: axisData,
        seriesDataF: seriesData,
        // totOdo:battTotOdo,
      }));

      setLoading(false);
    });
  }, [checkData, checkState]);
  const handleChangeBatt = (e) => {
    setLoading(true);

    let battC = [];
    let battV = [];
    // let battExV = [];
    let battSoc = [];
    let battSoh = [];
    // let battTotOdo = [];
    let newImei = e.target.value;

    setSelectedImei(newImei);
    let Url = endpoints.baseUrl + `/battery/chart?imei=` + newImei;
    axios.get(Url).then((response) => {
      setChartData(response.data.data[0]);
      const finalData = response.data.data[0];
      let cellTemps = [];
      let cellVolts = [];
      //   let i = 0;
      let len = 0;
      finalData.map((element, i) => {
        len = Object.keys(element.temp).length;
        let tempRow = element.temp;
        let voltRow = element.volt;

        cellTemps.push(tempRow);
        cellVolts.push(voltRow);

        timeData.push(element.time.toString());
        battV.push(element.battery_voltage);
        battC.push(element.battery_current);
        battSoc.push(element.soc);
        battSoh.push(element.soh);
      });
      let axisData = [
        {
          name: "Battery Voltage",
          type: "spline",
          visible: false,

          yAxis: 0,
          data: battV,
          tooltip: {
            valueSuffix: " V",
          },
          marker: {
            enabled: false,
          },
        },
        {
          name: "Battery Current",
          type: "spline",
          visible: false,

          yAxis: 1,
          data: battC,
          marker: {
            enabled: false,
          },
          // dashStyle: 'shortdot',
          tooltip: {
            valueSuffix: " A",
          },
        },
        {
          name: "SOC",
          type: "spline",
          visible: false,

          yAxis: 2,

          data: battSoc,
          marker: {
            enabled: false,
          },
          tooltip: {
            valueSuffix: " %",
          },
        },
        {
          name: "SOH",
          type: "spline",
          yAxis: 3,
          visible: false,

          data: battSoh,
          marker: {
            enabled: false,
          },
          tooltip: {
            valueSuffix: " %",
          },
        },
      ];
      let seriesData = [
        {
          // Primary yAxis
          labels: {
            format: "{value} V",
            style: {
              color: Highcharts.getOptions().colors[0],
            },
          },
          showEmpty: false,
          title: {
            text: "Battery Voltage",
            style: {
              color: Highcharts.getOptions().colors[0],
            },
          },
          opposite: true,
        },
        {
          // Secondary yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "Battery Current",
            style: {
              color: Highcharts.getOptions().colors[1],
            },
          },
          labels: {
            format: "{value} A",
            style: {
              color: Highcharts.getOptions().colors[1],
            },
          },
        },
        {
          // 4 yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "SOC",
            style: {
              color: Highcharts.getOptions().colors[2],
            },
          },
          labels: {
            format: "",
            style: {
              color: Highcharts.getOptions().colors[2],
            },
          },
          // opposite: true
        },
        {
          // 5 yAxis
          showEmpty: false,

          gridLineWidth: 0,
          title: {
            text: "SOH",
            style: {
              color: Highcharts.getOptions().colors[3],
            },
          },
          labels: {
            format: "",
            style: {
              color: Highcharts.getOptions().colors[3],
            },
          },
          opposite: false,
        },
      ];
      let dataCellTempsAll = [];
      let dataCellVoltsAll = [];

      if (tmpT) {
        for (let k = 0; k < Object.keys(cellTemps[0]).length; k++) {
          let dataCellTemps = {};
          dataCellTemps[Object.keys(cellTemps[0])[k]] = [];
          for (let j = 0; j < cellTemps.length; j++) {
            //   let newData = [];
            let name = Object.keys(cellTemps[0])[k];
            //   console.log("name", name);
            dataCellTemps[name].push(cellTemps[j][name]);
          }
          dataCellTempsAll.push(dataCellTemps);
        }
        cellVoltageDataset = dataCellTempsAll[0];

        for (let l = 0; l < Object.keys(cellTemps[0]).length; l++) {
          let newEntry = {};
          let newEntryS = {};
          Object.assign(newEntry, {
            name: "Cell Temp " + Number(l + 1),
            type: "spline",
            visible: false,

            yAxis: 4,
            tooltip: {
              valueSuffix: " C",
            },
            data: dataCellTempsAll[l]["cell_temp_" + Number(l + 1)],
          });
          Object.assign(newEntryS, {
            gridLineWidth: 0,
            opposite: false,
            visible: l !== 0 ? false : true,
            // zoomEnabled: false,
            showEmpty: false,

            title: {
              // text: "Cell Temperature " + Number(l + 1),
              text: "Cell Temperature",
              style: {
                color: Highcharts.getOptions().colors[Number(l + 4)],
              },
            },
            //  min:-100,
            //   max:100,
            labels: {
              enabled: l !== 0 ? false : true,

              style: {
                color: Highcharts.getOptions().colors[Number(l + 4)],
                // fontFamily:'inherit'
              },
            },
          });
          //   newEntry.marker.enabled = false;
          //   newEntry.tooltip.valueSuffix = ' V';

          axisData.push(newEntry);

          //   newEntryS.title.style.color = Highcharts.getOptions().colors[l+4];
          //   newEntryS.labels.style.color = Highcharts.getOptions().colors[l+4];
          seriesData.push(newEntryS);
        }
      }

      // console.log(
      //   "Object.keys(cellVolts[0]).length",
      //   Object.keys(cellVolts[0]).length
      // );
      if (voltT) {
        if (Object.keys(cellVolts[0]).length !== 0) {
          for (let k = 0; k < Object.keys(cellVolts[0]).length; k++) {
            let dataCellTemps = {};
            dataCellTemps[Object.keys(cellVolts[0])[k]] = [];
            for (let j = 0; j < cellVolts.length; j++) {
              //   let newData = [];
              let name = Object.keys(cellVolts[0])[k];
              //   console.log("name", name);
              dataCellTemps[name].push(cellVolts[j][name]);
            }
            dataCellVoltsAll.push(dataCellTemps);
          }
          cellTempDataset = dataCellVoltsAll[0];
          for (let l = 0; l < Object.keys(cellVolts[0]).length; l++) {
            let newEntry = {};
            let newEntryS = {};
            Object.assign(newEntry, {
              name: "Cell Volt " + Number(l + 1),
              type: "spline",
              visible: false,

              yAxis: (Object.keys(cellTemps[0]).length || 0) + 4,
              tooltip: {
                valueSuffix: " V",
              },
              data: dataCellVoltsAll[l]["cell_volt_" + Number(l + 1)],
            });
            Object.assign(newEntryS, {
              gridLineWidth: 0,
              opposite: false,
              visible: l !== 0 ? false : true,
              // zoomEnabled: false,
              showEmpty: false,

              title: {
                // text: "Cell Temperature " + Number(l + 1),
                text: "Cell Voltage",
                style: {
                  color: Highcharts.getOptions().colors[
                    Number(Object.keys(cellTemps[0]).length + 4)
                  ],
                },
              },
              //  min:-100,
              //   max:100,
              labels: {
                enabled: l !== 0 ? false : true,

                style: {
                  color: Highcharts.getOptions().colors[
                    Number(Object.keys(cellTemps[0]).length + 4)
                  ],
                  // fontFamily:'inherit'
                },
              },
            });
            //   newEntry.marker.enabled = false;
            //   newEntry.tooltip.valueSuffix = ' V';

            axisData.push(newEntry);

            //   newEntryS.title.style.color = Highcharts.getOptions().colors[l+4];
            //   newEntryS.labels.style.color = Highcharts.getOptions().colors[l+4];
            seriesData.push(newEntryS);
          }
        }
      }

      //   console.log("cellVoltageDataset", dataCellTempsAll);

      //   console.log("axisData", axisData);
      //   console.log("seriesData", seriesData);

      setTimeLine(timeData);
      setChartData((state) => ({
        ...state,
        battCData: battC,
        battVData: battV,
        //   extVoltage:battExV,
        soc: battSoc,
        soh: battSoh,
        cellTemps: cellVoltageDataset,
        axisDataF: axisData,
        seriesDataF: seriesData,
        // totOdo:battTotOdo,
      }));
      setLoading(false);
    });
  };
  //   console.log("axissssssssss", axisDataF);
  var chartOptions = {
    chart: {
      panning: true,
      displayErrors: true,
      height:500,
      // tickWidth: 1,
      // tickLength: 20,
      panKey: "ctrl",
      zoomType: "xy",
    },

    title: {
      text: "",
      align: "left",
    },

    // subtitle: {
    //     text: 'Source: WorldClimate.com',
    //     align: 'left'
    // },
    xAxis: [
      {
        labels: {
          // step: 100,

          //   staggerLines: 5,
          //   step: 6,
          // distance: "50%",
          // autoRotation: [0],
          //           rotation: 0,
          // allowOverlap:false,
          //           overflow:'justify',
          formatter: function() {
            if (this.isFirst) {
              return (
                "<b>" +
                moment(this.value).format("DD-MM-YYYY") +
                "</b> - " +
                moment(this.value).format("hh:mm")
              );
            } else {
              return moment(this.value).format("hh:mm");
            }
          },
        },
        // events: {
        //   setExtremes: function(e) {
        //     // setTimeout(()=>{
        //     if (typeof e.min == "undefined" && typeof e.max == "undefined") {
        //       chartOptions.xAxis.labels.step =   200
        //     } else {
        //       setStepVal(10);
        //     }

        //     // },100)
        //   },
        // },

        // minTickInterval: 100,
        // maxTickInterval: 100,
        // tickPixelInterval:200,
        // crosshair: true,

        zoomEnabled: true,
        categories: timeLine,
      },
    ],
    yAxis: chartData.seriesDataF || [],

    tooltip: {
      shared: true,
    },
    // legend: {
    //   layout: "vertical",
    //   align: "left",
    //   useHTML: true,
    //   activeColor: "#3E576F",
    //   animation: true,
    //   arrowSize: 12,
    //   inactiveColor: "#CCC",
    //   fontFamily: "inherit",

    //   style: {
    //     fontWeight: "bold",
    //     fontFamily: "inherit",
    //     color: "#333",
    //     fontSize: "12px",
    //   },
    //   labelFormatter: function() {
    //     return '<div style="height:40px;">' + this.name + "</div>";
    //   },
    //   backgroundColor:
    //     Highcharts.defaultOptions.legend.backgroundColor || // theme
    //     "rgba(255,255,255,0.25)",
    // },
    legend: false,
    series: chartData.axisDataF || [],

    responsive: {
      rules: [
        {
          condition: {
            maxWidth: 500,
          },
          chartOptions: {
            legend: {
              floating: false,
              layout: "horizontal",
              align: "center",
              verticalAlign: "bottom",
              x: 0,
              y: 0,
            },
            yAxis: [
              {
                labels: {
                  align: "right",
                  x: 0,
                  y: -6,
                },
                showLastLabel: false,
              },
              {
                labels: {
                  align: "left",
                  x: 0,
                  y: -6,
                },
                showLastLabel: false,
              },
              {
                visible: false,
              },
            ],
          },
        },
      ],
    },
    credits: {
      enabled: false,
    },
    navigation: {
      buttonOptions: {
        enabled: true,
        align: "center",
      },
    },
  };
  var chartOptions2 = {
    chart: {
      zoomType: "xy",
    },

    title: {
      text: "",
      align: "left",
    },
    // subtitle: {
    //     text: 'Source: WorldClimate.com',
    //     align: 'left'
    // },
    xAxis: [
      {
        categories: timeLine,
        // type:'date',
        crosshair: true,
        //   type: "datetime",
        labels: {
          rotation: false,
          formatter: function() {
            if (this.isFirst) {
              return (
                "<b>" +
                moment(this.value).format("DD-MM-YYYY") +
                "</b> - " +
                moment(this.value).format("hh:mm")
              );
            } else {
              return moment(this.value).format("hh:mm");
            }
          },
        },
      },
    ],
    yAxis: chartData.seriesDataF,
    // { // 6 yAxis
    // gridLineWidth: 0,
    // title: {
    //     text: 'Total Odometer',
    //     style: {
    //         color: Highcharts.getOptions().colors[5]
    //     }
    // },
    // labels: {
    //     format: '',
    //     style: {
    //         color: Highcharts.getOptions().colors[5]
    //     }
    // },
    // opposite: false
    // }

    tooltip: {
      shared: true,
    },
    legend: {
      layout: "vertical",
      align: "left",
      backgroundColor:
        Highcharts.defaultOptions.legend.backgroundColor || // theme
        "rgba(255,255,255,0.25)",
    },
    series: chartData.axisDataF,

    responsive: {
      rules: [
        {
          condition: {
            maxWidth: 500,
          },
          chartOptions: {
            legend: {
              floating: false,
              layout: "horizontal",
              align: "center",
              verticalAlign: "bottom",
              x: 0,
              y: 0,
            },
            yAxis: [
              {
                labels: {
                  align: "right",
                  x: 0,
                  y: -6,
                },
                showLastLabel: false,
              },
              {
                labels: {
                  align: "left",
                  x: 0,
                  y: -6,
                },
                showLastLabel: false,
              },
              {
                visible: false,
              },
            ],
          },
        },
      ],
    },
    credits: {
      enabled: false,
    },
    navigation: {
      buttonOptions: {
        enabled: true,
        align: "center",
      },
    },
  };

  // console.log("================================", checkData);

  return (
    <div
      style={{
        width: "100%",
        display: "flex",
        justifycontent: "space-between",
      }}
    >
      {/* <div
        style={{
          display: "flex",
          flexDirection: "column",
          marginLeft: 10,
          width: "18%",
        }}
      > */}
      <Grid container spacing={2}>
        <Grid  xs={4} lg={2}>
        <Box style={{ height: "450px", overflowY: "auto" }}>
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                icon={<Icon icon="ic:baseline-remove-red-eye" />}
                checkedIcon={
                  <Icon icon="ic:baseline-remove-red-eye" color="primary" />
                }
                checked={checkData.batVolt}
                onChange={(e) => {
                  setCheckData((s) => ({
                    ...s,
                    batVolt: e.target.checked,
                  }));
                }}
              />
            }
            label="Battery Voltage"
          />
          <FormControlLabel
            control={
              <Checkbox
                icon={<Icon icon="ic:baseline-remove-red-eye" />}
                checkedIcon={
                  <Icon icon="ic:baseline-remove-red-eye" color="primary" />
                }
                checked={checkData.batCurr}
                onChange={(e) => {
                  setCheckData((s) => ({
                    ...s,
                    batCurr: e.target.checked,
                  }));
                }}
              />
            }
            label="Battery Current"
          />
          <FormControlLabel
            control={
              <Checkbox
                icon={<Icon icon="ic:baseline-remove-red-eye" />}
                checkedIcon={
                  <Icon icon="ic:baseline-remove-red-eye" color="primary" />
                }
                checked={checkData.soc}
                onChange={(e) => {
                  setCheckData((s) => ({
                    ...s,
                    soc: e.target.checked,
                  }));
                }}
              />
            }
            label="Soc"
          />
          <FormControlLabel
            control={
              <Checkbox
                icon={<Icon icon="ic:baseline-remove-red-eye" />}
                checkedIcon={
                  <Icon icon="ic:baseline-remove-red-eye" color="primary" />
                }
                checked={checkData.soh}
                onChange={(e) => {
                  setCheckData((s) => ({
                    ...s,
                    soh: e.target.checked,
                  }));
                }}
              />
            }
            label="Soh"
          />
          <FormControlLabel
            control={
              <Checkbox
                icon={<Icon icon="material-symbols:add-box-outline-rounded" />}
                checkedIcon={<Icon icon="fluent:subtract-square-24-regular" />}
                checked={checkState.cellTemp}
                onChange={(e) => {
                  let newItem = checkData;
                  Object.keys(newItem).map((key) => {
                    if (key.includes("temp")) {
                      newItem[key] = false;
                    }
                  });
                  setCheckState((s) => ({
                    ...s,
                    cellTemp: e.target.checked,
                  }));
                  setCheckData(newItem);
                }}
              />
            }
            label={"Cell Temperatures"}
          />

          <Collapse in={checkState.cellTemp} timeout="auto" unmountOnExit>
            <FormGroup style={{ marginLeft: 15 }}>
              {Object.keys(checkData).map((key) => {
                return (
                  key.includes("temp") && (
                    <>
                      <FormControlLabel
                        control={
                          <Checkbox
                            icon={<Icon icon="ic:baseline-remove-red-eye" />}
                            checkedIcon={
                              <Icon
                                icon="ic:baseline-remove-red-eye"
                                color="primary"
                              />
                            }
                            checked={checkData[key]}
                            onChange={(e) => {
                              setCheckData((s) => ({
                                ...s,
                                [key]: e.target.checked,
                              }));
                            }}
                          />
                        }
                        style={{ textTransform: "capitalize" }}
                        label={key.replaceAll("_", " ")}
                      />
                    </>
                  )
                );
              })}
            </FormGroup>
            {/* <ListItemButton sx={{ pl: 4 }}>
                <ListItemText primary={"Cell Tempera"} />
              </ListItemButton> */}
          </Collapse>
          <FormControlLabel
            control={
              <Checkbox
                icon={<Icon icon="material-symbols:add-box-outline-rounded" />}
                checkedIcon={<Icon icon="fluent:subtract-square-24-regular" />}
                checked={checkState.cellVolt}
                onChange={(e) => {
                  let newItem = checkData;
                  Object.keys(newItem).map((key) => {
                    if (key.includes("volt")) {
                      newItem[key] = false;
                    }
                  });
                  setCheckState((s) => ({
                    ...s,
                    cellVolt: e.target.checked,
                  }));
                  setCheckData(newItem);
                }}
              />
            }
            label={"Cell Voltages"}
          />
          <Collapse in={checkState.cellVolt} timeout="auto" unmountOnExit>
            <FormGroup style={{ marginLeft: 15 }}>
              {Object.keys(checkData).map((key) => {
                return (
                  key.includes("volt") && (
                    <FormControlLabel
                      control={
                        <Checkbox
                          icon={<Icon icon="ic:baseline-remove-red-eye" />}
                          checkedIcon={
                            <Icon
                              icon="ic:baseline-remove-red-eye"
                              color="primary"
                            />
                          }
                          checked={checkData[key]}
                          onChange={(e) => {
                            setCheckData((s) => ({
                              ...s,
                              [key]: e.target.checked,
                            }));
                          }}
                        />
                      }
                      style={{ textTransform: "capitalize" }}
                      label={key.replaceAll("_", " ")}
                    />
                  )
                );
              })}
            </FormGroup>
          </Collapse>
        </FormGroup>
      </Box>
        </Grid>
        <Grid  xs={4} lg={10}>
        <figure
        class="highcharts-figure"
        style={{ opacity: !loading ? 1 : 0.5,
        //  width: "70%"
         border:'2px solid #77b93e'
         }}
      >
        <HighchartsReact
          constructorType={"chart"}
          highcharts={gantt}
          options={chartOptions}
        />
        {/* <br /> */}
      </figure>
        </Grid>
      </Grid>
 
      {/* </div> */}

    

      {loading ? (
        <Loading style={{ opacity: 0.5, position: "absolute" }} />
      ) : null}
    </div>
  );
}
