import React, { useState} from "react";
import { useDispatch, useSelector } from 'react-redux';

import PropTypes from "prop-types";
import { Helmet } from "react-helmet";
import brand from "enl-api/dummy/brand";
import { PapperBlock } from "enl-components";
import { injectIntl, FormattedMessage } from "react-intl";
// import messages from "./messages";
import Paper from "@material-ui/core/Paper";
import GenericPage from './Generic';
import CellVoltagePage from './CellVoltage';
import CellTempPage from './CellTemp';
import PageTitle from '../../../components/Utils/PageTitle';
import { Typography } from "@material-ui/core";
import { IconButton } from "@material-ui/core";
import { Icon } from '@iconify/react';

function Analytic(props) {
  const title = brand.name + " - Analytics";
  const description = brand.desc;
  const { intl } = props;
  const logged_user = useSelector((store) => store.user.loggeduser);

  return (
    <div>
      <Helmet>
        <title> {title} </title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="twitter:title" content={title} />
        <meta property="twitter:description" content={description} />
      </Helmet>
      <div style={{ marginTop: '-30px' }}><PageTitle /><br />
        <GenericPage logged_user={logged_user}/> <br />

        <br />

      </div>
    </div>
  );
}

Analytic.propTypes = {
  intl: PropTypes.object.isRequired,
};

export default injectIntl(Analytic);
