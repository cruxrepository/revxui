import React, { PureComponent, useState } from 'react';
import {
  Label,
  LineChart,
  Line,
  Legend,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceArea,
  ResponsiveContainer,
} from 'recharts';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

const initialData = [
  { name: 1, TUBSOC: 4.11, PackVoltage: 7.11, PackCurrent: 10, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, CellVoltage: 5.3, CellTemperature: 1.9 },
  { name: 2, TUBSOC: 2.39, PackVoltage: 9.39, PackCurrent: 12, BatteryCurrent: 7.39, SOC: 6.39, SOH: 42, CellVoltage: 2.3, CellTemperature: 2.9 },
  { name: 3, TUBSOC: 3.39, PackVoltage: 6.39, PackCurrent: 15, BatteryCurrent: 6.39, SOC: 9.39, SOH: 25, CellVoltage: 9.3, CellTemperature: 3.9 },
  { name: 4, TUBSOC: 5.39, PackVoltage: 5.39, PackCurrent: 18, BatteryCurrent: 2.39, SOC: 2.39, SOH: 8, CellVoltage: 6.3, CellTemperature: 4.9 },
  { name: 5, TUBSOC: 6.29, PackVoltage: 21.29, PackCurrent: 20, BatteryCurrent: 3.29, SOC: 11.29, SOH: 30, CellVoltage: 12.3, CellTemperature: 5.9 },
  { name: 6, TUBSOC: 3, PackVoltage: 3.88, PackCurrent: 19, BatteryCurrent: 3, SOC: 4.88, SOH: 10, CellVoltage: 5.3, CellTemperature: 9.9 },
  { name: 7, TUBSOC: 0.53, PackVoltage: 5.53, PackCurrent: 5, BatteryCurrent: 2.39, SOC: 2.39, SOH: 8, CellVoltage: 8.3, CellTemperature: 6.9 },
  { name: 8, TUBSOC: 2.52, PackVoltage: 9.52, PackCurrent: 10, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, CellVoltage: 3.3, CellTemperature: 7.9 },
  { name: 9, TUBSOC: 1.79, PackVoltage: 11.79, PackCurrent: 20, BatteryCurrent: 6.39, SOC: 9.39, SOH: 25, CellVoltage: 1.3, CellTemperature: 8.9 },
  { name: 10, TUBSOC: 2.94, PackVoltage: 5.94, PackCurrent: 22, BatteryCurrent: 3, SOC: 4.88, SOH: 10, CellVoltage: 7.3, CellTemperature: 9.9 },
  { name: 11, TUBSOC: 4.3, PackVoltage: 2.3, PackCurrent: 21, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, CellVoltage: 9.3, CellTemperature: 1.9 },
  { name: 12, TUBSOC: 4.41, PackVoltage: 8.41, PackCurrent: 30, BatteryCurrent: 3.29, SOC: 11.29, SOH: 30, CellVoltage: 3.3, CellTemperature: 2.9 },
  { name: 13, TUBSOC: 2.1, PackVoltage: 0.1, PackCurrent: 5, BatteryCurrent: 6.39, SOC: 9.39, SOH: 25, CellVoltage: 6.3, CellTemperature: 3.9 },
  { name: 14, TUBSOC: 6, PackVoltage: 6.6, PackCurrent: 19, BatteryCurrent: 3.29, SOC: 11.29, SOH: 30, CellVoltage: 11.3, CellTemperature: 4.9 },
  { name: 15, TUBSOC: 0, PackVoltage: 8.0, PackCurrent: 30, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, CellVoltage: 4.3, CellTemperature: 5.9 },
  { name: 16, TUBSOC: 6, PackVoltage: 7.6, PackCurrent: 40, BatteryCurrent: 3, SOC: 4.88, SOH: 10, CellVoltage: 19.3, CellTemperature: 6.9 },
  { name: 17, TUBSOC: 3, PackVoltage: 4.3, PackCurrent: 20, BatteryCurrent: 3, SOC: 4.88, SOH: 10, CellVoltage: 0.3, CellTemperature: 9.9 },
  { name: 18, TUBSOC: 2, PackVoltage: 2.2, PackCurrent: 50, BatteryCurrent: 6.39, SOC: 9.39, SOH: 25, CellVoltage: 3.3, CellTemperature: 8.9 },
  { name: 19, TUBSOC: 3, PackVoltage: 0.3, PackCurrent: 10, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, CellVoltage: 1.3, CellTemperature: 9.9 },
  { name: 20, TUBSOC: 7, PackVoltage: 1.7, PackCurrent: 10, BatteryCurrent: 7.39, SOC: 6.39, SOH: 42, CellVoltage: 2.3, CellTemperature: 1.9 }
];

const getAxisYDomain = (from, to, ref, offset) => {
  const refData = initialData.slice(from - 1, to);
  let [bottom, top] = [refData[0][ref], refData[0][ref]];
  refData.forEach((d) => {
    if (d[ref] > top) top = d[ref];
    if (d[ref] < bottom) bottom = d[ref];
  });

  return [(bottom | 0) - offset, (top | 0) + offset];
};

const initialState = {
  data: initialData,
  left: 'dataMin',
  right: 'dataMax',
  refAreaLeft: '',
  refAreaRight: '',
  top: 'dataMax+1',
  bottom: 'dataMin-1',
  top2: 'dataMax+20',
  bottom2: 'dataMin-20',
  animation: true,
  isChecked: false,
  isChecked1: false,
  isChecked2: false,
  isChecked3: false,
  isChecked4: false,
  isChecked5: false,
  isChecked6: false,
  isChecked7: false,
};

export default class Example extends PureComponent {
  static demoUrl = 'https://codesandbox.io/s/highlight-zomm-line-chart-v77bt';

  constructor(props) {
    super(props);
    this.state = initialState;
    // this.isChecked = true;


    // const [checked, setChecked] = useState(['TUBSOC', 'PackVoltage']);

    // const handleChange = event => {
    //   setCoin(event.target.value);
    // };

    //   const handleToggle = value => () => {
    //     const currentIndex = checked.indexOf(value);
    //     const newChecked = [...checked];

    //     if (currentIndex === -1) {
    //       newChecked.push(value);
    //     } else {
    //       newChecked.splice(currentIndex, 1);
    //     }

    //     setChecked(newChecked);
    //   };
  }

  zoom() {
    let { refAreaLeft, refAreaRight } = this.state;
    const { data } = this.state;

    if (refAreaLeft === refAreaRight || refAreaRight === '') {
      this.setState(() => ({
        refAreaLeft: '',
        refAreaRight: '',
      }));
      return;
    }

    // xAxis domain
    if (refAreaLeft > refAreaRight) [refAreaLeft, refAreaRight] = [refAreaRight, refAreaLeft];

    // yAxis domain
    const [bottom, top] = getAxisYDomain(refAreaLeft, refAreaRight, 'TUBSOC', 1);
    const [bottom2, top2] = getAxisYDomain(refAreaLeft, refAreaRight, ' CellVoltage', 50);
    const [bottom3, top3] = getAxisYDomain(refAreaLeft, refAreaRight, 'CellTemperature', 50);


    this.setState(() => ({
      refAreaLeft: '',
      refAreaRight: '',
      data: data.slice(),
      left: refAreaLeft,
      right: refAreaRight,
      bottom,
      top,
      bottom2,
      top2,
    }));
  }

  zoomOut() {
    const { data } = this.state;
    this.setState(() => ({
      data: data.slice(),
      refAreaLeft: '',
      refAreaRight: '',
      left: 'dataMin',
      right: 'dataMax',
      top: 'dataMax+1',
      bottom: 'dataMin',
      top2: 'dataMax+50',
      bottom2: 'dataMin+50',
    }));
  }
  zoomIn() {
    const { data } = this.state;
    this.setState(() => ({
      data: data.slice(),
      refAreaLeft: '',
      refAreaRight: '',
      left: 'dataMax',
      right: 'dataMin',
      top: 'dataMax-1',
      bottom: 'dataMax',
      top2: 'dataMin-50',
      bottom2: 'dataMax-50',
    }));
  }

  render() {
    const { data, barIndex, left, right, refAreaLeft, refAreaRight, top, bottom, top2, bottom2, top3, bottom3, top4, bottom4,
      top5, bottom5, top6, bottom6, top7, bottom7, top8, bottom8, isChecked,
      isChecked1, isChecked2, isChecked3, isChecked4, isChecked5, isChecked6, isChecked7 } = this.state;
    // const [isChecked, setIsChecked] = false;
    // const isChecked = false;
    // setIsChecked(!isChecked);

    const handleOnChange = () => {
      this.setState(() => ({
        isChecked: !this.state.isChecked
      }));
    };
    const handleOnChange1 = () => {
      this.setState(() => ({
        isChecked1: !this.state.isChecked1
      }));
    };
    const handleOnChange2 = () => {
      this.setState(() => ({
        isChecked2: !this.state.isChecked2
      }));
    };
    const handleOnChange3 = () => {
      this.setState(() => ({
        isChecked3: !this.state.isChecked3
      }));
    };
    const handleOnChange4 = () => {
      this.setState(() => ({
        isChecked4: !this.state.isChecked4
      }));
    };
    const handleOnChange5 = () => {
      this.setState(() => ({
        isChecked5: !this.state.isChecked5
      }));
    };
    const handleOnChange6 = () => {
      this.setState(() => ({
        isChecked6: !this.state.isChecked6
      }));
    };
    const handleOnChange7 = () => {
      this.setState(() => ({
        isChecked7: !this.state.isChecked7
      }));
    };

    return (
      <div className="highlight-bar-charts" style={{ userSelect: 'none', width: '100%' }}>

        {/* <button type="button" className="btn update" onClick={this.zoomOut.bind(this)}>
          Zoom Out
        </button>&nbsp;&nbsp;
        <button type="button" className="btn update" onClick={this.zoomIn.bind(this)}>
          Zoom in
        </button> */}
        <br />
        <Typography style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>Parameters</Typography>
        <Grid container spacing={2}>
          <Grid item xs={2}>
            <div className="App">
              <div className="isChecked" style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>
                {/* {this.state.isChecked ? <Icon icon="bi:eye-fill" color="#68a724" /> : <Icon icon="bi:eye-fill" />} */}

                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill"  color="#C4C4C4"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" />} checked={this.state.isChecked}
                    onChange={handleOnChange} />}
                />
                {/* <input
                  type="checkbox"
                  id="isChecked"
                  name="isChecked"
                  value="isChecked"
                  checked={this.state.isChecked}
                  onChange={handleOnChange}
                /> */}
                TU Battery SOC
              </div>
              <div className="isChecked1" style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>
                
              <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" />} 
                  checked={this.state.isChecked1}  onChange={handleOnChange1} />}
                />
                {/* <input
                  type="checkbox"
                  id="isChecked1"
                  name="isChecked1"
                  value="isChecked1"
                  checked={this.state.isChecked1}
                  onChange={handleOnChange1}
                /> */}
                Pack Voltage
              </div>
              <div className="isChecked2" style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>
              <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" />} 
                  checked={this.state.isChecked2}  onChange={handleOnChange2} />}
                />
                {/* <input
                  type="checkbox"
                  id="isChecked2"
                  name="isChecked2"
                  value="isChecked2"
                  checked={this.state.isChecked2}
                  onChange={handleOnChange2}
                /> */}
                Pack Current
              </div>
              <div className="isChecked3" style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>
              <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" />} 
                  checked={this.state.isChecked3}  onChange={handleOnChange3} />}
                />
                {/* <input
                  type="checkbox"
                  id="isChecked3"
                  name="isChecked3"
                  value="isChecked3"
                  checked={this.state.isChecked3}
                  onChange={handleOnChange3}
                /> */}
                Battery Current
              </div>
              <div className="isChecked4" style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>
              <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" />} 
                  checked={this.state.isChecked4}  onChange={handleOnChange4} />}
                />
                {/* <input
                  type="checkbox"
                  id="isChecked4"
                  name="isChecked4"
                  value="isChecked4"
                  checked={this.state.isChecked4}
                  onChange={handleOnChange4}
                /> */}
                SOC
              </div>
              <Typography className="isChecked5" style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>
              <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" />} 
                  checked={this.state.isChecked5}  onChange={handleOnChange5} />}
                />
                {/* <input
                  type="checkbox"
                  id="isChecked5"
                  name="isChecked5"
                  value="isChecked5"
                  checked={this.state.isChecked5}
                  onChange={handleOnChange5}
                /> */}
                SOH
              </Typography>
              <div className="isChecked6" style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>
              <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" />} 
                  checked={this.state.isChecked6}  onChange={handleOnChange6} />}
                />
                {/* <input
                  type="checkbox"
                  id="isChecked6"
                  name="isChecked6"
                  value="isChecked6"
                  checked={this.state.isChecked6}
                  onChange={handleOnChange6}
                /> */}
                Cell Voltage
              </div>
              <div className="isChecked7" style={{ textTransform: 'Capitalize', color: '#68A724', margin: 5, fontFamily: 'Maven Pro', fontWeight: 600 }}>
              <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" />} 
                  checked={this.state.isChecked7}  onChange={handleOnChange7} />}
                />
                {/* <input
                  type="checkbox"
                  id="isChecked7"
                  name="isChecked7"
                  value="isChecked7"
                  checked={this.state.isChecked7}
                  onChange={handleOnChange7}
                /> */}
                Cell Temperature
              </div>
            </div>
          </Grid>
          <Grid item xs={10}>
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <><IconButton onClick={this.zoomIn.bind(this)}><Icon icon="akar-icons:zoom-in" /></IconButton>
                <IconButton onClick={this.zoomOut.bind(this)}><Icon icon="akar-icons:zoom-out" /></IconButton></></div>

            <ResponsiveContainer width="100%" height={400}>
              <LineChart
                width={800}
                height={400}
                data={data}
                onMouseDown={(e) => this.setState({ refAreaLeft: e.activeLabel })}
                onMouseMove={(e) => this.state.refAreaLeft && this.setState({ refAreaRight: e.activeLabel })}
                // eslint-disable-next-line react/jsx-no-bind
                onMouseUp={this.zoom.bind(this)}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis allowDataOverflow dataKey="name" domain={[left, right]} type="number" />
                {this.state.isChecked ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'TU Battery SOC (%)', angle: -90 }} domain={[bottom, top]} type="number" yAxisId="1" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked1 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'Pack Voltage (V)', angle: -90 }} domain={[bottom2, top2]} type="number" yAxisId="2" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked2 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'Pack Current (A)', angle: -90 }} domain={[bottom3, top3]} type="number" yAxisId="3" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked3 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'Battery Current (A)', angle: -90 }} domain={[bottom4, top4]} type="number" yAxisId="4" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked4 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'SOC (%)', angle: -90 }} domain={[bottom5, top5]} type="number" yAxisId="5" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked5 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'SOH (%)', angle: -90 }} domain={[bottom6, top6]} type="number" yAxisId="6" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked6 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'Cell Voltage (V)', angle: -90 }} domain={[bottom7, top7]} type="number" yAxisId="7" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked7 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'Cell Temperature (ºC)', angle: -90 }} domain={[bottom8, top8]} type="number" yAxisId="8" /> : !this.state.isChecked ? null : null}


                <YAxis orientation="right" allowDataOverflow domain={[bottom2, top2]} type="number" yAxisId="2" />
                {/* <YAxis orientation="right" allowDataOverflow domain={[bottom2, top2]} type="number" yAxisId="3" /> */}
                <Tooltip />
                {this.state.isChecked ? <Line yAxisId="1" type="natural" dataKey="TUBSOC" stroke="#8884d8" animationDuration={300} dot={false} /> : !this.state.isChecked ? null : null}
                {this.state.isChecked1 ? <Line yAxisId="2" type="natural" dataKey="PackVoltage" stroke="#82ca9d" animationDuration={300} dot={false} /> : !this.state.isChecked1 ? null : null}
                {this.state.isChecked2 ? <Line yAxisId="3" type="natural" dataKey="PackCurrent" stroke="#fcba03" animationDuration={300} dot={false} /> : !this.state.isChecked2 ? null : null}
                {this.state.isChecked3 ? <Line yAxisId="4" type="natural" dataKey="BatteryCurrent" stroke="#9c1da1" animationDuration={300} dot={false} /> : !this.state.isChecked3 ? null : null}
                {this.state.isChecked4 ? <Line yAxisId="5" type="natural" dataKey="SOC" stroke="#e30e2a" animationDuration={300} dot={false} /> : !this.state.isChecked4 ? null : null}
                {this.state.isChecked5 ? <Line yAxisId="6" type="natural" dataKey="SOH" stroke="#41bf2e" animationDuration={300} dot={false} /> : !this.state.isChecked5 ? null : null}
                {this.state.isChecked6 ? <Line yAxisId="7" type="natural" dataKey="CellVoltage" stroke="#09c5de" animationDuration={300} dot={false} /> : !this.state.isChecked5 ? null : null}
                {this.state.isChecked7 ? <Line yAxisId="8" type="natural" dataKey="CellTemperature" stroke="#1b2ad1" animationDuration={300} dot={false} /> : !this.state.isChecked5 ? null : null}
                <Legend iconType="circle" verticalALign="bottom" iconSize={10} />

                {/* <Line yAxisId="1" type="natural" dataKey="TUBSOC" stroke="#8884d8" animationDuration={300} dot={false} /> */}
                {/* <Line yAxisId="2" type="natural" dataKey="PackVoltage" stroke="#82ca9d" animationDuration={300} dot={false} /> */}

                {refAreaLeft && refAreaRight ? (
                  <>
                  <ReferenceArea yAxisId="1" x1={refAreaLeft} x2={refAreaRight} strokeOpacity={0.3} />
                  </>
                ) : null}

              </LineChart>

            </ResponsiveContainer>


          </Grid>
        </Grid>



      </div>
    );
  }
}
