import React from "react";
import {
  Label,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceArea
} from "recharts";
import axios from "axios";
import endpoints from "../../../endpoints/endpoints";
const data = [
  { name: 1, cost: 4.11, impression: 100 },
  { name: 2, cost: 2.39, impression: 120 },
  { name: 3, cost: 1.37, impression: 150 },
  { name: 4, cost: 1.16, impression: 180 },
  { name: 5, cost: 2.29, impression: 200 },
  { name: 6, cost: 3, impression: 499 },
  { name: 7, cost: 0.53, impression: 50 },
  { name: 8, cost: 2.52, impression: 100 },
  { name: 9, cost: 1.79, impression: 200 },
  { name: 10, cost: 2.94, impression: 222 },
  { name: 11, cost: 4.3, impression: 210 },
  { name: 12, cost: 4.41, impression: 300 },
  { name: 13, cost: 2.1, impression: 50 },
  { name: 14, cost: 8, impression: 190 },
  { name: 15, cost: 0, impression: 300 },
  { name: 16, cost: 9, impression: 400 },
  { name: 17, cost: 3, impression: 200 },
  { name: 18, cost: 2, impression: 50 },
  { name: 19, cost: 3, impression: 100 },
  { name: 20, cost: 7, impression: 100 }
];



const initialState = {
  data,
  left: "dataMin",
  right: "dataMax",
  refAreaLeft: "",
  refAreaRight: "",
  top: "dataMax+1",
  bottom: "dataMin-1",
  top2: "dataMax+20",
  bottom2: "dataMin-20",
  animation: true,
  isChecked: false,
  isChecked1: false,
  isChecked2: false,
  isChecked3: false,
  isChecked4: false,
  isChecked5: false,
  isChecked6: false,
  isChecked7: false,
  graphData: '',
  batteryDrop: '',
  selectedImei:'',

};

export default class StreamingDemo extends React.Component {
  constructor(props) {
    super(props);
    this.state = initialState;
  }
  componentDidMount() {
    let newImei = this.state.selectedImei ? this.state.selectedImei :  `352625695105765`
    let Url = endpoints.baseUrl + `/battery/chart?imei=` + newImei;
    axios.get(Url).then((response) => {
      this.setState(() => ({
        graphData: response.data.data[0]
      }));
    const finalData = response.data.data;
    let cellTempLength = 0;
    let i = 0;
    finalData[0].forEach(element => {
      cellTempLength =  Object.keys(element.temp);
// console.log("length",cellTempLength);
    //   if(i === 1){
    //     cellTempLength =  Object.keys(element.temp);
    //     cellTempLength.forEach(ele => {
    //       let cellTemp = {};
    //       cellTemp.name = ele;
    //       cellTemp.value = element[ele]
    //       console.log("_____________",cellTemp);
          
    //     })
    //   }
    //   let myArr = Object.keys(element.temp).length === 9 ?  element.temp  : "18"
    // i++
    });
//  finalData[0].for((el)=>{

//   el.temp && el.temp.map((singleCt)=>{

//     let thisState = this.state.cellTempChecks;
//     this.setState(() => ({
//       cellTempChecks: thisState.push(singleCt)
//     }));
//   }) 
//  })
    }).catch((error) => { })


    let BatteryData = endpoints.baseUrl + `/battery/get/` + this.entityId;
    axios.get(BatteryData).then((response) => {
      this.setState(() => ({
        batteryDrop: response.data.data
      }));
    }).catch((error) => { })

  }
  zoom() {
    let { refAreaLeft, refAreaRight, graphData } = this.state;

    if (refAreaLeft === refAreaRight || refAreaRight === "") {
      this.setState(() => ({
        refAreaLeft: "",
        refAreaRight: ""
      }));
      return;
    }
    
    // xAxis domain
    if (refAreaLeft > refAreaRight)
      [refAreaLeft, refAreaRight] = [refAreaRight, refAreaLeft];

    // yAxis domain
    const [bottom, top] = this.getAxisYDomain(refAreaLeft, refAreaRight, "battery_current", 1);
    const [bottom2, top2] = this.getAxisYDomain(
      refAreaLeft,
      refAreaRight,
      "battery_voltage",
      50
    );

    this.setState(() => ({
      refAreaLeft: "",
      refAreaRight: "",
      graphData: graphData.slice(),
      left: refAreaLeft,
      right: refAreaRight,
      bottom,
      top,
      bottom2,
      top2
    }));
  }
  getAxisYDomain  (from, to, ref, offset)   {
    const refData = this.state.graphData.slice(from - 1, to);
    // console.log("this.state.graphData",refData)

    let [bottom, top] = [refData[0][ref], refData[0][ref]];
    refData.forEach(d => {
      if (d[ref] > top) top = d[ref];
      if (d[ref] < bottom) bottom = d[ref];
    });
  
    return [(bottom | 0) - offset, (top | 0) + offset];
  };
  zoomOut() {
    this.setState(({ graphData }) => ({
      graphData: graphData.slice(),
      refAreaLeft: "",
      refAreaRight: "",
      left: "dataMin",
      right: "dataMax",
      top: "dataMax+1",
      top2: "dataMax+50",
      bottom: "dataMin"
    }));
  }

  render() {
    const {
      data,
      left,
      right,
      refAreaLeft,
      refAreaRight,
      top,
      bottom,
      top2,
      bottom2
    } = this.state;
    const handleOnChange = () => {
      this.setState(() => ({
        isChecked: !this.state.isChecked
      }));
    };
    const handleOnChange1 = () => {
      this.setState(() => ({
        isChecked1: !this.state.isChecked1
      }));
    };
    const handleOnChange2 = () => {
      this.setState(() => ({
        isChecked2: !this.state.isChecked2
      }));
    };
    const handleOnChange3 = () => {
      this.setState(() => ({
        isChecked3: !this.state.isChecked3
      }));
    };
    const handleOnChange4 = () => {
      this.setState(() => ({
        isChecked4: !this.state.isChecked4
      }));
    };
    const handleOnChange5 = () => {
      this.setState(() => ({
        isChecked5: !this.state.isChecked5
      }));
    };
    const handleOnChange6 = () => {
      this.setState(() => ({
        isChecked6: !this.state.isChecked6
      }));
    };
    const handleOnChange7 = () => {
      this.setState(() => ({
        isChecked7: !this.state.isChecked7
      }));
    };
    const handleOnChange8 = (e) => {
      // console.log("sdsd",e)
      this.setState(() => ({
        selectedImei: e.target.value
      }));
      let newImei = this.state.selectedImei ? this.state.selectedImei :  `352625695105765`
    let Url = endpoints.baseUrl + `/battery/chart?imei=` + newImei;
    axios.get(Url).then((response) => {
      // console.log("responseresponse", response)
      let newGraph = response.data ? response.data.data[0] : null;
      const finalData = response.data.data
      newGraph.forEach(element => {
        let myArr = Object.keys(element.temp).length
    // console.log("SSSSSSSSSSSS",myArr)
      })
      this.setState(() => ({
        graphData: newGraph
      }));
    }).catch((error) => { })

    };
    return (
      <div className="highlight-bar-charts" style={{userSelect:'none'}}>
        <button className="btn update" onClick={this.zoomOut.bind(this)}>
          Zoom Out
        </button>

        <LineChart
          width={800}
          height={400}
          data={this.state.graphData}
          onMouseDown={e => this.setState({ refAreaLeft: e.activeLabel })}
          onMouseMove={e =>  this.setState({ refAreaRight: e.activeLabel })
          }
          onMouseUp={this.zoom.bind(this)}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            allowDataOverflow={true}
            dataKey="time"
            domain={[left, right]}
          />
          <YAxis
            allowDataOverflow={true}
            domain={[bottom, top]}
            type="number"
            yAxisId="1"
          />
          <YAxis
            orientation="right"
            allowDataOverflow={true}
            domain={[bottom2, top2]}
            type="number"
            yAxisId="2"
          />
          <Tooltip />
          <Line
            yAxisId="1"
            type="natural"
            dataKey="battery_current"
            stroke="#8884d8"
            animationDuration={300}
          />
          <Line
            yAxisId="2"
            type="natural"
            dataKey="battery_voltage"
            stroke="#82ca9d"
            animationDuration={300}
          />

          {refAreaLeft && refAreaRight ? (
            <ReferenceArea
              yAxisId="1"
              x1={refAreaLeft}
              x2={refAreaRight}
              strokeOpacity={0.3}
            />
          ) : null}
        </LineChart>
      </div>
    );
  }
}
