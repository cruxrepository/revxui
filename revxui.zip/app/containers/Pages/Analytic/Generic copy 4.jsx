import React, { PureComponent, useState, useEffect } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import {
  Label,
  LineChart,
  Line,
  Legend,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceArea,
  ResponsiveContainer,
} from 'recharts';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import endpoints from '../../../endpoints/endpoints';
import { getMyBatteryBulk } from '../../../redux/actions/asyncActions';
import { useDispatch, useSelector } from 'react-redux';
import Loading from '../../../components/Loading';

const initialData = [
  { name: 1, BatteryVoltage: 4.11, CurrentState: 7.11, PreviousState: 10, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, TotalOdometer: 5.3, ExternalVoltage: 1.9 },
  { name: 2, BatteryVoltage: 2.39, CurrentState: 9.39, PreviousState: 12, BatteryCurrent: 7.39, SOC: 6.39, SOH: 42, TotalOdometer: 2.3, ExternalVoltage: 2.9 },
  { name: 3, BatteryVoltage: 3.39, CurrentState: 6.39, PreviousState: 15, BatteryCurrent: 6.39, SOC: 9.39, SOH: 25, TotalOdometer: 9.3, ExternalVoltage: 3.9 },
  { name: 4, BatteryVoltage: 5.39, CurrentState: 5.39, PreviousState: 18, BatteryCurrent: 2.39, SOC: 2.39, SOH: 8, TotalOdometer: 6.3, ExternalVoltage: 4.9 },
  { name: 5, BatteryVoltage: 6.29, CurrentState: 21.29, PreviousState: 20, BatteryCurrent: 3.29, SOC: 11.29, SOH: 30, TotalOdometer: 12.3, ExternalVoltage: 5.9 },
  { name: 6, BatteryVoltage: 3, CurrentState: 3.88, PreviousState: 19, BatteryCurrent: 3, SOC: 4.88, SOH: 10, TotalOdometer: 5.3, ExternalVoltage: 9.9 },
  { name: 7, BatteryVoltage: 0.53, CurrentState: 5.53, PreviousState: 5, BatteryCurrent: 2.39, SOC: 2.39, SOH: 8, TotalOdometer: 8.3, ExternalVoltage: 6.9 },
  { name: 8, BatteryVoltage: 2.52, CurrentState: 9.52, PreviousState: 10, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, TotalOdometer: 3.3, ExternalVoltage: 7.9 },
  { name: 9, BatteryVoltage: 1.79, CurrentState: 11.79, PreviousState: 20, BatteryCurrent: 6.39, SOC: 9.39, SOH: 25, TotalOdometer: 1.3, ExternalVoltage: 8.9 },
  { name: 10, BatteryVoltage: 2.94, CurrentState: 5.94, PreviousState: 22, BatteryCurrent: 3, SOC: 4.88, SOH: 10, TotalOdometer: 7.3, ExternalVoltage: 9.9 },
  { name: 11, BatteryVoltage: 4.3, CurrentState: 2.3, PreviousState: 21, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, TotalOdometer: 9.3, ExternalVoltage: 1.9 },
  { name: 12, BatteryVoltage: 4.41, CurrentState: 8.41, PreviousState: 30, BatteryCurrent: 3.29, SOC: 11.29, SOH: 30, TotalOdometer: 3.3, ExternalVoltage: 2.9 },
  { name: 13, BatteryVoltage: 2.1, CurrentState: 0.1, PreviousState: 5, BatteryCurrent: 6.39, SOC: 9.39, SOH: 25, TotalOdometer: 6.3, ExternalVoltage: 3.9 },
  { name: 14, BatteryVoltage: 6, CurrentState: 6.6, PreviousState: 19, BatteryCurrent: 3.29, SOC: 11.29, SOH: 30, TotalOdometer: 11.3, ExternalVoltage: 4.9 },
  { name: 15, BatteryVoltage: 0, CurrentState: 8.0, PreviousState: 30, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, TotalOdometer: 4.3, ExternalVoltage: 5.9 },
  { name: 16, BatteryVoltage: 6, CurrentState: 7.6, PreviousState: 40, BatteryCurrent: 3, SOC: 4.88, SOH: 10, TotalOdometer: 19.3, ExternalVoltage: 6.9 },
  { name: 17, BatteryVoltage: 3, CurrentState: 4.3, PreviousState: 20, BatteryCurrent: 3, SOC: 4.88, SOH: 10, TotalOdometer: 0.3, ExternalVoltage: 9.9 },
  { name: 18, BatteryVoltage: 2, CurrentState: 2.2, PreviousState: 50, BatteryCurrent: 6.39, SOC: 9.39, SOH: 25, TotalOdometer: 3.3, ExternalVoltage: 8.9 },
  { name: 19, BatteryVoltage: 3, CurrentState: 0.3, PreviousState: 10, BatteryCurrent: 1.11, SOC: 11.11, SOH: 20, TotalOdometer: 1.3, ExternalVoltage: 9.9 },
  { name: 20, BatteryVoltage: 7, CurrentState: 1.7, PreviousState: 10, BatteryCurrent: 7.39, SOC: 6.39, SOH: 42, TotalOdometer: 2.3, ExternalVoltage: 1.9 }
];



const initialState = {
  data: initialData,
  left: 'dataMin',
  right: 'dataMax',
  refAreaLeft: '',
  refAreaRight: '',
  top: 'dataMax+1',
  bottom: 'dataMin-1',
  top2: 'dataMax+20',
  bottom2: 'dataMin-20',
  animation: true,
  isChecked: false,
  isChecked1: false,
  isChecked2: false,
  isChecked3: false,
  isChecked4: false,
  isChecked5: false,
  isChecked6: false,
  isChecked7: false,

  graphData: '',
  batteryDrop: '',
  selectedImei:'',
  cellTempChecks :''
};




export default class Example extends PureComponent {


  constructor(props) {
    super(props);
    this.state = initialState;
    this.entityId = props.logged_user.entity_id
    
  }

  componentDidMount() {
    let newImei = this.state.selectedImei ? this.state.selectedImei :  `352625695105765`
    let Url = endpoints.baseUrl + `/battery/chart?imei=` + newImei;
    axios.get(Url).then((response) => {
      this.setState(() => ({
        graphData: response.data.data[0]
      }));
    const finalData = response.data.data;
    let cellTempLength = 0;
    let i = 0;
    finalData[0].forEach(element => {
      cellTempLength =  Object.keys(element.temp);
// console.log("length",cellTempLength);
    //   if(i === 1){
    //     cellTempLength =  Object.keys(element.temp);
    //     cellTempLength.forEach(ele => {
    //       let cellTemp = {};
    //       cellTemp.name = ele;
    //       cellTemp.value = element[ele]
    //       console.log("_____________",cellTemp);
          
    //     })
    //   }
    //   let myArr = Object.keys(element.temp).length === 9 ?  element.temp  : "18"
    // i++
    });
//  finalData[0].for((el)=>{

//   el.temp && el.temp.map((singleCt)=>{

//     let thisState = this.state.cellTempChecks;
//     this.setState(() => ({
//       cellTempChecks: thisState.push(singleCt)
//     }));
//   }) 
//  })
    }).catch((error) => { })


    let BatteryData = endpoints.baseUrl + `/battery/get/` + this.entityId;
    axios.get(BatteryData).then((response) => {
      this.setState(() => ({
        batteryDrop: response.data.data
      }));
    }).catch((error) => { })

  }
   getAxisYDomain = (from, to, ref, offset) => {
    const { graphData } = this.state;

    const refData = graphData.slice(from - 1, to);
    // console.log("refDatarefData",refData)
    let [bottom, top] = [refData[0][ref], refData[0][ref]];
    refData.forEach((d) => {
      if (d[ref] > top) top = d[ref];
      if (d[ref] < bottom) bottom = d[ref];
    });
  
    return [(bottom | 0) - offset, (top | 0) + offset];
  };

 
  zoom() {
    let { refAreaLeft, refAreaRight,graphData } = this.state;

    if (refAreaLeft === refAreaRight || refAreaRight === "") {
      this.setState(() => ({
        refAreaLeft: "",
        refAreaRight: ""
      }));
      return;
    }

    // xAxis domain
    if (refAreaLeft > refAreaRight)
      [refAreaLeft, refAreaRight] = [refAreaRight, refAreaLeft];

    // yAxis domain
    const [bottom, top] = this.getAxisYDomain(refAreaLeft, refAreaRight, 'battery_voltage', 1);
    const [bottom2, top2] = this.getAxisYDomain(refAreaLeft, refAreaRight, ' battery_current', 50);
    const [bottom3, top3] = this.getAxisYDomain(refAreaLeft, refAreaRight, 'soc', 50);
    const [bottom4, top4] = this.getAxisYDomain(refAreaLeft, refAreaRight, 'soh', 50);
    // const [bottom5, top5] = this.getAxisYDomain(refAreaLeft, refAreaRight, 'current_state', 50);
    // const [bottom6, top6] = this.getAxisYDomain(refAreaLeft, refAreaRight, 'previous_state', 50);
    const [bottom7, top7] = this.getAxisYDomain(refAreaLeft, refAreaRight, 'total_odometer', 50);
    const [bottom8, top8] = this.getAxisYDomain(refAreaLeft, refAreaRight, 'external_voltage', 50);

    this.setState(() => ({
      refAreaLeft: "",
      refAreaRight: "",
      data: graphData.slice(),
      left: refAreaLeft,
      right: refAreaRight,
      bottom,
      top,
      bottom2,
      top2
    }));
  }

  zoomOut() {
    const { graphData } = this.state;
    this.setState(() => ({
      data: graphData.slice(),
      refAreaLeft: "",
      refAreaRight: "",
      left: "dataMin",
      right: "dataMax",
      top: "dataMax+1",
      bottom: "dataMin",
      top2: "dataMax+50",
      bottom2: "dataMin+50"
    }));
  }

  render() {
    const { data, barIndex, left, right, refAreaLeft, refAreaRight, top, bottom, top2, bottom2, top3, bottom3, top4, bottom4,
      top5, bottom5, top6, bottom6, top7, bottom7, top8, bottom8, isChecked,
      isChecked1, isChecked2, isChecked3, isChecked4, isChecked5, isChecked6, isChecked7, graphData } = this.state;

    const handleOnChange = () => {
      this.setState(() => ({
        isChecked: !this.state.isChecked
      }));
    };
    const handleOnChange1 = () => {
      this.setState(() => ({
        isChecked1: !this.state.isChecked1
      }));
    };
    const handleOnChange2 = () => {
      this.setState(() => ({
        isChecked2: !this.state.isChecked2
      }));
    };
    const handleOnChange3 = () => {
      this.setState(() => ({
        isChecked3: !this.state.isChecked3
      }));
    };
    const handleOnChange4 = () => {
      this.setState(() => ({
        isChecked4: !this.state.isChecked4
      }));
    };
    const handleOnChange5 = () => {
      this.setState(() => ({
        isChecked5: !this.state.isChecked5
      }));
    };
    const handleOnChange6 = () => {
      this.setState(() => ({
        isChecked6: !this.state.isChecked6
      }));
    };
    const handleOnChange7 = () => {
      this.setState(() => ({
        isChecked7: !this.state.isChecked7
      }));
    };
    const handleOnChange8 = (e) => {
      // console.log("sdsd",e)
      this.setState(() => ({
        selectedImei: e.target.value
      }));
      let newImei = this.state.selectedImei ? this.state.selectedImei :  `352625695105765`
    let Url = endpoints.baseUrl + `/battery/chart?imei=` + newImei;
    axios.get(Url).then((response) => {
      // console.log("responseresponse", response)
      let newGraph = response.data ? response.data.data[0] : null;
      const finalData = response.data.data
      newGraph.forEach(element => {
        let myArr = Object.keys(element.temp).length
    // console.log("SSSSSSSSSSSS",myArr)
      })
      this.setState(() => ({
        graphData: newGraph
      }));
    }).catch((error) => { })

    };

    return (
      <div className="highlight-bar-charts" style={{ userSelect: 'none', width: '100%' }}>
        <div style={{ display: 'flex', flexDirection: 'column' }}><Typography style={{ color: '#68A724', fontFamily: 'Maven Pro', fontWeight: 600 }}>Select Battery</Typography>
          {/* <p>{this.state.selectedImei}</p> */}
          <Select
          onChange={handleOnChange8}
          style={{ width: '300px' }} value={this.state.selectedImei || ''}>
            {this.state.batteryDrop.length && this.state.batteryDrop.map((imei) => {
              return (
                imei.imei ? 
                <MenuItem value={imei.imei}>{imei.serial_number}</MenuItem>: null 

              )
            }
            )}
          </Select>
          </div>


        <br />

        <Grid container spacing={2}>
          <Grid item xs={2}>

            <Typography className="isChecked" style={{ color: '#68A724', fontFamily: 'Maven Pro', fontWeight: 600 }}>Parameters</Typography><br />
            <div className="App">
              <Typography className="isChecked" style={{ fontSize: '0.875rem', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400 }}>

                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4" width="22" height="22" />} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" width="22" height="22" />} checked={this.state.isChecked}
                    onChange={handleOnChange} />}
                />
                Battery Voltage
              </Typography>

              <Typography className="isChecked1" style={{ fontSize: '0.875rem', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400 }}>
                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4" width="22" height="22" />} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" width="22" height="22" />}
                    checked={this.state.isChecked1} onChange={handleOnChange1} />}
                />
                Battery Current
              </Typography>
              <Typography className="isChecked2" style={{ fontSize: '0.875rem', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400 }}>
                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4" width="22" height="22" />} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" width="22" height="22" />}
                    checked={this.state.isChecked2} onChange={handleOnChange2} />}
                />
                SOC
              </Typography>
              <Typography className="isChecked3" style={{ fontSize: '0.875rem', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400 }}>
                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4" width="22" height="22" />} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" width="22" height="22" />}
                    checked={this.state.isChecked3} onChange={handleOnChange3} />}
                />
                SOH
              </Typography>
              {/* <Typography className="isChecked4" style={{fontSize: '0.875rem', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400 }}>
                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4" width="22" height="22"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" width="22" height="22"/>}
                    checked={this.state.isChecked4} onChange={handleOnChange4} />}
                />
                SOC
              </Typography>
              <Typography className="isChecked5" style={{fontSize: '0.875rem', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400 }}>
                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4" width="22" height="22"/>} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" width="22" height="22" />}
                    checked={this.state.isChecked5} onChange={handleOnChange5} />}
                />
                SOH
              </Typography> */}
              <Typography className="isChecked6" style={{ fontSize: '0.875rem', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400 }}>
                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4" width="22" height="22" />} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" width="22" height="22" />}
                    checked={this.state.isChecked6} onChange={handleOnChange6} />}
                />
                Total Odometer
              </Typography>
              <Typography className="isChecked7" style={{ fontSize: '0.875rem', fontFamily: 'Maven Pro,sans-serif', fontWeight: 400 }}>
                <FormControlLabel
                  control={<Checkbox icon={<Icon icon="bi:eye-fill" color="#C4C4C4" width="22" height="22" />} checkedIcon={<Icon icon="bi:eye-fill" color="#68a724" width="22" height="22" />}
                    checked={this.state.isChecked7} onChange={handleOnChange7} />}
                />
                External Voltage
              </Typography>
            </div>
          </Grid>
          {graphData ?  
          <Grid item xs={10}>
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <>
              <IconButton onClick={this.zoom.bind(this)}><Icon icon="akar-icons:zoom-in" color="#68a724" /></IconButton>
                <IconButton onClick={this.zoomOut.bind(this)}><Icon icon="akar-icons:zoom-out" color="#68a724" /></IconButton>
                <IconButton onClick={this.zoomOut.bind(this)}><Icon icon="bx:reset" color="#68a724" /></IconButton></></div>

            <ResponsiveContainer width="100%" height={500}>
              <LineChart
                width={800}
                height={500}
                // data={data}
                data={this.state.graphData}
                onMouseDown={(e) => this.setState({ refAreaLeft: e.activeLabel })}
                onMouseMove={(e) => this.state.refAreaLeft && this.setState({ refAreaRight: e.activeLabel })}
                // eslint-disable-next-line react/jsx-no-bind
                onMouseUp={this.zoom.bind(this)}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis allowDataOverflow dataKey="time" domain={[left, right]} />
                {this.state.isChecked ? <YAxis allowDataOverflow dataKey="battery_voltage" label={{ className: 'yaxix-value', value: 'Battery Voltage (V)', angle: -90 }} domain={[bottom, top]} type="number" yAxisId="1" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked1 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'Battery Current', angle: -90 }} domain={[bottom2, top2]} type="number" yAxisId="2" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked2 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'SOC (%)', angle: -90 }} domain={[bottom3, top3]} type="number" yAxisId="3" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked3 ? <YAxis allowDataOverflow label={{ className: 'yaxix-value', value: 'SOH (%)', angle: -90 }} domain={[bottom4, top4]} type="number" yAxisId="4" /> : !this.state.isChecked ? null : null}
                {/* {this.state.isChecked4 ? <YAxis allowDataOverflow orientation="right" label={{ className: 'yaxix-value', value: 'SOC (%)', angle: -90 }} domain={[bottom5, top5]} type="number" yAxisId="5" /> : !this.state.isChecked ? null : null} */}
                {/* {this.state.isChecked5 ? <YAxis allowDataOverflow orientation="right" label={{ className: 'yaxix-value', value: 'SOH (%)', angle: -90 }} domain={[bottom6, top6]} type="number" yAxisId="6" /> : !this.state.isChecked ? null : null} */}
                {this.state.isChecked6 ? <YAxis allowDataOverflow orientation="right" label={{ className: 'yaxix-value', value: 'Total Odometer', angle: -90 }} domain={[bottom7, top7]} type="number" yAxisId="7" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked7 ? <YAxis allowDataOverflow orientation="right" label={{ className: 'yaxix-value', value: 'External Voltage', angle: -90 }} domain={[bottom8, top8]} type="number" yAxisId="8" /> : !this.state.isChecked ? null : null}
                {/* {this.state.isChecked6 ? <YAxis allowDataOverflow orientation="right" label={{ className: 'yaxix-value', value: 'Cell Voltage (V)', angle: -90 }} domain={[bottom7, top7]} type="number" yAxisId="7" /> : !this.state.isChecked ? null : null}
                {this.state.isChecked7 ? <YAxis allowDataOverflow orientation="right" label={{ className: 'yaxix-value', value: 'Cell Temperature (ºC)', angle: -90 }} domain={[bottom8, top8]} type="number" yAxisId="8" /> : !this.state.isChecked ? null : null} */}


                {/* <YAxis orientation="right" allowDataOverflow domain={[bottom2, top2]} type="number" yAxisId="2" /> */}
                {/* <YAxis orientation="right" allowDataOverflow domain={[bottom2, top2]} type="number" yAxisId="3" /> */}
                <Tooltip />
                {this.state.isChecked ? <Line yAxisId="1" type="natural" dataKey="battery_voltage" stroke="#8884d8" animationDuration={300} dot={false} /> : !this.state.isChecked ? null : null}
                {this.state.isChecked1 ? <Line yAxisId="2" type="natural" dataKey="battery_current" stroke="#82ca9d" animationDuration={300} dot={false} /> : !this.state.isChecked1 ? null : null}
                {this.state.isChecked2 ? <Line yAxisId="3" type="natural" dataKey="soc" stroke="#fcba03" animationDuration={300} dot={false} /> : !this.state.isChecked2 ? null : null}
                {this.state.isChecked3 ? <Line yAxisId="4" type="natural" dataKey="soh" stroke="#9c1da1" animationDuration={300} dot={false} /> : !this.state.isChecked3 ? null : null}
                {/* {this.state.isChecked4 ? <Line yAxisId="5" type="natural" dataKey="current_state" stroke="#e30e2a" animationDuration={300} dot={false} /> : !this.state.isChecked4 ? null : null} */}
                {/* {this.state.isChecked5 ? <Line yAxisId="6" type="natural" dataKey="previous_state" stroke="#41bf2e" animationDuration={300} dot={false} /> : !this.state.isChecked5 ? null : null} */}
                {this.state.isChecked6 ? <Line yAxisId="7" type="natural" dataKey="total_odometer" stroke="#09c5de" animationDuration={300} dot={false} /> : !this.state.isChecked5 ? null : null}
                {this.state.isChecked7 ? <Line yAxisId="8" type="natural" dataKey="external_voltage" stroke="#1b2ad1" animationDuration={300} dot={false} /> : !this.state.isChecked5 ? null : null}
                <Legend iconType="circle" verticalALign="bottom" iconSize={10} />

                {/* <Line yAxisId="1" type="natural" dataKey="TUBSOC" stroke="#8884d8" animationDuration={300} dot={false} /> */}
                {/* <Line yAxisId="2" type="natural" dataKey="CurrentState" stroke="#82ca9d" animationDuration={300} dot={false} /> */}

                {refAreaLeft && refAreaRight ? (
                  <ReferenceArea yAxisId="1" x1={refAreaLeft} x2={refAreaRight} strokeOpacity={0.3} />
                ) : null}
              </LineChart>

            </ResponsiveContainer>


          </Grid> : <h1>No Data Found</h1>}
         
        </Grid>



      </div>
    );
  }
}
