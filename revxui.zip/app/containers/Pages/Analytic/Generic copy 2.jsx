import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import GraphicEq from '@material-ui/icons/GraphicEq';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import Divider from '@material-ui/core/Divider';
import Typography from '@material-ui/core/Typography';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { injectIntl, FormattedMessage } from 'react-intl';
import 'enl-styles/vendors/rechart/styles.css';
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ReferenceArea,ResponsiveContainer
} from 'recharts';
import { dataCrypto } from './chartMiniData';
import colorfull from 'enl-api/palette/colorfull';
import messages from './messages';
import styles from './widget-jss';
import PapperBlock from './PapperBlock';
import { Icon } from '@iconify/react';


const color = ({
  main: colorfull[2],
  secondary: colorfull[3],
  third: colorfull[0],
  fourth: colorfull[1],
  fifth: colorfull[4],
  sixth: colorfull[5],
  seventh: colorfull[6],
});

function Generic(props) {
  const [coin, setCoin] = useState('SELECT');
  const [checked, setChecked] = useState(['PackCurrent', 'packvoltage', 'TodayTripDistance', 'DistancetoEmpty', 'totalodometer', 'RemainingCapacity']);

  const handleChange = event => {
    setCoin(event.target.value);
  };

  const handleToggle = value => () => {
    const currentIndex = checked.indexOf(value);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(value);
    } else {
      newChecked.splice(currentIndex, 1);
    }

    setChecked(newChecked);
  };
  const getAxisYDomain = (from, to, ref, offset) => {
    const refData = data.slice(from - 1, to);
    let [bottom, top] = [refData[0][ref], refData[0][ref]];
    refData.forEach(d => {
      if (d[ref] > top) top = d[ref];
      if (d[ref] < bottom) bottom = d[ref];
    });
  
    return [(bottom | 0) - offset, (top | 0) + offset];
  };
  
  const initialState = {
    dataCrypto,
    left: "dataMin",
    right: "dataMax",
    refAreaLeft: "",
    refAreaRight: "",
    top: "dataMax+1",
    bottom: "dataMin-1",
    top2: "dataMax+20",
    bottom2: "dataMin-20",
    animation: true
  };
  const { classes, intl } = props;
  return (
    
    <PapperBlock
      whiteBg
      noMargin
      title="Generic"
      icon="insert_chart"
      desc=""
    >
      <Grid container spacing={2}>
      <Grid item md={2} xs={12}>
          <Typography className={classes.smallTitle} variant="button">
            <GraphicEq className={classes.leftIcon} />
            <FormattedMessage {...messages.chartIndicator} />
          </Typography>
          {/* <Divider className={classes.divider} /> */}
          <div style={{ width: '100%'}}>
            <List component="nav">
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('packvoltage')}
                    className={classes.listItem}
                  >
                    <Checkbox icon={<Icon icon="ant-design:eye-filled" />} checkedIcon={<Icon icon="ant-design:eye-filled" color="primary"/>}
                      checked={checked.indexOf('packvoltage') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText style={{ fontSize: '12px' }}>Pack Voltage</ListItemText>
                  </ListItem>
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('PackCurrent')}
                    className={classes.listItem}
                  >
                    <Checkbox icon={<Icon icon="ant-design:eye-filled" />} checkedIcon={<Icon icon="ant-design:eye-filled" color="primary"/>}
                      checked={checked.indexOf('PackCurrent') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText>Pack Current</ListItemText>
                  </ListItem>
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('TodayTripDistance')}
                    className={classes.listItem}
                  >
                    <Checkbox icon={<Icon icon="ant-design:eye-filled" />} checkedIcon={<Icon icon="ant-design:eye-filled" color="primary"/>}
                      checked={checked.indexOf('TodayTripDistance') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText>Today's Trip<br/>Distance</ListItemText>
                  </ListItem>
                <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('totalodometer')}
                    className={classes.listItem}
                  >
                    <Checkbox icon={<Icon icon="ant-design:eye-filled" />} checkedIcon={<Icon icon="ant-design:eye-filled" color="primary"/>}
                      checked={checked.indexOf('totalodometer') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText primary="Total Odometer"
                    // secondary="Quisque ut metus sit amet" 
                    />
                  </ListItem>
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('RemainingCapacity')}
                    className={classes.listItem}
                  >
                    <Checkbox
                      checked={checked.indexOf('RemainingCapacity') !== -1}
                      icon={<Icon icon="ant-design:eye-filled" />} checkedIcon={<Icon icon="ant-design:eye-filled" color="primary"/>} tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText>Remaining<br/>Capacity</ListItemText>
                  </ListItem>
                  
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('DistancetoEmpty')}
                    className={classes.listItem}
                  >
                    <Checkbox icon={<Icon icon="ant-design:eye-filled" />} checkedIcon={<Icon icon="ant-design:eye-filled" color="primary"/>}
                      checked={checked.indexOf('DistancetoEmpty') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText primary="Distance to Empty"
                    // secondary="Interdum et malesuada fames" 
                    />
                  </ListItem>


            </List>
          </div>
        </Grid>
        <Grid item md={10} xs={12}>
          <div className={classes.chartWrap}>
            <div className={classes.chartFluid}>
              <ResponsiveContainer width={1000} height="100%">
                <ComposedChart
                  data={dataCrypto}
                >
                  <XAxis dataKey="name" tickLine={false} />
                  
                  {checked.indexOf('totalodometer') > -1 && <YAxis label={{className:'yaxix-value', value: 'Total Odometer (Km)', angle: -90}} />}
                  {checked.indexOf('RemainingCapacity') > -1 && <YAxis label={{className:'yaxix-value', value: 'Remaining Capacity (Ah)', angle: -90}} />}
                  {checked.indexOf('DistancetoEmpty') > -1 && <YAxis label={{className:'yaxix-value', value: 'Distance to Empty (Km)', angle: -90}} />}
                  {checked.indexOf('packvoltage') > -1 && <YAxis label={{className:'yaxix-value', value: 'Pack Voltage (V)', angle: -90}} />}
                  {checked.indexOf('TodayTripDistance') > -1 && <YAxis label={{className:'yaxix-value', value: 'Today Trip Distance (Km)', angle: -90}} />}
                  {checked.indexOf('PackCurrent') > -1 && <YAxis label={{className:'yaxix-value', value: 'Pack Current (A)', angle: -90}} />}
                  
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <Tooltip />
                  {checked.indexOf('totalodometer') > -1 && <Line type="monotone" stackId="4" dataKey="TotalOdometer" strokeWidth={2} stroke={color.main} dot={false}/>}
                  {checked.indexOf('RemainingCapacity') > -1 && <Line type="monotone" stackId="5" dataKey="RemainingCapacity" strokeWidth={2} stroke={color.fifth} dot={false}/>}
                  {checked.indexOf('DistancetoEmpty') > -1 && <Line type="monotone" stackId="3" dataKey="DistancetoEmpty" strokeWidth={2} stroke={color.third} dot={false}/>}
                  {checked.indexOf('packvoltage') > -1 && <Line type="monotone" stackId="1" dataKey="PackVoltage" strokeWidth={2} fill={color.fourth} dot={false}/>}
                  {checked.indexOf('TodayTripDistance') > -1 && <Line type="monotone" stackId="6" dataKey="TodayTripDistance" strokeWidth={2} fill={color.secondary} dot={false}/>}
                  {checked.indexOf('PackCurrent') > -1 && <Line type="monotone" stackId="8" dataKey="PackCurrent" strokeWidth={2} fill={color.seventh} dot={false}/>}
                  <Legend iconType="circle" verticalALign="bottom" iconSize={10} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Grid>
       
      </Grid>
    </PapperBlock>
  );


}

Generic.propTypes = {
  classes: PropTypes.object.isRequired,
  intl: PropTypes.object.isRequired
};

export default withStyles(styles)(injectIntl(Generic));
