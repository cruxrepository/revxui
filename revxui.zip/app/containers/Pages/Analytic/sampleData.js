export const data1 = [
  {
    name: "9 AM",

    percentage: 10,
  },
  {
    name: "10 AM",

    percentage: 18,
  },
  {
    name: "11 AM",

    percentage: 35,
  },
  {
    name: "12 AM",

    percentage: 40,
  },
  {
    name: "1 PM",

    percentage: 57,
  },
  {
    name: "2 PM",

    percentage: 70,
  },
  {
    name: "3 PM",

    percentage: 80,
  },
  {
    name: "4 PM",

    percentage: 100,
  },
];
export const data1year = [
  {
    name: "Jan",

    percentage: 10,
  },
  {
    name: "Feb",

    percentage: 18,
  },
  {
    name: "Mar",

    percentage: 35,
  },
  {
    name: "Apr",

    percentage: 40,
  },
  {
    name: "May",

    percentage: 57,
  },
  {
    name: "June",

    percentage: 40,
  },
  {
    name: "July",

    percentage: 50,
  },
  {
    name: "Aug",

    percentage: 85,
  },
  {
    name: "Sep",

    percentage: 43,
  },
  {
    name: "Oct",

    percentage: 66,
  },
  {
    name: "Nov",

    percentage: 40,
  },
  {
    name: "Dec",

    percentage: 20,
  },
];
function generateMonth () {
  const data1monthArr = [];
    for(let i=1; i < 31; i++)
    {
     let sample = Math.floor(Math.random() * 100);
     let obj = {};
     obj.percentage = sample;
     obj.name = i;
     data1monthArr.push(obj);
    }
  return data1monthArr;
}

export const data1month = generateMonth();
export const data2 = [
  {
    name: "9 AM",

    pv: 10,
  },
  {
    name: "10 AM",

    pv: 18,
  },
  {
    name: "11 AM",

    pv: 35,
  },
  {
    name: "12 AM",

    pv: 40,
  },
  {
    name: "1 PM",

    pv: 57,
  },
  {
    name: "2 PM",

    pv: 70,
  },
  {
    name: "3 PM",

    pv: 80,
  },
  {
    name: "4 PM",

    pv: 100,
  },
];

export const data3 = [
  {
    name: "9 AM",

    uv: 10,
  },
  {
    name: "10 AM",

    uv: 15,
  },
  {
    name: "11 AM",

    uv: 30,
  },
  {
    name: "12 AM",

    uv: 20,
  },
  {
    name: "1 PM",

    uv: 57,
  },
  {
    name: "2 PM",

    uv: 30,
  },
  {
    name: "3 PM",

    uv: 80,
  },
  {
    name: "4 PM",

    uv: 90,
  },
];

export const data4 = [
  {
    name: "Group A",
    value: 400,
  },
  {
    name: "Group B",
    value: 300,
  },
  {
    name: "Group C",
    value: 300,
  },
  {
    name: "Group D",
    value: 200,
  },
  {
    name: "Group E",
    value: 278,
  },
  {
    name: "Group F",
    value: 189,
  },
];

export const data5 = [
  {
    name: "Group A",
    value: 2400,
  },
  {
    name: "Group B",
    value: 4567,
  },
  {
    name: "Group C",
    value: 1398,
  },
  {
    name: "Group D",
    value: 9800,
  },
  {
    name: "Group E",
    value: 3908,
  },
  {
    name: "Group F",
    value: 4800,
  },
];

export const data6 = [
  {
    name: "Group A",
    value: 400,
  },
  {
    name: "Group B",
    value: 300,
  },
  {
    name: "Group C",
    value: 300,
  },
  {
    name: "Group D",
    value: 200,
  },
];

export const data7 = [
  {
    subject: "Math",
    A: 120,
    B: 110,
    fullMark: 150,
  },
  {
    subject: "Chinese",
    A: 98,
    B: 130,
    fullMark: 150,
  },
  {
    subject: "English",
    A: 86,
    B: 130,
    fullMark: 150,
  },
  {
    subject: "Geography",
    A: 99,
    B: 100,
    fullMark: 150,
  },
  {
    subject: "Physics",
    A: 85,
    B: 90,
    fullMark: 150,
  },
  {
    subject: "History",
    A: 65,
    B: 85,
    fullMark: 150,
  },
];

export const data8 = [
  {
    x: 10,
    y: 30,
  },
  {
    x: 30,
    y: 200,
  },
  {
    x: 45,
    y: 100,
  },
  {
    x: 50,
    y: 400,
  },
  {
    x: 70,
    y: 150,
  },
  {
    x: 100,
    y: 250,
  },
];

export const data9 = [
  {
    x: 30,
    y: 20,
  },
  {
    x: 50,
    y: 180,
  },
  {
    x: 75,
    y: 240,
  },
  {
    x: 100,
    y: 100,
  },
  {
    x: 120,
    y: 190,
  },
];
