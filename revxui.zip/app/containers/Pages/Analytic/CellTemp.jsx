import React, { useState } from 'react';
import CellTempTable from './CellTempTable';
let counter = 0;
function createData(market, name, price, change, position, stats, volume, balance) {
  counter += 1;
  return {
    id: counter,
    market,
    name,
    price,
    change,
    position,
    stats,
    volume,
    balance
  };
}

function CellTemp() {
  const [order] = useState('asc');
  const [orderBy] = useState('market');
  const [columnData] = useState([
    {
      id: 'market',
      numeric: false,
      disablePadding: true,
      label: 'Cell Temperature'
    }, 
    // {
    //   id: 'price',
    //   numeric: true,
    //   disablePadding: false,
    //   label: 'Price (USD)'
    // }, 
    {
      id: 'change',
      numeric: true,
      disablePadding: false,
      label: 'Change (%)'
    }, {
      id: 'stats',
      numeric: false,
      disablePadding: false,
      label: '12H Stats'
    }, 
    // {
    //   id: 'volume',
    //   numeric: true,
    //   disablePadding: false,
    //   label: 'Volume (mn USD)'
    // }, {
    //   id: 'balance',
    //   numeric: true,
    //   disablePadding: false,
    //   label: 'Balance (USD)'
    // },
  ]);
  const [data] = useState([
    createData('Cell Temperature', 'Binance', 2.5, 4.3, 'up', 'ltc', 341, 0),
    createData('Cell Temperature', 'Bitcoin', 7345, 1.3, 'down', 'btc', 12, 0.72),
    createData( 'Cell Temperature', 'Bytecoin', 320, 10, 'down', 'xlm', 110, 0),
    createData( 'Cell Temperature', 'Cardano', 194, 17, 'down', 'ada', 23, 0),
    // createData( 'Cell Temperature', 'Decred', 2.7, 2.6, 'up', 'xrp', 9, 0),
    // createData( 'Cell Temperature', 'Iconic', 192, 9.3, 'up', 'xlm', 14, 0),
    // createData( 'Cell Temperature', 'Iota', 77.2, 2.1, 'down', 'ltc', 221, 10.55),
    // createData( 'Cell Temperature', 'Litecoin', 90.4, 43, 'up', 'ada', 14, 0),
    // createData( 'Cell Temperature', 'Monero', 2.1, 9, 'up', 'btc', 20, 0),
    // createData( 'Cell Temperature', 'Nano Coin', 4.8, 89, 'stay', 'ltc', 19, 0),
    // createData( 'Cell Temperature', 'Nem', 92, 27, 'up', 'xrp', 273, 720),
    // createData( 'Cell Temperature', 'Papulous', 2300, 5.7, 'stay', 'ltc', 442, 0),
    // createData( 'Cell Temperature', 'Ripple', 86, 22.9, 'up', 'xlm', 35.2, 88.98),
    // createData( 'Cell Temperature', 'Stellar Lumens', 11.5, 2.1, 'up', 'btc', 45, 19.23),
    // createData( 'Cell Temperature', 'Stratis', 14.7, 11.9, 'up', 'ltc', 17.7, 0),
    // createData( 'Cell Temperature', 'Tron', 201, 27.2, 'down', 'xrp', 98, 103),
  ].sort((a, b) => (a.price < b.price ? -1 : 1)));
  const [page] = useState(0);
  const [rowsPerPage] = useState(4);
  const [defaultPerPage] = useState(5);
  const [filterText] = useState('');

  return (
    <CellTempTable
      // order={order}
      // orderBy={orderBy}
      data={data}
      page={page}
      rowsPerPage={rowsPerPage}
      // defaultPerPage={defaultPerPage}
      filterText={filterText}
      columnData={columnData}
    />
  );
}

export default CellTemp;
