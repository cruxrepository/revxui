import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import GraphicEq from '@material-ui/icons/GraphicEq';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import Divider from '@material-ui/core/Divider';
import Typography from '@material-ui/core/Typography';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { injectIntl, FormattedMessage } from 'react-intl';
import 'enl-styles/vendors/rechart/styles.css';
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { dataCrypto } from './chartMiniData';
import colorfull from 'enl-api/palette/colorfull';
import messages from './messages';
import styles from './widget-jss';
import PapperBlock from './PapperBlock';

const color = ({
  main: colorfull[2],
  secondary: colorfull[3],
  third: colorfull[0],
  fourth: colorfull[1],
  fifth: colorfull[4],
  sixth: colorfull[5],
  seventh: colorfull[6],
});

function Generic(props) {
  const [coin, setCoin] = useState('SELECT');
  const [checked, setChecked] = useState(['PackCurrent', 'packvoltage', 'TodayTripDistance', 'DistancetoEmpty', 'totalodometer', 'RemainingCapacity']);

  const handleChange = event => {
    setCoin(event.target.value);
  };

  const handleToggle = value => () => {
    const currentIndex = checked.indexOf(value);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(value);
    } else {
      newChecked.splice(currentIndex, 1);
    }

    setChecked(newChecked);
  };

  const { classes, intl } = props;
  return (
    <PapperBlock
      whiteBg
      noMargin
      title="Generic"
      icon="insert_chart"
      desc=""
    >
      <Grid container spacing={2}>
        <Grid item md={8} xs={12}>
          <Grid container spacing={2}>
            <Grid item md={5} xs={12}>
              <form autoComplete="off">
                <FormControl className={classes.formControl}>
                  <InputLabel htmlFor="coin-simple">Battery</InputLabel>
                  <Select
                    value={coin}
                    onChange={handleChange}
                    inputProps={{
                      name: 'coin',
                      id: 'coin-simple4',
                    }}
                  >
                    <MenuItem value="SELECT">SELECT</MenuItem>
                    {/* <MenuItem value="BNB">BNB (Binance)</MenuItem>
                    <MenuItem value="BTC">BTC (Bitcoin)</MenuItem>
                    <MenuItem value="BCN">BCN (Bytecoin)</MenuItem>
                    <MenuItem value="ADA">ADA (Cardano)</MenuItem>
                    <MenuItem value="DCR">DCR (Decred)</MenuItem>
                    <MenuItem value="ICX">ICX (Iconic)</MenuItem>
                    <MenuItem value="IOTA">IOTA (Iota)</MenuItem>
                    <MenuItem value="LTC">LTC (Litecoin)</MenuItem>
                    <MenuItem value="XMR">XMR (Monero)</MenuItem>
                    <MenuItem value="NANO">NANO (Nano Coin)</MenuItem>
                    <MenuItem value="NEM">NEM (Nem)</MenuItem>
                    <MenuItem value="PPT">PPT (Papulous)</MenuItem>
                    <MenuItem value="XRP">XRP (Ripple)</MenuItem>
                    <MenuItem value="XLM">XLM (Stellar Lumens)</MenuItem>
                    <MenuItem value="STRAT">STRAT (Stratis)</MenuItem>
                    <MenuItem value="TRX">TRX (Tron)</MenuItem> */}
                  </Select>
                </FormControl>
              </form>
            </Grid>
            {/* <Grid item md={2} xs={6}>
              <Typography variant="caption">
                <FormattedMessage {...messages.lastPrice} />
              </Typography>
              <Typography variant="subtitle1">$ 8,901</Typography>
            </Grid>
            <Grid item md={2} xs={6}>
              <Typography variant="caption">
                <FormattedMessage {...messages.dailyChanges} />
              </Typography>
              <Typography variant="subtitle1">$ 267.89</Typography>
            </Grid>
            <Grid item md={3} xs={12}>
              <Typography variant="caption">
                <FormattedMessage {...messages.volume24h} />
              </Typography>
              <Typography variant="subtitle1">16,900,222 BTC</Typography>
            </Grid> */}
          </Grid>
          <div className={classes.chartWrap}>
            <div className={classes.chartFluid}>
              <ResponsiveContainer width={800} height="80%">
                <ComposedChart
                  data={dataCrypto}
                >
                  <XAxis dataKey="name" tickLine={false} />
                  <YAxis axisLine={false} tickSize={3} tickLine={false} tick={{ stroke: 'none' }} />
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <Tooltip />
                  <Bar stackId="2" baDistancetoEmptyze={10} fillOpacity="0.8" dataKey="TUBSOC" fill={color.sixth} />
                  <Bar stackId="5" baDistancetoEmptyze={10} fillOpacity="0.8" dataKey="SOC" fill={color.secondary} />
                  <Bar stackId="7" baDistancetoEmptyze={10} fillOpacity="0.8" dataKey="SOH" fill={color.third} />
                  {checked.indexOf('totalodometer') > -1 && <Line type="monotone" stackId="4" dataKey="TotalOdometer" strokeWidth={2} stroke={color.main} />}
                  {checked.indexOf('RemainingCapacity') > -1 && <Line type="monotone" stackId="5" dataKey="RemainingCapacity" strokeWidth={2} stroke={color.fifth} />}
                  {checked.indexOf('DistancetoEmpty') > -1 && <Line type="monotone" stackId="3" dataKey="DistancetoEmpty" strokeWidth={2} stroke={color.third} />}
                  {checked.indexOf('packvoltage') > -1 && <Area type="monotone" stackId="1" dataKey="PackVoltage" stroke={color.fourth} fill={color.fourth} />}
                  {checked.indexOf('TodayTripDistance') > -1 && <Area type="monotone" stackId="6" dataKey="TodayTripDistance" stroke={color.main} fill={color.secondary} />}
                  {checked.indexOf('PackCurrent') > -1 && <Area type="monotone" stackId="8" dataKey="PackCurrent" stroke={color.main} fill={color.seventh} />}
                  <Legend iconType="circle" verticalALign="bottom" iconSize={10} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Grid>
        <Grid item md={4} xs={12}>
          <Typography className={classes.smallTitle} variant="button">
            <GraphicEq className={classes.leftIcon} />
            <FormattedMessage {...messages.chartIndicator} />
          </Typography>
          <Divider className={classes.divider} />
          <div style={{ width: '100%', marginTop: '24px' }}>
            <List component="nav">
              <Grid container spacing={1}>
                <Grid item lg={6} xs={12}>
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('packvoltage')}
                    className={classes.listItem}
                  >
                    <Checkbox
                      checked={checked.indexOf('packvoltage') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText style={{ fontSize: '12px' }}>Pack Voltage</ListItemText>
                  </ListItem>
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('PackCurrent')}
                    className={classes.listItem}
                  >
                    <Checkbox
                      checked={checked.indexOf('PackCurrent') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText>Pack Current</ListItemText>
                  </ListItem>
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('TodayTripDistance')}
                    className={classes.listItem}
                  >
                    <Checkbox
                      checked={checked.indexOf('TodayTripDistance') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText>Today's Trip Distance</ListItemText>
                  </ListItem>
                  </Grid>
                <Grid item lg={6} xs={12}>
                <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('totalodometer')}
                    className={classes.listItem}
                  >
                    <Checkbox
                      checked={checked.indexOf('totalodometer') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText primary="Total Odometer"
                    // secondary="Quisque ut metus sit amet" 
                    />
                  </ListItem>
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('RemainingCapacity')}
                    className={classes.listItem}
                  >
                    <Checkbox
                      checked={checked.indexOf('RemainingCapacity') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText primary="Remaining Capacity"
                    // secondary="Quisque ut metus sit amet" 
                    />
                  </ListItem>
                  
                  <ListItem
                    role={undefined}
                    dense
                    button
                    onClick={handleToggle('DistancetoEmpty')}
                    className={classes.listItem}
                  >
                    <Checkbox
                      checked={checked.indexOf('DistancetoEmpty') !== -1}
                      tabIndex={-1}
                      disableRipple
                    />
                    <ListItemText primary="Distance to Empty"
                    // secondary="Interdum et malesuada fames" 
                    />
                  </ListItem></Grid>
              </Grid>


            </List>
          </div>
        </Grid>
      </Grid>
    </PapperBlock>
  );


}

Generic.propTypes = {
  classes: PropTypes.object.isRequired,
  intl: PropTypes.object.isRequired
};

export default withStyles(styles)(injectIntl(Generic));
