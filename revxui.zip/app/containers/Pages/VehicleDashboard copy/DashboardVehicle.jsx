import React from "react";
import axios from 'axios';
import { makeStyles, useTheme, styled } from '@material-ui/core/styles';
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import CloseIcon from '@material-ui/icons/Close';
import { TextField } from "@material-ui/core/";
import InputAdornment from '@material-ui/core/InputAdornment';
import SearchIcon from '@material-ui/icons/Search';
import { IconButton } from "@material-ui/core/";
import colorfull from 'enl-api/palette/colorfull';
import classNames from 'classnames';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Divider from '@material-ui/core/Divider';
import Avatar from '@material-ui/core/Avatar';
import SimpleMap from "./BasicMap";
// import RemoveCircleOutlinedIcon from '@material-ui/icons/RemoveCircleOutlined';
// import AccountCircle from '@material-ui/icons/AccountCircle';
import Brightness1Icon from '@material-ui/icons/Brightness1';
import endpoints from '../../../endpoints/endpoints';
import { setLiveTrackerList, setLiveTrackerSelected } from "../../../redux/actions/normalActions";
import { useDispatch, useSelector } from "react-redux";
import { Icon } from "@iconify/react";
import { LocalLibrary, Style } from "@material-ui/icons";
import Chart from './Chart';
import Chart1 from './Chart1';

const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'left',
    color: theme.palette.text.secondary,
}));
const useStyles = makeStyles((theme) => ({
    avatar: {
        marginRight: theme.spacing(1),
        boxShadow: theme.shadows[4],
        background: theme.palette.background.paper,
        '& svg': {
            fontSize: 24,
            fill: theme.palette.primary.main
        },
        '&$sm': {
            width: 30,
            height: 30
        },
        '&$mc': {
            width: 24,
            height: 24,
            top: 2,
            left: 8,
            marginRight: 0
        },
    },
    pinkAvatar: {
        color: colorfull[0],
        border: `1px solid ${colorfull[0]}`
    },
    purpleAvatar: {
        color: colorfull[1],
        border: `1px solid ${colorfull[1]}`
    },
    blueAvatar: {
        color: colorfull[2],
        border: `1px solid ${colorfull[2]}`
    },
    tealAvatar: {
        color: colorfull[3],
        border: `1px solid ${colorfull[3]}`
    }, paperHeading: {
        height: 400, borderRadius: 2
    },
    green: {
        position: 'sticky', zIndex: 10, top: 0,
        backgroundColor: '#68A72480  !important', border: 'none',
        height: 60, borderBottomLeftRadius: 0, borderBottomRightRadius: 0
    },
    search: {
        marginLeft: '15px', backgroundColor: '#fff', width: '300px',
        borderRadius: '8px', '.MuiOutlinedInput-notchedOutline': {
            borderColor: '#fff !important',
            borderRadius: '9px !important'
        },
        '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#fff  !important' }
    },
    list: {
        width: '100%', backgroundColor: 'background.paper', height: '85%'
        , overflowY: 'scroll'
    },
    hover: {
        backgroundColor: theme.palette.grey.A100
    },
    map: {
        height: 400, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    primaryText: {
        fontFamily: 'Open Sans', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px'
    },
    primaryTextVV: {
        fontFamily: 'Open Sans', fontSize: '14px', fontWeight: 600, color: 'primary', width: '300px', marginTop: '8px'
    },
    secondaryTextVV: {
        fontFamily: 'Roboto', fontSize: '12px', fontWeight: 500, color: '#68A724', width: '100%', marginTop: '8px'
    },
    secondaryText: {
        fontFamily: 'Roboto', fontSize: '12px', fontWeight: 400, color: '#7A7A7D', width: '100%'
    },
    secondaryTextG: {
        fontFamily: 'Roboto', fontSize: '14px', fontWeight: 500, color: '#68A724', width: '100%'
    },
    secondaryTextGV: {
        fontFamily: 'Roboto', fontSize: '12px', fontWeight: 500, color: '#68A724', width: '100%', marginTop: '-10px'
    },
    listNum: {
        fontFamily: 'Roboto', fontSize: '16px', fontWeight: 500
    },
    listName:
    {
        fontFamily: 'Roboto', fontSize: '14px', fontWeight: 400, color: '#7A7A7D'
    },
    assets: {
        fontFamily: 'Roboto', fontSize: '22px', fontWeight: 700, color: 'primary'
    },
    icon: {
        color: '#AAAAAA', marginBottom: '3px'
    },
    driving: {
        color: '#82E219', marginLeft: '-110px'
    },
    drivingR: {
        color: '#ff0000', marginLeft: '-110px'
    },
    copyRight: {
        fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    height: {
        marginTop: '18px', height: '40px', marginLeft: '8px'
    },
    bigResume: {
        marginBottom: theme.spacing(5),
        justifyContent: 'space-between',
        display: 'flex',
        [theme.breakpoints.down('xs')]: {
            height: 160,
            display: 'block',
        },
        '& li': {
            paddingRight: theme.spacing(3),
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-start',
            [theme.breakpoints.down('xs')]: {
                paddingRight: 0,
                paddingBottom: theme.spacing(2),
                width: '50%',
                float: 'left',
            },
        },
        '& $avatar': {
            [theme.breakpoints.up('sm')]: {
                width: 50,
                height: 50,
                '& svg': {
                    fontSize: 32
                }
            }
        }
    },

}));

export default function VehicleDashboard() {
    const dispatch = useDispatch()
    const logged_user = useSelector((store) => store.login.result);
    let enty = logged_user.entity_id
    const [currIndex, setCurrIndex] = React.useState({ asset_linkage_id: 14 });
    const [trackerSearch, setTrackerSearch] = React.useState("");
    const [zoomVar, setZoomVar] = React.useState(0);
    const theme = useTheme();
    const classes = useStyles();
    const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

    const [trackerData, setTrackerData] = React.useState([]);
    const [trackerDetailData, setTrackerDetailData] = React.useState([]);
    const searchDriver = (e, asset_linkage_id) => {
        const getTrackerUrl = endpoints.baseUrl + `/driver/livetrackDetailViewNew/` + asset_linkage_id;
        axios.get(getTrackerUrl, { headers: { 'Authorization': 'bearer aeyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTMsIm1vYmlsZSI6OTg2NTkyNDk1NCwiZXhwIjoxNjUyODY0Nzc4fQ.qe8BWTkJ95KSFr9C0qfwlG3TiVuSFfJ83FBiAcjwIVM' } }).then((response) => {
            setCurrIndex(response.data.data)
            dispatch(setLiveTrackerSelected(response.data.data))
            dispatch(setLiveTrackerSelected(response.data.data))
        })
    }
    const [refreshRate, setRefreshRate] = React.useState(false);
    setTimeout(() => {
        setRefreshRate(!refreshRate)
    }, 60000)
    React.useEffect(() => {
        let alltrackerData = null;
        let enty1 = enty;

        const getTrackerUrl = endpoints.baseUrl + `/driver/livetracknew/` + enty1 + `?search=` + trackerSearch;
        axios.get(getTrackerUrl, { headers: { 'Authorization': 'bearer aeyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTMsIm1vYmlsZSI6OTg2NTkyNDk1NCwiZXhwIjoxNjUyODY0Nzc4fQ.qe8BWTkJ95KSFr9C0qfwlG3TiVuSFfJ83FBiAcjwIVM' } }).then((response) => {
            setTrackerData(response.data.data)
            alltrackerData = response.data;

            dispatch(setLiveTrackerList(trackerData, enty));

        }).catch((error) => {
            let status = null;
            let data = null;
            //If no response from server
            if (!error.response) {
                status = 500;
                data = "No response from server";
            } else {
                status = error.response.status;
                data = error.response.data;
            }
            // dispatch({
            //   type: "GET_ALL_ATTRIBUTE_DATA_OVERVIEW_FAILED",
            //   payload: { status, data },
            // });
        });


    }

        , [trackerSearch, refreshRate])


    const [zoom, setZoom] = React.useState(10);



    // const toNormCase = (word) => {

    //     return word ? word.substr(0, 1).toUpperCase() + word.substr(1) : null
    // }
    const validateKeyData = (key) => {
        return key ? key : "-";
    };
    const currDate = new Date().toLocaleDateString();
    const currTime = new Date().toLocaleTimeString();
    return (
        <>

            <Grid container spacing={2}>
                <Grid item lg={4} xs={12} style={{ marginTop: '20px', borderRadius: '15px' }}>
                    <Paper style={{ height: 390, borderRadius: 2, position: 'relative' }}>
                        <Grid container spacing={2}>
                            <Grid item lg={1} xs={6} /><Grid item lg={1} xs={6}>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={6} />
                                    <Grid item lg={12} xs={6} />
                                    <Grid item lg={12} xs={6}>
                                        <Avatar className={classNames(classes.avatar, classes.pinkAvatar)}>
                                            ID
                                        </Avatar>
                                    </Grid>
                                    <Grid item lg={12} xs={6} />
                                </Grid>
                            </Grid>
                            <Grid item lg={2} xs={6} />
                            <Grid item lg={8} xs={6}>
                                <Grid container spacing={2}>
                                    <Grid item lg={6} xs={6}><Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>12</span>
                                        <Typography>
                                            Battery ID
                                        </Typography>
                                    </Typography></Grid>
                                    <Grid item lg={6} xs={6}><Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>34</span>
                                        <Typography>
                                            Motor ID
                                        </Typography>
                                    </Typography></Grid>
                                    <Grid item lg={6} xs={6}><Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>45</span>
                                        <Typography>
                                            TU ID
                                        </Typography>
                                    </Typography></Grid>
                                    <Grid item lg={6} xs={6}><Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>67</span>
                                        <Typography>
                                            Vehicle ID
                                        </Typography>
                                    </Typography></Grid>
                                </Grid>
                            </Grid><Grid item lg={1} xs={6} />
                        </Grid><br />
                        <Divider component="ul" style={{ marginTop: '5px', marginBottom: '5px' }} /><br />
                        <Grid container spacing={2}>
                            <Grid item lg={1} xs={6} /><Grid item lg={1} xs={6}>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={6} />
                                    <Grid item lg={12} xs={6} />
                                    <Grid item lg={12} xs={6}>
                                        <Avatar className={classNames(classes.avatar, classes.pinkAvatar)}>
                                            <Icon icon="carbon:temperature-celsius" color="#67a11c" width="24" height="24" />
                                        </Avatar>
                                    </Grid>
                                    <Grid item lg={12} xs={6} />
                                </Grid>
                            </Grid>
                            <Grid item lg={2} xs={6} />
                            <Grid item lg={8} xs={6}>
                                <Grid container spacing={2}>
                                    <Grid item lg={6} xs={6}><Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>25C</span>
                                        <Typography>
                                            Motor
                                        </Typography>
                                    </Typography></Grid>
                                    <Grid item lg={6} xs={6}><Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>45C</span>
                                        <Typography>
                                            Controller
                                        </Typography>
                                    </Typography></Grid>
                                    <Grid item lg={6} xs={6}><Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>35C</span>
                                        <Typography>
                                            Battery
                                        </Typography>
                                    </Typography></Grid>
                                    <Grid item lg={6} xs={6}><Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>45C</span>
                                        <Typography>
                                            Ambient
                                        </Typography>
                                    </Typography></Grid>
                                </Grid>
                            </Grid>
                        </Grid></Paper>
                </Grid>
                <Grid xs={12} lg={8}>
                    <Item elevation={0}><Paper className={classes.map} variant="outlined" elevation={2}>
                        <SimpleMap zoom={zoom} />
                    </Paper></Item>
                </Grid>
            </Grid>
            <br />
            {/* <ul className={classes.bigResume}>
                <Grid container spacing={2}>
                    <Grid item lg={3} xs={6}><li>
                        <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                            <Icon icon="fluent:vehicle-car-28-filled" color="#67a11c" width="24" height="24" />
                        </Avatar>
                        <Typography variant="h6">
                            <span style={{
                                color: colorfull[1],
                                '& svg': {
                                    fill: colorfull[1],
                                }
                            }}>Fault</span>
                            <Typography>
                                Status
                            </Typography>
                        </Typography>
                    </li></Grid>
                    <Grid item lg={3} xs={6}><li>
                        <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                            <Icon icon="tabler:steering-wheel" color="#67a11c" width="26" height="26" />
                        </Avatar>
                        <Typography variant="h6">
                        <span style={{
                                color: colorfull[1],
                                '& svg': {
                                    fill: colorfull[1],
                                }
                            }}>Drive</span>
                            <Typography>
                                Driving Mode
                            </Typography>
                        </Typography>
                    </li></Grid>
                    <Grid item lg={3} xs={6}><li>
                        <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                            <Icon icon="ic:outline-speed" color="#67a11c" width="26" height="26" />
                        </Avatar>
                        <Typography variant="h6">
                        <span style={{
                                color: colorfull[1],
                                '& svg': {
                                    fill: colorfull[1],
                                }
                            }}>70 mph</span>
                            <Typography>
                                Speed
                            </Typography>
                        </Typography>
                    </li></Grid>
                    <Grid item lg={3} xs={6}><li>
                        <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                            <Icon icon="mdi:battery-charging-medium" color="#67a11c" width="26" height="26" />
                        </Avatar>
                        <Typography variant="h6">
                        <span style={{
                                color: colorfull[1],
                                '& svg': {
                                    fill: colorfull[1],
                                }
                            }}>60</span>
                            <Typography>
                                SOC
                            </Typography>
                        </Typography>
                    </li></Grid>
                    <Grid item lg={3} xs={6}><li>
                        <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                            <Icon icon="mdi:location-distance" color="#67a11c" width="26" height="26" />
                        </Avatar>
                        <Typography variant="h6">
                        <span style={{
                                color: colorfull[1],
                                '& svg': {
                                    fill: colorfull[1],
                                }
                            }}>98</span>
                            <Typography>
                                Distance to Empty
                            </Typography>
                        </Typography>
                    </li></Grid>
                    <Grid item lg={3} xs={6}><li>
                        <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                            <Icon icon="mdi:battery-recycle" color="#67a11c" width="26" height="26" />
                        </Avatar>
                        <Typography variant="h6">
                        <span style={{
                                color: colorfull[1],
                                '& svg': {
                                    fill: colorfull[1],
                                }
                            }}>98</span>
                            <Typography>
                                Battery Cycle Count
                            </Typography>
                        </Typography>
                    </li></Grid>
                    <Grid item lg={3} xs={6}><li>
                        <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1j6t-VgBMaZ859TfctT6_allvLd3X5pZJcA&usqp=CAU" />
                        </Avatar>
                        <Typography variant="h6">
                        <span style={{
                                color: colorfull[1],
                                '& svg': {
                                    fill: colorfull[1],
                                }
                            }}>98</span>
                            <Typography>
                                Total CO2 Saves
                            </Typography>
                        </Typography>
                    </li></Grid>
                    <Grid item lg={3} xs={6}><li>
                        <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                            <Icon icon="game-icons:path-distance" color="#67a11c" width="26" height="26" />
                        </Avatar>
                        <Typography variant="h6">
                        <span style={{
                                color: colorfull[1],
                                '& svg': {
                                    fill: colorfull[1],
                                }
                            }}>160</span>
                            <Typography>
                                Total Trip Distance
                            </Typography>
                        </Typography>
                    </li></Grid>
                </Grid>
            </ul> */}
            <Grid container spacing={3}>
                <Grid xs={12} lg={6}>
                    <Item elevation={0}><Paper variant="outlined" elevation={2}>
                        <div style={{ margin: 10 }}>
                            <div style={{ display: 'flex', margin: 10, alignItems: 'center' }}>
                                <><Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <Icon icon="fluent:vehicle-car-28-filled" color="#67a11c" width="24" height="24" />
                                </Avatar>&nbsp;&nbsp;
                                    <Divider orientation="vertical" flexItem /></>&nbsp;&nbsp;
                                <><Typography className={classes.primaryText}>&nbsp;&nbsp;Status</Typography>
                                    <Typography className={classes.secondaryTextG}>Fault</Typography></>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10, alignItems: 'center' }}>
                                <><Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    {/* <Icon icon="tabler:steering-wheel-off" color="#67a11c" width="26" height="26" /> */}
                                    <Icon icon="tabler:steering-wheel" color="#67a11c" width="26" height="26" />
                                </Avatar>&nbsp;&nbsp;
                                    <Divider orientation="vertical" flexItem /></>&nbsp;&nbsp;
                                <><Typography className={classes.primaryText}>&nbsp;&nbsp;Driving Mode</Typography>
                                    <Typography className={classes.secondaryTextG}>Drive</Typography></>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10, alignItems: 'center' }}>
                                <><Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <Icon icon="ic:outline-speed" color="#67a11c" width="26" height="26" />
                                </Avatar>&nbsp;&nbsp;
                                    <Divider orientation="vertical" flexItem /></>&nbsp;&nbsp;
                                <><Typography className={classes.primaryText}>&nbsp;&nbsp;Speed</Typography>
                                    <Typography className={classes.secondaryTextG}>70 mph</Typography></>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10, alignItems: 'center' }}>
                                <><Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <Icon icon="mdi:battery-charging-medium" color="#67a11c" width="26" height="26" />
                                </Avatar>&nbsp;&nbsp;
                                    <Divider orientation="vertical" flexItem /></>&nbsp;&nbsp;
                                <><Typography className={classes.primaryText}>&nbsp;&nbsp;SOC</Typography>
                                    <Typography className={classes.secondaryTextG}>60</Typography></>
                            </div>
                        </div>
                    </Paper></Item>
                </Grid>
                <Grid xs={12} lg={6}>
                    <Item elevation={0}><Paper variant="outlined" elevation={2}>
                        <div style={{ margin: 10 }}>
                            <div style={{ display: 'flex', margin: 10, alignItems: 'center' }}>
                                <><Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <Icon icon="mdi:location-distance" color="#67a11c" width="26" height="26" />
                                </Avatar>&nbsp;&nbsp;
                                    <Divider orientation="vertical" flexItem /></>&nbsp;&nbsp;
                                <><Typography className={classes.primaryText}>&nbsp;&nbsp;Distance to Empty</Typography>
                                    <Typography className={classes.secondaryTextG}>98</Typography></>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10, alignItems: 'center' }}>
                                <><Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <Icon icon="mdi:battery-recycle" color="#67a11c" width="26" height="26" />
                                </Avatar>&nbsp;&nbsp;
                                    <Divider orientation="vertical" flexItem /></>&nbsp;&nbsp;
                                <><Typography className={classes.primaryText}>&nbsp;&nbsp;Battery Cycle Count</Typography>
                                    <Typography className={classes.secondaryTextG}>65</Typography></>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10, alignItems: 'center' }}>
                                <><Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1j6t-VgBMaZ859TfctT6_allvLd3X5pZJcA&usqp=CAU" />
                                </Avatar>&nbsp;&nbsp;
                                    <Divider orientation="vertical" flexItem /></>&nbsp;&nbsp;
                                <><Typography className={classes.primaryText}>&nbsp;&nbsp;Total CO2 Saves</Typography>
                                    <Typography className={classes.secondaryTextG}>90</Typography></>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', margin: 10, alignItems: 'center' }}>
                                <><Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <Icon icon="game-icons:path-distance" color="#67a11c" width="26" height="26" />
                                </Avatar>&nbsp;&nbsp;
                                    <Divider orientation="vertical" flexItem /></>&nbsp;&nbsp;
                                <><Typography className={classes.primaryText}>&nbsp;&nbsp;Total Trip Distance</Typography>
                                    <Typography className={classes.secondaryTextG}>160</Typography></>
                            </div>
                        </div>
                    </Paper></Item>
                </Grid>
                <Grid item xs={12} lg={6}>
                    <Paper style={{height: '360px', border: '1px solid #D8D8D8', backgroundColor: '#e5e5ed'}}>
                            <Chart />
                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={6}>
                    <Paper style={{height: '360px', border: '1px solid #D8D8D8', backgroundColor: '#e5e5ed'}}>
                            <Chart1 />
                        </Paper>
                    </Grid>
            </Grid>


            <br />
            <Typography align="center" style={{ fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap' }} > Copyright© 2023 ReVx Energy Pvt. Ltd. </Typography>
        </>
    )
};