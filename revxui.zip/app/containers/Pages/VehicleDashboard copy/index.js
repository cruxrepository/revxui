import React from "react";
import PropTypes from "prop-types";
import { Helmet } from "react-helmet";
import brand from "enl-api/dummy/brand";
import { PapperBlock } from "enl-components";
import { injectIntl, FormattedMessage } from "react-intl";
import messages from "./messages";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import DashboardVehicle from './DashboardVehicle';
import PageTitle from '../../../components/Utils/PageTitle';

function VehicleDashboard(props) {
  const title = brand.name + " - VehicleDashboard";
  const description = brand.desc;
  const { intl } = props;
  return (
    <div>
      <Helmet>
        <title> {title} </title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="twitter:title" content={title} />
        <meta property="twitter:description" content={description} />
      </Helmet> 
      <div style={{marginTop:'-25px'}}><PageTitle/>
    <DashboardVehicle /></div>
    </div>
  );
}

VehicleDashboard.propTypes = {
  intl: PropTypes.object.isRequired,
};

export default injectIntl(VehicleDashboard);
