import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { withStyles, makeStyles, useTheme } from '@material-ui/core/styles';
import Toolbar from '@material-ui/core/Toolbar';
import classNames from 'classnames';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { Icon } from '@iconify/react';
import './App1.css';
import useMediaQuery from "@material-ui/core/useMediaQuery";


let id = 0;
function createData(issue, fleet, vehicleNum, overdue) {
  id += 1;
  return {
    id,
    issue,
    fleet,
    vehicleNum,
    overdue
  };
}

const data = [
  createData('Battery Low Soh', 'EVIFY','TN 01 A 0001', '10/06/2022'),
  createData('Motor Controller High temperature', 'EVIFY','TN 02 B 0002', '25/07/2022'),
  createData('Low Fleet Utilisation', 'Moeving','TN 03 C 0003', '27/08/2022'),
  createData('Battery Pack Short Circuit', 'Moeving','TN 04 D 0004', '8/06/2022'),
  createData('Battery Pack Short Circuit', 'Moeving','TN 04 D 0004', '8/06/2022'),
  createData('Battery Pack Short Circuit', 'Moeving','TN 04 D 0004', '8/06/2022'),
  createData('Battery Pack Short Circuit', 'Moeving','TN 04 D 0004', '8/06/2022'),
  createData('Battery Pack Short Circuit', 'Moeving','TN 04 D 0004', '8/06/2022'),
  createData('Battery Pack Short Circuit', 'Moeving','TN 04 D 0004', '8/06/2022'),
  createData('Battery Pack Short Circuit', 'Moeving','TN 04 D 0004', '8/06/2022'),

];
const useStyles = makeStyles((theme) => ({
  rootTable: {
    width: '100%', margin: 0
  },
  title: {
    backgroundColor: '#009688CC'
  },
  titleFont: {
    color: '#FFFFFF'
  },
  text1: {
    fontFamily: 'Maven Pro', fontSize: '15px', fontWeight: 400, color: '#000000'
  },
  text1M: {
    fontFamily: 'Maven Pro', fontSize: '10px', fontWeight: 400, color: '#000000'
  },
  text2: {
    fontFamily: 'Maven Pro', fontSize: '15px', fontWeight: 400, color: '#FF0B0B'
  },
  text2M: {
    fontFamily: 'Maven Pro', fontSize: '10px', fontWeight: 400, color: '#FF0B0B'
  }
}));

function StrippedTable() {
  //   const { classes } = props;
  const classes = useStyles();
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

  return (
    <>
      <div>
        <Table className={classes.rootTable}>
          <TableHead className={classes.title}>
            <TableRow>
              <TableCell padding="normal" className={classes.titleFont}>Issue</TableCell>
              <TableCell padding="center" className={classes.titleFont}>Fleet Operator</TableCell>
              <TableCell padding="center" className={classes.titleFont}>Vehicle Number</TableCell>
              <TableCell align="right" className={classes.titleFont}>Overdue  Date</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map(n => ([
              <TableRow key={n.id}>
                <TableCell className={isMdUp === true ? classes.text1 : classes.text1M} >{n.issue}</TableCell>
                <TableCell className={isMdUp === true ? classes.text1 : classes.text1M}>{n.fleet}</TableCell>
                <TableCell className={isMdUp === true ? classes.text1 : classes.text1M}>{n.vehicleNum}</TableCell>
                <TableCell align="right" className={isMdUp === true ? classes.text2 : classes.text2M}>{n.overdue}</TableCell>
              </TableRow>
            ]))}
          </TableBody>
        </Table>
      </div>
    </>

  );
}

StrippedTable.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default (StrippedTable);