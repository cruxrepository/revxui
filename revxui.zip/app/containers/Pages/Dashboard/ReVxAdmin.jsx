import React from 'react';
import colorfull from 'enl-api/palette/colorfull';
import { makeStyles, useTheme, styled, withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import SimpleMap from "./SimpleMap";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import Slider from '@material-ui/core/Slider';
import { Icon } from '@iconify/react';
import BasicTable from './BasicTable';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import classNames from 'classnames';
import TableRow from '@material-ui/core/TableRow';
import './App1.css';
import CO2 from "./imgs/co2-cloud.png";
import PaymentPieMobile from "./PaymentPieMobile";
import { Avatar, Divider } from '@material-ui/core';
import { Computer, LocalLibrary, Style, Toys } from '@material-ui/icons';
import Chart from './Chart';
import Chart1 from './Chart1';

const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'left',
    color: theme.palette.text.secondary,
}));
const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.secondary.dark,
        backgroundColor: theme.palette.secondary.light,
    },
    map: {
        height: 350, overflowY: 'hidden', borderRadius: 2, position: 'relative'
    },
    turingX: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#009688', letterSpacing: '0.03em'
    },
    box: {
        border: '1px solid #009688', height: '130px', borderRadius: '40px', backgroundColor: '#F8F8F8'

    },
    box1: {
        height: '160px', borderRadius: '23px', backgroundColor: '#E5E5E5', marginTop: 25, margin: 20

    },
    copyRight: {
        fontSize: '16px', color: '#68A724', fontWeight: 700, fontStyle: 'Bold', whiteSpace: 'nowrap'
    },
    drive: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: theme.palette.secondary.dark, margin: 45
    },
    paperH: {
        height: '350px', border: '1px solid #D8D8D8'
    },
    paperH1: {
        height: '200px', border: '1px solid #D8D8D8'
    },
    paperH2: {
        height: '300px', border: '1px solid #D8D8D8'
    },
    paperH3: {
        height: '300px', border: '1px solid #D8D8D8'
    },
    slide: {
        margin: 30
    },
    slider: {
        '& > .MuiSlider-thumbColorPrimary': { opacity: '0 !important' },
        color: '#009688', borderRadius: '0px',
        '& > .MuiSlider-rail': { height: '5px', color: '#C4C4C4' }, '& > .MuiSlider-track': { height: '5px' },
        marginTop: '-5px'
    },
    sliderTxt: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 600
    },
    sliderTxt2: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 500, color: '#5F6368', marginLeft: '125px', marginTop: '-30px'
    },
    icon: {
        marginLeft: 45
    },
    iconS: {
        marginLeft: 20
    },
    iconSM: {
        marginLeft: 20
    },
    boxGreen: {
        border: '5px solid #68A724', width: 45, height: 45, borderRadius: '25px', marginTop: '-65px', marginLeft: '-38px'
    },
    boxYellow: {
        border: '5px solid #BCBC26', width: 45, height: 45, borderRadius: '25px', marginTop: '20px', marginLeft: '-40px'
    },
    boxRed: {
        border: '5px solid #C4C4C4', width: 45, height: 45, borderRadius: '25px', marginTop: '20px', marginLeft: '-40px'
    },
    txt1: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 400, color: '#000000'
    },
    txt2: {
        fontFamily: 'Maven Pro', fontSize: '17px', fontWeight: 700, color: '#000000'
    },
    txt3: {
        fontFamily: 'Maven Pro', fontSize: '18px', fontWeight: 700, color: '#000000'
    },
    txt1M: {
        fontFamily: 'Maven Pro', fontSize: '15px', fontWeight: 400, color: '#000000'
    },
    txt2M: {
        fontFamily: 'Maven Pro', fontSize: '12px', fontWeight: 700, color: '#000000'
    },
    txt3M: {
        fontFamily: 'Maven Pro', fontSize: '10px', fontWeight: 700, color: '#000000'
    },
    boxtxt: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#000000', marginTop: '5px'
    },
    boxtxtM: {
        fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#000000', marginTop: '10px'
    },
    boxGreenM: {
        border: '5px solid #68A724', width: 45, height: 45, borderRadius: '25px'
    },
    boxYellowM: {
        border: '5px solid #BCBC26', width: 45, height: 45, borderRadius: '25px'
    },
    boxRedM: {
        border: '5px solid #C4C4C4', width: 45, height: 45, borderRadius: '25px'
    },
    bigResume: {
        marginBottom: theme.spacing(5),
        justifyContent: 'space-between',
        display: 'flex',
        [theme.breakpoints.down('xs')]: {
            height: 160,
            display: 'block',
        },
        '& li': {
            paddingRight: theme.spacing(3),
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-start',
            [theme.breakpoints.down('xs')]: {
                paddingRight: 0,
                paddingBottom: theme.spacing(2),
                width: '50%',
                float: 'left',
            },
        },
        '& $avatar': {
            [theme.breakpoints.up('sm')]: {
                width: 50,
                height: 50,
                '& svg': {
                    fontSize: 32
                }
            }
        }
    },
    bigResume1: {
        marginBottom: theme.spacing(5),
        justifyContent: 'space-between',
        display: 'flex',
        [theme.breakpoints.down('xs')]: {
            height: 160,
            display: 'block',
        },
        '& li': {
            paddingRight: theme.spacing(3),
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-start',
            [theme.breakpoints.down('xs')]: {
                paddingRight: 0,
                paddingBottom: theme.spacing(2),
                width: '100%',
                float: 'left',
            },
        },
        '& $avatar': {
            [theme.breakpoints.up('sm')]: {
                width: 50,
                height: 50,
                '& svg': {
                    fontSize: 32
                }
            }
        }
    },
    avatar: {
        marginRight: theme.spacing(1),
        boxShadow: theme.shadows[4],
        background: theme.palette.background.paper,
        '& svg': {
            fontSize: 24,
            fill: theme.palette.primary.main
        },
        '&$sm': {
            width: 30,
            height: 30
        },
        '&$mc': {
            width: 24,
            height: 24,
            top: 2,
            left: 8,
            marginRight: 0
        },
    },
    pinkAvatar: {
        color: colorfull[0],
        border: `1px solid ${colorfull[0]}`
    },
    purpleAvatar: {
        color: colorfull[1],
        border: `1px solid ${colorfull[1]}`
    },
    blueAvatar: {
        color: colorfull[2],
        border: `1px solid ${colorfull[2]}`
    },
    tealAvatar: {
        color: colorfull[3],
        border: `1px solid ${colorfull[3]}`
    },
}));

export default function RevxAdmin() {


    const [trackerSearch, setTrackerSearch] = React.useState("");
    const [zoomVar, setZoomVar] = React.useState(0);
    const theme = useTheme();
    const classes = useStyles();
    const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

    return (
        <>

            <div className={classes.root}>
                <Grid container spacing={2}>
                    <Grid item lg={12} xs={12}>
                        <ul className={classes.bigResume}>
                            <Grid container spacing={2}>
                                <Grid item lg={3} xs={6}><li>
                                    <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                        <Icon icon="fluent:vehicle-car-28-filled" color="#9ccc65" width="24" height="24" />
                                    </Avatar>
                                    <Typography variant="h6">
                                        <span style={{
                                            color: colorfull[1],
                                            '& svg': {
                                                fill: colorfull[1],
                                            }
                                        }}>Fault</span>
                                        <Typography>
                                            Status
                                        </Typography>
                                    </Typography>
                                </li></Grid>
                                <Grid item lg={3} xs={6}><li>
                                    <Avatar className={classNames(classes.avatar, classes.blueAvatar)}>
                                    {/* <Icon icon="tabler:steering-wheel-off" color="#9ccc65" width="26" height="26" /> */}
                                    <Icon icon="tabler:steering-wheel" color="#9ccc65" width="26" height="26" />
                                    </Avatar>
                                    <Typography variant="h6">
                                        <span style={{
                                            color: colorfull[2],
                                            '& svg': {
                                                fill: colorfull[2],
                                            }
                                        }}>Drive</span>
                                        <Typography>
                                            Driving Mode
                                        </Typography>
                                    </Typography>
                                </li></Grid>
                                <Grid item lg={3} xs={6}><li>
                                    <Avatar className={classNames(classes.avatar, classes.tealAvatar)}>
                                        <Style />
                                    </Avatar>
                                    <Typography variant="h6">
                                        <span style={{
                                            color: colorfull[3],
                                            '& svg': {
                                                fill: colorfull[3],
                                            }
                                        }}>70 mph</span>
                                        <Typography>
                                            Speed
                                        </Typography>
                                    </Typography>
                                </li></Grid>
                                <Grid item lg={3} xs={6}><li>
                                    <Avatar className={classNames(classes.avatar, classes.pinkAvatar)}>
                                    <Icon icon="mdi:battery-charging-medium" color="#9ccc65" width="26" height="26" />
                                    </Avatar>
                                    <Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>60</span>
                                        <Typography>
                                            SOC
                                        </Typography>
                                    </Typography>
                                </li></Grid>
                                <Grid item lg={3} xs={6}><li>
                                    <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <Icon icon="mdi:location-distance" color="#9ccc65" width="26" height="26" />
                                    </Avatar>
                                    <Typography variant="h6">
                                        <span style={{
                                            color: colorfull[1],
                                            '& svg': {
                                                fill: colorfull[1],
                                            }
                                        }}>98</span>
                                        <Typography>
                                            Distance to Empty
                                        </Typography>
                                    </Typography>
                                </li></Grid>
                                <Grid item lg={3} xs={6}><li>
                                    <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <Icon icon="mdi:battery-recycle" color="#9ccc65" width="26" height="26" />
                                    </Avatar>
                                    <Typography variant="h6">
                                        <span style={{
                                            color: colorfull[1],
                                            '& svg': {
                                                fill: colorfull[1],
                                            }
                                        }}>98</span>
                                        <Typography>
                                            Battery Cycle Count
                                        </Typography>
                                    </Typography>
                                </li></Grid>
                                <Grid item lg={3} xs={6}><li>
                                    <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                                    <CO2 />
                                    </Avatar>
                                    <Typography variant="h6">
                                        <span style={{
                                            color: colorfull[1],
                                            '& svg': {
                                                fill: colorfull[1],
                                            }
                                        }}>98</span>
                                        <Typography>
                                            Total CO2 Saves
                                        </Typography>
                                    </Typography>
                                </li></Grid>
                                <Grid item lg={3} xs={6}><li>
                                    <Avatar className={classNames(classes.avatar, classes.pinkAvatar)}>
                                        <LocalLibrary />
                                    </Avatar>
                                    <Typography variant="h6">
                                        <span style={{
                                            color: colorfull[0],
                                            '& svg': {
                                                fill: colorfull[0],
                                            }
                                        }}>160</span>
                                        <Typography>
                                            Total Trip Distance
                                        </Typography>
                                    </Typography>
                                </li></Grid>
                            </Grid>
                        </ul>
                        <Grid container spacing={2}>
                            <Grid item lg={3} xs={12} style={{ marginTop: '20px', borderRadius: '15px' }}>
                                <Grid container spacing={2}>
                                    <Grid item lg={1} xs={6}>
                                        <Grid container spacing={2}>
                                            <Grid item lg={12} xs={6} />
                                            <Grid item lg={12} xs={6} />
                                            <Grid item lg={12} xs={6}>
                                                <Avatar className={classNames(classes.avatar, classes.pinkAvatar)}>
                                                    ID
                                                </Avatar>
                                            </Grid>
                                            <Grid item lg={12} xs={6} />
                                        </Grid>
                                    </Grid>
                                    <Grid item lg={1} xs={6} />
                                    <Grid item lg={7} xs={6}>
                                        <Grid container spacing={2}>
                                            <Grid item lg={6} xs={6}><Typography variant="h6">
                                                <span style={{
                                                    color: colorfull[0],
                                                    '& svg': {
                                                        fill: colorfull[0],
                                                    }
                                                }}>12</span>
                                                <Typography>
                                                    Battery ID
                                                </Typography>
                                            </Typography></Grid>
                                            <Grid item lg={6} xs={6}><Typography variant="h6">
                                                <span style={{
                                                    color: colorfull[0],
                                                    '& svg': {
                                                        fill: colorfull[0],
                                                    }
                                                }}>34</span>
                                                <Typography>
                                                    Motor ID
                                                </Typography>
                                            </Typography></Grid>
                                            <Grid item lg={6} xs={6}><Typography variant="h6">
                                                <span style={{
                                                    color: colorfull[0],
                                                    '& svg': {
                                                        fill: colorfull[0],
                                                    }
                                                }}>45</span>
                                                <Typography>
                                                    TU ID
                                                </Typography>
                                            </Typography></Grid>
                                            <Grid item lg={6} xs={6}><Typography variant="h6">
                                                <span style={{
                                                    color: colorfull[0],
                                                    '& svg': {
                                                        fill: colorfull[0],
                                                    }
                                                }}>67</span>
                                                <Typography>
                                                    Vehicle ID
                                                </Typography>
                                            </Typography></Grid>
                                        </Grid>
                                    </Grid><Grid item lg={1} xs={6} />
                                </Grid><br/>
                                <Divider component="ul" style={{marginTop:'5px', marginBottom:'5px'}} /><br/>
                                <Grid container spacing={2}>
                                    <Grid item lg={1} xs={6}>
                                        <Grid container spacing={2}>
                                            <Grid item lg={12} xs={6} />
                                            <Grid item lg={12} xs={6} />
                                            <Grid item lg={12} xs={6}>
                                                <Avatar className={classNames(classes.avatar, classes.pinkAvatar)}>
                                                    <Icon icon="carbon:temperature-celsius" color="#9ccc65" width="24" height="24" />
                                                </Avatar>
                                            </Grid>
                                            <Grid item lg={12} xs={6} />
                                        </Grid>
                                    </Grid>
                                    <Grid item lg={1} xs={6} />
                                    <Grid item lg={7} xs={6}>
                                        <Grid container spacing={2}>
                                            <Grid item lg={6} xs={6}><Typography variant="h6">
                                                <span style={{
                                                    color: colorfull[0],
                                                    '& svg': {
                                                        fill: colorfull[0],
                                                    }
                                                }}>25C</span>
                                                <Typography>
                                                    Motor
                                                </Typography>
                                            </Typography></Grid>
                                            <Grid item lg={6} xs={6}><Typography variant="h6">
                                                <span style={{
                                                    color: colorfull[0],
                                                    '& svg': {
                                                        fill: colorfull[0],
                                                    }
                                                }}>45C</span>
                                                <Typography>
                                                    Controller
                                                </Typography>
                                            </Typography></Grid>
                                            <Grid item lg={6} xs={6}><Typography variant="h6">
                                                <span style={{
                                                    color: colorfull[0],
                                                    '& svg': {
                                                        fill: colorfull[0],
                                                    }
                                                }}>35C</span>
                                                <Typography>
                                                    Battery
                                                </Typography>
                                            </Typography></Grid>
                                            <Grid item lg={6} xs={6}><Typography variant="h6">
                                                <span style={{
                                                    color: colorfull[0],
                                                    '& svg': {
                                                        fill: colorfull[0],
                                                    }
                                                }}>45C</span>
                                                <Typography>
                                                    Ambient
                                                </Typography>
                                            </Typography></Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} lg={9}>
                            <Paper className={classes.map} variant="outlined" >
                            <SimpleMap zoom={zoomVar} />
                        </Paper>
                        
                    </Grid>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} lg={6}>
                    <Paper style={{height: '360px', border: '1px solid #D8D8D8', backgroundColor: '#e5e5ed'}}>
                            <Chart />
                        </Paper>
                    </Grid>
                    <Grid item xs={12} lg={6}>
                    <Paper style={{height: '360px', border: '1px solid #D8D8D8', backgroundColor: '#e5e5ed'}}>
                            <Chart1 />
                        </Paper>
                    </Grid>
                   
                </Grid>
            </div>
            <br />
            <Typography align="center" className={classes.copyRight} > Copyright© 2023 ReVx Energy Pvt.Ltd. </Typography>
        </>
    )
};
