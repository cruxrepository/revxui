import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Toolbar from '@material-ui/core/Toolbar';
import classNames from 'classnames';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import Box from '@material-ui/core/Box';
import TableRow from '@material-ui/core/TableRow';
import { Icon } from '@iconify/react';
import './App1.css';


// let id = 0;
// function createData(issue, overdue) {
//   id += 1;
//   return {
//     id,
//     issue,
//     overdue
//   };
// }

// const data = [
//   createData('Energy Problem', '20.12.2020'),
//   createData('Energy Problem', '21.04.2020'),
//   createData('Energy Problem', '22.01.2022'),
//   createData('Energy Problem', '22.01.2022')
// ];
const useStyles = makeStyles((theme) => ({
  rootTable: {
    width: '100%',borderBottom:0
  },
  txt1: {
    fontFamily: 'Maven Pro',fontSize: '17px',fontWeight: 400,color:'#000000'
  },
  txt2: {
    fontFamily:'Maven Pro', fontSize: '17px', fontWeight: 700,color:'#000000'  
  },
  txt3: {
    fontFamily:'Maven Pro', fontSize: '18px', fontWeight: 700,color:'#000000'  
  },
  boxGreen: {
    border: '5px solid #68A724', width: 45, height: 45, borderRadius: '25px',marginTop:'-65px',marginLeft:'-55px'
  },
  boxYellow: {
    border: '5px solid #BCBC26', width: 45, height: 45, borderRadius: '25px',marginTop:'20px',marginLeft:'-60px'
  },
  boxRed: {
    border: '5px solid #C4C4C4', width: 45, height: 45, borderRadius: '25px',marginTop:'20px',marginLeft:'-65px'
  },
  boxtxt: {
    fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#000000',marginTop:'5px'
  },
  health: {
    fontFamily: 'Maven Pro', fontSize: '20px', fontWeight: 700, color: '#000000'

  },
  cl: {
    color: '#68A724'
  }
}));



function StrippedTable() {
  //   const { classes } = props;
  const classes = useStyles();

  return (
    <>
      <div>
        <Table className={classes.rootTable}>
          <TableBody>
            <TableRow>
              <TableCell className={classes.txt1}>2 W<Typography className={classes.txt2}>100</Typography></TableCell>
              <TableCell className={classes.txt3}>Healthy<Icon icon="mdi:minus" color="#68a724" width="40" height="45" /></TableCell>
              <Box className={classes.boxGreen} align="center">
                <Typography align="center" className={classes.boxtxt}></Typography>30</Box> 

              <TableCell className={classes.txt3}>UnHealthy<Icon icon="mdi:minus" color="#BCBC26" width="40" height="45" /></TableCell>
              <Box className={classes.boxYellow} align="center">
              <Typography align="center" className={classes.boxtxt}></Typography>30</Box> 

              <TableCell className={classes.txt3}>Deactivated<Icon icon="mdi:minus" color="#C4C4C4" width="40" height="45" /></TableCell>
              <Box className={classes.boxRed} align="center">
              <Typography align="center" className={classes.boxtxt}></Typography>30</Box> 
            </TableRow>

            <TableRow>
              <TableCell className={classes.txt1}>3 W<Typography className={classes.txt2}>150</Typography></TableCell>
              <TableCell className={classes.txt3}>Healthy<Icon icon="mdi:minus" color="#68a724" width="40" height="45" /></TableCell>
              <Box className={classes.boxGreen} align="center">
                <Typography align="center" className={classes.boxtxt}></Typography>70</Box> 

              <TableCell className={classes.txt3}>UnHealthy<Icon icon="mdi:minus" color="#BCBC26" width="40" height="45" /></TableCell>
              <Box className={classes.boxYellow} align="center">
              <Typography align="center" className={classes.boxtxt}></Typography>50</Box> 

              <TableCell className={classes.txt3}>Deactivated<Icon icon="mdi:minus" color="#C4C4C4" width="40" height="45" /></TableCell>
              <Box className={classes.boxRed} align="center">
              <Typography align="center" className={classes.boxtxt}></Typography>30</Box> 
            </TableRow>

            <TableRow>
              <TableCell className={classes.txt1}>Battery<Typography className={classes.txt2}>200</Typography></TableCell>
              <TableCell className={classes.txt3}>Healthy<Icon icon="mdi:minus" color="#68a724" width="40" height="45" /></TableCell>
              <Box className={classes.boxGreen} align="center">
                <Typography align="center" className={classes.boxtxt}></Typography>120</Box> 

              <TableCell className={classes.txt3}>UnHealthy<Icon icon="mdi:minus" color="#BCBC26" width="40" height="45" /></TableCell>
              <Box className={classes.boxYellow} align="center">
              <Typography align="center" className={classes.boxtxt}></Typography>40</Box> 

              <TableCell className={classes.txt3}>Deactivated<Icon icon="mdi:minus" color="#C4C4C4" width="40" height="45" /></TableCell>
              <Box className={classes.boxRed} align="center">
              <Typography align="center" className={classes.boxtxt}></Typography>10</Box> 
            </TableRow>
          </TableBody>
        </Table>
      </div>
    </>

  );
}

StrippedTable.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default (StrippedTable);