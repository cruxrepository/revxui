import React from 'react';
import { Helmet } from 'react-helmet';
import brand from 'enl-api/dummy/brand';
import { PapperBlock } from 'enl-components';
import CompossedLineBarArea from './CompossedLineBarArea';
import StrippedTable from '../Table/StrippedTable';
import Box from '@material-ui/core/Box';
import RevxAdmin from './ReVxAdmin';
import PageTitle from '../../../components/Utils/PageTitle';
import Button from '@material-ui/core/Button';
import { useDispatch, useSelector } from "react-redux";

function BasicTable() {
  const title = brand.name + ' - Dashboard';
  const description = brand.desc;
  const loc = location.pathname;
  // const logged_user = useSelector((store) => store.user.loggeduser);
   return (
    <div>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="twitter:title" content={title} />
        <meta property="twitter:description" content={description} />
      </Helmet> 
      <div style={{marginTop:'-25px'}}><PageTitle /><br/>
      <Button href="/app/pages/dashboard" variant={loc === '/app/pages/dashboard' ? "contained" : "outlined"} color="primary">
      ReVx Admin 
          </Button>&nbsp;
          <Button href="/app/pages/fleetmanager" variant={loc === '/app/pages/fleetmanager' ? "contained" : "outlined"} color="primary">
          Fleet Manager
          </Button>&nbsp;
          <Button href="/app/pages/operationsmanager" variant={loc === '/app/pages/operationsmanager' ? "contained" : "outlined"} color="primary">
          Operations Manager
          </Button>&nbsp;
          <Button href="/app/pages/vehicleinvestor" variant={loc === '/app/pages/vehicleinvestor' ? "contained" : "outlined"} color="primary">
          Vehicle Investor
          </Button>&nbsp;
          <Button href="/app/pages/batteryinvestor" variant={loc === '/app/pages/batteryinvestor' ? "contained" : "outlined"} color="primary">
          Battery Investor
          </Button><br /><br />
       <Box><RevxAdmin /></Box></div>
      {/* <PapperBlock title="Statistic Chart" icon="insert_chart" desc="" overflowX>
        <div>
          <CompossedLineBarArea />
        </div>
      </PapperBlock>
      <PapperBlock title="Table" whiteBg icon="grid_on" desc="UI Table when no data to be shown">
        <div>
          <StrippedTable />
        </div>
      </PapperBlock> */}
    </div>
  );
}

export default BasicTable;
