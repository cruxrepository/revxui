import React from "react";
// import GoogleMapReact from "google-map-react";
import { GoogleMap, LoadScript, Marker, Polyline } from "@react-google-maps/api";
import { Link } from "react-router-dom";
import endpoints from "../../../endpoints/endpoints";
import { Icon } from "@iconify/react";
import LocationOnIcon from "@material-ui/icons/LocationOn";
import { useDispatch, useSelector } from "react-redux";
import vech1_a from "./imgs/vech1_a.svg";
export default function MyComponent(props) {
  const { zoom, mapRes } = props;

  const markerStyle = {
    position: "absolute",
    top: "100%",
    left: "50%",
    transform: "translate(-50%, -100%)",
  };
  const containerStyle = {
    width: "100%",
    height: "100%",
  };
  let defaultProps = {
    center: {
      lat: 77.31012,
      lng: 28.4922766,
    },
    zoom: 10,
  };

  let VDashboardMeta = useSelector((store) => store.vehicleDash)

  const [newLat, setNewLat] = React.useState(
    parseFloat(VDashboardMeta.data[0] && VDashboardMeta.data[0]["current_lat"])
  );
  const [newLan, setNewLan] = React.useState(
    parseFloat(VDashboardMeta.data[0] && VDashboardMeta.data[0]["current_lan"])
  );
  let responsePath = mapRes;
  const [finalPath, setFinalPath] = React.useState([]);
  let newFinalObj = [];

  // React.useEffect(()=>{

  responsePath && responsePath.map((el) => {
    el = el.split(",");
    // console.log("el", el);

    let newObj = {};
    newObj.lat = Number(el[1]);
    newObj.lng = Number(el[0]);
    newFinalObj.push(newObj);
  });
  //  setFinalPath(newFinalObj)
  // },[])

  // console.log("finalPath", newFinalObj);
  const center = {
    // lat: newLat,
    // lng: newLan

    lat: newLat,
    lng: newLan,
  };
  const onLoad = (polyline) => {
    // console.log("polyline: ", polyline);
  };


  const options = {
    strokeColor: "blue",
    strokeOpacity: 0.8,
    strokeWeight: 5,
    fillColor: "light blue",
    fillOpacity: 1,
    clickable: false,
    draggable: false,
    editable: false,
    visible: true,
    // radius: 30000,
    paths: newFinalObj,
    zIndex: 1,
  };

  return (
    // Important! Always set the container height explicitly
    // <div style={{ height: "100%", width: "100%" }}>
    <LoadScript googleMapsApiKey="AIzaSyDTqXNwhdiuyeCvRCvFkbPj8NxXpTTHsJU">
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        // panTo={center}
        zoom={zoom}
      // onClick={(ev) => {
      //     setLattitude(ev.latLng.lat())
      //     setLongitude(ev.latLng.lng())
      //   }}
      >
        <Marker icon={vech1_a} position={center} />
        <Polyline
          onLoad={onLoad}
          path={newFinalObj}
          options={options}
        ></Polyline>
      </GoogleMap>
    </LoadScript>
    // </div>
  );
}
