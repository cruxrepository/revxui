import React from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";

export default function Chart() {
    const options = {
        chart: {
            type: "spline"
        },
        title: {
            align: "left",text: "Mileage"
        },
        legend: false,
        xAxis: {
            label: "Time"
        },
        series: [
            {
                data: [9,1,4,9,5,1,4,7,3,2,8,9,5,4,3,3,9,4,2,8,4,8]
            }
        ]
    };

    return (
        <HighchartsReact highcharts={Highcharts} options={options} />
    );
}