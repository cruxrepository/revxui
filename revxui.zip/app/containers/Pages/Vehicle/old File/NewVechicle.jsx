import React from "react";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import PostAddOutlinedIcon from "@material-ui/icons/PostAddOutlined";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
  useStyles,
} from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
import InputAdornment from "@material-ui/core/InputAdornment";
import TextField from "@material-ui/core/TextField";
import { Icon } from "@iconify/react";
import vehicleTruckCube24Regular from "@iconify/icons-fluent/vehicle-truck-cube-24-regular";
import tabAdd24Filled from "@iconify/icons-fluent/tab-add-24-filled";
//import { DialogComponent, PositionDataModel } from '@syncfusion/ej2-react-popups';
//import Dialog from "react-native-dialog";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import { useState } from "react";
import DateFnsUtils from "@date-io/date-fns";

import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";

export default function NewVechicle(props) {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("sm"));

  const [openVehicle, setOpenVehicle] = React.useState(false);
  const [openModel, setOpenModel] = React.useState(false);
  const handleClick = () => {
  };

  const useStyles = makeStyles((theme) => ({
    margin: {
      margin: theme.spacing(3),
    },
    withoutLabel: {
      marginTop: theme.spacing(3),
      '& > div': {
        alignItems: 'center'
      }
    },
    textField: {
      flexBasis: 200,
    },
    dialogPaper: {
      height: "100%",
      width: "150%",
    },
    divStyle: {
      width: "500px",
    },
    screensize: {},
    modelIcon: {
      "&:hover": {
        color: "#9ccc65",
      },
      transform: "translateX(-10em)",
    },
    vehicleIcon: {
      "&:hover": {
        color: "#9ccc65",
      },
      transform: "translateX(-10em)",
    },
    styleL: {
      fontSize: "15px",
      fontFamily: " Maven Pro",
      fontWeight: 400,
      color: "#A7A7A7",
    },
    styleM: {
      //width: "100%",
      borderRadius: "9px",
      marginBottom: "10px",
      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
        borderColor: "#7A7A7D  !important",
      },
    },
    styleN: {
      ".MuiPaper-root": { width: "80% !important", marginLeft: "60px" },
    },
    styleO: {
      width: "90%",
      color: "#7A7A7D",
      borderRadius: "9px",
      //paddingBottom: "10px",
      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
        borderColor: "#C4C4C4  !important",
      },
      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
    },
    styleE: {
      padding: "8px",
    },
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    "& input": {
      color: theme.palette.text.primary,
      background: "transparent",
      width: "100%",
      height: "100%",
      margin: 0,
      padding: "2px 20px 2px 2px",
      boxSizing: "border-box",
      border: "none",
      boxShadow: "none",
      outline: "none",
      fontSize: "15px",

    },
  }));

  //   const theme = useTheme();
  const classes = useStyles();
  const [index, setIndex] = React.useState(0);
  const [insuExpDate, setInsuExpDate] = React.useState(
    new Date("2022-08-18T21:11:54")
  );
  const [permitExpDate, setPermitExpDate] = React.useState(
    new Date("2022-08-18T21:11:54")
  );
  const [manufaDate, setManufaDate] = React.useState(
    new Date("2022-08-18T21:11:54")
  );

  const handleDateChange1 = (date) => {
    setInsuExpDate(date);
  };

  const handleDateChange2 = (date) => {
    setPermitExpDate(date);
  };
  const handleDateChange3 = (date) => {
    setManufaDate(date);
  };
  const vechList = [
    {
      vehiNumber: "TN 12 C1234",
      vehiNumberLabel: "Vehicle Number",
      ownerName: "Gabby George",
      ownerNameLabel: "Owner Name",
      typeVechi: "2W",
      typeVechiLabel: "Type of Vehicle",
      socLeft: "56km Left",
      socLabel: "SOC/Km Left",
      actionButton: "Deactive",
      actionLabel: "Action Button",
      status: "healthy",
      statusLabel: "Status",
    },
    {
      vehiNumber: "TN 12 I1489",
      vehiNumberLabel: "Vehicle Number",
      ownerName: "Blake Duncan",
      ownerNameLabel: "Owner Name",
      typeVechi: "3W",
      typeVechiLabel: "Type of Vehicle",
      socLeft: "56km Left",
      socLabel: "SOC/Km Left",
      actionButton: "Assign",
      actionLabel: "Action Button",
      status: "Unhealthy",
      statusLabel: "Status",
    },
    {
      vehiNumber: "TN 12 C1234",
      vehiNumberLabel: "Vehicle Number",
      ownerName: "Franky Rees",
      ownerNameLabel: "Owner Name",
      typeVechi: "4W",
      typeVechiLabel: "Type of Vehicle",
      socLeft: "56km Left",
      socLabel: "SOC/Km Left",
      actionButton: "Deactive",
      actionLabel: "Action Button",
      status: "healthy",
      statusLabel: "Status",
    },
  ];

  const [dataState, setDataState] = useState({
    vechiModel: "",
    vechiSeats: "",
    status: "",
    weight:""
  });

  const handleChange = (event) => {
    setDataState({
      ...dataState,
      [event.target.name]: event.target.value,
    });
  };
  
  return (
    <>
        <DialogContent>
          <div className={classes.divStyle}>
            <DialogTitle id="responsive-dialog-title">
              Vehicle Model
            </DialogTitle>
            <Grid container spacing={2}>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>
                  Vehicle Model
                </Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Vehicle Model"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>Fuel</Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Fuel"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>
                  Unladen_weight
                </Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Unladen_weight"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}> Seating</Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Seating"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}> Width</Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Width"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}> Length</Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Length"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}> Height</Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Height"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>
                  Gross Vehicle Weight
                </Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Gross Vehicle Weight"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>
                  Payload Weight
                </Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg:  Payload Weight"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>Top Speed</Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Top Speed"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>
                  Typical Range
                </Typography>
                <TextField
                  size="small"
                  id="outlined"
                  className={classes.styleO}
                  placeholder="eg: Typical Range"
                  defaultValue={vechList[index].Uname}
                />
              </Grid>

              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>
                  Reference Image
                </Typography>
                <Button
                  sx={{
                    ":hover": { backgroundColor: "#fff" },
                  }}
                >
                  <input type="file" style={{ color: "#C1C1C1" }} />
                </Button>
              </Grid>
              <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>
                  Online link/Datasheet
                </Typography>
                <Button
                  sx={{
                    ":hover": { backgroundColor: "#fff" },
                  }}
                >
                  <input type="file" style={{ color: "#C1C1C1" }} />
                </Button>
              </Grid>
            </Grid>
          </div>
        </DialogContent>
        <DialogActions>
          <Button
            autoFocus
            onClick={() => setOpenModel(false)}
            color="secondary"
          >
            Cancel
          </Button>
          <Button onClick={() => setOpenModel(false)} color="primary" autoFocus>
            Agree
          </Button>
        </DialogActions>
    </>
  );
}

// export default withStyles(CustomToolbar, defaultToolbarStyles, { name: "CustomToolbar" });
