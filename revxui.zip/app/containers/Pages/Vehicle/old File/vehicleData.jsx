import Typography from "@material-ui/core/Typography";
import React from "react";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "@material-ui/core/Button";
import { element } from "prop-types";


const VehicleColumn = [
  {
    name: "Vehicle Number",
    options: {
      filter: true,
      customBodyRender: (value) => (
        <Typography
          //onClick={() => setScreen(true)}
          style={{ color: "#33a6ff", cursor: "pointer" }}
          variant="subtitle2"
        >
          {value}
        </Typography>
      ),
    },
  },
  {
    name: "Owner Name",
    options: {
      filter: true,
      customBodyRender: (value) => (
        <Typography variant="subtitle2">{value}</Typography>
      ),
    },
  },
  {
    name: "Type of Vehicle",
    options: {
      filter: false,
      customBodyRender: (value) => (
        <Typography variant="subtitle2">{value}</Typography>
        //   <LinearProgress variant="determinate" color="secondary" value={value} />
      ),
    },
  },
  {
    name: "SOC/Km Left",
    options: {
      filter: true,

      customBodyRender: (value) => {
        return (
          <Typography variant="subtitle2" color="secondary">
            {value}
          </Typography>
        );
      },
    },
  },

  {
    name: "Action Button",
    options: {
      filter: true,
      customBodyRender: (value) => {
        if (value === "assign") {
          return (
            <Select style={{ minWidth: 150, color: "#FFC130" }} value="assign">
              <MenuItem style={{ color: "red !important" }} value="deactive">
                Deactivate
              </MenuItem>
              <MenuItem style={{ color: "#FFC130 !important" }} value="assign">
                Assign
              </MenuItem>
            </Select>
          );
        } else {
          return (
            <Select style={{ minWidth: 150, color: "red" }} value="deactive">
              <MenuItem style={{ color: "red !important" }} value="deactive">
                Deactivate
              </MenuItem>
              <MenuItem style={{ color: "#FFC130 !important" }} value="assign">
                Assign
              </MenuItem>
            </Select>
          );
        }
      },
    },
  },
  {
    name: "Status",
    options: {
      filter: true,
      customBodyRender: (value) => {
        if (value === "unhealthy") {
          return (
            <Button
              variant="contained"
              style={{ minWidth: 130, background: "#FFC130", color: "white" }}
            >
              {value}
            </Button>
          );
        } else {
          return (
            <Button
              variant="contained"
              style={{ minWidth: 130, background: "#68A724", color: "white" }}
            >
              {value}
            </Button>
          );
        }
      },
    },
  },
];
 const VehicleModel = [
  {
    name: "Vehicle Model",
    options: {
      filter: true,
      customBodyRender: (value) => (
        <Typography
          //onClick={() => setScreen(true)}
          style={{ color: "#000000", cursor: "pointer" }}
          variant="subtitle2"
        >
          {value}
        </Typography>
      ),
    },
  },
  {
    name: "Seating",
    options: {
      filter: true,
      customBodyRender: (value) => (
        <Typography variant="subtitle2">{value}</Typography>
      ),
    },
  },
  {
    name: "Top Speed",
    options: {
      filter: false,
      customBodyRender: (value) => (
        <Typography variant="subtitle2">{value}</Typography>
        //   <LinearProgress variant="determinate" color="secondary" value={value} />
      ),
    },
  },
  {
    name: "Payload Weight",
    options: {
      filter: true,

      customBodyRender: (value) => {
        return (
          <Typography variant="subtitle2" color="secondary">
            {value}
          </Typography>
        );
      },
    },
  },
  {
    name: "Typical Range",
    options: {
      filter: true,

      customBodyRender: (value) => {
        return (
          <Typography variant="subtitle2" color="secondary">
            {value}
          </Typography>
        );
      },
    },
  },

  {
    name: "Action Button",
    options: {
      filter: true,
      customBodyRender: (value) => {
        if (value === "assign") {
          return (
            <Select style={{ minWidth: 150, color: "#FFC130" }} value="assign">
              <MenuItem style={{ color: "red !important" }} value="deactive">
                Deactivate
              </MenuItem>
              <MenuItem style={{ color: "#FFC130 !important" }} value="assign">
                Assign
              </MenuItem>
            </Select>
          );
        } else {
          return (
            <Select style={{ minWidth: 150, color: "red" }} value="deactive">
              <MenuItem style={{ color: "red !important" }} value="deactive">
                Deactivate
              </MenuItem>
              <MenuItem style={{ color: "#FFC130 !important" }} value="assign">
                Assign
              </MenuItem>
            </Select>
          );
        }
      },
    },
  },
];

 const VehiData = [
  ["TN 12 C1234", " Gabby George", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 u4234", " Aiden Lloyd", "2 W", "56 KM Left", "deactive", "healthy"],
  [
    "TN 12 I1489",
    " Jaden Collins ",
    "2 W",
    "56 KM Left",
    "deactive",
    "healthy",
  ],
  ["TN 12 M1598", "Franky Rees", "2 W", "56 KM Left", "Assign", "unhealthy"],
  ["TN 12 V3698", "Aaren Rose", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 V1789", " Blake Duncan", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 A2589", " Frankie Parry", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 D5896", " Lane Wilson", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 C1234", " Robin Duncan", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 C1234", " Gabby George", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 u4234", " Gabby George", "2 W", "56 KM Left", "deactive", "healthy"],
  [
    "TN 12 I1489",
    " Gabby George",
    "2 W",
    "56 KM Left",
    "deactive",
    "unhealthy",
  ],
  ["TN 12 M1598", " Gabby George", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 V3698", " Gabby George", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 V1789", " Gabby George", "2 W", "56 KM Left", "deactive", "healthy"],
  ["TN 12 A2589", " Gabby George", "2 W", "56 KM Left", "deactive", "healthy"],
  [
    "TN 12 D5896",
    " Gabby George",
    "2 W",
    "56 KM Left",
    "deactive",
    "unhealthy",
  ],
  ["TN 12 C1234", " Gabby George", "2 W", "56 KM Left", "deactive", "healthy"],
];
 const ModelData = [
  ["TVS ", " 4 Seating", "80km", "105", "40-50", "edit"],
  ["Honda ", " 4 Seating", "80km", "105", "40-50", "edit"],
  ["TVS ", " 4 Seating", "80km", "105", "40-50", "edit"],
  ["Honda ", " 4 Seating", "80km", "105", "40-50", "edit"],
  ["Honda ", " 4 Seating", "80km", "105", "40-50", "edit"],
  ["TVS ", " 4 Seating", "80km", "105", "40-50", "edit"],
  ["TVS ", " 4 Seating", "80km", "105", "40-50", "edit"],
  ["Honda ", " 4 Seating", "80km", "105", "40-50", "edit"],
];


// export const ModelDataedit = [
//   {id: 0, model: "TVS ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
//   {id: 1, model: "Suzuki ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
//   {id: 2, model: "Honda ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
//   {id: 3, model: "Maruti ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
//   {id: 4, model: "Innova ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
//   {id: 5, model: "Hero ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
//   {id: 6, model: "Activa ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
//   {id: 7, model: "TVS ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
//   {id: 8, model: "Mahendra ", seating:" 4 Seating", top_spead:"80km", payload_weight:"105", typical_range:"40-50", action:""},
// ];

export function getColumns(value) {
  if (value === 0) {
    return VehicleColumn;
  }
  if (value === 1) {
    return VehicleColumn;
  }
  return VehicleModel;
}

export function getData(value) {

  if (value === 0) {
    return VehiData;
  }
  if (value === 1) {
    return VehiData;
  }
  return ModelData;
}


// const handleChange=()=> {
  
//   if(VehicleModel[5].options=="edit"){
//       Window.alert("edit me")
//   }
// };
