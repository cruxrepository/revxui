import React from "react";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import PostAddOutlinedIcon from '@material-ui/icons/PostAddOutlined';
import { withStyles, makeStyles, useTheme, styled, useStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';



export default function AddVehicle(props) {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const [openAdd, setOpenAdd] = React.useState(false);
  const handleClick = () => {
  }
  const useStyles = makeStyles((theme) => ({
    IconButton: {
      '&:hover': {
        color: '#9ccc65'
      },
      transform: "translateX(-12em)"
    }
  }));

  //   const theme = useTheme();
  const classes = useStyles();

  return (
    <React.Fragment>
      <Tooltip style={{ flex: 'left' }} title={"Add"}>
        <IconButton className={classes.IconButton} onClick={() => setOpenAdd(true)}>
          <PostAddOutlinedIcon />
        </IconButton>
      </Tooltip>
      <Dialog
        fullScreen={fullScreen}
        open={openAdd}
        maxWidth={"lg"}
        onClose={() => setOpenAdd(false)}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogTitle id="responsive-dialog-title">{"Add"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
          To be used as Add new Form 
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus onClick={() => setOpenAdd(false)}
            color="secondary">
            Cancel
          </Button>
          <Button onClick={() => setOpenAdd(false)}
            color="primary" autoFocus>
            Agree
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );


}

// export default withStyles(CustomToolbar, defaultToolbarStyles, { name: "CustomToolbar" });
