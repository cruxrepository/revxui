import React, { useState } from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import ListItemText from "@material-ui/core/ListItemText";
import InputLabel from "@material-ui/core/InputLabel";
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import Tooltip from "@material-ui/core/Tooltip";
import useMediaQuery from '@material-ui/core/useMediaQuery';

import Grid from "@material-ui/core/Grid";
import IconButton from "@material-ui/core/IconButton";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
// import makeAPICall from "../../reducers/batteryActions";
// import { getAllEBatteries } from '../../../actions/asyncActions';
// import getCBattery from "../../../api/batteryPage/getCBattery"
import { Icon } from "@iconify/react";
import endpoints from "../../../endpoints/endpoints";
// import CustomToolbar from "./CustomToobar";
import TabIcon from "@material-ui/icons/Tab";
import AirportShuttleIcon from "@material-ui/icons/AirportShuttle";
import FormControl from "@material-ui/core/FormControl";

import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Pagination from "@material-ui/lab/Pagination";
import Checkbox from "@material-ui/core/Checkbox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import FormControlLabel from "@material-ui/core/FormControlLabel";

import TextField from "@material-ui/core/TextField";
import DateFnsUtils from "@date-io/date-fns";

import { useDispatch, useSelector } from "react-redux";
import {
  getCommVBulk,
  getErickVBulk,
  getCVBulk,
  getEVBulk,
  getVMBulk,
  getIVBulk,
  getOMBulk,
  getFleetBulk,
  getVDABulk,
  getEVDABulk,
  getTelematicsBulk,
  getVModelBulk,
  getBABulk,
  getTeleModelBulk,
  TeleAssignBulk
} from "../../../redux/actions/asyncActions";
import Loading from "../../../components/Loading";
import ErrorWrap from "../../../components/Error/ErrorWrap";
import SimpleSnackbar from "../Users/SimpleSnackbar";
import { Avatar, Divider, StepButton } from "@material-ui/core";
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';

const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  dialog: {
    // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
    position: 'relative', marginLeft: '680px'
  },
  tabsSection: {
    [theme.breakpoints.up("lg")]: {
      // borderRadius:0,position:'sticky',top:0 ,width:500
      borderRadius: 0,
      position: "sticky",
      top: 0,
      width: 500,
    },
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },

  textField: {
    flexBasis: 200,
  },
  // divStyle: {
  //   width: "500px",
  // },
  // screensize: {},
  // modelIcon: {
  //   "&:hover": {
  //     color: "#9ccc65",
  //   },
  //   transform: "translateX(-10em)",
  // },
  styleL: {
    fontSize: "15px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#A7A7A7",
  },
  styleM: {
    //width: "100%",
    borderRadius: "9px",
    marginBottom: "10px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#7A7A7D  !important",
    },
  },
  styleN: {
    ".MuiPaper-root": { width: "80% !important", marginLeft: "60px" },
  },
  styleO: {
    width: "100%",
    color: "#7A7A7D",
    borderRadius: "9px",
    //paddingBottom: "10px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#C4C4C4  !important",
    },
    "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
  },
  styleE: {
    padding: "8px",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  "& input": {
    color: theme.palette.text.primary,
    background: "transparent",
    width: "100%",
    height: "100%",
    margin: 0,
    padding: "2px 20px 2px 2px",
    boxSizing: "border-box",
    border: "none",
    boxShadow: "none",
    outline: "none",
    fontSize: "15px",
  },

  //CSS For Textfield

  dialogPaper: {
    height: "85%",
    width: "50%",
    marginLeft: "700px",
  },
  divStyle: {
    width: "500px",
  },
  // screensize: {},
  // modelIcon: {
  //   "&:hover": {
  //     color: "#9ccc65",
  //   },
  //   transform: "translateX(-10em)",
  // },
  secondaryTextG: {
    fontFamily: "Maven Pro",
    fontSize: "16px",
    fontWeight: 600,
    color: "#68A724",
    width: "100%",
  },
}));

/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function VehicleContent() {
  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const CVVData = useSelector((store) => store.commV)
  const CVVDataRaw = useSelector((store) => store.commV.rawData)
  let CVVMeta = useSelector((store) => store.commV)
  let CVVFetching = useSelector((store) => store.commV.fetching)
  let CVVResponsecode = useSelector((store) => store.commV.responseStatus)
  let CVVMetaPresent = useSelector((store) => store.commV.dataPresent)

  const EVVData = useSelector((store) => store.erickV)
  const EVVDataRaw = useSelector((store) => store.erickV.rawData)
  let EVVMeta = useSelector((store) => store.erickV)
  let EVVFetching = useSelector((store) => store.erickV.fetching)
  let EVVResponsecode = useSelector((store) => store.erickV.responseStatus)
  let EVVMetaPresent = useSelector((store) => store.erickV.dataPresent)


  const theme = useTheme();
  const [openCVehicle, setOpenCVehicle] = React.useState(false);
  const [openCVEdit, setOpenCVEdit] = React.useState(false);

  const [openEVehicle, setOpenEVehicle] = React.useState(false);
  const [openEVEdit, setOpenEVEdit] = React.useState(false);

  const [openVM, setOpenVM] = React.useState(false);
  const [openVMEdit, setOpenVMEdit] = React.useState(false);

  const [openDriverDeActive, setOpenDriverDeActive] = React.useState(false);
  const [openDriverActive, setOpenDriverActive] = React.useState(false);

  const [openEDriverDeActive, setOpenEDriverDeActive] = React.useState(false);
  const [openEDriverActive, setOpenEDriverActive] = React.useState(false);

  const [openBAssign, setOpenBAssign] = React.useState(false);
  const [openBReAssign, setOpenBReAssign] = React.useState(false);

  const [openRC, setOpenRC] = React.useState(false);
  const [openIns, setOpenIns] = React.useState(false);
  const [openPermit, setOpenPermit] = React.useState(false);
  const [openERC, setOpenERC] = React.useState(false);
  const [openEIns, setOpenEIns] = React.useState(false);
  const [openEPermit, setOpenEPermit] = React.useState(false);
  const [openRef, setOpenRef] = React.useState(false);
  const [openData, setOpenData] = React.useState(false);

  const [vehBatID, setVehBatID] = React.useState(0);
  const [assignID, setAssignID] = React.useState(0);
  const [assetLink, setAssetLink] = React.useState(0);

  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false);

  const [openTele, setOpenTele] = React.useState(false);
  const [openTeleD, setOpenTeleD] = React.useState(false);

  const [notificationTimeOut, setNotificationTimeOut] = React.useState(3000);
  const [addResponse, setAddResponce] = React.useState("");
  const [page, setPage] = React.useState(1);
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const [open, setOpen] = React.useState(false);
  const [ddd, setDdd] = React.useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };
  const [open1, setOpen1] = React.useState(false);
  const [ddd1, setDdd1] = React.useState(false);

  const handleClick1 = () => {
    setOpen1(true);
  };

  const handleClose1 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen1(false);
  };
  const [open2, setOpen2] = React.useState(false);
  const [ddd2, setDdd2] = React.useState(false);

  const handleClick2 = () => {
    setOpen2(true);
  };

  const handleClose2 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen2(false);
  };
  const [open3, setOpen3] = React.useState(false);
  const [ddd3, setDdd3] = React.useState(false);

  const handleClick3 = () => {
    setOpen3(true);
  };

  const handleClose3 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen3(false);
  };
  const [open4, setOpen4] = React.useState(false);
  const [ddd4, setDdd4] = React.useState(false);

  const handleClick4 = () => {
    setOpen4(true);
  };

  const handleClose4 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen4(false);
  };
  const [file, setFile] = React.useState();

  function handleChangeRC(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setCVAddForm((state) => ({ ...state, upload_rc_book: response.data }));
    });
  }

  function handleChangeIns(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setCVAddForm((state) => ({ ...state, upload_insurance: response.data }));
    });
  }

  function handleChangePermit(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setCVAddForm((state) => ({
        ...state,
        upload_permit_image: response.data,
      }));
    });
  }

  function handleChangeRCedit(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEditCArray((state) => ({ ...state, upload_rc_book: response.data }));
    });
  }

  function handleChangeInsedit(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEditCArray((state) => ({ ...state, upload_insurance: response.data }));
    });
  }

  function handleChangePermitedit(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEditCArray((state) => ({
        ...state,
        upload_permit_image: response.data,
      }));
    });
  }

  function handleChangeERC(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEVAddForm((state) => ({ ...state, upload_rc_book: response.data }));
    });
  }

  function handleChangeEIns(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEVAddForm((state) => ({ ...state, upload_insurance: response.data }));
    });
  }

  function handleChangeEPermit(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEVAddForm((state) => ({
        ...state,
        upload_permit_image: response.data,
      }));
    });
  }

  function handleChangeRef(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setAddVMForm((state) => ({ ...state, reference_Image: response.data }));
    });
  }
  function handleChangeDataSheet(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setAddVMForm((state) => ({ ...state, datasheet: response.data }));
    });
  }

  const changePage = (event, newValue) => {
    setPage(newValue);
  };

  const logged_user = useSelector((store) => store.login.result);
  let enty = logged_user.entity_id;
  let enty1 = logged_user.entity_id === "1";
  let uName = logged_user.username;
  let roid = logged_user.role_id;
  let vehicleEditAccess = logged_user.vehicle === "edit";
  let pWord = logged_user.password

  const CVData = useSelector((store) => store.cvAll);
  const CVDataRaw = useSelector((store) => store.cvAll.rawData);
  const CVMeta = {};
  CVMeta.data = [];
  const CVMetaa = useSelector((store) => store.cvAll);
  if (CVMetaa.data.length >= 1) {
    CVMeta.data = CVMetaa.data;
  }
  const MyCVPage = useSelector((store) => store.cvAll.page_number);
  const MyCVCount = Math.ceil(
    useSelector((store) => store.cvAll.total_records) / 10
  );
  let CVFetching = useSelector((store) => store.cvAll.fetching);
  let CVResponsecode = useSelector((store) => store.cvAll.responseStatus);
  const CVMetaPresent = useSelector((store) => store.cvAll.dataPresent);
  // console.log("CVMetaa.data",CVMetaa.data)


  const CVLData = useSelector((store) => store.cvTotal);
  const CVLDataRaw = useSelector((store) => store.cvTotal.rawData);
  const CVLMeta = {};
  CVLMeta.data = [];
  const CVLMetaa = useSelector((store) => store.cvTotal);
  if (CVLMetaa.data.length >= 1) {
    CVLMeta.data = CVLMetaa.data;
  }
  let CVLFetching = useSelector((store) => store.cvTotal.fetching);
  let CVLResponsecode = useSelector((store) => store.cvTotal.responseStatus);
  const CVLMetaPresent = useSelector((store) => store.cvTotal.dataPresent);

  let VehicleNumber = CVLMeta.data.map(function (el) { return el[0]; });
  let VehicleType = CVLMeta.data.map(function (el) { return el[1]; });
  let VehicleStatus = CVLMeta.data.map(function (el) { return el[2]; });
  let VehicleInvestor = CVLMeta.data.map(function (el) { return el[3]; });
  let VehicleDriver = CVLMeta.data.map(function (el) { return el[4]; });
  let VehicleBattery = CVLMeta.data.map(function (el) { return el[5]; });
  let VehicleDistance = CVLMeta.data.map(function (el) { return el[6]; });
  let VehicleBatteryStatus = CVLMeta.data.map(function (el) { return el[7]; });
  let VehicleDriverStatus = CVLMeta.data.map(function (el) { return el[8]; });
  let VehicleModelInfo = CVLMeta.data.map(function (el) { return el[9]; });
  let VehicleChassisNumber = CVLMeta.data.map(function (el) { return el[10]; });
  let VehicleEngineNumber = CVLMeta.data.map(function (el) { return el[11]; });
  let VehicleFleet = CVLMeta.data.map(function (el) { return el[12]; });
  let VehicleOperationalManager = CVLMeta.data.map(function (el) { return el[13]; });

  //Erick 
  const EVData = useSelector((store) => store.evAll);
  const EVDataRaw = useSelector((store) => store.evAll.rawData);
  let EVMeta = useSelector((store) => store.evAll);
  const MyEVPage = useSelector((store) => store.evAll.page_number);
  const MyEVCount = Math.ceil(
    useSelector((store) => store.evAll.total_records) / 10
  );
  let EVFetching = useSelector((store) => store.evAll.fetching);
  let EVResponsecode = useSelector((store) => store.evAll.responseStatus);
  let EVMetaPresent = useSelector((store) => store.evAll.dataPresent);


  const EVLData = useSelector((store) => store.evTotal);
  const EVLDataRaw = useSelector((store) => store.evTotal.rawData);
  const EVLMeta = {};
  EVLMeta.data = [];
  const EVLMetaa = useSelector((store) => store.evTotal);
  if (EVLMetaa.data.length >= 1) {
    EVLMeta.data = EVLMetaa.data;
  }
  let EVLFetching = useSelector((store) => store.evTotal.fetching);
  let EVLResponsecode = useSelector((store) => store.evTotal.responseStatus);
  let EVLMetaPresent = useSelector((store) => store.evTotal.dataPresent);

  let EVehicleNumber = EVLMeta.data.map(function (el) { return el[0]; });
  let EVehicleInvestor = EVLMeta.data.map(function (el) { return el[1]; });
  let EVehicleSOC = EVLMeta.data.map(function (el) { return el[2]; });
  let EVehicleModel = EVLMeta.data.map(function (el) { return el[3]; });
  let EVehicleChassis = EVLMeta.data.map(function (el) { return el[4]; });
  let EVehicleEngine = EVLMeta.data.map(function (el) { return el[5]; });
  let EVehicleFleet = EVLMeta.data.map(function (el) { return el[6]; });
  let EVehicleOperationalManager = EVLMeta.data.map(function (el) { return el[7]; });
  let EVehicleType = EVLMeta.data.map(function (el) { return el[8]; });
  let EVehicleStatus = EVLMeta.data.map(function (el) { return el[9]; });
  let EVehicleDriverStatus = EVLMeta.data.map(function (el) { return el[10]; });
  let EVehicleDriver = EVLMeta.data.map(function (el) { return el[11]; });
  let EVehicleDistance = EVLMeta.data.map(function (el) { return el[12]; });

  //Model
  const VMData = useSelector((store) => store.vmAll);
  const VMDataRaw = useSelector((store) => store.vmAll.rawData);
  let VMMeta = useSelector((store) => store.vmAll);
  const MyVMPage = useSelector((store) => store.vmAll.page_number);
  const MyVMCount = Math.ceil(
    useSelector((store) => store.vmAll.total_records) / 10
  );
  let VMFetching = useSelector((store) => store.vmAll.fetching);
  let VMResponsecode = useSelector((store) => store.vmAll.responseStatus);
  let VMMetaPresent = useSelector((store) => store.vmAll.dataPresent);

  // Investor
  const IVData = useSelector((store) => store.ivAll);
  const IVDataRaw = useSelector((store) => store.ivAll.rawData);
  let IVMeta = useSelector((store) => store.ivAll);
  let IVFetching = useSelector((store) => store.ivAll.fetching);
  let IVResponsecode = useSelector((store) => store.ivAll.responseStatus);
  let IVMetaPresent = useSelector((store) => store.ivAll.dataPresent);

  //  Operation
  const OMData = useSelector((store) => store.omAll);
  const OMDataRaw = useSelector((store) => store.omAll.rawData);
  let OMMeta = useSelector((store) => store.omAll);
  let OMFetching = useSelector((store) => store.omAll.fetching);
  let OMResponsecode = useSelector((store) => store.omAll.responseStatus);
  let OMMetaPresent = useSelector((store) => store.omAll.dataPresent);

  //Fleet
  const FleetData = useSelector((store) => store.fleetAll);
  const FleetDataRaw = useSelector((store) => store.fleetAll.rawData);

  let FleetMeta = useSelector((store) => store.fleetAll);
  let FleetFetching = useSelector((store) => store.fleetAll.fetching);
  let FleetResponsecode = useSelector((store) => store.fleetAll.responseStatus);
  let FleetMetaPresent = useSelector((store) => store.fleetAll.dataPresent);

  //Driver Assign
  const VDAData = useSelector((store) => store.vdaAll);
  const VDADataRaw = useSelector((store) => store.vdaAll.rawData);
  let VDAMeta = useSelector((store) => store.vdaAll);
  let VDAFetching = useSelector((store) => store.vdaAll.fetching);
  let VDAResponsecode = useSelector((store) => store.vdaAll.responseStatus);
  let VDAMetaPresent = useSelector((store) => store.vdaAll.dataPresent);

  const EVDAData = useSelector((store) => store.evdaAll);
  const EVDADataRaw = useSelector((store) => store.evdaAll.rawData);
  let EVDAMeta = useSelector((store) => store.evdaAll);
  let EVDAFetching = useSelector((store) => store.evdaAll.fetching);
  let EVDAResponsecode = useSelector((store) => store.evdaAll.responseStatus);
  let EVDAMetaPresent = useSelector((store) => store.evdaAll.dataPresent);

  const BAData = useSelector((store) => store.bAAll);
  const BADataRaw = useSelector((store) => store.bAAll.rawData);
  let BAMeta = useSelector((store) => store.bAAll);
  let BAFetching = useSelector((store) => store.bAAll.fetching);
  let BAResponsecode = useSelector((store) => store.bAAll.responseStatus);
  let BAMetaPresent = useSelector((store) => store.bAAll.dataPresent);

  const VModelData = useSelector((store) => store.vModel);
  const VModelDataRaw = useSelector((store) => store.vModel.rawData);
  let VModelMeta = useSelector((store) => store.vModel);
  let VModelFetching = useSelector((store) => store.vModel.fetching);
  let VModelResponsecode = useSelector((store) => store.vModel.responseStatus);
  let VModelMetaPresent = useSelector((store) => store.vModel.dataPresent);

  //Telematics
  const TelematicsData = useSelector((store) => store.teleModelAll);
  const TelematicsDataRaw = useSelector((store) => store.teleModelAll.rawData);
  let TelematicsMeta = {};
  TelematicsMeta.data = [];
  let TelematicsMetaa = useSelector((store) => store.teleModelAll);
  if (TelematicsMetaa.data.length >= 1) {
    TelematicsMeta.data = TelematicsMetaa.data;
  }
  let TelematicsFetching = useSelector((store) => store.teleModelAll.fetching);
  let TelematicsResponsecode = useSelector(
    (store) => store.teleModelAll.responseStatus
  );
  let TelematicsMetaPresent = useSelector(
    (store) => store.teleModelAll.dataPresent
  );


  //Telematics IMEI

  const TeleIMEIData = useSelector((store) => store.imeiAll);
  const TeleIMEIDataRaw = useSelector((store) => store.imeiAll.rawData);
  let TeleIMEIMeta = useSelector((store) => store.imeiAll);
  let TeleIMEIFetching = useSelector((store) => store.imeiAll.fetching);
  let TeleIMEIResponsecode = useSelector((store) => store.imeiAll.responseStatus);
  let TeleIMEIMetaPresent = useSelector((store) => store.imeiAll.dataPresent);

  const dispatch = useDispatch();

  const [getImei, setGetImei] = React.useState({});
  React.useEffect(() => {
    const get = endpoints.baseUrl + `/telematics/assign/get`;
    const cinemaCatGet = axios
      .get(get)
      .then((response) => {
        setGetImei(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);


  const [modelPage, setModelPage] = React.useState(1);
  const changePageBatModel = (event, newValue) => {
    setModelPage(newValue);
  };
  const [pageCV, setPageCV] = React.useState(1);
  const changePageCV = (event, newValue) => {
    setPageCV(newValue);
  };
  const [pageEV, setPageEV] = React.useState(1);
  const changePageEV = (event, newValue) => {
    setPageEV(newValue);
  };
  React.useEffect(() => {
    dispatch(TeleAssignBulk());
  }, [dispatch, TeleIMEIMetaPresent]);

  React.useEffect(() => {
    dispatch(getCVBulk(enty, pageCV));
    dispatch(getVMBulk(modelPage));
    dispatch(getIVBulk(enty));
    // dispatch(getEVLBulk(enty));
    dispatch(getFleetBulk());
    dispatch(getVDABulk(enty));
    dispatch(getEVDABulk(enty));
    dispatch(getTelematicsBulk(page));
    dispatch(getVModelBulk());
    dispatch(getBABulk());
  }, [
    dispatch,
    EVLMetaPresent,
    CVMetaPresent,
    CVVMetaPresent,
    EVVMetaPresent,
    CVLMetaPresent,
    pageCV,
    VMMetaPresent,
    modelPage,
    FleetMetaPresent,
    IVMetaPresent,
    VDAMetaPresent,
    EVDAMetaPresent,
    TelematicsMetaPresent,
    page,
    VModelMetaPresent,
    BAMetaPresent,
  ]);
  React.useEffect(() => {
    dispatch(getEVBulk(enty, pageEV));
  }, [dispatch, EVMetaPresent, pageEV]);


  let allVM = VMMeta.data;
  let modelList = VModelMeta.data;
  let allTele = TelematicsMeta.data;
  const validateKeyData = (key) => {
    return key ? key : "-";
  };

  const [dataOn, setDataOn] = React.useState(false);

  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const [password1, setPassword1] = React.useState("");
  const [password2, setPassword2] = React.useState("");
  const [delete1, setDelete1] = React.useState("");
  const [delete2, setDelete2] = React.useState("");
  const [selectedId1, setSelectedId1] = React.useState("");
  const [selectedId2, setSelectedId2] = React.useState("");

  const handleChange = (event, newValue) => {
    setValue(newValue);
    setOpenCVehicle(false)
    setOpenCVEdit(false)
    setOpenEVehicle(false)
    setOpenEVEdit(false)
    setOpenVM(false)
    setOpenVMEdit(false)
    handleReset()
    handleReset1()
    handleReset2()
    handleReset3()
    handleReset4()
    handleReset5()
  };

  const options = {
    filter: false,
    search: true,
    responsive: "vertical",
    print: false,
    rowsPerPage: 100,
    downloadCsv: true,
    selectableRows: "none",
    onDownload: (buildHead, buildBody, columns, data) => {
      buildHead = () => {
        return ["Vehicle Number", "Vehicle Type", "Investor", "Driver Name", "Battery", "Distance to Empty"]
      }
      buildBody = () => {
        let allRows = []

        data.map((col) => {
          let newRow = [];
          newRow.push(col.data[0])
          newRow.push(col.data[1]['type'])
          newRow.push(col.data[2])
          newRow.push(col.data[3])
          newRow.push(col.data[4])
          newRow.push(col.data[5])
          allRows.push("\n" + newRow)
        })

        return allRows;
      }
      return "\uFEFF" + buildHead() + buildBody();
    },
    customToolbar: () => {
      if (vehicleEditAccess === true)
        return (<Tooltip style={{ flex: "left" }} title={"Onboarding Vehicle"}>
          <IconButton
            style={{ transform: "translateX(-8em)" }}
            onClick={() => {
              setOpenCVehicle(true);
            }}
          >
            < Icon icon="ic:baseline-airport-shuttle" width="22"
              height="22" />
          </IconButton>
        </Tooltip>);
      else {
        return (null)
      }
    },
  };

  const options1 = {
    filter: false,
    filterType: "dropdown",
    responsive: "vertical",
    search: true,
    print: false,
    page: 0,
    downloadCsv: true,
    selectableRows: "none",
    onDownload: (buildHead, buildBody, columns, data) => {
      buildHead = () => {
        return ["Vehicle Number", "Investor", "Distance to Empty"]
      }
      buildBody = () => {
        let allRows = []

        data.map((col) => {
          let newRow = [];
          newRow.push(col.data[0])
          newRow.push(col.data[1])
          newRow.push(col.data[2])
          allRows.push("\n" + newRow)
        })

        return allRows;
      }
      return "\uFEFF" + buildHead() + buildBody();
    },
    customToolbar: () => {
      if (vehicleEditAccess === true)
        return (
          <Tooltip style={{ flex: "left" }} title={"Onboarding E-Ricksaw"}>
            <IconButton
              style={{ transform: "translateX(-8em)" }}
              onClick={() => {
                setOpenEVehicle(true);
              }}
            >
              <Icon
                icon="material-symbols:electric-rickshaw"
                width="22"
                height="22"
              />
            </IconButton>
          </Tooltip>
        );
      else {
        return (null)
      }
    },
  };

  const options2 = {
    filterType: "dropdown",
    responsive: "vertical",
    print: false,
    search: true,
    page: 0,
    downloadCsv: true,
    selectableRows: "none",
    customToolbar: () => {
      if (vehicleEditAccess === true)
        return (
          <Tooltip style={{ flex: "left" }} title={"Onboarding Model"}>
            <IconButton
              style={{ transform: "translateX(-10em)" }}
              onClick={() => {
                setOpenVM(true);
              }}
            >
              <Icon
                icon="material-symbols:tab-outline"
                width="22"
                height="22"
              />
            </IconButton>
          </Tooltip>
        );
      else {
        null;
      }
    },
  };
  const [chartOneVal, setChartOneVal] = React.useState("day");
  const handleChartOneVal = (e) => {
    setChartOneVal(e.target.value);
  };
  const Header = () => { };

  const [dataState, setDataState] = useState({
    vechiModel: "",
    vechiSeats: "",
    status: "",
    weight: "",
  });

  const [frame, setFrame] = React.useState(false);

  const [rowIndex, setRowIndex] = React.useState(0);

  const [clear1, setClear1] = React.useState([]);
  const [clear2, setClear2] = React.useState([]);
  const [clear3, setClear3] = React.useState([]);
  const [clear4, setClear4] = React.useState([]);
  const [clear5, setClear5] = React.useState([]);
  const [clear6, setClear6] = React.useState([]);
  const [clear7, setClear7] = React.useState([]);
  const [clear8, setClear8] = React.useState([]);
  const [clear9, setClear9] = React.useState([]);
  const [clear10, setClear10] = React.useState([]);
  const [clear11, setClear11] = React.useState([]);
  const [clear12, setClear12] = React.useState([]);
  const [clear13, setClear13] = React.useState([]);
  const [clear14, setClear14] = React.useState([]);

  const VehicleColumn = [
    {
      name: "Vehicle",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-start', marginLeft: '35px' }}>


            {
              value.type === "2W" && value.vehicle_status === "assign" ?
                <><Tooltip style={{ flex: "left" }} title={"Assigned"}>
                  <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px', marginTop: 1 }}>
                    <Icon
                      icon="mdi:motorbike"
                      color="#fff"
                      width="22"
                      height="22"
                    />
                  </Avatar>
                </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                value.type === "E-Auto" &&
                  value.vehicle_status === "assign" ?
                  <><Tooltip style={{ flex: "left" }} title={"Assigned"}>
                    <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px', marginTop: 1 }}>
                      <Icon
                        icon="fluent-emoji-high-contrast:auto-rickshaw"
                        color="#fff"
                        width="22"
                        height="22"
                      />
                    </Avatar>
                  </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                  value.type === "l5n" &&
                    value.vehicle_status === "assign" ?
                    <>
                      <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                        <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px', marginTop: 1 }}>
                          <Icon
                            icon="fa-solid:truck-pickup"
                            color="#fff"
                            width="22"
                            height="22"
                          />
                        </Avatar>
                      </Tooltip>
                      <Divider orientation="vertical" variant="middle" flexItem /></>
                    :
                    value.type === "2W" && value.vehicle_status === "unassign" ?
                      <><Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                        <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px', marginTop: 1 }}>
                          <Icon
                            icon="mdi:motorbike"
                            color="#fff"
                            width="22"
                            height="22"
                          />
                        </Avatar>
                      </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                      value.type === "E-Auto" && value.vehicle_status === "unassign" ?
                        <><Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                          <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px', marginTop: 1 }}>
                            <Icon
                              icon="fluent-emoji-high-contrast:auto-rickshaw"
                              color="#fff"
                              width="22"
                              height="22"
                            />
                          </Avatar>
                        </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                        value.type === "l5n" && value.vehicle_status === "unassign" ?
                          <><Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                            <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px', marginTop: 1 }}>
                              <Icon
                                icon="fa-solid:truck-pickup"
                                color="#fff"
                                width="22"
                                height="22"
                              />
                            </Avatar>
                          </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                          <><Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                            <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px', marginTop: 1 }}>
                              <Icon
                                icon="mdi:motorbike"
                                color="#fff"
                                width="22"
                                height="22"
                              />
                            </Avatar>
                          </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></>

            }
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}><Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}
            >
              {validateKeyData(value.vehicle_number)}
            </Typography>
              <Typography
                style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
              >
                {validateKeyData(value.vehicle_model)}
              </Typography>
            </div>
          </div>
        ),
      },
    },
    {
      name: "Battery",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', marginLeft: '60px' }}>
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}
            >{validateKeyData(value.serial_number)}</Typography>
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
            >{validateKeyData(value.updated_at)}</Typography></div>
        ),
      },
    },
    {
      name: " Investor",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <Typography
              style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-15px' }}
            >
              {validateKeyData(value)}
            </Typography>

          );
        },
      },
    },
    {
      name: "Driver",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <Typography
              style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-15px' }}
            >
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Distance to Empty",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
            >
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Assignment",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverDeActive(true);
                    setCVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setSelectedImei(value.imei)
                    setCVEditArray(value.vehicle_id);
                    setAssetLink(value.asset_linkage_id);
                    setOpenTeleD(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)

                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          } else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverDeActive(true);
                    setCVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    setDrive(value.driver_name); }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#c4c4c4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setAssignTele((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setOpenTele(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          } else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverActive(true);
                    setCVEditArray(value.vehicle_id);
                    setCVEditArray(value.vehicle_id);
                    setAssignDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDrive(value.driver_name);}}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setAssignTele((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setOpenTele(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton 
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
          else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverActive(true);
                    setCVEditArray(value.vehicle_id);
                    setCVEditArray(value.vehicle_id);
                    setDrive(value.driver_name);
                    setAssignDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setSelectedImei(value.imei)
                    setCVEditArray(value.vehicle_id);
                    setAssetLink(value.asset_linkage_id);
                    setOpenTeleD(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
          else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverDeActive(true);
                    setCVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setAssignTele((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setOpenTele(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
          else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverDeActive(true);
                    setCVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setSelectedImei(value.imei)
                    setCVEditArray(value.vehicle_id);
                    setAssetLink(value.asset_linkage_id);
                    setOpenTeleD(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
          else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverActive(true);
                    setCVEditArray(value.vehicle_id);
                    setAssignDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setSelectedImei(value.imei)
                    setCVEditArray(value.vehicle_id);
                    setAssetLink(value.asset_linkage_id);
                    setOpenTeleD(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          } else {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverActive(true);
                    setCVEditArray(value.vehicle_id);
                    setAssignDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setAssignTele((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setOpenTele(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
        },
      },
    },
  ];
  const VehicleColumn1 = [
    {
      name: "Vehicle",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-start', marginLeft: '35px' }}>


            {
              value.type === "2W" && value.vehicle_status === "assign" ?
                <><Tooltip style={{ flex: "left" }} title={"Assigned"}>
                  <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px' }}>
                    <Icon
                      icon="mdi:motorbike"
                      color="#fff"
                      width="22"
                      height="22"
                    />
                  </Avatar>
                </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                value.type === "E-Auto" &&
                  value.vehicle_status === "assign" ?
                  <><Tooltip style={{ flex: "left" }} title={"Assigned"}>
                    <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px' }}>
                      <Icon
                        icon="fluent-emoji-high-contrast:auto-rickshaw"
                        color="#fff"
                        width="22"
                        height="22"
                      />
                    </Avatar>
                  </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                  value.type === "l5n" &&
                    value.vehicle_status === "assign" ?
                    <>
                      <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                        <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px' }}>
                          <Icon
                            icon="fa-solid:truck-pickup"
                            color="#fff"
                            width="22"
                            height="22"
                          />
                        </Avatar>
                      </Tooltip>
                      <Divider orientation="vertical" variant="middle" flexItem /></>
                    :
                    value.type === "2W" && value.vehicle_status === "unassign" ?
                      <><Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                        <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                          <Icon
                            icon="mdi:motorbike"
                            color="#fff"
                            width="22"
                            height="22"
                          />
                        </Avatar>
                      </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                      value.type === "E-Auto" && value.vehicle_status === "unassign" ?
                        <><Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                          <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                            <Icon
                              icon="fluent-emoji-high-contrast:auto-rickshaw"
                              color="#fff"
                              width="22"
                              height="22"
                            />
                          </Avatar>
                        </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                        value.type === "l5n" && value.vehicle_status === "unassign" ?
                          <><Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                            <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                              <Icon
                                icon="fa-solid:truck-pickup"
                                color="#fff"
                                width="22"
                                height="22"
                              />
                            </Avatar>
                          </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> :
                          <><Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                            <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                              <Icon
                                icon="mdi:motorbike"
                                color="#fff"
                                width="22"
                                height="22"
                              />
                            </Avatar>
                          </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></>

            }
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}><Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}
            >
              {validateKeyData(value.vehicle_number)}
            </Typography>
              <Typography
                style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
              >
                {validateKeyData(value.vehicle_model)}
              </Typography>
            </div>
          </div>
        ),
      },
    },
    {
      name: "Battery",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', marginLeft: '60px' }}>
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
            >{validateKeyData(value.serial_number)}</Typography>
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
            >{validateKeyData(value.updated_at)}</Typography></div>
        ),
      },
    },
    {
      name: " Investor",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <Typography
              style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-15px' }}
            >
              {validateKeyData(value)}
            </Typography>

          );
        },
      },
    },
    {
      name: "Driver",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <Typography
              style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-15px' }}
            >
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Distance to Empty",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
            >
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Assignment",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#c4c4c4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          }
          else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          }
          else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          }
          else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          }
          else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          } else {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          }
        },
      },
    },
  ];

  const ErickColumn = [
    {
      name: "Vehicle",
      options: {
        filter: true,
        display: true,
        customBodyRender: (value) => (
          <Grid container spacing={0}>
            <Grid item xs={2} />
            <Grid item xs={4}>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                {value.vehicle_status === "assign" ?
                  <><Tooltip style={{ flex: "left" }} title={"Assigned"}>
                    <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px' }}>
                      <Icon
                        icon="material-symbols:electric-rickshaw"
                        color="#fff"
                        width="22"
                        height="22"
                      />
                    </Avatar>
                  </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> : <><Tooltip style={{ flex: "left" }} title={"Assigned"}>
                    <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                      <Icon
                        icon="material-symbols:electric-rickshaw"
                        color="#fff"
                        width="22"
                        height="22"
                      />
                    </Avatar>
                  </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></>}
                <Typography
                  style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '1rem', fontWeight: 400, whiteSpace: 'nowrap' }}
                >
                  {validateKeyData(value.vehicle_number)}
                </Typography>

              </div>
            </Grid>
          </Grid>


        ),
      },
    },
    {
      name: "Battery",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', marginLeft: '60px' }}>
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}
            >{validateKeyData(value.serial_number)}</Typography>
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
            >{validateKeyData(value.updated_at)}</Typography></div>
        ),
      },
    },
    {
      name: "Investor",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-15px' }}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      name: "Driver",
      options: {
        customBodyRender: (value) => {
          return (
            <Typography style={{ cursor: "pointer", marginLeft: '-15px', color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Distance to Empty",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <Typography style={{ cursor: "pointer", marginLeft: '-15px', color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },

    {
      name: "Assignment",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverDeActive(true);
                    setEVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setSelectedImei(value.imei)
                    setEVEditArray(value.vehicle_id);
                    setAssetLink(value.asset_linkage_id);
                    setOpenTeleD(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
      
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          } else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverDeActive(true);
                    setEVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#c4c4c4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setAssignTele((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setOpenTele(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          } else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverActive(true);
                    setEVEditArray(value.vehicle_id);
                    setAssignEDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setAssignTele((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setOpenTele(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton 
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
          else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverActive(true);
                    setEVEditArray(value.vehicle_id);
                    setAssignEDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setSelectedImei(value.imei)
                    setEVEditArray(value.vehicle_id);
                    setAssetLink(value.asset_linkage_id);
                    setOpenTeleD(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
          else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "unassign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverDeActive(true);
                    setEVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setAssignTele((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setOpenTele(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
          else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "unassign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverDeActive(true);
                    setEVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setSelectedImei(value.imei)
                    setEVEditArray(value.vehicle_id);
                    setAssetLink(value.asset_linkage_id);
                    setOpenTeleD(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
          else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "assign" &&
            value.telematics_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverActive(true);
                    setEVEditArray(value.vehicle_id);
                    setAssignEDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setSelectedImei(value.imei)
                    setEVEditArray(value.vehicle_id);
                    setAssetLink(value.asset_linkage_id);
                    setOpenTeleD(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          } else {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverActive(true);
                    setEVEditArray(value.vehicle_id);
                    setAssignEDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDrive(value.driver_name);
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setDdd1(value.serial_number)
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setAssignTele((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                    setOpenTele(true)
                  }}
                >
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
                {value.driver_status === "assign" ?
                  <IconButton
                  onClick={() => {
                    handleClick(true);
                    setDdd(value.driver_name)
                  }}
                  >
                    <Icon
                      icon="ic:baseline-delete"
                      color="#fa5d41"
                      width="22"
                      height="22"
                    />
                  </IconButton> :
                  value.batteryassign_status === "assign" ?
                    <IconButton
                    onClick={() => {
                      handleClick1(true);
                      setDdd1(value.serial_number)
                    }}
                    >
                      <Icon
                        icon="ic:baseline-delete"
                        color="#fa5d41"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    value.telematics_status === "assign" ?
                      <IconButton
                      onClick={() => {
                        handleClick2(true);
                        setDdd2(value.imei)
                      }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton> :
                      <IconButton
                        onClick={() => {
                          setDelete1(true);
                          setSelectedId1(value.vehicle_id);
                        }}
                      >
                        <Icon
                          icon="ic:baseline-delete"
                          color="#fa5d41"
                          width="22"
                          height="22"
                        />
                      </IconButton>}
              </>
            );
          }
        },
      },
    },
  ];
  const ErickColumn1 = [
    {
      name: "Vehicle",
      options: {
        filter: true,
        display: true,
        customBodyRender: (value) => (
          <Grid container spacing={0}>
            <Grid item xs={2} />
            <Grid item xs={4}>
              <div style={{ display: 'flex', alignItems: 'center', marginLeft: '35px' }}>
                {value.vehicle_status === "assign" ?
                  <><Tooltip style={{ flex: "left" }} title={"Assigned"}>
                    <Avatar style={{ backgroundColor: '#ffcb0d', marginLeft: '-15px' }}>
                      <Icon
                        icon="material-symbols:electric-rickshaw"
                        color="#fff"
                        width="22"
                        height="22"
                      />
                    </Avatar>
                  </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></> : <><Tooltip style={{ flex: "left" }} title={"Assigned"}>
                    <Avatar style={{ backgroundColor: '#c4c4c4', marginLeft: '-15px' }}>
                      <Icon
                        icon="material-symbols:electric-rickshaw"
                        color="#fff"
                        width="22"
                        height="22"
                      />
                    </Avatar>
                  </Tooltip><Divider orientation="vertical" variant="middle" flexItem /></>}
                <Typography
                  style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '1rem', fontWeight: 400, whiteSpace: 'nowrap' }}
                >
                  {validateKeyData(value.vehicle_number)}
                </Typography>

              </div>
            </Grid>
          </Grid>


        ),
      },
    },
    {
      name: "Battery",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', marginLeft: '60px' }}>
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '1rem', fontWeight: 400 }}
            >{validateKeyData(value.serial_number)}</Typography>
            <Typography
              style={{ cursor: "pointer", textAlign: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}
            >{validateKeyData(value.updated_at)}</Typography></div>
        ),
      },
    },
    {
      name: "Investor",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-15px' }}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      name: "Driver",
      options: {
        customBodyRender: (value) => {
          return (
            <Typography style={{ cursor: "pointer", marginLeft: '-15px', color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Distance to Empty",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <Typography style={{ cursor: "pointer", marginLeft: '-15px', color: "#4caf50", fontSize: '0.875rem', fontWeight: 400 }}>
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },

    {
      name: "Assignment",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (value.driver_status === "assign" && value.telematics_status === "assign") {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                {
                  value.batteryassign_status === "assign" ?
                    <IconButton>
                      <Icon
                        icon="mdi:car-battery"
                        color="#68a724"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    <IconButton>
                      <Icon
                        icon="mdi:car-battery"
                        color="#c4c4c4"
                        width="22"
                        height="22"
                      />
                    </IconButton>
                }
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          } else if (value.driver_status === "assign" && value.telematics_status === "unassign") {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="22"
                    height="22"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#68a724"
                    width="22"
                    height="22"
                  />
                </IconButton>
                {
                  value.batteryassign_status === "assign" ?
                    <IconButton>
                      <Icon
                        icon="mdi:car-battery"
                        color="#68a724"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    <IconButton>
                      <Icon
                        icon="mdi:car-battery"
                        color="#c4c4c4"
                        width="22"
                        height="22"
                      />
                    </IconButton>
                }
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          } else if (value.driver_status === "unassign" && value.telematics_status === "assign") {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                {
                  value.batteryassign_status === "assign" ?
                    <IconButton>
                      <Icon
                        icon="mdi:car-battery"
                        color="#68a724"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    <IconButton>
                      <Icon
                        icon="mdi:car-battery"
                        color="#c4c4c4"
                        width="22"
                        height="22"
                      />
                    </IconButton>
                }
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#68a724"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          } else {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="22"
                    height="22"
                  />
                </IconButton>
                {
                  value.batteryassign_status === "assign" ?
                    <IconButton>
                      <Icon
                        icon="mdi:car-battery"
                        color="#68a724"
                        width="22"
                        height="22"
                      />
                    </IconButton> :
                    <IconButton>
                      <Icon
                        icon="mdi:car-battery"
                        color="#c4c4c4"
                        width="22"
                        height="22"
                      />
                    </IconButton>
                }
                <IconButton>
                  <Icon
                    icon="material-symbols:wifi"
                    color="#C4C4C4"
                    width="20"
                    height="20"
                  />
                </IconButton>
              </>
            );
          }
        },
      },
    },
  ];
  const VehicleModel = [
    {
      name: "Vehicle Model",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Seating",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>{value}</Typography>
        ),
      },
    },
    {
      name: "Max Speed (kmph)",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>{value}</Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "Vehicle Gross Weight (Kg)",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>
              {value}
            </Typography>
          );
        },
      },
    },
    {
      name: "Range Per Charge (Km)",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>
              {value}
            </Typography>
          );
        },
      },
    },

    {
      name: "Action",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <IconButton
                onClick={() => {
                  setOpenVMEdit(true);
                  setVMEditArray(value);
                }}
              >
                <Icon
                  icon="bxs:edit-alt"
                  color="#33a6ff"
                  width="22"
                  height="22"
                />
              </IconButton>
              <IconButton
                onClick={() => {
                  setDelete2(true);
                  setSelectedId2(value);
                }}
              >
                <Icon
                  icon="ic:baseline-delete"
                  color="#fa5d41"
                  width="22"
                  height="22"
                />
              </IconButton>
            </div>
          );
        },
      },
    },
  ];
  const VehicleModel1 = [
    {
      name: "Vehicle Model",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Seating",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>{value}</Typography>
        ),
      },
    },
    {
      name: "Max Speed (kmph)",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>{value}</Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "Vehicle Gross Weight (Kg)",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>
              {value}
            </Typography>
          );
        },
      },
    },
    {
      name: "Range Per Charge (Km)",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }}>
              {value}
            </Typography>
          );
        },
      },
    },
  ];
  const [selectedD, setSelectedD] = React.useState("");
  React.useEffect(() => {
    setAssignDriv({
      vehicle_id: "",
      driver_id: "",
    }),
      setAssignEDriv({
        vehicle_id: "",
        driver_id: "",
      });
  }, [selectedD]);

  const [selectedImei, setSelectedImei] = React.useState("");
  const [drive, setDrive] = React.useState("");
  React.useEffect(() => {
    setAssignTele({
      vehicle_id: "",
      telematics_id: "",
    });
  }, [selectedImei]);

  const [assignTele, setAssignTele] = React.useState({
    vehicle_id: "",
    telematics_id: "",
  });

  const AssignTelematics = () => {
    if (assignTele.vehicle_id && assignTele.telematics_id) {
      const postImei = endpoints.baseUrl + `/telematics/assign/vehicle`;

      axios.post(postImei, assignTele).then((response) => {
        handleClick3(true);
        response.status === 200
          ? setDdd3("Telematics assigned successfully!")
          : setDdd3(response.message);
        dispatch(getCVBulk(enty, pageCV));
        dispatch(getEVBulk(enty, pageEV));
        dispatch(getVDABulk(enty));
        dispatch(getEVDABulk(enty));
        dispatch(TeleAssignBulk());
        dispatch(getBABulk());
        setOpenTele(false);
      }).catch((err) => {
        handleClick4(true);
      setDdd4(err)
      });
      setOpenTele(false);
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  const ReassignImei = (asset_linkage_id) => {
    const Dimei = endpoints.baseUrl + `/telematics/deactivate/` + asset_linkage_id;
    axios.delete(Dimei).then((response) => {
      handleClick3(true);
        response.status === 200
          ? setDdd3("Imei deactivated")
        : setDdd3(response.message);
      dispatch(getCVBulk(enty, pageCV));
      dispatch(getEVBulk(enty, pageEV));
      dispatch(getVDABulk(enty));
      dispatch(getEVDABulk(enty));
      dispatch(TeleAssignBulk());
      dispatch(getBABulk());
      setOpenTeleD(false);
    });
  };

  const [assignDriv, setAssignDriv] = React.useState({
    vehicle_id: "",
    driver_id: "",
  });

  const assDriver = () => {
    if (assignDriv.driver_id) {
      const postDriv = endpoints.baseUrl + `/vehicle/driver/add`;

      axios.post(postDriv, assignDriv).then((response) => {
        dispatch(getCVBulk(enty, pageCV));
        handleClick3(true);
        response.status === 200
          ? setDdd3("Driver assigned successfully!")
          : setDdd3(response.message);
          dispatch(getEVBulk(enty, pageEV));
          dispatch(getVDABulk(enty));
          dispatch(getEVDABulk(enty));
          dispatch(TeleAssignBulk());
          dispatch(getBABulk());
        setOpenDriverActive(false);
        setOpenDriverDeActive(false);
      });
      setOpenDriverActive(false);
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  // }
  const DeactiveD = (assignment_id) => {
    const DeactiveDri =
      endpoints.baseUrl + `/vehicle/driver/deactivate/` + assignment_id;
    axios.delete(DeactiveDri).then((response) => {
      handleClick3(true);
        response.status === 200
          ? setDdd3("Driver unassigned successfully!")
        : setDdd3(response.message);
      dispatch(getCVBulk(enty, pageCV));
      dispatch(getEVBulk(enty, pageEV));
      dispatch(getVDABulk(enty));
      dispatch(getEVDABulk(enty));
      dispatch(TeleAssignBulk());
      dispatch(getBABulk());
      setOpenDriverDeActive(false);
    });
  };

  const DeactiveE = (assignment_id) => {
    const DeactiveEDri =
      endpoints.baseUrl + `/vehicle/driver/deactivate/` + assignment_id;
    axios.delete(DeactiveEDri).then((response) => {
      handleClick3(true);
        response.status === 200
          ? setDdd3("Driver unassigned successfully!")
          : setDdd3(response.message);
      dispatch(getEVBulk(enty, pageEV));
      dispatch(getVDABulk(enty));
      dispatch(getEVDABulk(enty));
      dispatch(TeleAssignBulk());
      dispatch(getBABulk());
      setOpenEDriverDeActive(false);
    });
  };

  const [assignEDriv, setAssignEDriv] = React.useState({
    vehicle_id: "",
    driver_id: "",
  });

  const assEDriver = () => {
    if (assignEDriv.vehicle_id) {
      const postEDriv = endpoints.baseUrl + `/vehicle/driver/erick/add`;

      axios.post(postEDriv, assignEDriv).then((response) => {
        handleClick3(true);
        response.status === 200
          ? setDdd3("Driver assigned successfully!")
          : setDdd3(response.message);
          dispatch(getEVBulk(enty, pageEV));
          dispatch(getVDABulk(enty));
          dispatch(getEVDABulk(enty));
          dispatch(TeleAssignBulk());
          dispatch(getBABulk());
          setOpenEDriverActive(false);
      });
      setOpenEDriverActive(false);
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  const [assignBattery, setAssignBattery] = React.useState({
    battery_id: "",
    vehicle_id: "",
  });

  const assignBatteryy = () => {
    if (assignBattery.battery_id) {
      const postba = endpoints.baseUrl + `/vehicle/battery/add`;

      axios.post(postba, assignBattery).then((response) => {
        handleClick3(true);
        response.status === 200
          ? setDdd3("Battery assigned successfully!")
          : setDdd3(response.message);
          dispatch(getCVBulk(enty, pageCV));
          dispatch(getEVBulk(enty, pageEV));
          dispatch(getVDABulk(enty));
          dispatch(getEVDABulk(enty));
          dispatch(TeleAssignBulk());
          dispatch(getBABulk());
          setOpenBAssign(false);
      });
      setOpenBAssign(false);
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };

  const [editBReAssign, setEditBReAssign] = React.useState({});
  const setBAEditArray = (vehicle_battery_id) => {
    let allBA = BADataRaw;
    let findBArray = allBA.find(
      (el) => el.vehicle_battery_id === vehicle_battery_id
    );
    setEditBReAssign(findBArray);
  };
  const submitBReassign = () => {
    // console.log("editBReAssign", editBReAssign)
    if (editBReAssign.battery_id) {
      const putBA =
        endpoints.baseUrl +
        `/vehicle/battery/reassign/` +
        editBReAssign.vehicle_battery_id;
      axios.put(putBA, editBReAssign).then((response) => {
        handleClick3(true);
        response.status === 200
          ? setDdd3("Reassigned successfully!")
          : setDdd3(response.message);
        dispatch(getCVBulk(enty, pageCV));
        setOpenBReAssign(false);
      });
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  const setBAEditFormArray = (e, key, array) => {
    setEditBReAssign((state) => ({ ...state, [key]: e.target.value }));
  };
  const currentDate = new Date().toISOString().split("T")[0];;
  const [cVAddForm, setCVAddForm] = React.useState({
    model_id: "",
    vehicle_number: "",
    chassis_number: "",
    engine_number: "",
    owner_name: "raj",
    upload_rc_book: "",
    upload_insurance: "",
    upload_permit_image: "",
    insurance_expiry_date: "",
    permit_expiry_date: "",
    manufacturing_date: "",
    type: "",
    asset: {
      asset_type: "Vehicle",
      entity_id: "",
    },
    investor: {
      asset_type: "Vehicle",
      entity_id: enty,
      user_id: "",
    },
    user: {
      asset_type: "Vehicle",
      entity_id: enty,
      user_id: "",
    },
    telematics: {
      telematics_data_id: "",
      sim_operator: "",
      mobile_number: "",
      imei: "",
    },
  });
  const submitCV = () => {
    if (cVAddForm.model_id && cVAddForm.vehicle_number && cVAddForm.asset.entity_id) {
      const postCV = endpoints.baseUrl + `/vehicle/add`;
      // const postCV = endpoints.baseUrl + `/vehicle/add`;

      axios.post(postCV, cVAddForm).then((response) => {
        handleClick3(true);
        response.status === 201
          ? setDdd3("Vehicle onboarded successfully!")
          : setDdd3(response.message);
      });
      dispatch(getCVBulk(enty, pageCV));
      setCVAddForm({})
      setOpenCVehicle(false);
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  const setCVAddFormArray = (e, key, array) => {
    if (array) {
      setCVAddForm((state) => ({
        ...state,
        [array]: {
          ...state[array],
          [key]: e.target.value,
        },
      }));
    } else {
      setCVAddForm((state) => ({ ...state, [key]: e.target.value }));
    }
  };

  const handleSubmitAddCV = () => {
    submitCV(true);
    dispatch(getCVBulk(enty, pageCV));
    handleReset()
  };

  const [editCArray, setEditCArray] = React.useState({});
  const setCVEditArray = (vehicle_id) => {
    // console.log("editCArray", editCArray)
    let allCV = CVDataRaw;
    let findCArray = allCV.find((el) => el.vehicle_id === vehicle_id);
    setEditCArray(findCArray);
  };
  const submitCVEdit = () => {
    if (editCArray.model_id && editCArray.type) {
      const putCV =
        endpoints.baseUrl + `/vehicle/edit/` + editCArray.vehicle_id;
      axios.put(putCV, editCArray).then((response) => {
        handleClick3(true);
        response.status === 200
          ? setDdd3("Vehicle details edited successfully!")
          : setDdd3(response.message);
        setOpenCVEdit(false);
        dispatch(getCVBulk(enty, pageCV));
        handleReset1()
      });
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  const setCVEditFormArray = (e, key, array) => {
    if (array) {
      setEditCArray((state) => ({
        ...state,
        [array]: {
          ...state[array],
          [key]: e.target.value,
        },
      }));
    } else {
      setEditCArray((state) => ({ ...state, [key]: e.target.value }));
    }

    // setEditCArray((state) => ({ ...state, [key]: e.target.value }));
  };
  const deleteVehicle = (vehicle_id) => {
    const deleteV = endpoints.baseUrl + `/vehicle/SoftDelete/` + vehicle_id;
    axios
      .delete(deleteV)
      .then((response) => {
        handleClick3(true);
        response.status === 200
          ? setDdd3("Vehicle offboarded successfully!") : setDdd3(response.message)
        setDelete1(false)
        setPassword1()
        setPassword2()
        dispatch(getCVBulk(enty, pageCV));
        dispatch(getEVBulk(enty, pageEV));
      });
  }
  //add EV
  const [eVAddForm, setEVAddForm] = React.useState({
    model_id: "",
    vehicle_number: "",
    chassis_number: "",
    engine_number: "",
    owner_name: "raj",
    upload_rc_book: "",
    upload_insurance: "",
    upload_permit_image: "",
    insurance_expiry_date: "",
    permit_expiry_date: "",
    manufacturing_date: "",
    type: "Erickshaw",
    asset: {
      asset_type: "Vehicle",
      entity_id: "",
    },
    investor: {
      asset_type: "Vehicle",
      entity_id: enty,
      user_id: "",
    },
    user: {
      asset_type: "Vehicle",
      entity_id: enty,
      user_id: "",
    },
    telematics: {
      telematics_data_id: "",
      sim_operator: "",
      mobile_number: "",
      imei: "",
    },
  });
  const submitEV = () => {
    if (eVAddForm.model_id && eVAddForm.vehicle_number && eVAddForm.asset.entity_id) {
      const postEV = endpoints.baseUrl + `/vehicle/add`;
      // const postCV = endpoints.baseUrl + `/vehicle/add`;

      axios.post(postEV, eVAddForm).then((response) => {
        handleClick3(true);
        response.status === 201
          ? setDdd3("Erickshaw onboarded successfully!")
          : setDdd3(response.message);
        dispatch(getEVBulk(enty, pageEV));
        setOpenEVehicle(false);
        setEVAddForm({})
        handleReset2()
      });
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  const setEVAddFormArray = (e, key, array) => {
    if (array) {
      setEVAddForm((state) => ({
        ...state,
        [array]: {
          ...state[array],
          [key]: e.target.value,
        },
      }));
    } else {
      setEVAddForm((state) => ({ ...state, [key]: e.target.value }));
    }
  };


  //edit ev
  const [editEArray, setEditEArray] = React.useState({});
  const setEVEditArray = (vehicle_id) => {
    let allEV = EVDataRaw;
    let findEArray = allEV.find((el) => el.vehicle_id === vehicle_id);
    setEditEArray(findEArray);
  };
  const submitEVEdit = () => {
    if (editEArray.model_id && editEArray.type) {
      const putEV =
        endpoints.baseUrl + `/vehicle/edit/` + editEArray.vehicle_id;
      axios.put(putEV, editEArray).then((response) => {
        handleClick3(true);
        response.status === 200
          ? setDdd3("Erickshaw details edited successfully!")
          : setDdd3(response.message);
        dispatch(getEVBulk(enty, pageEV));
        setOpenEVEdit(false);
        handleReset3()
      });
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };

  // const setEVEditFormArray = (e, key) => {
  //   setEditEArray((state) => ({ ...state, [key]: e.target.value }));

  // }
  const setEVEditFormArray = (e, key, array) => {
    if (array) {
      setEditEArray((state) => ({
        ...state,
        [array]: {
          ...state[array],
          [key]: e.target.value,
        },
      }));
    } else {
      setEditEArray((state) => ({ ...state, [key]: e.target.value }));
    }

    // setEditCArray((state) => ({ ...state, [key]: e.target.value }));
  };

  //add Model

  const [addVMForm, setAddVMForm] = React.useState({
    model: "",
    fuel: "Electric",
    unladen_wt: "",
    seating: "",
    width: "",
    length: "",
    height: "",
    gross_vehicle_weight: "",
    payload_weight: "",
    top_speed: "",
    typical_range: "",
    manufacturer: "revx",
    reference_Image: "",
    datasheet: "",
    vehicle_type: "L3N",
    vehicle_class: "3 wheeler",
  });
  const submitVM = () => {
    if (
      addVMForm.model &&
      addVMForm.fuel &&
      addVMForm.unladen_wt &&
      addVMForm.seating &&
      addVMForm.width &&
      addVMForm.length &&
      addVMForm.height &&
      addVMForm.gross_vehicle_weight &&
      addVMForm.payload_weight &&
      addVMForm.top_speed &&
      addVMForm.typical_range
    ) {
      const postVM = endpoints.baseUrl + `/vehiclemodel/add`;

      axios.post(postVM, addVMForm).then((response) => {
        handleClick3(true);
        response.status === 201
          ? setDdd3("Vehicle model onboarded successfully!")
          : setDdd3(response.message);
        dispatch(getVMBulk(modelPage));
        setAddVMForm({});
        handleReset4()
      });
      setOpenVM(false);
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  const setVMAddFormArray = (e, key) => {
    setAddVMForm((state) => ({ ...state, [key]: e.target.value }));
  };

  const handleSubmitAddVM = () => {
    submitVM();
    // setOpenVM(false)
  };

  //editModel

  const [editArray, setEditArray] = React.useState({});
  const setVMEditArray = (model_id) => {
    let allModel = VMDataRaw;
    let findArray = allModel.find((el) => el.model_id === model_id);
    setEditArray(findArray);
  };
  const submitVMEdit = () => {
    if (editArray.model) {
      const putVM =
        endpoints.baseUrl + `/vehiclemodel/edit/` + editArray.model_id;
      axios.put(putVM, editArray).then((response) => {
        handleClick3(true);
        response.status === 200
          ? setDdd3("Model details edited successfully!")
          : setDdd3(response.message);
        dispatch(getVMBulk(modelPage));
        setOpenVMEdit(false);
        handleReset5()
      });
    } else {
      handleClick4(true);
      setDdd4("Please fill the required fields");
    }
  };
  const setVMEditFormArray = (e, key) => {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));
  };

  const deleteVM = (model_id) => {
    const deleteModel =
      endpoints.baseUrl + `/vehiclemodel/SoftDelete/` + model_id;
    axios.delete(deleteModel).then((response) => {
      handleClick3(true);
        response.status === 200
          ? setDdd3("Model offboarded successfully!")
        : setDdd3(response.message);
      setDelete2(false)
      dispatch(getVMBulk(modelPage));
    });
  };

  const DeactiveB = (vehicle_battery_id) => {
    const DeactiveBat =
      endpoints.baseUrl + `/battery/vehicle/deactivate/` + vehicle_battery_id;
    axios.delete(DeactiveBat).then((response) => {
      handleClick3(true);
        response.status === 200
          ? setDdd3("Battery deactivated")
        : setDdd3(response.message);
      dispatch(getCVBulk(enty, pageCV));
      dispatch(getEVBulk(enty, pageEV));
      dispatch(getVDABulk(enty));
      dispatch(getEVDABulk(enty));
      dispatch(TeleAssignBulk());
      dispatch(getBABulk());
      setOpenBReAssign(false);
    });
  };

  const [state, setState] = React.useState({
    checkedA: false,
    checkedB: false,
  });

  const handleChangeC = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
  };
  const [stateb, setStateb] = React.useState({
    checkedB: true,
    checkedC: true,
  });

  const handleChangeB = (event) => {
    setStateb({ ...stateb, [event.target.name]: event.target.checked });
  };
  const getSafe = (fn, defaultVal) => {
    try {
      if (fn().length !== 0) {
        return fn();
      }
    } catch (e) {
      return defaultVal;
    }
  };

  const upload = () => {
    const uploadimg = endpoints.baseUrl + `/uplaod`;

    axios.post(uploadimg).then((response) => {
      response;
    });
  };

  function getSteps() {
    return ['Identifiction', 'Association', 'Attestation', 'Mobilize'];
  }

  function getStepContent(step) {
    switch (step) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography style={{
                fontSize: "15px",
                fontFamily: " Maven Pro",
                fontWeight: 400,
                color: "#A7A7A7",
              }}>
                Vehicle Model
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <FormControl style={{
              width: "100%",
              color: "#7A7A7D",
              borderRadius: "9px",
              //paddingBottom: "10px",
              ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                borderColor: "#C4C4C4  !important",
              },
              "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
            }}>
              <Select
                onChange={(e) => {
                  setCVAddFormArray(e, "model_id");
                }}
                error={addBatteryErrors && cVAddForm.model_id === ""}
                value={cVAddForm.model_id}
              >
                <MenuItem value="">Select your Model</MenuItem>
                {modelList.length &&
                  modelList.map((modelL) => {
                    return (
                      <MenuItem value={modelL[1]}>{modelL[0]}</MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography style={{
                fontSize: "15px",
                fontFamily: " Maven Pro",
                fontWeight: 400,
                color: "#A7A7A7",
              }}>
                Vehicle Type
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <FormControl style={{
              width: "100%",
              color: "#7A7A7D",
              borderRadius: "9px",
              //paddingBottom: "10px",
              ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                borderColor: "#C4C4C4  !important",
              },
              "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
            }}>
              <Select
                onChange={(e) => {
                  setCVAddFormArray(e, "type");
                }}
                error={addBatteryErrors && cVAddForm.type === ""}
                value={cVAddForm.type}
              >
                <MenuItem value="">Select your Type</MenuItem>
                <MenuItem value={"2w"}>2 Wheeler</MenuItem>
                <MenuItem value={"E-Auto"}>E-Auto</MenuItem>
                <MenuItem value={"l5n"}>L5 Commercial Vehicle</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography style={{
                fontSize: "15px",
                fontFamily: " Maven Pro",
                fontWeight: 400,
                color: "#A7A7A7",
              }}>
                Vehicle Number
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              required
              onChange={(e) => {
                setCVAddFormArray(e, "vehicle_number");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && cVAddForm.vehicle_number === ""}
              helperText={!/^[A-Z][A-Z]?[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$/.test(cVAddForm.vehicle_number) ? "Enter valid alphanumeric Vehicle Number without space" : null}
              value={cVAddForm.vehicle_number && cVAddForm.vehicle_number.toUpperCase() && cVAddForm.vehicle_number.toUpperCase().trim()}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Vehicle Number"
            />
          </Grid>

          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography style={{
              fontSize: "15px",
              fontFamily: " Maven Pro",
              fontWeight: 400,
              color: "#A7A7A7",
            }}>
              Chassis Number
            </Typography>
            <TextField
              onChange={(e) => {
                setCVAddFormArray(e, "chassis_number");
              }}
              size="small"
              id="outlined"
              value={cVAddForm.chassis_number && cVAddForm.chassis_number.trim()}
              helperText={cVAddForm.chassis_number != '' && !/^[A-Za-z0-9]{17}$/.test(cVAddForm.chassis_number) ? "Enter 17-digit valid Chasis Number" : null}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Chassis Number"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography style={{
              fontSize: "15px",
              fontFamily: " Maven Pro",
              fontWeight: 400,
              color: "#A7A7A7",
            }}>
              Engine Number
            </Typography>
            <TextField
              onChange={(e) => {
                setCVAddFormArray(e, "engine_number");
              }}
              size="small"
              id="outlined"
              value={cVAddForm.engine_number && cVAddForm.engine_number.trim()}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Engine Number"
            />
          </Grid></Grid>;
      case 1:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Fleet Name
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography> {addBatteryErrors && cVAddForm.asset && cVAddForm.asset.entity_id === "" ? <p style={{ color: 'red' }}> required</p> : null}
            </div>
            {enty1 === true ? (
              <><FormControl className={classes.styleO}>
                <Select
                  onChange={(e) => {
                    setCVAddFormArray(e, "entity_id", "asset");
                    dispatch(getOMBulk(e.target.value));
                  }}
                  error={addBatteryErrors && cVAddForm.asset && cVAddForm.asset.entity_id === ""}
                  id="demo-simple-select-error" value={cVAddForm.asset && cVAddForm.asset.entity_id}
                >
                  <MenuItem value="">Select your Manager</MenuItem>
                  {FleetMeta.data.length &&
                    FleetMeta.data.map((fleet) => {
                      return (
                        <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>
                      );
                    })}
                </Select>

              </FormControl>

              </>
            ) : (
              <TextField
                size="small"
                id="outlined"
                value={uName}
                className={classes.styleO}
              />
            )}
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Operation Manager
            </Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setCVAddFormArray(e, "user_id", "user");
                }}
                // error={addBatteryErrors && cVAddForm.user_id === ""}
                value={cVAddForm.user && cVAddForm.user.user_id}
              >
                <MenuItem value="">Select your Manager</MenuItem>
                {OMMeta.data.length &&
                  OMMeta.data.map((om) => {
                    return <MenuItem value={om[1]}>{om[0]}</MenuItem>;
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Investor</Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setCVAddFormArray(e, "user_id", "investor");
                }}
                // error={addBatteryErrors && cVAddForm.user_id === ""}
                value={cVAddForm.user_id}
              >
                <MenuItem value="">Select your Investor</MenuItem>
                {IVMeta.data.length &&
                  IVMeta.data.map((iv) => {
                    return <MenuItem value={iv[1]}>{iv[0]}</MenuItem>;
                  })}
              </Select>
            </FormControl>
          </Grid>
        </Grid>;
      case 2:
        return <Grid container spacing={2}>
          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload RC Book
            </Typography>
            <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangeRC}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button>
          </Grid>
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Manufacturing Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              max={currentDate}
              onChange={(e) => {
                setCVAddFormArray(e, "manufacturing_date");
              }}
              size="small"
              id="outlined"
              value={cVAddForm.manufacturing_date}
              // className={classes.styleO}
              placeholder="eg:  manufacturing_date"
            />
          </Grid>
          <Grid item lg={5} xs={12} />

          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload Insurance
            </Typography>
            <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangeIns}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button>
          </Grid>
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Insurance Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={currentDate}
              onChange={(e) => {
                setCVAddFormArray(e, "insurance_expiry_date");
              }}
              size="small"
              id="outlined"
              value={cVAddForm.insurance_expiry_date}
              placeholder="eg:  insurance_expiry_date"
            />
          </Grid>
          <Grid item lg={5} xs={12} />

          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload Permit Image
            </Typography>
            <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangePermit}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button>
          </Grid>
          {cVAddForm.manufacturing_date === '' ? <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Permit Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={cVAddForm.manufacturing_date}
              // onChange={(e) => {
              //   setCVAddFormArray(e, "permit_expiry_date");
              // }}
              size="small"
              id="outlined"
              value={cVAddForm.permit_expiry_date}
              // className={classes.styleO}
              placeholder="eg:  permit_expiry_date"
            />
          </Grid> : <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Permit Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={cVAddForm.manufacturing_date}
              onChange={(e) => {
                setCVAddFormArray(e, "permit_expiry_date");
              }}
              size="small"
              id="outlined"
              value={cVAddForm.permit_expiry_date}
              // className={classes.styleO}
              placeholder="eg:  permit_expiry_date"
            />
          </Grid>}
        </Grid>
      case 3:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Model</Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setCVAddFormArray(
                    e,
                    "telematics_data_id",
                    "telematics"
                  );
                }}
                error={
                  addBatteryErrors &&
                  cVAddForm.telematics_data_id === ""
                }
                value={
                  cVAddForm.telematics &&
                  cVAddForm.telematics.telematics_data_id
                }
              >
                <MenuItem value="">Select your Model</MenuItem>
                {allTele.length &&
                  allTele.map((tele) => {
                    return (
                      <MenuItem value={tele[0]}>{tele[1]}</MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              IMEI Number
            </Typography>
            <TextField
              onChange={(e) => {
                setCVAddFormArray(e, "imei", "telematics");
              }}
              size="small"
              id="outlined"
              helperText={cVAddForm.telematics && cVAddForm.telematics.imei != '' &&
                !/^(\d{15})$/.test(cVAddForm.telematics && cVAddForm.telematics.imei) ? 'Enter valid IMEI' : null}
              value={cVAddForm.telematics && cVAddForm.telematics.imei && cVAddForm.telematics.imei.trim()}
              className={classes.styleO}
              placeholder="eg:  imei"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              SIM Operator
            </Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setCVAddFormArray(e, "sim_operator", "telematics");
                }}
                // error={addBatteryErrors && cVAddForm.model_id === ""}
                value={
                  cVAddForm.telematics &&
                  cVAddForm.telematics.sim_operator
                }
              >
                <MenuItem value="">Select your Model</MenuItem>
                <MenuItem value="Airtel">Airtel</MenuItem>
                <MenuItem value="Jio">Jio</MenuItem>
                <MenuItem value="VI">VI</MenuItem>
                {/* {allVM.length && allVM.map((model) => {
                return (
                  <MenuItem value={model[5]}>{model[0]}</MenuItem>

                )
              }
              )} */}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Mobile Number
            </Typography>
            <TextField
              onChange={(e) => {
                setCVAddFormArray(e, "mobile_number", "telematics");
              }}
              type="number"
              value={
                cVAddForm.telematics &&
                cVAddForm.telematics.mobile_number && cVAddForm.telematics.mobile_number.trim()
              }
              helperText={cVAddForm.telematics && cVAddForm.telematics.mobile_number != '' &&
                !/^[0-9]{10}$/.test(cVAddForm.telematics && cVAddForm.telematics.mobile_number) ? 'Mobile number must be 10 digits' : null}
              className={classes.styleO}
              placeholder="eg:  9876678666"
            />
          </Grid>
          <Grid item lg={4.5} />

        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep, setActiveStep] = React.useState(0);
  const [completed, setCompleted] = React.useState({});
  const steps = getSteps();

  const totalSteps = () => steps.length;

  const completedSteps = () => Object.keys(completed).length;

  const isLastStep = () => activeStep === totalSteps() - 1;

  const allStepsCompleted = () => completedSteps() === totalSteps();

  const handleNext = () => {
    const newActiveStep = isLastStep() && !allStepsCompleted() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps.findIndex((step, i) => !(i in completed))
      : activeStep + 1;
    setActiveStep(newActiveStep);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStep = (step) => () => {
    setActiveStep(step);
  };

  const handleComplete = () => {
    const newCompleted = completed;
    newCompleted[activeStep] = true;
    setCompleted(newCompleted);
    handleNext();
  };

  const handleReset = () => {
    setActiveStep(0);
    setCompleted({});
  };

  function getSteps1() {
    return ['Identifiction', 'Association', 'Attestation', 'Mobilize'];
  }

  function getStepContent1(step1) {
    switch (step1) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Model
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setCVEditFormArray(e, "model_id");
                }}
                error={addBatteryErrors && editCArray.model_id === ""}
                value={editCArray.model_id}
              >
                <MenuItem value="">Select your Model</MenuItem>
                {modelList.length &&
                  modelList.map((modelL) => {
                    return (
                      <MenuItem value={modelL[1]}>{modelL[0]}</MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Type
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <Select
              onChange={(e) => {
                setCVEditFormArray(e, "type");
              }}
              error={addBatteryErrors && editCArray.type === ""}
              value={editCArray.type}
              className={classes.styleO}
            >
              <MenuItem value={"2w"}>2 Wheeler</MenuItem>
              <MenuItem value={"E-Auto"}>E-Auto</MenuItem>
              <MenuItem value={"l5n"}>L5 Commercial Vehicle</MenuItem>
            </Select>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography style={{
                fontSize: "15px",
                fontFamily: " Maven Pro",
                fontWeight: 400,
                color: "#A7A7A7",
              }}>
                Vehicle Number
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              required
              onChange={(e) => {
                setCVEditFormArray(e, "vehicle_number");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && editCArray.vehicle_number === ""}
              helperText={!/^[A-Z][A-Z]?[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$/.test(editCArray.vehicle_number) ? "Please! Enter Valid Number" : null}
              value={editCArray.vehicle_number && editCArray.vehicle_number.toUpperCase() && editCArray.vehicle_number.toUpperCase().trim()}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
            />
          </Grid>

          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography style={{
              fontSize: "15px",
              fontFamily: " Maven Pro",
              fontWeight: 400,
              color: "#A7A7A7",
            }}>
              Chassis Number
            </Typography>
            <TextField
              onChange={(e) => {
                setCVEditFormArray(e, "chassis_number");
              }}
              size="small"
              id="outlined"
              value={editCArray.chassis_number && editCArray.chassis_number.trim()}
              helperText={editCArray.chassis_number != '' && !/^[A-Za-z0-9]{17}$/.test(editCArray.chassis_number) ? "Please! Enter Valid Details" : null}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Chassis Number"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography style={{
              fontSize: "15px",
              fontFamily: " Maven Pro",
              fontWeight: 400,
              color: "#A7A7A7",
            }}>
              Engine Number
            </Typography>
            <TextField
              onChange={(e) => {
                setCVEditFormArray(e, "engine_number");
              }}
              size="small"
              id="outlined"
              value={editCArray.engine_number && editCArray.engine_number.trim()}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Engine Number"
            />
          </Grid></Grid>;
      case 1:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Fleet Name
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography> {addBatteryErrors && editCArray.asset && editCArray.asset.entity_id === "" ? <p style={{ color: 'red' }}> required</p> : null}
            </div>
            {enty1 === true ? (
              <FormControl className={classes.styleO}>
                <Select
                  onChange={(e) => {
                    setCVEditFormArray(e, "entity_id", "asset");
                    dispatch(getOMBulk(e.target.value));
                  }}
                  error={addBatteryErrors && (editCArray.asset && editCArray.asset.fleet_name === "")}
                  value={editCArray.asset && editCArray.asset.entity_id}
                >
                  {FleetMeta.data.length &&
                    FleetMeta.data.map((fleet) => {
                      return (
                        <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>
                      );
                    })}
                </Select>
              </FormControl>
            ) : (
              <TextField
                size="small"
                id="outlined"
                value={uName}
                className={classes.styleO}
              />
            )}
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Operation Manager
            </Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setCVEditFormArray(e, "user_id", "user");
                }}
                value={editCArray.user && editCArray.user.user_id}
              >
                {OMMeta.data.length &&
                  OMMeta.data.map((om) => {
                    return <MenuItem value={om[1]}>{om[0]}</MenuItem>;
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Investor</Typography>
            <Select
              className={classes.styleO}
              onChange={(e) => {
                setCVEditFormArray(e, "user_id", "investor");
              }}
              value={editCArray.investor && editCArray.investor.user_id}
            >
              {IVMeta.data.length &&
                IVMeta.data.map((iv) => {
                  return <MenuItem value={iv[1]}>{iv[0]}</MenuItem>;
                })}
            </Select>
          </Grid>
        </Grid>;
      case 2:
        return <Grid container spacing={2}>
          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload RC Book
            </Typography>
            {editCArray.upload_rc_book === '' ? <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangeRCedit}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button> :
              <Button onClick={() => setOpenRC(true)}>
                <img src={editCArray.upload_rc_book} />
              </Button>}

            <Dialog
              //fullScreen={fullScreen}
              open={openRC}
              maxWidth={"lg"}
              onClose={() => {
                setOpenRC(false);
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <></>
                <IconButton
                  onClick={() => {
                    setOpenRC(false);
                  }}
                >
                  <Icon
                    icon="akar-icons:circle-x"
                    width="26"
                    height="26"
                    color="#77b93e"
                  />
                </IconButton>
              </div>

              <DialogContent>
                <img src={editCArray.upload_rc_book} />
              </DialogContent>
            </Dialog>
          </Grid>
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Manufacturing Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              max={currentDate}
              onChange={(e) => {
                setCVEditFormArray(e, "manufacturing_date");
              }}
              size="small"
              id="outlined"
              value={editCArray.manufacturing_date}
            />
          </Grid>
          <Grid item lg={5} xs={12} />

          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload Insurance
            </Typography>
            {editCArray.upload_insurance === '' ? <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangeInsedit}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button> :
              <Button onClick={() => setOpenIns(true)}>
                <img src={editCArray.upload_insurance} />
              </Button>}
            <Dialog
              open={openIns}
              maxWidth={"lg"}
              onClose={() => {
                setOpenIns(false);
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <></>
                <IconButton
                  onClick={() => {
                    setOpenIns(false);
                  }}
                >
                  <Icon
                    icon="akar-icons:circle-x"
                    width="26"
                    height="26"
                    color="#77b93e"
                  />
                </IconButton>
              </div>

              <DialogContent>
                <img src={editCArray.upload_insurance} />
              </DialogContent>
            </Dialog>
          </Grid>
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Insurance Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={currentDate}
              onChange={(e) => {
                setCVEditFormArray(e, "insurance_expiry_date");
              }}
              size="small"
              id="outlined"
              value={editCArray.insurance_expiry_date}
            />
          </Grid>
          <Grid item lg={5} xs={12} />

          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload Permit Image
            </Typography>
            {editCArray.upload_permit_image === '' ? <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangePermitedit}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button> :
              <Button onClick={() => setOpenPermit(true)}>
                <img src={editCArray.upload_permit_image} />
              </Button>}
            <Dialog
              open={openPermit}
              maxWidth={"lg"}
              onClose={() => {
                setOpenPermit(false);
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <></>
                <IconButton
                  onClick={() => {
                    setOpenPermit(false);
                  }}
                >
                  <Icon
                    icon="akar-icons:circle-x"
                    width="26"
                    height="26"
                    color="#77b93e"
                  />
                </IconButton>
              </div>

              <DialogContent>
                <img src={editCArray.upload_permit_image} />
              </DialogContent>
            </Dialog>
          </Grid>
          {editCArray.manufacturing_date === '' ? null : <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Permit Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={editCArray.manufacturing_date}
              onChange={(e) => {
                setCVEditFormArray(e, "permit_expiry_date");
              }}
              size="small"
              id="outlined"
              value={editCArray.permit_expiry_date}
            // className={classes.styleO}
            />
          </Grid>}
        </Grid>
      case 3:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Model</Typography>
            <Select onChange={(e) => {
              setCVEditFormArray(e, 'telematics_data_id', 'telematics')
            }}
              value={editCArray && editCArray.telematics && editCArray.telematics.telematics_data_id}
              className={classes.styleO}>

              {allTele.length && allTele.map((telem) => {
                return (
                  <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                )
              }
              )}
            </Select>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              IMEI Number
            </Typography>
            <TextField
              onChange={(e) => {
                setCVEditFormArray(e, 'imei', 'telematics')
              }}
              size="small" id="outlined"
              value={editCArray.telematics && editCArray.telematics.imei && editCArray.telematics.imei.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              SIM Operator
            </Typography>
            <Select className={classes.styleO}
              onChange={(e) => { setCVEditFormArray(e, 'sim_operator', 'telematics') }}
              value={editCArray.telematics && editCArray.telematics.sim_operator}
            >
              <MenuItem value="">Select your Model</MenuItem>
              <MenuItem value="Airtel">Airtel</MenuItem>
              <MenuItem value="Jio">Jio</MenuItem>
              <MenuItem value="VI">VI</MenuItem>

            </Select>
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Mobile Number
            </Typography>
            <TextField
              onChange={(e) => {
                setCVEditFormArray(e, 'mobile_number', 'telematics')
              }}
              type="number"
              helperText={editCArray.telematics && editCArray.telematics.mobile_number != '' &&
                !/^[0-9]{10}$/.test(editCArray.telematics && editCArray.telematics.mobile_number) ?
                'Mobile number must be 10 digits' : null}
              value={editCArray.telematics && editCArray.telematics.mobile_number && editCArray.telematics.mobile_number.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={4.5} />

        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep1, setActiveStep1] = React.useState(0);
  const [completed1, setCompleted1] = React.useState({});
  const steps1 = getSteps1();

  const totalSteps1 = () => steps1.length;

  const completedSteps1 = () => Object.keys(completed1).length;

  const isLastStep1 = () => activeStep1 === totalSteps1() - 1;

  const allStepsCompleted1 = () => completedSteps1() === totalSteps1();

  const handleNext1 = () => {
    const newActiveStep1 = isLastStep1() && !allStepsCompleted1() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps1.findIndex((step1, i) => !(i in completed1))
      : activeStep1 + 1;
    setActiveStep1(newActiveStep1);
  };

  const handleBack1 = () => {
    setActiveStep1((prevActiveStep1) => prevActiveStep1 - 1);
  };

  const handleStep1 = (step1) => () => {
    setActiveStep1(step1);
  };

  const handleComplete1 = () => {
    const newCompleted1 = completed1;
    newCompleted1[activeStep1] = true;
    setCompleted1(newCompleted1);
    handleNext1();
  };

  const handleReset1 = () => {
    setActiveStep1(0);
    setCompleted1({});
  };

  function getSteps2() {
    return ['Identifiction', 'Association', 'Attestation', 'Mobilize'];
  }

  function getStepContent2(step2) {
    switch (step2) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography style={{
                fontSize: "15px",
                fontFamily: " Maven Pro",
                fontWeight: 400,
                color: "#A7A7A7",
              }}>
                Vehicle Model
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <FormControl style={{
              width: "100%",
              color: "#7A7A7D",
              borderRadius: "9px",
              //paddingBottom: "10px",
              ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                borderColor: "#C4C4C4  !important",
              },
              "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
            }}>
              <Select
                onChange={(e) => {
                  setEVAddFormArray(e, "model_id");
                }}
                error={addBatteryErrors && eVAddForm.model_id === ""}
                value={eVAddForm.model_id}
              >
                <MenuItem value="">Select your Model</MenuItem>
                {modelList.length &&
                  modelList.map((modelL) => {
                    return (
                      <MenuItem value={modelL[1]}>{modelL[0]}</MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          {/* <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography style={{
                fontSize: "15px",
                fontFamily: " Maven Pro",
                fontWeight: 400,
                color: "#A7A7A7",
              }}>
                Vehicle Type
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <FormControl style={{
              width: "100%",
              color: "#7A7A7D",
              borderRadius: "9px",
              //paddingBottom: "10px",
              ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                borderColor: "#C4C4C4  !important",
              },
              "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
            }}>
              <Select
                onChange={(e) => {
                  setEVAddFormArray(e, "type");
                }}
                error={addBatteryErrors && eVAddForm.type === ""}
                value={eVAddForm.type}
              >
                <MenuItem value="">Select your Type</MenuItem>
                <MenuItem value={"2w"}>2 Wheeler</MenuItem>
                <MenuItem value={"E-Auto"}>E-Auto</MenuItem>
                <MenuItem value={"l5n"}>L5 Commercial Vehicle</MenuItem>
                <MenuItem value={"Erickshaw"}>Erickshaw</MenuItem>
              </Select>
            </FormControl>
          </Grid> */}

          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography style={{
                fontSize: "15px",
                fontFamily: " Maven Pro",
                fontWeight: 400,
                color: "#A7A7A7",
              }}>
                Vehicle Number
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              required
              onChange={(e) => {
                setEVAddFormArray(e, "vehicle_number");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && eVAddForm.vehicle_number === ""}
              helperText={!/^[A-Z][A-Z]?[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$/.test(eVAddForm.vehicle_number) ? "Enter valid alphanumeric Vehicle Number without space" : null}
              value={eVAddForm.vehicle_number && eVAddForm.vehicle_number.toUpperCase() && eVAddForm.vehicle_number.toUpperCase().trim()}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Vehicle Number"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography style={{
              fontSize: "15px",
              fontFamily: " Maven Pro",
              fontWeight: 400,
              color: "#A7A7A7",
            }}>
              Chassis Number
            </Typography>
            <TextField
              onChange={(e) => {
                setEVAddFormArray(e, "chassis_number");
              }}
              size="small"
              id="outlined"
              value={eVAddForm.chassis_number && eVAddForm.chassis_number.trim()}
              helperText={eVAddForm.chassis_number != '' && !/^[A-Za-z0-9]{17}$/.test(eVAddForm.chassis_number) ? "Enter 17-digit valid Chasis Number" : null}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Chassis Number"
            />
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />

          <Grid item lg={3} xs={12}>
            <Typography style={{
              fontSize: "15px",
              fontFamily: " Maven Pro",
              fontWeight: 400,
              color: "#A7A7A7",
            }}>
              Engine Number
            </Typography>
            <TextField
              onChange={(e) => {
                setEVAddFormArray(e, "engine_number");
              }}
              size="small"
              id="outlined"
              value={eVAddForm.engine_number && eVAddForm.engine_number.trim()}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Engine Number"
            />
          </Grid></Grid>;
      case 1:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Fleet Name
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography> {addBatteryErrors && eVAddForm.asset && eVAddForm.asset.entity_id === "" ? <p style={{ color: 'red' }}> required</p> : null}
            </div>
            {enty1 === true ? (
              <><FormControl className={classes.styleO}>
                <Select
                  onChange={(e) => {
                    setEVAddFormArray(e, "entity_id", "asset");
                    dispatch(getOMBulk(e.target.value));
                  }}
                  error={addBatteryErrors && eVAddForm.asset && eVAddForm.asset.entity_id === ""}
                  id="demo-simple-select-error" value={eVAddForm.asset && eVAddForm.asset.entity_id}
                >
                  <MenuItem value="">Select your Manager</MenuItem>
                  {FleetMeta.data.length &&
                    FleetMeta.data.map((fleet) => {
                      return (
                        <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>
                      );
                    })}
                </Select>

              </FormControl>

              </>
            ) : (
              <TextField
                size="small"
                id="outlined"
                value={uName}
                className={classes.styleO}
              />
            )}
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Operation Manager
            </Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setEVAddFormArray(e, "user_id", "user");
                }}
                // error={addBatteryErrors && eVAddForm.user_id === ""}
                value={eVAddForm.user && eVAddForm.user.user_id}
              >
                <MenuItem value="">Select your Manager</MenuItem>
                {OMMeta.data.length &&
                  OMMeta.data.map((om) => {
                    return <MenuItem value={om[1]}>{om[0]}</MenuItem>;
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Investor</Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setEVAddFormArray(e, "user_id", "investor");
                }}
                // error={addBatteryErrors && eVAddForm.user_id === ""}
                value={eVAddForm.user_id}
              >
                <MenuItem value="">Select your Investor</MenuItem>
                {IVMeta.data.length &&
                  IVMeta.data.map((iv) => {
                    return <MenuItem value={iv[1]}>{iv[0]}</MenuItem>;
                  })}
              </Select>
            </FormControl>
          </Grid>
        </Grid>;
      case 2:
        return <Grid container spacing={2}>
          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload RC Book
            </Typography>
            <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangeRC}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button>
          </Grid>
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Manufacturing Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              max={currentDate}
              onChange={(e) => {
                setEVAddFormArray(e, "manufacturing_date");
              }}
              size="small"
              id="outlined"
              value={eVAddForm.manufacturing_date}
              // className={classes.styleO}
              placeholder="eg:  manufacturing_date"
            />
          </Grid>
          <Grid item lg={5} xs={12} />

          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload Insurance
            </Typography>
            <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangeIns}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button>
          </Grid>
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Insurance Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={currentDate}
              onChange={(e) => {
                setEVAddFormArray(e, "insurance_expiry_date");
              }}
              size="small"
              id="outlined"
              value={eVAddForm.insurance_expiry_date}
              // className={classes.styleO}
              placeholder="eg:  insurance_expiry_date"
            />
          </Grid>
          <Grid item lg={5} xs={12} />

          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Upload Permit Image
            </Typography>
            <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangePermit}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button>
          </Grid>
          {eVAddForm.manufacturing_date === '' ? <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Permit Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={eVAddForm.manufacturing_date}
              // onChange={(e) => {
              //   setEVAddFormArray(e, "permit_expiry_date");
              // }}
              size="small"
              id="outlined"
              value={eVAddForm.permit_expiry_date}
              // className={classes.styleO}
              placeholder="eg:  permit_expiry_date"
            />
          </Grid> : <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Permit Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={eVAddForm.manufacturing_date}
              onChange={(e) => {
                setEVAddFormArray(e, "permit_expiry_date");
              }}
              size="small"
              id="outlined"
              value={eVAddForm.permit_expiry_date}
              // className={classes.styleO}
              placeholder="eg:  permit_expiry_date"
            />
          </Grid>}
        </Grid>
      case 3:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Model</Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setEVAddFormArray(
                    e,
                    "telematics_data_id",
                    "telematics"
                  );
                }}
                error={
                  addBatteryErrors &&
                  eVAddForm.telematics_data_id === ""
                }
                value={
                  eVAddForm.telematics &&
                  eVAddForm.telematics.telematics_data_id
                }
              >
                <MenuItem value="">Select your Model</MenuItem>
                {allTele.length &&
                  allTele.map((tele) => {
                    return (
                      <MenuItem value={tele[0]}>{tele[1]}</MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              IMEI Number
            </Typography>
            <TextField
              onChange={(e) => {
                setEVAddFormArray(e, "imei", "telematics");
              }}
              size="small"
              id="outlined"
              // error={addBatteryErrors && eVAddForm.imei === ""}
              value={eVAddForm.telematics && eVAddForm.telematics.imei && eVAddForm.telematics.imei.trim()}
              className={classes.styleO}
              placeholder="eg:  imei"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              SIM Operator
            </Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setEVAddFormArray(e, "sim_operator", "telematics");
                }}
                // error={addBatteryErrors && eVAddForm.model_id === ""}
                value={
                  eVAddForm.telematics &&
                  eVAddForm.telematics.sim_operator
                }
              >
                <MenuItem value="">Select your Model</MenuItem>
                <MenuItem value="Airtel">Airtel</MenuItem>
                <MenuItem value="Jio">Jio</MenuItem>
                <MenuItem value="VI">VI</MenuItem>
                {/* {allVM.length && allVM.map((model) => {
                return (
                  <MenuItem value={model[5]}>{model[0]}</MenuItem>

                )
              }
              )} */}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Mobile Number
            </Typography>
            <TextField
              type="number"
              onChange={(e) => {
                setEVAddFormArray(e, "mobile_number", "telematics");
              }}
              value={
                eVAddForm.telematics &&
                eVAddForm.telematics.mobile_number &&
                eVAddForm.telematics.mobile_number.trim()
              }
              helperText={eVAddForm.telematics && eVAddForm.telematics.mobile_number != '' &&
                !/^[0-9]{10}$/.test(eVAddForm.telematics && eVAddForm.telematics.mobile_number) ?
                'Mobile number must be 10 digits' : null}
              className={classes.styleO}
              placeholder="eg:  9876678666"
            />
          </Grid>
          <Grid item lg={4.5} />

        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep2, setActiveStep2] = React.useState(0);
  const [completed2, setCompleted2] = React.useState({});
  const steps2 = getSteps2();

  const totalSteps2 = () => steps2.length;

  const completedSteps2 = () => Object.keys(completed2).length;

  const isLastStep2 = () => activeStep2 === totalSteps2() - 1;

  const allStepsCompleted2 = () => completedSteps2() === totalSteps2();

  const handleNext2 = () => {
    const newActiveStep2 = isLastStep2() && !allStepsCompleted2() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps2.findIndex((step2, i) => !(i in completed2))
      : activeStep2 + 1;
    setActiveStep2(newActiveStep2);
  };

  const handleBack2 = () => {
    setActiveStep2((prevActiveStep2) => prevActiveStep2 - 1);
  };

  const handleStep2 = (step2) => () => {
    setActiveStep2(step2);
  };

  const handleComplete2 = () => {
    const newCompleted2 = completed2;
    newCompleted2[activeStep2] = true;
    setCompleted2(newCompleted2);
    handleNext2();
  };

  const handleReset2 = () => {
    setActiveStep2(0);
    setCompleted2({});
  };

  function getSteps3() {
    return ['Identifiction', 'Association', 'Attestation', 'Mobilize'];
  }

  function getStepContent3(step3) {
    switch (step3) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Model
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setEVEditFormArray(e, "model_id");
                }}
                error={addBatteryErrors && editEArray.model_id === ""}
                value={editEArray.model_id}
              >
                <MenuItem value="">Select your Model</MenuItem>
                {modelList.length &&
                  modelList.map((modelL) => {
                    return (
                      <MenuItem value={modelL[1]}>{modelL[0]}</MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          {/* <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Type
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <Select
              onChange={(e) => {
                setEVEditFormArray(e, "type");
              }}
              error={addBatteryErrors && editEArray.type === ""}
              value={editEArray.type}
              className={classes.styleO}
            >
              <MenuItem value={"2w"}>2 Wheeler</MenuItem>
              <MenuItem value={"E-Auto"}>E-Auto</MenuItem>
              <MenuItem value={"l5n"}>L5 Commercial Vehicle</MenuItem>
              <MenuItem value={"Erickshaw"}>Erickshaw</MenuItem>
            </Select>
          </Grid>
          <Grid item lg={0.5} /> */}
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography style={{
                fontSize: "15px",
                fontFamily: " Maven Pro",
                fontWeight: 400,
                color: "#A7A7A7",
              }}>
                Vehicle Number
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              required
              onChange={(e) => {
                setEVEditFormArray(e, "vehicle_number");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && editEArray.vehicle_number === ""}
              helperText={!/^[A-Z][A-Z]?[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$/.test(editEArray.vehicle_number) ? "Please! Enter Valid Number" : null}
              value={editEArray.vehicle_number && editEArray.vehicle_number.toUpperCase() && editEArray.vehicle_number.toUpperCase().trim()}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
            />
          </Grid>
          <Grid item lg={0.5} />

          <Grid item lg={3} xs={12}>
            <Typography style={{
              fontSize: "15px",
              fontFamily: " Maven Pro",
              fontWeight: 400,
              color: "#A7A7A7",
            }}>
              Chassis Number
            </Typography>
            <TextField
              onChange={(e) => {
                setEVEditFormArray(e, "chassis_number");
              }}
              size="small"
              id="outlined"
              value={editEArray.chassis_number && editEArray.chassis_number.trim()}
              helperText={editEArray.chassis_number != '' && !/^[A-Za-z0-9]{17}$/.test(editEArray.chassis_number) ? "Please! Enter Valid Details" : null}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Chassis Number"
            />
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography style={{
              fontSize: "15px",
              fontFamily: " Maven Pro",
              fontWeight: 400,
              color: "#A7A7A7",
            }}>
              Engine Number
            </Typography>
            <TextField
              onChange={(e) => {
                setEVEditFormArray(e, "engine_number");
              }}
              size="small"
              id="outlined"
              value={editEArray.engine_number && editEArray.engine_number.trim()}
              style={{
                width: "100%",
                color: "#7A7A7D",
                borderRadius: "9px",
                //paddingBottom: "10px",
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
              }}
              placeholder="eg:  Engine Number"
            />
          </Grid></Grid>;
      case 1:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Fleet Name
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography> {addBatteryErrors && editEArray.asset && editEArray.asset.entity_id === "" ? <p style={{ color: 'red' }}> required</p> : null}
            </div>
            {enty1 === true ? (
              <FormControl className={classes.styleO}>
                <Select
                  onChange={(e) => {
                    setEVEditFormArray(e, "entity_id", "asset");
                    dispatch(getOMBulk(e.target.value));
                  }}
                  error={addBatteryErrors && (editEArray.asset && editEArray.asset.fleet_name === "")}
                  value={editEArray.asset && editEArray.asset.entity_id}
                >
                  {FleetMeta.data.length &&
                    FleetMeta.data.map((fleet) => {
                      return (
                        <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>
                      );
                    })}
                </Select>
              </FormControl>
            ) : (
              <TextField
                size="small"
                id="outlined"
                value={uName}
                className={classes.styleO}
              />
            )}
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Operation Manager
            </Typography>
            <FormControl className={classes.styleO}>
              <Select
                onChange={(e) => {
                  setEVEditFormArray(e, "user_id", "user");
                }}
                value={editEArray.user && editEArray.user.user_id}
              >
                {OMMeta.data.length &&
                  OMMeta.data.map((om) => {
                    return <MenuItem value={om[1]}>{om[0]}</MenuItem>;
                  })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Investor</Typography>
            <Select
              className={classes.styleO}
              onChange={(e) => {
                setEVEditFormArray(e, "user_id", "investor");
              }}
              value={editEArray.investor && editEArray.investor.user_id}
            >
              {IVMeta.data.length &&
                IVMeta.data.map((iv) => {
                  return <MenuItem value={iv[1]}>{iv[0]}</MenuItem>;
                })}
            </Select>
          </Grid>
        </Grid>;
      case 2:
        return <Grid container spacing={2}>
          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Upload RC Book
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <Button onClick={() => setOpenERC(true)}>
              <img src={editEArray.upload_rc_book} />
            </Button>
            <Dialog
              //fullScreen={fullScreen}
              open={openERC}
              maxWidth={"lg"}
              onClose={() => {
                setOpenERC(false);
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <></>
                <IconButton
                  onClick={() => {
                    setOpenERC(false);
                  }}
                >
                  <Icon
                    icon="akar-icons:circle-x"
                    width="26"
                    height="26"
                    color="#77b93e"
                  />
                </IconButton>
              </div>

              <DialogContent>
                <img src={editEArray.upload_rc_book} />
              </DialogContent>
            </Dialog>
          </Grid>
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Manufacturing Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              max={currentDate}
              onChange={(e) => {
                setEVEditFormArray(e, "manufacturing_date");
              }}
              size="small"
              id="outlined"
              value={editEArray.manufacturing_date}
            />
          </Grid>
          <Grid item lg={5} xs={12} />

          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Upload Insurance
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>

            <Button onClick={() => setOpenEIns(true)}>
              <img src={editEArray.upload_insurance} />
            </Button>
            <Dialog
              //fullScreen={fullScreen}
              open={openEIns}
              maxWidth={"lg"}
              onClose={() => {
                setOpenEIns(false);
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <></>
                <IconButton
                  onClick={() => {
                    setOpenEIns(false);
                  }}
                >
                  <Icon
                    icon="akar-icons:circle-x"
                    width="26"
                    height="26"
                    color="#77b93e"
                  />
                </IconButton>
              </div>

              <DialogContent>
                <img src={editEArray.upload_insurance} />
              </DialogContent>
            </Dialog>
          </Grid>
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Insurance Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={currentDate}
              onChange={(e) => {
                setEVEditFormArray(e, "insurance_expiry_date");
              }}
              size="small"
              id="outlined"
              value={editEArray.insurance_expiry_date}
            />
          </Grid>
          <Grid item lg={5} xs={12} />

          <Grid item lg={1} xs={12} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Upload Permit Image
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <Button onClick={() => setOpenEPermit(true)}>
              <img src={editEArray.upload_permit_image} />
            </Button>
            <Dialog
              //fullScreen={fullScreen}
              open={openEPermit}
              maxWidth={"lg"}
              onClose={() => {
                setOpenEPermit(false);
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <></>
                <IconButton
                  onClick={() => {
                    setOpenEPermit(false);
                  }}
                >
                  <Icon
                    icon="akar-icons:circle-x"
                    width="26"
                    height="26"
                    color="#77b93e"
                  />
                </IconButton>
              </div>

              <DialogContent>
                <img src={editEArray.upload_permit_image} />
              </DialogContent>
            </Dialog>
          </Grid>
          {editEArray.manufacturing_date === '' ? null : <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Permit Expiry Date
            </Typography>
            <input
              style={{
                width: "90%",
                color: "#7A7A7D",
                borderRadius: "9px",
                height: '40px',
                border: '1px solid #000',
                ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#C4C4C4  !important",
                },
                "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
              }}
              type="date"
              min={editEArray.manufacturing_date}
              onChange={(e) => {
                setEVEditFormArray(e, "permit_expiry_date");
              }}
              size="small"
              id="outlined"
              value={editEArray.permit_expiry_date}
            // className={classes.styleO}
            />
          </Grid>}
        </Grid>
      case 3:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Model</Typography>
            <Select onChange={(e) => {
              setEVEditFormArray(e, 'telematics_data_id', 'telematics')
            }}
              value={editEArray.telematics && editEArray.telematics.telematics_data_id}
              className={classes.styleO}>

              {allTele.length && allTele.map((telem) => {
                return (
                  <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                )
              }
              )}
            </Select>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              IMEI Number
            </Typography>
            <TextField
              onChange={(e) => {
                setEVEditFormArray(e, 'imei', 'telematics')
              }}
              size="small" id="outlined"
              value={editEArray.telematics && editEArray.telematics.imei && editEArray.telematics.imei.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              SIM Operator
            </Typography>
            <Select className={classes.styleO}
              onChange={(e) => { setEVEditFormArray(e, 'sim_operator', 'telematics') }}
              value={editEArray.telematics && editEArray.telematics.sim_operator}
            >
              <MenuItem value="">Select your Model</MenuItem>
              <MenuItem value="Airtel">Airtel</MenuItem>
              <MenuItem value="Jio">Jio</MenuItem>
              <MenuItem value="VI">VI</MenuItem>

            </Select>
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Mobile Number
            </Typography>
            <TextField
              type="number"
              onChange={(e) => {
                setEVEditFormArray(e, 'mobile_number', 'telematics')
              }}
              value={editEArray.telematics && editEArray.telematics.mobile_number && editEArray.telematics.mobile_number.trim()}
              helperText={editEArray.telematics && editEArray.telematics.mobile_number != '' &&
                !/^[0-9]{10}$/.test(editEArray.telematics && editEArray.telematics.mobile_number) ?
                'Mobile number must be 10 digits' : null}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={4.5} />

        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep3, setActiveStep3] = React.useState(0);
  const [completed3, setCompleted3] = React.useState({});
  const steps3 = getSteps3();

  const totalSteps3 = () => steps3.length;

  const completedSteps3 = () => Object.keys(completed3).length;

  const isLastStep3 = () => activeStep3 === totalSteps3() - 1;

  const allStepsCompleted3 = () => completedSteps3() === totalSteps3();

  const handleNext3 = () => {
    const newActiveStep3 = isLastStep3() && !allStepsCompleted3() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps3.findIndex((step3, i) => !(i in completed3))
      : activeStep3 + 1;
    setActiveStep3(newActiveStep3);
  };

  const handleBack3 = () => {
    setActiveStep3((prevActiveStep3) => prevActiveStep3 - 1);
  };

  const handleStep3 = (step3) => () => {
    setActiveStep3(step3);
  };

  const handleComplete3 = () => {
    const newCompleted3 = completed3;
    newCompleted3[activeStep3] = true;
    setCompleted3(newCompleted3);
    handleNext3();
  };

  const handleReset3 = () => {
    setActiveStep3(0);
    setCompleted3({});
  };


  function getSteps4() {
    return ['Define', 'Dimension', 'Attestation'];
  }

  function getStepContent4(step4) {
    switch (step4) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Catagory
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              // onChange={(e) => {
              //   setVMAddFormArray(e, 'fuel')
              // }}
              size="small"
              id="outlined"
              // error={addBatteryErrors && addVMForm.fuel === ""}
              value={addVMForm.fuel}
              className={classes.styleO}
              placeholder="eg:  Vehicle Catagory"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Model
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              onChange={(e) => {
                setVMAddFormArray(e, "model");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.model === ""}
              value={addVMForm.model && addVMForm.model.trim()}
              className={classes.styleO}
              placeholder="eg:  Vehicle Model"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Payload(Kg)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMAddFormArray(e, "unladen_wt");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.unladen_wt === ""}
              value={addVMForm.unladen_wt && addVMForm.unladen_wt.trim()}
              className={classes.styleO}
              placeholder="eg:  Payload(Kg)"
            />
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}> Seating</Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              onChange={(e) => {
                setVMAddFormArray(e, "seating");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.seating === ""}
              value={addVMForm.seating && addVMForm.seating.trim()}
              className={classes.styleO}
              placeholder="eg:  seating"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Max Speed (kmph)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMAddFormArray(e, "top_speed");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.top_speed === ""}
              value={addVMForm.top_speed && addVMForm.top_speed.trim()}
              className={classes.styleO}
              placeholder="eg: Max Speed (kmph)"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Range Per Charge (Km)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              onChange={(e) => {
                setVMAddFormArray(e, "typical_range");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.typical_range === ""}
              value={addVMForm.typical_range && addVMForm.typical_range.trim()}
              className={classes.styleO}
              placeholder="eg: Range Per Charge (Km)"
            />
          </Grid>
        </Grid>;
      case 1:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Width (mm)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>

            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMAddFormArray(e, "width");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.width === ""}
              value={addVMForm.width && addVMForm.width.trim()}
              className={classes.styleO}
              placeholder="eg:Vehicle Width (mm)"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Length (mm)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMAddFormArray(e, "length");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.length === ""}
              value={addVMForm.length && addVMForm.length.trim()}
              className={classes.styleO}
              placeholder="eg: Vehicle Length (mm)"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Height (mm)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMAddFormArray(e, "height");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.height === ""}
              value={addVMForm.height && addVMForm.height.trim()}
              className={classes.styleO}
              placeholder="eg: Vehicle Height (mm)"
            />
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Kerb Weight (Kg)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMAddFormArray(e, "gross_vehicle_weight");
              }}
              size="small"
              id="outlined"
              error={
                addBatteryErrors && addVMForm.gross_vehicle_weight === ""
              }
              value={addVMForm.gross_vehicle_weight && addVMForm.gross_vehicle_weight.trim()}
              className={classes.styleO}
              placeholder="eg: Vehicle Kerb Weight (Kg)"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Gross Weight (Kg)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMAddFormArray(e, "payload_weight");
              }}
              size="small"
              id="outlined"
              error={addBatteryErrors && addVMForm.payload_weight === ""}
              value={addVMForm.payload_weight && addVMForm.payload_weight.trim()}
              className={classes.styleO}
              placeholder="eg: Vehicle Gross Weight (Kg)"
            />
          </Grid>

        </Grid>;
      case 2:
        return <Grid container spacing={2}>
          <Grid item lg={2} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Reference Image
            </Typography>
            <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangeRef}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Online link/Datasheet
            </Typography>
            <Button
              sx={{
                ":hover": { backgroundColor: "#fff" },
              }}
            >
              <input
                onChange={handleChangeDataSheet}
                type="file"
                style={{ color: "#C1C1C1" }}
              />
            </Button>
          </Grid>
        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep4, setActiveStep4] = React.useState(0);
  const [completed4, setCompleted4] = React.useState({});
  const steps4 = getSteps4();

  const totalSteps4 = () => steps4.length;

  const completedSteps4 = () => Object.keys(completed4).length;

  const isLastStep4 = () => activeStep4 === totalSteps4() - 1;

  const allStepsCompleted4 = () => completedSteps4() === totalSteps4();

  const handleNext4 = () => {
    const newActiveStep4 = isLastStep4() && !allStepsCompleted4() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps4.findIndex((step4, i) => !(i in completed4))
      : activeStep4 + 1;
    setActiveStep4(newActiveStep4);
  };

  const handleBack4 = () => {
    setActiveStep4((prevActiveStep4) => prevActiveStep4 - 1);
  };

  const handleStep4 = (step4) => () => {
    setActiveStep4(step4);
  };

  const handleComplete4 = () => {
    const newCompleted4 = completed4;
    newCompleted4[activeStep4] = true;
    setCompleted4(newCompleted4);
    handleNext4();
  };

  const handleReset4 = () => {
    setActiveStep4(0);
    setCompleted4({});
  };

  function getSteps5() {
    return ['Define', 'Dimension', 'Attestation'];
  }

  function getStepContent5(step5) {
    switch (step5) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Catagory
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              // onChange={(e) => {
              //   setVMEditFormArray(e, "fuel");
              // }}
              size="small"
              id="outlined"
              value={editArray.fuel}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Model
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              onChange={(e) => {
                setVMEditFormArray(e, "model");
              }}
              size="small"
              id="outlined"
              value={editArray.model && editArray.model.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Payload(Kg)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMEditFormArray(e, "unladen_wt");
              }}
              size="small"
              id="outlined"
              value={editArray.unladen_wt && editArray.unladen_wt.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}> Seating</Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              onChange={(e) => {
                setVMEditFormArray(e, "seating");
              }}
              size="small"
              id="outlined"
              value={editArray.seating && editArray.seating.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Max Speed (kmph)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMEditFormArray(e, "top_speed");
              }}
              size="small"
              id="outlined"
              value={editArray.top_speed && editArray.top_speed.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Range Per Charge (Km)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              onChange={(e) => {
                setVMEditFormArray(e, "typical_range");
              }}
              size="small"
              id="outlined"
              value={editArray.typical_range && editArray.typical_range.trim()}
              className={classes.styleO}
            />
          </Grid>
        </Grid>;
      case 1:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Width (mm)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>

            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMEditFormArray(e, "width");
              }}
              size="small"
              id="outlined"
              value={editArray.width && editArray.width.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Length (mm)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMEditFormArray(e, "length");
              }}
              size="small"
              id="outlined"
              value={editArray.length && editArray.length.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Height (mm)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMEditFormArray(e, "height");
              }}
              size="small"
              id="outlined"
              value={editArray.height && editArray.height.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Kerb Weight (Kg)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMEditFormArray(e, "gross_vehicle_weight");
              }}
              size="small"
              id="outlined"
              value={editArray.gross_vehicle_weight && editArray.gross_vehicle_weight.trim()}
              className={classes.styleO}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: "flex" }}>
              <Typography className={classes.styleL}>
                Vehicle Gross Weight (Kg)
              </Typography>
              &nbsp;
              <Typography style={{ color: "red", fontSize: "18px" }}>
                *
              </Typography>
            </div>
            <TextField
              type="number"
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              onChange={(e) => {
                setVMEditFormArray(e, "payload_weight");
              }}
              size="small"
              id="outlined"
              value={editArray.payload_weight && editArray.payload_weight.trim()}
              className={classes.styleO}
            />
          </Grid>

        </Grid>;
      case 2:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Reference Image
            </Typography>
            <Button onClick={() => setOpenRef(true)}>
              <img src={editArray.reference_Image} />
            </Button>
            <Dialog
              //fullScreen={fullScreen}
              open={openRef}
              maxWidth={"lg"}
              onClose={() => {
                setOpenRef(false);
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <></>
                <IconButton
                  onClick={() => {
                    setOpenRef(false);
                  }}
                >
                  <Icon
                    icon="akar-icons:circle-x"
                    width="26"
                    height="26"
                    color="#77b93e"
                  />
                </IconButton>
              </div>

              <DialogContent>
                <img src={editArray.reference_Image} />
              </DialogContent>
            </Dialog>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Online link/Datasheet
            </Typography>
            <Button onClick={() => setOpenData(true)}>
              <img src={editArray.datasheet} />
            </Button>
            <Dialog
              //fullScreen={fullScreen}
              open={openData}
              maxWidth={"lg"}
              onClose={() => {
                setOpenData(false);
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div
                style={{ display: "flex", justifyContent: "flex-end" }}
              >
                <></>
                <IconButton
                  onClick={() => {
                    setOpenData(false);
                  }}
                >
                  <Icon
                    icon="akar-icons:circle-x"
                    width="26"
                    height="26"
                    color="#77b93e"
                  />
                </IconButton>
              </div>

              <DialogContent>
                <img src={editArray.datasheet} />
              </DialogContent>
            </Dialog>
          </Grid>
        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep5, setActiveStep5] = React.useState(0);
  const [completed5, setCompleted5] = React.useState({});
  const steps5 = getSteps5();

  const totalSteps5 = () => steps5.length;

  const completedSteps5 = () => Object.keys(completed5).length;

  const isLastStep5 = () => activeStep5 === totalSteps5() - 1;

  const allStepsCompleted5 = () => completedSteps5() === totalSteps5();

  const handleNext5 = () => {
    const newActiveStep5 = isLastStep5() && !allStepsCompleted5() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps5.findIndex((step5, i) => !(i in completed5))
      : activeStep5 + 1;
    setActiveStep5(newActiveStep5);
  };

  const handleBack5 = () => {
    setActiveStep5((prevActiveStep5) => prevActiveStep5 - 1);
  };

  const handleStep5 = (step5) => () => {
    setActiveStep5(step5);
  };

  const handleComplete5 = () => {
    const newCompleted5 = completed5;
    newCompleted5[activeStep5] = true;
    setCompleted5(newCompleted5);
    handleNext5();
  };

  const handleReset5 = () => {
    setActiveStep5(0);
    setCompleted5({});
  };


  return (
    <div onMouseEnter={() => setFrame(true)} className={classes.table}>
      <Snackbar open={open} autoHideDuration={3000} onClose={handleClose} 
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      style={{marginTop:'180px'}}
      >
        <Alert onClose={handleClose} severity="warning">
          This vehicle assigned to {ddd}
        </Alert>
      </Snackbar>
      <Snackbar open={open1} autoHideDuration={3000} onClose={handleClose1} 
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      style={{marginTop:'235px'}}
      >
        <Alert onClose={handleClose1} severity="warning">
          This vehicle assigned to {ddd1}
        </Alert>
      </Snackbar>
      <Snackbar open={open2} autoHideDuration={3000} onClose={handleClose2} 
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      style={{marginTop:'180px'}}
      >
        <Alert onClose={handleClose2} severity="warning">
          This vehicle assigned to {ddd2}
        </Alert>
      </Snackbar>
      <Snackbar open={open3} autoHideDuration={3000} onClose={handleClose3} 
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      style={{marginTop:'180px'}}
      >
        <Alert onClose={handleClose3} severity="success">
          {ddd3}
        </Alert>
      </Snackbar>
      <Snackbar open={open4} autoHideDuration={3000} onClose={handleClose4} 
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      style={{marginTop:'180px'}}
      >
        <Alert onClose={handleClose4} severity="warning">
          {ddd4}
        </Alert>
      </Snackbar>
      <SimpleSnackbar
        logInMessage={addResponse}
        notificationTimeOut={notificationTimeOut}
        setLoginSucess={setAddBatteryErrors}
        loginSuccess={addBatteryErrors}
      />

      <Tabs
        className={classes.tabsSection}
        value={value}
        onChange={handleChange}
        variant="fullWidth"
        indicatorColor="primary"
        aria-label="icon tabs example"
      >
        <Tab
          label="Commercial"
          icon={<Icon icon="ic:baseline-airport-shuttle" width="22"
            height="22" />}
          aria-label="favorite"
        />
        <Tab
          label="E-Rickshaw"
          icon={
            <Icon
              icon="material-symbols:electric-rickshaw"
              width="22"
              height="22"
            />
          }
          aria-label="phone"
        />
        <Tab label={"VEHICLE Model"} icon={<Icon
          icon="material-symbols:tab-outline"
          width="22"
          height="22"
        />} aria-label="phone" />
      </Tabs>

      <Paper square className={classes.root} />
      <>
        {
          value === 0 ? (
            <>
              {openCVehicle === true ?
                <div style={{
                  width: '100%', overflow: 'hidden'
                }}><br />
                  <h3>Onboarding Vehicle</h3><br />
                  <Stepper nonLinear activeStep={activeStep}>
                    {steps.map((label, index) => (
                      <Step key={label}>
                        <StepButton onClick={handleStep(index)} completed={completed[index]}>
                          {label}
                        </StepButton>
                      </Step>
                    ))}
                  </Stepper>
                  <div>
                    {allStepsCompleted() ? (
                      <div>
                        <Typography style={{
                          marginTop: theme.spacing(1),
                          marginBottom: theme.spacing(1)
                        }}>
                          All steps completed - you&apos;re finished
                        </Typography>
                        <Button onClick={handleReset}>Reset</Button>
                      </div>
                    ) : (
                      <div><br />
                        <Typography style={{
                          marginTop: theme.spacing(1),
                          marginBottom: theme.spacing(1)
                        }}>{getStepContent(activeStep)}</Typography>
                        <br /><br /><br /><br />
                        <div>
                          <Button
                            onClick={() => {
                              setOpenCVehicle(false);
                              handleReset()
                              setCVAddForm({})
                            }}
                            style={{
                              marginRight: theme.spacing(1)
                            }}>
                            Cancel
                          </Button>
                          <Button disabled={activeStep === 0} onClick={handleBack} style={{
                            marginRight: theme.spacing(1)
                          }}>
                            Back
                          </Button>
                          {cVAddForm.model_id != '' && cVAddForm.type != '' &&
                            /^[A-Z][A-Z]?[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$/.test(cVAddForm.vehicle_number) &&
                            (/^[A-Za-z0-9]{17}$/.test(cVAddForm.chassis_number) || cVAddForm.chassis_number === '' )? <Button
                              variant="contained"
                              color="primary"
                              onClick={handleNext}
                              style={{
                                marginRight: theme.spacing(1)
                              }} disabled={activeStep === totalSteps() - 1}
                            >
                            Next
                          </Button> : <Button disabled
                            variant="contained"
                            style={{
                              marginRight: theme.spacing(1)
                            }}
                          >
                            Next
                          </Button>
                          }
                          {activeStep === totalSteps() - 1 ?
                            <Button variant="contained" color="primary"
                              onClick={() => {
                                handleSubmitAddCV(true);
                              }}
                            >Finish
                            </Button> : <Button disabled variant="contained">Finish
                            </Button>}


                          {/* ))
                          } */}
                        </div>
                      </div>
                    )}
                  </div><br /><br /><br />
                </div> :
                openCVEdit === true ?
                  <div style={{
                    width: '100%', overflow: 'hidden'
                  }}><br /><h3>Vehicle Profile</h3><br />
                    <Stepper nonLinear activeStep={activeStep1}>
                      {steps1.map((label1, index) => (
                        <Step key={label1}>
                          <StepButton onClick={handleStep1(index)} completed={completed1[index]}>
                            {label1}
                          </StepButton>
                        </Step>
                      ))}
                    </Stepper>
                    <div>
                      {allStepsCompleted1() ? (
                        <div>
                          <Typography style={{
                            marginTop: theme.spacing(1),
                            marginBottom: theme.spacing(1)
                          }}>
                            All steps completed - you&apos;re finished
                          </Typography>
                          <Button onClick={handleReset1}>Reset</Button>
                        </div>
                      ) : (
                        <div><br />
                          <Typography style={{
                            marginTop: theme.spacing(1),
                            marginBottom: theme.spacing(1)
                          }}>{getStepContent1(activeStep1)}</Typography>
                          <br /><br /><br /><br />
                          <div>
                            <Button
                              onClick={() => {
                                setOpenCVEdit(false);
                                handleReset1()
                              }}
                              style={{
                                marginRight: theme.spacing(1)
                              }}>
                              Cancel
                            </Button>
                            <Button disabled={activeStep1 === 0} onClick={handleBack1} style={{
                              marginRight: theme.spacing(1)
                            }}>
                              Back
                            </Button>
                            {editCArray.model_id != '' && editCArray.type != '' &&
                              editCArray.vehicle_number != '' ? <Button
                                variant="contained"
                                color="primary"
                                onClick={handleNext1}
                                style={{
                                  marginRight: theme.spacing(1)
                                }} disabled={activeStep1 === totalSteps1() - 1}
                              >
                              Next
                            </Button> : <Button disabled
                              variant="contained"
                              style={{
                                marginRight: theme.spacing(1)
                              }}
                            >
                              Next
                            </Button>
                            }

                            {activeStep1 === totalSteps1() - 1 ?
                              <Button variant="contained" color="primary"
                                onClick={() => {
                                  submitCVEdit(true);
                                }}
                              >Finish
                              </Button> : <Button disabled variant="contained">Finish
                              </Button>}


                            {/* ))
                        } */}
                          </div>
                        </div>
                      )}
                    </div><br /><br /><br />
                  </div>
                  : <><MUIDataTable
                    checkboxSelection={false}
                    title={"Commercial"}
                    data={CVMeta.data}
                    columns={vehicleEditAccess === true ? VehicleColumn : VehicleColumn1}
                    options={options}
                    selectableRows={1}
                    selectableRowsHideCheckboxes
                  />
                    <br />
                    <Pagination
                      count={MyCVCount}
                      page={MyCVPage}
                      onChange={changePageCV}
                    /></>}
            </>
          ) : null}

        {
          value === 1 ? (
            <>
              {openEVehicle === true ?
                <div style={{
                  width: '100%', overflow: 'hidden'
                }}><br />
                  <h3>Onboarding Vehicle</h3><br />
                  <Stepper nonLinear activeStep={activeStep2}>
                    {steps2.map((label2, index) => (
                      <Step key={label2}>
                        <StepButton onClick={handleStep2(index)} completed={completed2[index]}>
                          {label2}
                        </StepButton>
                      </Step>
                    ))}
                  </Stepper>
                  <div>
                    {allStepsCompleted2() ? (
                      <div>
                        <Typography style={{
                          marginTop: theme.spacing(1),
                          marginBottom: theme.spacing(1)
                        }}>
                          All steps completed - you&apos;re finished
                        </Typography>
                        <Button onClick={handleReset2}>Reset</Button>
                      </div>
                    ) : (
                      <div><br />
                        <Typography style={{
                          marginTop: theme.spacing(1),
                          marginBottom: theme.spacing(1)
                        }}>{getStepContent2(activeStep2)}</Typography>
                        <br /><br /><br /><br />
                        <div>
                          <Button
                            onClick={() => {
                              setOpenEVehicle(false);
                              handleReset2()
                              setEVAddForm({})
                            }}
                            style={{
                              marginRight: theme.spacing(1)
                            }}>
                            Cancel
                          </Button>
                          <Button disabled={activeStep2 === 0} onClick={handleBack2} style={{
                            marginRight: theme.spacing(1)
                          }}>
                            Back
                          </Button>
                          {eVAddForm.model_id != '' && eVAddForm.type != '' &&
                            /^[A-Z][A-Z]?[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$/.test(eVAddForm.vehicle_number) &&
                            (/^[A-Za-z0-9]{17}$/.test(eVAddForm.chassis_number) || eVAddForm.chassis_number === '' ) ? <Button
                              variant="contained"
                              color="primary"
                              onClick={handleNext2}
                              style={{
                                marginRight: theme.spacing(1)
                              }} disabled={activeStep2 === totalSteps2() - 1}
                            >
                            Next
                          </Button> : <Button disabled
                            variant="contained"
                            style={{
                              marginRight: theme.spacing(1)
                            }}
                          >
                            Next
                          </Button>
                          }
                          {activeStep2 === totalSteps2() - 1 ?
                            <Button variant="contained" color="primary"
                              onClick={() => {
                                submitEV();
                              }}
                            >Finish
                            </Button> : <Button disabled variant="contained">Finish
                            </Button>}


                          {/* ))
                        } */}
                        </div>
                      </div>
                    )}
                  </div><br /><br /><br />
                </div> :
                openEVEdit === true ?
                  <div style={{
                    width: '100%', overflow: 'hidden'
                  }}><br /><h3>Vehicle Profile</h3><br />
                    <Stepper nonLinear activeStep={activeStep3}>
                      {steps1.map((label3, index) => (
                        <Step key={label3}>
                          <StepButton onClick={handleStep3(index)} completed={completed3[index]}>
                            {label3}
                          </StepButton>
                        </Step>
                      ))}
                    </Stepper>
                    <div>
                      {allStepsCompleted3() ? (
                        <div>
                          <Typography style={{
                            marginTop: theme.spacing(1),
                            marginBottom: theme.spacing(1)
                          }}>
                            All steps completed - you&apos;re finished
                          </Typography>
                          <Button onClick={handleReset3}>Reset</Button>
                        </div>
                      ) : (
                        <div><br />
                          <Typography style={{
                            marginTop: theme.spacing(1),
                            marginBottom: theme.spacing(1)
                          }}>{getStepContent3(activeStep3)}</Typography>
                          <br /><br /><br /><br />
                          <div>
                            <Button
                              onClick={() => {
                                setOpenEVEdit(false);
                                handleReset3()
                              }}
                              style={{
                                marginRight: theme.spacing(1)
                              }}>
                              Cancel
                            </Button>
                            <Button disabled={activeStep3 === 0} onClick={handleBack3} style={{
                              marginRight: theme.spacing(1)
                            }}>
                              Back
                            </Button>
                            {editEArray.model_id != '' && editEArray.type != '' &&
                              editEArray.vehicle_number != '' ? <Button
                                variant="contained"
                                color="primary"
                                onClick={handleNext3}
                                style={{
                                  marginRight: theme.spacing(1)
                                }} disabled={activeStep3 === totalSteps3() - 1}
                              >
                              Next
                            </Button> : <Button disabled
                              variant="contained"
                              style={{
                                marginRight: theme.spacing(1)
                              }}
                            >
                              Next
                            </Button>
                            }

                            {activeStep3 === totalSteps3() - 1 ?
                              <Button variant="contained" color="primary"
                                onClick={() => {
                                  submitEVEdit(true);
                                }}
                              >Finish
                              </Button> : <Button disabled variant="contained">Finish
                              </Button>}


                            {/* ))
                        } */}
                          </div>
                        </div>
                      )}
                    </div><br /><br /><br />
                  </div> : <><MUIDataTable
                    checkboxSelection={false}
                    title={"E-Rickshaw"}
                    data={EVMeta.data}
                    columns={vehicleEditAccess === true ? ErickColumn : ErickColumn1}
                    options={options1}
                    selectableRows={1}
                    selectableRowsHideCheckboxes
                  />
                    <br />
                    <Pagination
                      count={MyEVCount}
                      page={MyEVPage}
                      onChange={changePageEV}
                    /></>}
            </>
          ) : null}
        {value === 2 ? (
          <>{
            openVM === true ?
              <div style={{
                width: '100%', overflow: 'hidden'
              }}><br />
                <h3>Onboarding Model</h3><br />
                <Stepper nonLinear activeStep={activeStep4}>
                  {steps4.map((label4, index) => (
                    <Step key={label4}>
                      <StepButton onClick={handleStep4(index)} completed={completed4[index]}>
                        {label4}
                      </StepButton>
                    </Step>
                  ))}
                </Stepper>
                <div>
                  {allStepsCompleted4() ? (
                    <div>
                      <Typography style={{
                        marginTop: theme.spacing(1),
                        marginBottom: theme.spacing(1)
                      }}>
                        All steps completed - you&apos;re finished
                      </Typography>
                      <Button onClick={handleReset4}>Reset</Button>
                    </div>
                  ) : (
                    <div><br />
                      <Typography style={{
                        marginTop: theme.spacing(1),
                        marginBottom: theme.spacing(1)
                      }}>{getStepContent4(activeStep4)}</Typography>
                      <br /><br /><br /><br />
                      <div>
                        <Button
                          onClick={() => {
                            setOpenVM(false);
                            handleReset4()
                            setAddVMForm({})
                          }}
                          style={{
                            marginRight: theme.spacing(1)
                          }}>
                          Cancel
                        </Button>
                        <Button disabled={activeStep4 === 0} onClick={handleBack4} style={{
                          marginRight: theme.spacing(1)
                        }}>
                          Back
                        </Button>
                        {addVMForm.fuel != '' && addVMForm.model != '' && addVMForm.unladen_wt != '' &&
                          addVMForm.seating != '' && addVMForm.top_speed != '' && addVMForm.typical_range != '' ?
                          <Button disabled={activeStep4 === 1 && addVMForm.payload_weight === '' || activeStep4 === totalSteps4() - 1}
                            variant="contained"
                            color="primary"
                            onClick={handleNext4}
                            style={{
                              marginRight: theme.spacing(1)
                            }}
                          >
                            Next
                          </Button> :
                          activeStep4 === 1 && addVMForm.width != '' && addVMForm.length != '' && addVMForm.height != '' &&
                            addVMForm.gross_vehicle_weight != '' && addVMForm.payload_weight != '' ?
                            <Button variant="contained"
                              color="primary"
                              onClick={handleNext4}
                              style={{
                                marginRight: theme.spacing(1)
                              }}
                            >
                              Next
                            </Button>
                            : null}
                        {activeStep4 === totalSteps4() - 1 ?
                          <Button variant="contained" color="primary"
                            onClick={() => {
                              handleSubmitAddVM(true);
                            }}
                          >Finish
                          </Button> : <Button disabled variant="contained">Finish
                          </Button>}


                        {/* ))
                          } */}
                      </div>
                    </div>
                  )}
                </div><br /><br /><br />
              </div> :
              openVMEdit === true ?
                <div style={{
                  width: '100%', overflow: 'hidden'
                }}><br />
                  <h3>Model Profile</h3><br />
                  <Stepper nonLinear activeStep={activeStep5}>
                    {steps5.map((label5, index) => (
                      <Step key={label5}>
                        <StepButton onClick={handleStep5(index)} completed={completed5[index]}>
                          {label5}
                        </StepButton>
                      </Step>
                    ))}
                  </Stepper>
                  <div>
                    {allStepsCompleted5() ? (
                      <div>
                        <Typography style={{
                          marginTop: theme.spacing(1),
                          marginBottom: theme.spacing(1)
                        }}>
                          All steps completed - you&apos;re finished
                        </Typography>
                        <Button onClick={handleReset5}>Reset</Button>
                      </div>
                    ) : (
                      <div><br />
                        <Typography style={{
                          marginTop: theme.spacing(1),
                          marginBottom: theme.spacing(1)
                        }}>{getStepContent5(activeStep5)}</Typography>
                        <br /><br /><br /><br />
                        <div>
                          <Button
                            onClick={() => {
                              setOpenVMEdit(false);
                              handleReset5()
                            }}
                            style={{
                              marginRight: theme.spacing(1)
                            }}>
                            Cancel
                          </Button>
                          <Button disabled={activeStep5 === 0} onClick={handleBack5} style={{
                            marginRight: theme.spacing(1)
                          }}>
                            Back
                          </Button>
                          {editArray.fuel != '' && editArray.model != '' && editArray.unladen_wt != '' &&
                            editArray.seating != '' && editArray.top_speed != '' && editArray.typical_range != '' ?
                            <Button disabled={activeStep5 === 1 && editArray.payload_weight === '' || activeStep5 === totalSteps5() - 1}
                              variant="contained"
                              color="primary"
                              onClick={handleNext5}
                              style={{
                                marginRight: theme.spacing(1)
                              }}
                            >
                              Next
                            </Button> :
                            activeStep5 === 1 && editArray.width != '' && editArray.length != '' && editArray.height != '' &&
                              editArray.gross_vehicle_weight != '' && editArray.payload_weight != '' ?
                              <Button variant="contained"
                                color="primary"
                                onClick={handleNext5}
                                style={{
                                  marginRight: theme.spacing(1)
                                }}
                              >
                                Next
                              </Button>
                              : null}
                          {activeStep5 === totalSteps5() - 1 ?
                            <Button variant="contained" color="primary"
                              onClick={() => {
                                submitVMEdit(true);
                              }}
                            >Finish
                            </Button> : <Button disabled variant="contained">Finish
                            </Button>}


                          {/* ))
                          } */}
                        </div>
                      </div>
                    )}
                  </div><br /><br /><br />
                </div> : <><MUIDataTable
                  checkboxSelection={false}
                  title={"Vehicle Model"}
                  data={VMMeta.data}
                  columns={
                    vehicleEditAccess === true ? VehicleModel : VehicleModel1
                  }
                  options={options2}
                  selectableRows={1}
                  selectableRowsHideCheckboxes
                />
                  <br />
                  <Pagination
                    count={MyVMCount}
                    page={MyVMPage}
                    onChange={changePageBatModel}
                  />
                </>}</>


        ) : null}
        <br />
        <Typography align="center" className={classes.copyRight}>
          Copyright© 2023 ReVx Energy Pvt.Ltd.
        </Typography>










        {/* Driver Active */}
        <Dialog
          fullScreen={fullScreen}
          open={openDriverActive}
          maxWidth={"lg"}
          onClose={() => setOpenDriverActive(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Driver Assignment"}
          </DialogTitle>
          <DialogContent style={{ height: '100px', width: '300px' }}>
            <DialogContentText>
              <Grid container spacing={2}>
                <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>Driver Name:</b>
                <Grid item lg={12} xs={12}>
                  <Select
                    onChange={(e) => {
                      setAssignDriv((state) => ({
                        ...state,
                        driver_id: e.target.value,
                      }));
                    }}
                    style={{
                      width: "100%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      //paddingBottom: "10px",
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
                    }}
                  // value={assignDriv.driver_id}
                  >
                    <MenuItem value="">Select your Driver</MenuItem>
                    {/* (VDAMetaPresent === true ? */}
                    {VDAMeta.data.length &&
                      VDAMeta.data.map((driver) => {
                        return (
                          <MenuItem value={driver[1]}>{driver[0]}</MenuItem>
                        );
                      })}
                    {/* : <MenuItem>No Driver to Assign</MenuItem>) */}
                  </Select>
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenDriverActive(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                assDriver();
              }}
              color="secondary"
              autoFocus
            >
              Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* Driver De-Active */}
        <Dialog
          fullScreen={fullScreen}
          open={openDriverDeActive}
          maxWidth={"lg"}
          onClose={() => setOpenDriverDeActive(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Driver Reassignment"}
          </DialogTitle>
          <DialogContent style={{ height: '100px', width: '300px' }}><br />
            <DialogContentText>
              {/* <Grid container spacing={2}> */}
              <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>Driver Name:&nbsp;{drive}</b>
              {/* <Grid item lg={12} xs={12}> */}
              {/* {editCArray.driver_name} */}
              {/* <Select onChange={(e) => {
                      setEditDriverReAssign((state) => ({
                        ...state,
                        "driver_id": e.target.value
                      }))
                      // setEditCArray((state) => ({
                      //   ...state,
                      //   "driver_id": e.target.value
                      // }))
                    }}
                      className={classes.styleO}
                    // value={selectedD ? assignDriv && assignDriv.driver_id : null}
                    // value={setEditDriverReAssign.driver_id}
                    >
                      <MenuItem value={editCArray.driver_id}>{editCArray.driver_name}</MenuItem>
                      {VDAMeta.data.length && VDAMeta.data.map((driver) => {
                        return (
                          <MenuItem value={driver[1]}>{driver[0]}</MenuItem>

                        )
                      }
                      )}

                    </Select> */}
              {/* </Grid>
              </Grid> */}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenDriverDeActive(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                DeactiveD(assignID);
              }}
              color="secondary"
              autoFocus
            >
              Re-Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* E-Driver Active */}
        <Dialog
          fullScreen={fullScreen}
          open={openEDriverActive}
          maxWidth={"lg"}
          onClose={() => setOpenEDriverActive(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Driver Assignment"}
          </DialogTitle>
          <DialogContent style={{ height: '100px', width: '300px' }}>
            <DialogContentText>
              <Grid container spacing={2}>
                <b style={{ color: "#00000080" }}>Driver Name:</b>
                <Grid item lg={12} xs={12}>
                  <Select
                    onChange={(e) => {
                      setAssignEDriv((state) => ({
                        ...state,
                        driver_id: e.target.value,
                      }));
                    }}
                    style={{
                      width: "100%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      //paddingBottom: "10px",
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
                    }}
                  >
                    {EVDAMeta.data.length === 0 ? <MenuItem value="">Select your Driver</MenuItem> :
                    <MenuItem value="">No driver to assign</MenuItem>}
                    {/* (VDAMetaPresent === true ? */}
                    {EVDAMeta.data.length &&
                      EVDAMeta.data.map((driver) => {
                        return (
                          <MenuItem value={driver[1]}>{driver[0]}</MenuItem>
                        );
                      })}
                    {/* : <MenuItem>No Driver to Assign</MenuItem>) */}
                  </Select>
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenEDriverActive(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                assEDriver();
              }}
              color="secondary"
              autoFocus
            >
              Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* E-Driver De-Active */}
        <Dialog
          fullScreen={fullScreen}
          open={openEDriverDeActive}
          maxWidth={"lg"}
          onClose={() => setOpenEDriverDeActive(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Driver Reassignment"}
          </DialogTitle>
          <DialogContent style={{ height: '100px', width: '300px' }}><br />
            <DialogContentText>
              {/* <Grid container spacing={2}> */}
              <b style={{ color: "#00000080" }}>Driver Name:&nbsp;{drive}</b>
              {/* <Grid item lg={12} xs={12}>
                    {editEArray.driver_name} */}
              {/* <Select onChange={(e) => {
                      setEditDriverReAssign((state) => ({
                        ...state,
                        "driver_id": e.target.value
                      }))
                      // setEditCArray((state) => ({
                      //   ...state,
                      //   "driver_id": e.target.value
                      // }))
                    }}
                      className={classes.styleO}
                    // value={selectedD ? assignDriv && assignDriv.driver_id : null}
                    // value={editCArray.driver_id}
                    >

                      <MenuItem value={editEArray.driver_id}>{editEArray.driver_name}</MenuItem>
                      {VDAMeta.data.length && VDAMeta.data.map((driver) => {
                        return (
                          <MenuItem value={driver[1]}>{driver[0]}</MenuItem>

                        )
                      }
                      )}
                    </Select> */}
              {/* </Grid>
              </Grid> */}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenEDriverDeActive(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                DeactiveE(assignID);
              }}
              color="secondary"
              autoFocus
            >
              Re-Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* Battery Active */}
        <Dialog
          fullScreen={fullScreen}
          open={openBAssign}
          maxWidth={"lg"}
          onClose={() => setOpenBAssign(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Battery Assignment"}
          </DialogTitle>
          <DialogContent style={{ height: '100px', width: '300px' }}>
            <DialogContentText>
              <Grid container spacing={2}>
                <b style={{ color: "#00000080" }}>Battery:</b>
                <Grid item lg={12} xs={12}>
                  <Select
                    onChange={(e) => {
                      setAssignBattery((state) => ({
                        ...state,
                        battery_id: e.target.value,
                      }));
                    }}
                    style={{ width: "100%" }}
                  >
                    <MenuItem value="">Select</MenuItem>
                    {BAMeta.data.length &&
                      BAMeta.data.map((battt) => {
                        return <MenuItem value={battt[1]}>{battt[0]}</MenuItem>;
                      })}
                  </Select>
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenBAssign(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                assignBatteryy();
              }}
              color="secondary"
              autoFocus
            >
              Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* Battery De-Active */}
        <Dialog
          fullScreen={fullScreen}
          open={openBReAssign}
          maxWidth={"lg"}
          onClose={() => setOpenBReAssign(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Battery Reassignment"}
          </DialogTitle>
          <DialogContent style={{ height: '100px', width: '300px' }}><br />
            <DialogContentText>
              {/* <Grid container spacing={2}> */}
              <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>Battery:&nbsp;{ddd1}</b>
              {/* <Grid item lg={12} xs={12}>
                    {editCArray.serial_number}
                  {/* <Select
                      onChange={(e) => {
                        setEditBReAssign((state) => ({
                          ...state,
                          "battery_id": e.target.value
                        }))
                      }}
                      // onChange={(e) => { setBAEditFormArray(e, 'battery_id') }}
                      size="small" id="outlined"
                      value={editBReAssign.battery_id}
                      className={classes.styleO}
                    // value={editCArray.battery_id }
                    >

                      <MenuItem value={editCArray.battery_id}>{editCArray.serial_number}</MenuItem>
                      {BAMeta.data.length && BAMeta.data.map((battt) => {
                        return (
                          <MenuItem value={battt[1]}>{battt[0]}</MenuItem>

                        )
                      }
                      )}
                    </Select> 
                </Grid> */}
              {/* </Grid> */}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenBReAssign(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                DeactiveB(vehBatID);
              }}
              color="secondary"
              autoFocus
            >
              Re-Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* Delete Vehicle */}
        <Dialog
          fullScreen={fullScreen}
          open={delete1}
          maxWidth={"lg"}
          onClose={() => setDelete1(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">{"Offboarding Vehicle"}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                <Grid item lg={12} xs={12}>
                  <TextField style={{
                    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
                    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
                  }}
                    onChange={(e) => { setPassword1(e.target.value) }}
                  />

                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setDelete1(false)}
              color="primary">
              Cancel
            </Button>
            <Button
              disabled={password1 !== pWord}
              onClick={() => {
                deleteVehicle(selectedId1);
              }}
              color="secondary">
              Offboarding
            </Button>
          </DialogActions>
        </Dialog>

        {/* Delete Model */}
        <Dialog
          fullScreen={fullScreen}
          open={delete2}
          maxWidth={"lg"}
          onClose={() => setDelete2(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">{"Offboarding Vehicle Model"}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: '#00000070' }}>Password</b>
                <Grid item lg={12} xs={12}>
                  <TextField style={{
                    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
                    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
                  }}
                    onChange={(e) => { setPassword2(e.target.value) }}
                  />

                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setDelete2(false)}
              color="primary">
              Cancel
            </Button>
            <Button
              disabled={password2 !== pWord}
              onClick={() => {
                deleteVM(selectedId2);
              }}
              color="secondary">
              Offboarding
            </Button>
          </DialogActions>
        </Dialog>
        {/* Telematics Assignment */}
        <Dialog
          fullScreen={fullScreen}
          open={openTele}
          maxWidth={"lg"}
          onClose={() => setOpenTele(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">{"Telematics Assignment"}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>Telematics Imei:</b>
                <Grid item lg={12} xs={12}>
                  <Select
                    onChange={(e) => {
                      setAssignTele((state) => ({
                        ...state,
                        telematics_id: e.target.value,
                      }));
                    }}
                    style={{
                      width: "100%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
                    }}
                  >
                    <MenuItem value="">Select IMEI</MenuItem>
                    {getImei.length &&
                      getImei.map((imeiD) => {
                        return (
                          <MenuItem value={imeiD.telematics_id}>{imeiD.imei}</MenuItem>
                        );
                      })}
                  </Select>
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setOpenTele(false)}
              color="primary">
              Cancel
            </Button>
            <Button
              onClick={() => {
                AssignTelematics();
              }}
              color="secondary">
              Assign
            </Button>
          </DialogActions>
        </Dialog>
        {/* Telematics De-Active */}
        <Dialog
          fullScreen={fullScreen}
          open={openTeleD}
          maxWidth={"lg"}
          onClose={() => setOpenTeleD(false)}
          aria-labelledby="responsive-dialog-title"
          style={{ marginLeft: '650px' }}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Telematics Reassignment"}
          </DialogTitle>
          <DialogContent style={{ height: '100px', width: '300px' }}><br />
            <DialogContentText>
              <b style={{ fontFamily: 'Maven Pro', fontSize: '14px', fontWeight: 600, color: "#00000080" }}>
                IMEI:&nbsp;{selectedImei}</b>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenTeleD(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                ReassignImei(assetLink)
              }}
              color="secondary"
              autoFocus
            >
              Re-Assign
            </Button>
          </DialogActions>
        </Dialog>
      </>
    </div>
  );

  // } else {
  //   return (<Loading
  //   />)
  // }
}
