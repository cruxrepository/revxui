import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import PropTypes from "prop-types";
import LinearProgress from "@material-ui/core/LinearProgress";
import Chip from "@material-ui/core/Chip";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "@material-ui/core/Button";
import Chart1 from "./Chart1";
import Chart2 from "./Chart2";
import Chart3 from "./Chart3";
import Chart4 from "./Chart4";
import Select from "@material-ui/core/Select";
import Tooltip from "@material-ui/core/Tooltip";
import NotificationImportantIcon from "@material-ui/icons/NotificationImportant";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import { useSelector, useDispatch } from 'react-redux';
import { CrudTable, Notification } from 'enl-components';
// import makeAPICall from "../../reducers/batteryActions";
// import { getAllEBatteries } from '../../../actions/asyncActions';
// import getCBattery from "../../../api/batteryPage/getCBattery"
import Icon from "@material-ui/core/Icon";
import endpoints from "../../../endpoints/endpoints";
import SimpleMap from "./BasicMap";
import CustomToolbar from "./CustomToobar";
import AddVehicle from "./AddVehicle";
const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  graphText: {
    fontSize: 12,
    position: "absolute",
    transform: "rotate(270deg)",
    left: "-40px",
    top: 370,
    color: "primary",
    fontWeight: 600,
  },
  graphSelect: {
    minWidth: 150,
    left: "20em",
    marginBottom: 20,
  },
  tabsSection: {
    [theme.breakpoints.up("lg")]: {
      // borderRadius:0,position:'sticky',top:0 ,width:500
      borderRadius: 0,
      position: "sticky",
      top: 0,
      width: 500,
    },
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
}));

/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function VehicleContent() {
  // const batteryArr = makeAPICall();

  const [fetchedData, setFetchedData] = React.useState([]);
  //const [batteryEReady, setbatteryEReady] = React.useState([]);

  let VehicleDetails = [];
  React.useEffect(() => {
    const getVehicleUrl = endpoints.baseUrl + `/battery?type=ebattery`;
    let allDetails = [];
    axios
      .get(getVehicleUrl)
      .then((response) => {
        allDetails = response.data.data;

        allDetails.map((en) => {
          let allData = [];

          allData.push(en.model_info);
          allData.push("12");
          allData.push(en.driver_name);
          // allData.push(en.vehicle_number)
          allData.push(en.soc);
          allData.push(en.current_state);
          allData.push(en.is_warning);
          allData.push("assign");
          allData.push(en.payment);
          allData.push(en.status);
          VehicleDetails.push(allData);
          // const payload_data = {
          //   status: response.status,
          //   data: response.data,
          // };
          //   dispatch({
          //     type: "GET_ALL_ATTRIBUTE_DATA_OVERVIEW_FULFILLED",
          //     payload: payload_data,
          //   });
        });
      })
      .catch((error) => {
        let status = null;
        let data = null;
        //If no response from server
        if (!error.response) {
          status = 500;
          data = "No response from server";
        } else {
          status = error.response.status;
          data = error.response.data;
        }
        // dispatch({
        //   type: "GET_ALL_ATTRIBUTE_DATA_OVERVIEW_FAILED",
        //   payload: { status, data },
        // });
      });

    setFetchedData(VehicleDetails);
  }, [value, screen, frame]);




  const theme = useTheme();
  const classes = useStyles();
  const [screen, setScreen] = React.useState(false);
  const [value, setValue] = React.useState(0);

  const dayDropdown = [
    { val: "day", name: "Day" },
    { val: "month", name: "Month" },
    { val: "year", name: "Year" },
    { val: "custom", name: "Custom" },
  ];
  const LightTooltip = styled(Tooltip)(({ theme }) => ({
    tooltip: {
      backgroundColor: theme.palette.common.white,
      color: "rgba(0, 0, 0, 0.87)",
      boxShadow: theme.shadows[1],
      fontSize: 20,
    },
    arrow: {
      arrow: {
        color: "#fff",
      },
    },
  }));

  const VehicleColumn = [
    {
      name: "Vehicle Number",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography
            //onClick={() => setScreen(true)}
            style={{ color: "#000000", cursor: "pointer" }}
            variant="subtitle2"
          >
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Owner Name",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
        ),
      },
    },
    {
      name: "Type of Vehicle",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "SOC/Km Left",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography variant="subtitle2" color="secondary">
              {value}
            </Typography>
          );
        },
      },
    },

    {
      name: "Action Button",
      options: {
        filter: true,
        customBodyRender: (value) => {
          if (value === "assign") {
            return (
              <Select
                style={{ minWidth: 150, color: "#FFC130" }}
                value="assign"
              >
                <MenuItem style={{ color: "red !important" }} value="deactive">
                  Deactivate
                </MenuItem>
                <MenuItem
                  style={{ color: "#FFC130 !important" }}
                  value="assign"
                >
                  Assign
                </MenuItem>
              </Select>
            );
          } else {
            return (
              <Select style={{ minWidth: 150, color: "red" }} value="deactive">
                <MenuItem style={{ color: "red !important" }} value="deactive">
                  Deactivate
                </MenuItem>
                <MenuItem
                  style={{ color: "#FFC130 !important" }}
                  value="assign"
                >
                  Assign
                </MenuItem>
              </Select>
            );
          }
        },
      },
    },
    {
      name: "Status",
      options: {
        filter: true,
        customBodyRender: (value) => {
          if (value === "unhealthy") {
            return (
              <Button
                variant="contained"
                style={{ minWidth: 130, background: "#FFC130", color: "white" }}
              >
                {value}
              </Button>
            );
          } else {
            return (
              <Button
                variant="contained"
                style={{ minWidth: 130, background: "#68A724", color: "white" }}
              >
                {value}
              </Button>
            );
          }
        },
      },
    },
  ];

  const data = [
    [
      "TN 12 C1234",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    ["TN 12 u4234", " Aiden Lloyd", "2 W", "56 KM Left", "deactive", "healthy"],
    [
      "TN 12 I1489",
      " Jaden Collins ",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    ["TN 12 M1598", "Franky Rees", "2 W", "56 KM Left", "Assign", "unhealthy"],
    ["TN 12 V3698", "Aaren Rose", "2 W", "56 KM Left", "deactive", "healthy"],
    [
      "TN 12 V1789",
      " Blake Duncan",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    [
      "TN 12 A2589",
      " Frankie Parry",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    ["TN 12 D5896", " Lane Wilson", "2 W", "56 KM Left", "deactive", "healthy"],
    [
      "TN 12 C1234",
      " Robin Duncan",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    [
      "TN 12 C1234",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    [
      "TN 12 u4234",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    [
      "TN 12 I1489",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "unhealthy",
    ],
    [
      "TN 12 M1598",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    [
      "TN 12 V3698",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    [
      "TN 12 V1789",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    [
      "TN 12 A2589",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    [
      "TN 12 D5896",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "unhealthy",
    ],
    [
      "TN 12 C1234",
      " Gabby George",
      "2 W",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
  ];

  const options = {
    filterType: "dropdown",
    responsive: "vertical",
    rowsPerPage: 10,
    page: 0,
    selectableRows: "none",
    customToolbar: () => {
      return <CustomToolbar/>
    },
  };
  const [chartOneVal, setChartOneVal] = React.useState("day");
  const handleChartOneVal = (e) => {
    setChartOneVal(e.target.value);
  };
  const Header = () => {};

  const [frame, setFrame] = React.useState(false);
  // const addEmptyRow = useDispatch();
  // const dataTable = useSelector(state => state.crudTableDemo.dataTable);

  return (
    <div onMouseEnter={() => setFrame(true)} className={classes.table}>
      <Paper square className={classes.root} />
      {screen !== true ? (
        <MUIDataTable
          checkboxSelection={false}
          title="Vehicle"
          data={data}
          addRow={(payload) => addEmptyRow(addAction(payload, branch))}
          columns={VehicleColumn}
          options={options}
          selectableRows={1}
          selectableRowsHideCheckboxes
          //onRowClick={window.alert('hi')}
          // onCellClick={window.alert('hi')} 
        />
      ) : (
        <>
          <Grid container spacing={2} style={{ marginTop: 40 }}>
            <Grid item xs>
              <Grid item xs>
                <h1>Location</h1>
              </Grid>
              <Grid item xs>
                <Select className={classes.graphSelect} value="day">
                  {dayDropdown.map((m) => {
                    return <MenuItem value={m.val}>{m.name}</MenuItem>;
                  })}
                </Select>
                <Chart2 />
              </Grid>
            </Grid>
            <Grid xs item>
              <Grid item xs>
                <h1>Battery</h1>
              </Grid>

              <Grid item xs>
                <Select className={classes.graphSelect} value="day">
                  {dayDropdown.map((m) => {
                    return <MenuItem value={m.val}>{m.name}</MenuItem>;
                  })}
                </Select>
                <Chart4 />
              </Grid>
            </Grid>
          </Grid>
          <Grid container spacing={4} style={{ marginTop: 30 }}>
            <Grid item xs>
              <td>
                <h1>Battery ID</h1>
              </td>
            </Grid>
            <Grid item xs>
              <td>
                <h1>Motor ID</h1>
              </td>
            </Grid>
            <Grid item xs>
              <h1>Charger ID</h1>
            </Grid>
            <Grid item xs>
              <h1>Telematics ID</h1>
            </Grid>
          </Grid>
        </>
      )}

      <br />
      <Typography align="center" className={classes.copyRight}>
        Copyright© 2023 ReVx Energy Pvt.Ltd.
      </Typography>
    </div>
  );
}
