import React, { useState } from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import ListItemText from "@material-ui/core/ListItemText";
import InputLabel from "@material-ui/core/InputLabel";
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import Tooltip from "@material-ui/core/Tooltip";
import useMediaQuery from '@material-ui/core/useMediaQuery';

import Grid from "@material-ui/core/Grid";
import IconButton from "@material-ui/core/IconButton";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
// import makeAPICall from "../../reducers/batteryActions";
// import { getAllEBatteries } from '../../../actions/asyncActions';
// import getCBattery from "../../../api/batteryPage/getCBattery"
import { Icon } from "@iconify/react";
import endpoints from "../../../endpoints/endpoints";
// import CustomToolbar from "./CustomToobar";
import TabIcon from "@material-ui/icons/Tab";
import AirportShuttleIcon from "@material-ui/icons/AirportShuttle";
import FormControl from "@material-ui/core/FormControl";

import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Pagination from "@material-ui/lab/Pagination";
import Checkbox from "@material-ui/core/Checkbox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import FormControlLabel from "@material-ui/core/FormControlLabel";

import TextField from "@material-ui/core/TextField";
import DateFnsUtils from "@date-io/date-fns";

import { useDispatch, useSelector } from "react-redux";
import {
  getCommVBulk,
  getErickVBulk,
  getCVBulk,
  getEVBulk,
  getVMBulk,
  getIVBulk,
  getOMBulk,
  getFleetBulk,
  getVDABulk,
  getTelematicsBulk,
  getVModelBulk,
  getBABulk,
  getCVLBulk,
  getEVLBulk
} from "../../../redux/actions/asyncActions";
import Loading from "../../../components/Loading";
import ErrorWrap from "../../../components/Error/ErrorWrap";
import SimpleSnackbar from "../Users/SimpleSnackbar";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  dialog: {
    // '.MuiPaper-root.MuiDialog-paper':  { marginLeft: '550px !important'}
    position: 'relative', marginLeft: '680px'
  },
  tabsSection: {
    [theme.breakpoints.up("lg")]: {
      // borderRadius:0,position:'sticky',top:0 ,width:500
      borderRadius: 0,
      position: "sticky",
      top: 0,
      width: 500,
    },
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },

  textField: {
    flexBasis: 200,
  },
  // divStyle: {
  //   width: "500px",
  // },
  // screensize: {},
  // modelIcon: {
  //   "&:hover": {
  //     color: "#9ccc65",
  //   },
  //   transform: "translateX(-10em)",
  // },
  styleL: {
    fontSize: "15px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#A7A7A7",
  },
  styleM: {
    //width: "100%",
    borderRadius: "9px",
    marginBottom: "10px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#7A7A7D  !important",
    },
  },
  styleN: {
    ".MuiPaper-root": { width: "80% !important", marginLeft: "60px" },
  },
  styleO: {
    width: "90%",
    color: "#7A7A7D",
    borderRadius: "9px",
    //paddingBottom: "10px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#C4C4C4  !important",
    },
    "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
  },
  styleE: {
    padding: "8px",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  "& input": {
    color: theme.palette.text.primary,
    background: "transparent",
    width: "100%",
    height: "100%",
    margin: 0,
    padding: "2px 20px 2px 2px",
    boxSizing: "border-box",
    border: "none",
    boxShadow: "none",
    outline: "none",
    fontSize: "15px",
  },

  //CSS For Textfield

  dialogPaper: {
    height: "85%",
    width: "50%",
    marginLeft: "700px",
  },
  divStyle: {
    width: "500px",
  },
  // screensize: {},
  // modelIcon: {
  //   "&:hover": {
  //     color: "#9ccc65",
  //   },
  //   transform: "translateX(-10em)",
  // },
  secondaryTextG: {
    fontFamily: "Maven Pro",
    fontSize: "16px",
    fontWeight: 600,
    color: "#68A724",
    width: "100%",
  },
}));

/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function VehicleContent() {

  const CVVData = useSelector((store) => store.commV)
  const CVVDataRaw = useSelector((store) => store.commV.rawData)
  let CVVMeta = useSelector((store) => store.commV)
  let CVVFetching = useSelector((store) => store.commV.fetching)
  let CVVResponsecode = useSelector((store) => store.commV.responseStatus)
  let CVVMetaPresent = useSelector((store) => store.commV.dataPresent)

  const EVVData = useSelector((store) => store.erickV)
  const EVVDataRaw = useSelector((store) => store.erickV.rawData)
  let EVVMeta = useSelector((store) => store.erickV)
  let EVVFetching = useSelector((store) => store.erickV.fetching)
  let EVVResponsecode = useSelector((store) => store.erickV.responseStatus)
  let EVVMetaPresent = useSelector((store) => store.erickV.dataPresent)


  const theme = useTheme();
  const [openCVehicle, setOpenCVehicle] = React.useState(false);
  const [openCVEdit, setOpenCVEdit] = React.useState(false);

  const [openEVehicle, setOpenEVehicle] = React.useState(false);
  const [openEVEdit, setOpenEVEdit] = React.useState(false);

  const [openVM, setOpenVM] = React.useState(false);
  const [openVMEdit, setOpenVMEdit] = React.useState(false);

  const [openDriverDeActive, setOpenDriverDeActive] = React.useState(false);
  const [openDriverActive, setOpenDriverActive] = React.useState(false);

  const [openEDriverDeActive, setOpenEDriverDeActive] = React.useState(false);
  const [openEDriverActive, setOpenEDriverActive] = React.useState(false);

  const [openBAssign, setOpenBAssign] = React.useState(false);
  const [openBReAssign, setOpenBReAssign] = React.useState(false);

  const [openRC, setOpenRC] = React.useState(false);
  const [openIns, setOpenIns] = React.useState(false);
  const [openPermit, setOpenPermit] = React.useState(false);
  const [openERC, setOpenERC] = React.useState(false);
  const [openEIns, setOpenEIns] = React.useState(false);
  const [openEPermit, setOpenEPermit] = React.useState(false);
  const [openRef, setOpenRef] = React.useState(false);
  const [openData, setOpenData] = React.useState(false);

  const [vehBatID, setVehBatID] = React.useState(0);
  const [assignID, setAssignID] = React.useState(0);

  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false);

  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000);
  const [addResponse, setAddResponce] = React.useState("");
  const [page, setPage] = React.useState(1);
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const [file, setFile] = React.useState();

  function handleChangeRC(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setCVAddForm((state) => ({ ...state, upload_rc_book: response.data }));
    });
  }

  function handleChangeIns(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setCVAddForm((state) => ({ ...state, upload_insurance: response.data }));
    });
  }

  function handleChangePermit(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setCVAddForm((state) => ({
        ...state,
        upload_permit_image: response.data,
      }));
    });
  }

  function handleChangeERC(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEVAddForm((state) => ({ ...state, upload_rc_book: response.data }));
    });
  }

  function handleChangeEIns(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEVAddForm((state) => ({ ...state, upload_insurance: response.data }));
    });
  }

  function handleChangeEPermit(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEVAddForm((state) => ({
        ...state,
        upload_permit_image: response.data,
      }));
    });
  }

  function handleChangeRef(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setAddVMForm((state) => ({ ...state, reference_Image: response.data }));
    });
  }
  function handleChangeDataSheet(event) {
    setFile(event.target.files[0]);

    event.preventDefault();
    const url = endpoints.baseUrl + "/upload";
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("fileName", event.target.files[0].name);
    const config = {
      headers: {
        "content-type": "multipart/form-data",
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setAddVMForm((state) => ({ ...state, datasheet: response.data }));
    });
  }

  const changePage = (event, newValue) => {
    setPage(newValue);
  };

  const logged_user = useSelector((store) => store.login.result);
  let enty = logged_user.entity_id;
  let enty1 = logged_user.entity_id === "1";
  let uName = logged_user.username;
  let roid = logged_user.role_id;
  let vehicleEditAccess = logged_user.vehicle === "edit";
  let pWord = logged_user.password

  const CVData = useSelector((store) => store.cvAll);
  const CVDataRaw = useSelector((store) => store.cvAll.rawData);
  const CVMeta = {};
  CVMeta.data = [];
  const CVMetaa = useSelector((store) => store.cvAll);
  if (CVMetaa.data.length >= 1) {
    CVMeta.data = CVMetaa.data;
  }
  const MyCVPage = useSelector((store) => store.cvAll.page_number);
  const MyCVCount = Math.ceil(
    useSelector((store) => store.cvAll.total_records) / 10
  );
  let CVFetching = useSelector((store) => store.cvAll.fetching);
  let CVResponsecode = useSelector((store) => store.cvAll.responseStatus);
  const CVMetaPresent = useSelector((store) => store.cvAll.dataPresent);
  // console.log("CVMetaa.data",CVMetaa.data)


  const CVLData = useSelector((store) => store.cvTotal);
  const CVLDataRaw = useSelector((store) => store.cvTotal.rawData);
  const CVLMeta = {};
  CVLMeta.data = [];
  const CVLMetaa = useSelector((store) => store.cvTotal);
  if (CVLMetaa.data.length >= 1) {
    CVLMeta.data = CVLMetaa.data;
  }
  let CVLFetching = useSelector((store) => store.cvTotal.fetching);
  let CVLResponsecode = useSelector((store) => store.cvTotal.responseStatus);
  const CVLMetaPresent = useSelector((store) => store.cvTotal.dataPresent);

  let VehicleNumber = CVLMeta.data.map(function (el) { return el[0]; });
  let VehicleType = CVLMeta.data.map(function (el) { return el[1]; });
  let VehicleStatus = CVLMeta.data.map(function (el) { return el[2]; });
  let VehicleInvestor = CVLMeta.data.map(function (el) { return el[3]; });
  let VehicleDriver = CVLMeta.data.map(function (el) { return el[4]; });
  let VehicleBattery = CVLMeta.data.map(function (el) { return el[5]; });
  let VehicleDistance = CVLMeta.data.map(function (el) { return el[6]; });
  let VehicleBatteryStatus = CVLMeta.data.map(function (el) { return el[7]; });
  let VehicleDriverStatus = CVLMeta.data.map(function (el) { return el[8]; });
  let VehicleModelInfo = CVLMeta.data.map(function (el) { return el[9]; });
  let VehicleChassisNumber = CVLMeta.data.map(function (el) { return el[10]; });
  let VehicleEngineNumber = CVLMeta.data.map(function (el) { return el[11]; });
  let VehicleFleet = CVLMeta.data.map(function (el) { return el[12]; });
  let VehicleOperationalManager = CVLMeta.data.map(function (el) { return el[13]; });
  // console.log('VehicleManufacturing',VehicleManufacturing);

  //Erick 
  const EVData = useSelector((store) => store.evAll);
  const EVDataRaw = useSelector((store) => store.evAll.rawData);
  let EVMeta = useSelector((store) => store.evAll);
  const MyEVPage = useSelector((store) => store.evAll.page_number);
  const MyEVCount = Math.ceil(
    useSelector((store) => store.evAll.total_records) / 10
  );
  let EVFetching = useSelector((store) => store.evAll.fetching);
  let EVResponsecode = useSelector((store) => store.evAll.responseStatus);
  let EVMetaPresent = useSelector((store) => store.evAll.dataPresent);


  const EVLData = useSelector((store) => store.evTotal);
  const EVLDataRaw = useSelector((store) => store.evTotal.rawData);
  const EVLMeta = {};
  EVLMeta.data = [];
  const EVLMetaa = useSelector((store) => store.evTotal);
  if (EVLMetaa.data.length >= 1) {
    EVLMeta.data = EVLMetaa.data;
  }
  let EVLFetching = useSelector((store) => store.evTotal.fetching);
  let EVLResponsecode = useSelector((store) => store.evTotal.responseStatus);
  let EVLMetaPresent = useSelector((store) => store.evTotal.dataPresent);

  let EVehicleNumber = EVLMeta.data.map(function (el) { return el[0]; });
  let EVehicleInvestor = EVLMeta.data.map(function (el) { return el[1]; });
  let EVehicleSOC = EVLMeta.data.map(function (el) { return el[2]; });
  let EVehicleModel = EVLMeta.data.map(function (el) { return el[3]; });
  let EVehicleChassis = EVLMeta.data.map(function (el) { return el[4]; });
  let EVehicleEngine = EVLMeta.data.map(function (el) { return el[5]; });
  let EVehicleFleet = EVLMeta.data.map(function (el) { return el[6]; });
  let EVehicleOperationalManager = EVLMeta.data.map(function (el) { return el[7]; });
  let EVehicleType = EVLMeta.data.map(function (el) { return el[8]; });
  let EVehicleStatus = EVLMeta.data.map(function (el) { return el[9]; });
  let EVehicleDriverStatus = EVLMeta.data.map(function (el) { return el[10]; });
  let EVehicleDriver = EVLMeta.data.map(function (el) { return el[11]; });
  let EVehicleDistance = EVLMeta.data.map(function (el) { return el[12]; });
  // console.log('EVehicleDistance', EVehicleDistance);

  //Model
  const VMData = useSelector((store) => store.vmAll);
  const VMDataRaw = useSelector((store) => store.vmAll.rawData);
  let VMMeta = useSelector((store) => store.vmAll);
  const MyVMPage = useSelector((store) => store.vmAll.page_number);
  const MyVMCount = Math.ceil(
    useSelector((store) => store.vmAll.total_records) / 10
  );
  let VMFetching = useSelector((store) => store.vmAll.fetching);
  let VMResponsecode = useSelector((store) => store.vmAll.responseStatus);
  let VMMetaPresent = useSelector((store) => store.vmAll.dataPresent);

  // Investor
  const IVData = useSelector((store) => store.ivAll);
  // console.log('hi')
  const IVDataRaw = useSelector((store) => store.ivAll.rawData);
  let IVMeta = useSelector((store) => store.ivAll);
  let IVFetching = useSelector((store) => store.ivAll.fetching);
  let IVResponsecode = useSelector((store) => store.ivAll.responseStatus);
  let IVMetaPresent = useSelector((store) => store.ivAll.dataPresent);

  //  Operation
  const OMData = useSelector((store) => store.omAll);
  const OMDataRaw = useSelector((store) => store.omAll.rawData);
  let OMMeta = useSelector((store) => store.omAll);
  // console.log("OMMeta",OMDataRaw);
  let OMFetching = useSelector((store) => store.omAll.fetching);
  let OMResponsecode = useSelector((store) => store.omAll.responseStatus);
  let OMMetaPresent = useSelector((store) => store.omAll.dataPresent);

  //Fleet
  const FleetData = useSelector((store) => store.fleetAll);
  const FleetDataRaw = useSelector((store) => store.fleetAll.rawData);

  let FleetMeta = useSelector((store) => store.fleetAll);
  let FleetFetching = useSelector((store) => store.fleetAll.fetching);
  let FleetResponsecode = useSelector((store) => store.fleetAll.responseStatus);
  let FleetMetaPresent = useSelector((store) => store.fleetAll.dataPresent);

  //Driver Assign
  const VDAData = useSelector((store) => store.vdaAll);
  const VDADataRaw = useSelector((store) => store.vdaAll.rawData);
  let VDAMeta = useSelector((store) => store.vdaAll);
  let VDAFetching = useSelector((store) => store.vdaAll.fetching);
  let VDAResponsecode = useSelector((store) => store.vdaAll.responseStatus);
  let VDAMetaPresent = useSelector((store) => store.vdaAll.dataPresent);

  const BAData = useSelector((store) => store.bAAll);
  const BADataRaw = useSelector((store) => store.bAAll.rawData);
  let BAMeta = useSelector((store) => store.bAAll);
  let BAFetching = useSelector((store) => store.bAAll.fetching);
  let BAResponsecode = useSelector((store) => store.bAAll.responseStatus);
  let BAMetaPresent = useSelector((store) => store.bAAll.dataPresent);

  const VModelData = useSelector((store) => store.vModel);
  const VModelDataRaw = useSelector((store) => store.vModel.rawData);
  let VModelMeta = useSelector((store) => store.vModel);
  let VModelFetching = useSelector((store) => store.vModel.fetching);
  let VModelResponsecode = useSelector((store) => store.vModel.responseStatus);
  let VModelMetaPresent = useSelector((store) => store.vModel.dataPresent);

  //Telematics
  const TelematicsData = useSelector((store) => store.telematicsAll);
  const TelematicsDataRaw = useSelector((store) => store.telematicsAll.rawData);
  let TelematicsMeta = {};
  TelematicsMeta.data = [];
  let TelematicsMetaa = useSelector((store) => store.telematicsAll);
  if (TelematicsMetaa.data.length >= 1) {
    TelematicsMeta.data = TelematicsMetaa.data;
  }
  let TelematicsFetching = useSelector((store) => store.telematicsAll.fetching);
  let TelematicsResponsecode = useSelector(
    (store) => store.telematicsAll.responseStatus
  );
  let TelematicsMetaPresent = useSelector(
    (store) => store.telematicsAll.dataPresent
  );

  const dispatch = useDispatch();

  const [modelPage, setModelPage] = React.useState(1);
  const changePageBatModel = (event, newValue) => {
    setModelPage(newValue);
  };
  const [pageCV, setPageCV] = React.useState(1);
  const changePageCV = (event, newValue) => {
    setPageCV(newValue);
  };
  const [pageEV, setPageEV] = React.useState(1);
  const changePageEV = (event, newValue) => {
    setPageEV(newValue);
  };
  //   React.useEffect(() => {
  //     if (dataOn === true) {
  //       dispatch(getCVBulk(enty));
  //     } else {
  //       dispatch(getCVBulk(enty, pageCV));
  //     }

  // }, [CVMetaPresent]);
  React.useEffect(() => {
    dispatch(getCVBulk(enty, pageCV));
    dispatch(getVMBulk(modelPage));
    dispatch(getIVBulk(enty));
    dispatch(getCVLBulk(enty));
    dispatch(getEVLBulk(enty));
    dispatch(getOMBulk(enty));
    dispatch(getFleetBulk());
    dispatch(getVDABulk(enty));
    dispatch(getTelematicsBulk(page));
    dispatch(getVModelBulk());
    dispatch(getBABulk());
  }, [
    dispatch,
    EVLMetaPresent,
    CVMetaPresent,
    CVVMetaPresent,
    EVVMetaPresent,
    CVLMetaPresent,
    pageCV,
    VMMetaPresent,
    modelPage,
    FleetMetaPresent,
    IVMetaPresent,
    OMMetaPresent,
    VDAMetaPresent,
    TelematicsMetaPresent,
    page,
    VModelMetaPresent,
    BAMetaPresent,
  ]);
  React.useEffect(() => {
    dispatch(getEVBulk(enty, pageEV));
  }, [dispatch, EVMetaPresent, pageEV]);

  let allVM = VMMeta.data;
  let modelList = VModelMeta.data;
  let allTele = TelematicsMeta.data;
  // let allOM = OMMeta.data
  const validateKeyData = (key) => {
    return key ? key : "-";
  };

  const [dataOn, setDataOn] = React.useState(false);

  const classes = useStyles();
  const [value, setValue] = React.useState(0);

  const [password1, setPassword1] = React.useState("");
  const [password2, setPassword2] = React.useState("");
  const [delete1, setDelete1] = React.useState("");
  const [delete2, setDelete2] = React.useState("");
  const [selectedId1, setSelectedId1] = React.useState("");
  const [selectedId2, setSelectedId2] = React.useState("");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const options = {
    filter: true,
    search: true,
    responsive: "vertical",
    print: false,
    rowsPerPage: 100,
    downloadCsv: true,
    selectableRows: "none",
    onDownload: (buildHead, buildBody, columns, data) => {
      buildHead = () => {
        return ["Vehicle Number", "Vehicle Type", "Investor", "Driver Name", "Battery", "Distance to Empty"]
      }
      buildBody = () => {
        let allRows = []

        data.map((col) => {
          let newRow = [];
          newRow.push(col.data[0])
          newRow.push(col.data[1]['type'])
          newRow.push(col.data[2])
          newRow.push(col.data[3])
          newRow.push(col.data[4])
          newRow.push(col.data[5])
          allRows.push("\n" + newRow)
        })

        return allRows;
      }
      return "\uFEFF" + buildHead() + buildBody();
    },
    customToolbar: () => {
      if (vehicleEditAccess === true)
        return (<Tooltip style={{ flex: "left" }} title={"Onboarding Vehicle"}>
          <IconButton
            style={{ transform: "translateX(-10em)" }}
            onClick={() => {
              setOpenCVehicle(true);
            }}
          >
            <AirportShuttleIcon />
          </IconButton>
        </Tooltip>);
      else {
        return (null)
      }
    },
  };

  const options1 = {
    filterType: "dropdown",
    responsive: "vertical",
    search: true,
    print: false,
    page: 0,
    downloadCsv: true,
    selectableRows: "none",
    onDownload: (buildHead, buildBody, columns, data) => {
      buildHead = () => {
        return ["Vehicle Number", "Investor", "SOC/Km Left"]
      }
      buildBody = () => {
        let allRows = []

        data.map((col) => {
          let newRow = [];
          // console.log("col.data",col.data)
          newRow.push(col.data[0])
          newRow.push(col.data[1])
          newRow.push(col.data[2])
          allRows.push("\n" + newRow)
        })

        return allRows;
      }
      return "\uFEFF" + buildHead() + buildBody();
    },
    customToolbar: () => {
      if (vehicleEditAccess === true)
        return (
          <Tooltip style={{ flex: "left" }} title={"Onboarding E-Ricksaw"}>
            <IconButton
              style={{ transform: "translateX(-10em)" }}
              onClick={() => {
                setOpenEVehicle(true);
              }}
            >
              <Icon
                icon="material-symbols:electric-rickshaw"
                width="30"
                height="30"
              />
            </IconButton>
          </Tooltip>
        );
      else {
        return (null)
      }
    },
  };

  const options2 = {
    filterType: "dropdown",
    responsive: "vertical",
    print: false,
    search: true,
    page: 0,
    downloadCsv: true,
    selectableRows: "none",
    customToolbar: () => {
      if (vehicleEditAccess === true)
        return (
          <Tooltip style={{ flex: "left" }} title={"Onboarding Model"}>
            <IconButton
              style={{ transform: "translateX(-10em)" }}
              onClick={() => {
                setOpenVM(true);
              }}
            >
              <TabIcon />
            </IconButton>
          </Tooltip>
        );
      else {
        null;
      }
    },
  };
  const [chartOneVal, setChartOneVal] = React.useState("day");
  const handleChartOneVal = (e) => {
    setChartOneVal(e.target.value);
  };
  const Header = () => { };

  const [dataState, setDataState] = useState({
    vechiModel: "",
    vechiSeats: "",
    status: "",
    weight: "",
  });

  const [frame, setFrame] = React.useState(false);

  const [rowIndex, setRowIndex] = React.useState(0);

  const [clear1, setClear1] = React.useState([]);
  const [clear2, setClear2] = React.useState([]);
  const [clear3, setClear3] = React.useState([]);
  const [clear4, setClear4] = React.useState([]);
  const [clear5, setClear5] = React.useState([]);
  const [clear6, setClear6] = React.useState([]);
  const [clear7, setClear7] = React.useState([]);
  const [clear8, setClear8] = React.useState([]);
  const [clear9, setClear9] = React.useState([]);
  const [clear10, setClear10] = React.useState([]);
  const [clear11, setClear11] = React.useState([]);
  const [clear12, setClear12] = React.useState([]);
  const [clear13, setClear13] = React.useState([]);
  const [clear14, setClear14] = React.useState([]);

  const VehicleColumn = [
    {
      name: "Vehicle Number",
      options: {
        filter: true,
        display: 'true',
        filterType: 'custom',
        filterList: clear1,
        filterOptions: {
          logic: (vehicle_number, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleNumber.filter((item,
              index) => VehicleNumber.indexOf(item) === index);
            return (
              <>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: '-12px' }}><Typography>Filters</Typography>
                  <Button style={{ color: '#9ccc65', width: '100px' }}
                    onClick={() => {
                      setClear1([])
                      setClear2([])
                      setClear3([])
                      setClear4([])
                      setClear5([])
                      setClear6([])
                      setClear7([])
                      setClear8([])
                      setClear9([])
                      setClear10([])
                      setClear11([])
                      setClear12([])
                      setClear13([])
                      setClear14([])
                      dispatch(getCVBulk(enty, pageCV));
                    }}>RESET</Button></div>
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Vehicle Number</InputLabel>
                  <Select
                    multiple
                    value={clear1.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear1(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item}
                        onClick={() => {
                          setDataOn(true)
                          dispatch(getCommVBulk(enty));
                        }}
                      >
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl></>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ cursor: "pointer", textAlign: "center", fontSize:'0.875rem', fontWeight:400 }}
            color="secondary"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Type",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (value.type === "2W" && value.vehicle_status === "assign") {
            return (
              <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                <IconButton>
                  <Icon
                    icon="mdi:motorbike"
                    color="#4caf50"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (
            value.type === "E-Auto" &&
            value.vehicle_status === "assign"
          ) {
            return (
              <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                <IconButton>
                  <Icon
                    icon="fluent-emoji-high-contrast:auto-rickshaw"
                    color="#4caf50"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (
            value.type === "l5n" &&
            value.vehicle_status === "assign"
          ) {
            return (
              <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                <IconButton>
                  <Icon
                    icon="fa-solid:truck-pickup"
                    color="#4caf50"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (value.type === "2W" && value.vehicle_status === "unassign") {
            return (
              <Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                <IconButton>
                  <Icon
                    icon="mdi:motorbike"
                    color="#c4c4c4"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (value.type === "E-Auto" && value.vehicle_status === "unassign") {
            return (
              <Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                <IconButton>
                  <Icon
                    icon="fluent-emoji-high-contrast:auto-rickshaw"
                    color="#c4c4c4"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (value.type === "l5n" && value.vehicle_status === "unassign") {
            return (
              <Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                <IconButton>
                  <Icon
                    icon="fa-solid:truck-pickup"
                    color="#c4c4c4"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                <IconButton>
                  <Icon
                    icon="mdi:motorbike"
                    color="#c4c4c4"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </Tooltip>
            );
          }

          // <>

          // </>
        },
      },
    },
    {
      name: "Investor",
      options: {
        filter: true,
        filterList: clear2,
        display: 'true',
        filterType: 'custom',
        filterOptions: {
          logic: (investor, filters, row) => {
            if (filters.length) return !filters.includes(investor);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues1 = VehicleInvestor.filter((item,
              index) => VehicleInvestor.indexOf(item) === index);
            const optionValues = optionValues1.filter((str) => str !== '');
            return (
              <><br/> <FormControl>
              <InputLabel htmlFor="select-multiple-chip">Vehicle Investor</InputLabel>
              <Select
                multiple
                value={clear2.length === 0 ? [] : filterList[index]}
                renderValue={selected => selected.join(', ')}
                onChange={event => {
                  filterList[index] = event.target.value;
                  onChange(filterList[index], index, column);
                  setClear2(filterList[index], index, column);
                }}
              >
                {optionValues.map(item => (
                  <MenuItem key={item} value={item} onClick={() => {
                    setDataOn(true)
                    dispatch(getCommVBulk(enty));
                  }}>
                    <ListItemText primary={item} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl></>
             
            );
          }
        },
        customBodyRender: (value) => (
          <Typography variant="subtitle2" color="secondary">{validateKeyData(value)}</Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "Driver Name",
      options: {
        filter: true,
        display: 'true',
        filterList: clear3,
        filterType: 'custom',
        filterOptions: {
          logic: (driver_name, filters, row) => {
            if (filters.length) return !filters.includes(driver_name);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleDriver.filter((str) => str !== '');
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Driver Name</InputLabel>
                <Select
                  multiple
                  value={clear3.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear3(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },

        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2" color="secondary"
              style={{textAlign: "center" }}
            >
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Battery",
      options: {
        filter: true,
        display: 'true',
        filterList: clear4,
        filterType: 'custom',
        filterOptions: {
          logic: (serial_number, filters, row) => {
            if (filters.length) return !filters.includes(serial_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleBattery.filter((str) => str !== '');
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Battery Serial</InputLabel>
                <Select
                  multiple
                  value={clear4.length === 0 ? [] :filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear4(filterList[index], index, column);
}}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },


        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2" color="secondary"
              style={{textAlign: "center" }}
            >
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Distance to Empty",
      options: {
        filter: true,
        filterList: clear5,
        display: 'true',
        filterType: 'custom',
        filterOptions: {
          logic: (distance_to_empty, filters, row) => {
            if (filters.length) return !filters.includes(distance_to_empty);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleDistance.filter((str) => str !== '');
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Distance To Empty</InputLabel>
                <Select
                  multiple
                  value={clear5.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear5(filterList[index], index, column);
}}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },

        customBodyRender: (value) => {
          return (
            <Typography variant="subtitle2"  color="secondary" style={{ textAlign: "center" }}>
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Assignment Status",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverDeActive(true);
                    setCVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);

                    // setAssignDriv((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id
                    // }))
                    // setEditDriverReAssign((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id,
                    //   "assignment_id": value.assignment_id
                    // }))
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#4caf50"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);
                    // setBAEditArray(value.vehicle_battery_id);
                    // setAssignBattery((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id
                    // }))
                    // setEditBReAssign((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id,
                    //   "vehicle_battery_id": value.vehicle_battery_id
                    // }))
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#4caf50"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setDelete1(true);
                    setSelectedId1(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="ic:baseline-delete"
                    color="#FF000050"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "unassign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverDeActive(true);
                    setCVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);
                    // setAssignDriv((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id
                    // }))
                    // setEditDriverReAssign((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id,
                    //   "assignment_id": value.assignment_id
                    // }))
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#4caf50"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#c4c4c4"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setDelete1(true);
                    setSelectedId1(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="ic:baseline-delete"
                    color="#FF000050"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverActive(true);
                    setCVEditArray(value.vehicle_id);
                    setCVEditArray(value.vehicle_id);
                    setAssignDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBReAssign(true);
                    setCVEditArray(value.vehicle_id);
                    setVehBatID(value.vehicle_battery_id);

                    // setBAEditArray(value.vehicle_battery_id);
                    // setAssignBattery((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id
                    // }))
                    // setEditBReAssign((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id,
                    //   "vehicle_battery_id": value.vehicle_battery_id
                    // }))
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#4caf50"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setDelete1(true);
                    setSelectedId1(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="ic:baseline-delete"
                    color="#FF000050"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </>
            );
          } else {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenCVEdit(true);
                    setCVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenDriverActive(true);
                    setCVEditArray(value.vehicle_id);
                    setAssignDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenBAssign(true);
                    setAssignBattery((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                  }}
                >
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="26"
                    height="26"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setDelete1(true);
                    setSelectedId1(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="ic:baseline-delete"
                    color="#FF000050"
                    width="26"
                    height="26"
                  />
                </IconButton>
              </>
            );
          }
        },
      },
    },
    {
      name: "Vehicle Model",
      options: {
        filter: true,
        filterList: clear6,
        display: false,
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_model, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_model);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleModelInfo.filter((item,
              index) => VehicleModelInfo.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Model Info</InputLabel>
                <Select
                  multiple
                  value={clear6.length === 0 ? [] :filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear6(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"  color="secondary"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Chassis Number",
      options: {
        filter: true,
        filterList: clear7,
        display: false,
        filterType: 'custom',
        filterOptions: {
          logic: (chassis_number, filters, row) => {
            if (filters.length) return !filters.includes(chassis_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleChassisNumber.filter((item,
              index) => VehicleChassisNumber.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Chassis Number</InputLabel>
                <Select
                  multiple
                  value={clear7.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear7(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography  color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Engine Number",
      options: {
        filter: true,
        display: false,
        filterList: clear8,
        filterType: 'custom',
        filterOptions: {
          logic: (engine_number, filters, row) => {
            if (filters.length) return !filters.includes(engine_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleEngineNumber.filter((item,
              index) => VehicleEngineNumber.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Engine Number</InputLabel>
                <Select
                  multiple
                  value={clear8.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear8(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography  color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Fleet Name",
      options: {
        filter: true,
        display: false,
        filterList: clear9,
        filterType: 'custom',
        filterOptions: {
          logic: (fleet_name, filters, row) => {
            if (filters.length) return !filters.includes(fleet_name);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleFleet.filter((item,
              index) => VehicleFleet.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Fleet Name</InputLabel>
                <Select
                  multiple
                  value={clear9.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear9(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography  color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Operational Manager",
      options: {
        filter: true,
        display: false,
        filterList: clear10,
        filterType: 'custom',
        filterOptions: {
          logic: (operational_manager, filters, row) => {
            if (filters.length) return !filters.includes(operational_manager);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleOperationalManager.filter((item,
              index) => VehicleOperationalManager.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Operational Manager</InputLabel>
                <Select
                  multiple
                  value={clear10.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear10(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Type",
      options: {
        filter: true,
        display: false,
        filterList: clear11,
        filterType: 'custom',
        filterOptions: {
          logic: (type, filters, row) => {
            if (filters.length) return !filters.includes(type);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleType.filter((item,
              index) => VehicleType.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Type</InputLabel>
                <Select
                  multiple
                  value={clear11.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear11(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography  color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Battery Status",
      options: {
        filter: true,
        display: false,
        filterList: clear12,
        filterType: 'custom',
        filterOptions: {
          logic: (batteryassign_status, filters, row) => {
            if (filters.length) return !filters.includes(batteryassign_status);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleBatteryStatus.filter((item,
              index) => VehicleBatteryStatus.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Battery Status</InputLabel>
                <Select
                  multiple
                  value={clear12.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear12(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Driver Status",
      options: {
        filter: true,
        display: false,
        filterList: clear13,
        filterType: 'custom',
        filterOptions: {
          logic: (driver_status, filters, row) => {
            if (filters.length) return !filters.includes(driver_status);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleDriverStatus.filter((item,
              index) => VehicleDriverStatus.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Driver Status</InputLabel>
                <Select
                  multiple
                  value={clear13.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear13(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography  color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Status",
      options: {
        filter: true,
        display: false,
        filterList: clear14,
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_status, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_status);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleStatus.filter((item,
              index) => VehicleStatus.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Status</InputLabel>
                <Select
                  multiple
                  value={clear14.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear13(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
  ];
  const VehicleColumn1 = [
    {
      name: "Vehicle Number",
      options: {
        filter: true,
        filterList: clear1,
        display: 'true',
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_number, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleNumber.filter((item,
              index) => VehicleNumber.indexOf(item) === index);
            return (
                <>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: '-12px' }}><Typography>Filters</Typography>
                  <Button style={{ color: '#9ccc65', width: '100px' }}
                    onClick={() => {
                      setClear1([])
                      setClear2([])
                      setClear3([])
                      setClear4([])
                      setClear5([])
                      setClear6([])
                      setClear7([])
                      setClear8([])
                      setClear9([])
                      setClear10([])
                      setClear11([])
                      setClear12([])
                      setClear13([])
                      setClear14([])
                      dispatch(getCVBulk(enty, pageCV));
                    }}>RESET</Button></div>
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Number</InputLabel>
                <Select
                  multiple
                  value={clear1.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear1(filterList[index], index, column);
                }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl></>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Type",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (value.type === "2W" && value.vehicle_status === "assign") {
            return (
              <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                <IconButton>
                  <Icon
                    icon="mdi:motorbike"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (
            value.type === "E-Auto" &&
            value.vehicle_status === "assign"
          ) {
            return (
              <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                <IconButton>
                  <Icon
                    icon="fluent-emoji-high-contrast:auto-rickshaw"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (
            value.type === "l5n" &&
            value.vehicle_status === "assign"
          ) {
            return (
              <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                <IconButton>
                  <Icon
                    icon="fa-solid:truck-pickup"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (value.type === "2W" && value.vehicle_status === "unassign") {
            return (
              <Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                <IconButton>
                  <Icon
                    icon="mdi:motorbike"
                    color="#c4c4c4"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (value.type === "E-Auto" && value.vehicle_status === "unassign") {
            return (
              <Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                <IconButton>
                  <Icon
                    icon="fluent-emoji-high-contrast:auto-rickshaw"
                    color="#c4c4c4"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </Tooltip>
            );
          } else if (value.type === "l5n" && value.vehicle_status === "unassign") {
            return (
              <Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                <IconButton>
                  <Icon
                    icon="fa-solid:truck-pickup"
                    color="#c4c4c4"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </Tooltip>
            );
          } else {
            return (
              <Tooltip style={{ flex: "left" }} title={"Unassigned"}>
                <IconButton>
                  <Icon
                    icon="mdi:motorbike"
                    color="#c4c4c4"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </Tooltip>
            );
          }

          // <>

          // </>
        },
      },
    },
    {
      name: "Investor",
      options: {
        filter: true,
        display: 'true',
        filterList: clear2,
        filterType: 'custom',
        filterOptions: {
          logic: (investor, filters, row) => {
            if (filters.length) return !filters.includes(investor);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues1 = VehicleInvestor.filter((item,
              index) => VehicleInvestor.indexOf(item) === index);
            const optionValues = optionValues1.filter((str) => str !== '');
            return (
                <><br/>
                <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Investor</InputLabel>
                <Select
                  multiple
                  value={clear2.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear2(filterList[index], index, column);
                }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl></>
              
            );
          }
        },
        customBodyRender: (value) => (
          <Typography variant="subtitle2" color="secondary">{validateKeyData(value)}</Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "Driver Name",
      options: {
        filter: true,
        filterList: clear3,
        display: 'true',
        filterType: 'custom',
        filterOptions: {
          logic: (driver_name, filters, row) => {
            if (filters.length) return !filters.includes(driver_name);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleDriver.filter((str) => str !== '');
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Driver Name</InputLabel>
                <Select
                  multiple
                  value={clear3.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear3(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },


        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2" color="secondary"
              style={{ textAlign: "center" }}
            >
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Battery",
      options: {
        filter: true,
        display: 'true',
        filterList: clear4,
        filterType: 'custom',
        filterOptions: {
          logic: (serial_number, filters, row) => {
            if (filters.length) return !filters.includes(serial_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleBattery.filter((str) => str !== '');
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Battery Serial</InputLabel>
                <Select
                  multiple
                  value={clear4.length === 0 ? [] :filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear4(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },

        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2" color="secondary"
              style={{ textAlign: "center" }}
            >
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Distance to Empty",
      options: {
        filter: true,
        filterList: clear5,
        display: 'true',
        filterType: 'custom',
        filterOptions: {
          logic: (distance_to_empty, filters, row) => {
            if (filters.length) return !filters.includes(distance_to_empty);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleDistance.filter((str) => str !== '');
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Distance To Empty</InputLabel>
                <Select
                  multiple
                  value={clear5.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear5(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },

        customBodyRender: (value) => {
          return (
            <Typography variant="subtitle2" color="secondary" style={{ textAlign: "center" }}>
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },
    {
      name: "Assignment Status",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "assign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "assign" &&
            value.batteryassign_status === "unassign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#c4c4c4"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "unassign" &&
            value.batteryassign_status === "assign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="mdi:car-battery"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          }
        },
      },
    },
    {
      name: "Vehicle Model",
      options: {
        filter: true,
        display: false,
        filterList: clear6,
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_model, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_model);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleModelInfo.filter((item,
              index) => VehicleModelInfo.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Model Info</InputLabel>
                <Select
                  multiple
                  value={clear6.length === 0 ? [] :filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear6(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Chassis Number",
      options: {
        filter: true,
        display: false,
        filterList: clear7,
        filterType: 'custom',
        filterOptions: {
          logic: (chassis_number, filters, row) => {
            if (filters.length) return !filters.includes(chassis_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleChassisNumber.filter((item,
              index) => VehicleChassisNumber.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Chassis Number</InputLabel>
                <Select
                  multiple
                  value={clear7.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear7(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Engine Number",
      options: {
        filter: true,
        display: false,
        filterList: clear8,
        filterType: 'custom',
        filterOptions: {
          logic: (engine_number, filters, row) => {
            if (filters.length) return !filters.includes(engine_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleEngineNumber.filter((item,
              index) => VehicleEngineNumber.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Engine Number</InputLabel>
                <Select
                  multiple
                  value={clear8.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear8(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Fleet Name",
      options: {
        filter: true,
        display: false,
        filterList: clear9,
        filterType: 'custom',
        filterOptions: {
          logic: (fleet_name, filters, row) => {
            if (filters.length) return !filters.includes(fleet_name);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleFleet.filter((item,
              index) => VehicleFleet.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Fleet Name</InputLabel>
                <Select
                  multiple
                  value={clear9.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear9(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Operational Manager",
      options: {
        filter: true,
        display: false,
        filterList: clear10,
        filterType: 'custom',
        filterOptions: {
          logic: (operational_manager, filters, row) => {
            if (filters.length) return !filters.includes(operational_manager);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleOperationalManager.filter((item,
              index) => VehicleOperationalManager.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Operational Manager</InputLabel>
                <Select
                  multiple
                  value={clear10.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear10(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Type",
      options: {
        filter: true,
        display: false,
        filterList: clear11,
        filterType: 'custom',
        filterOptions: {
          logic: (type, filters, row) => {
            if (filters.length) return !filters.includes(type);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleType.filter((item,
              index) => VehicleType.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Type</InputLabel>
                <Select
                  multiple
                  value={clear11.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear11(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Battery Status",
      options: {
        filter: true,
        display: false,
        filterList: clear12,
        filterType: 'custom',
        filterOptions: {
          logic: (batteryassign_status, filters, row) => {
            if (filters.length) return !filters.includes(batteryassign_status);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleBatteryStatus.filter((item,
              index) => VehicleBatteryStatus.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Battery Status</InputLabel>
                <Select
                  multiple
                  value={clear12.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear12(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Driver Status",
      options: {
        filter: true,
        display: false,
        filterList: clear13,
        filterType: 'custom',
        filterOptions: {
          logic: (driver_status, filters, row) => {
            if (filters.length) return !filters.includes(driver_status);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleDriverStatus.filter((item,
              index) => VehicleDriverStatus.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Driver Status</InputLabel>
                <Select
                  multiple
                  value={clear13.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear13(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{  cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Status",
      options: {
        filter: true,
        display: false,
        filterList: clear14,
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_status, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_status);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = VehicleStatus.filter((item,
              index) => VehicleStatus.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Status</InputLabel>
                <Select
                  multiple
                  value={clear14.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear13(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getCommVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography color="secondary"
            style={{ cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
  ];
  const ErickColumn = [
    {
      name: "Vehicle Number",
      options: {
        filter: true,
        display: true,
        filterList: clear1,
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_number, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleNumber.filter((item,
              index) => EVehicleNumber.indexOf(item) === index);
            return (
                <>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: '-12px' }}><Typography>Filters</Typography>
                  <Button style={{ color: '#9ccc65', width: '100px' }}
                    onClick={() => {
                      setClear1([])
                      setClear2([])
                      setClear3([])
                      setClear4([])
                      setClear5([])
                      setClear6([])
                      setClear7([])
                      setClear8([])
                      setClear9([])
                      setClear10([])
                      setClear11([])
                      dispatch(getEVBulk(enty, pageEV));
                    }}>RESET</Button></div>
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Number</InputLabel>
                <Select
                  multiple
                  value={clear1.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear1(filterList[index], index, column);
                }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl></>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Investor",
      options: {
        filter: true,
        filterList: clear2,
        display: 'true',
        filterType: 'custom',
        filterOptions: {
          logic: (investor, filters, row) => {
            if (filters.length) return !filters.includes(investor);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues1 = EVehicleInvestor.filter((item,
              index) => EVehicleInvestor.indexOf(item) === index);
            const optionValues = optionValues1.filter((str) => str !== '');
            return (
                <><br/>
                <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Investor</InputLabel>
                <Select
                  multiple
                  value={clear2.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear2(filterList[index], index, column);
                }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
                </>
              
            );
          }
        },
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      name: "SOC/Km Left",
      options: {
        filter: true,
        filterList: clear3,
        display: 'true',
        filterType: 'custom',
        filterOptions: {
          logic: (soc, filters, row) => {
            if (filters.length) return !filters.includes(soc);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleSOC.filter((str) => str !== '');
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">SOC</InputLabel>
                <Select
                  multiple
                  value={clear3.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear3(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },

        customBodyRender: (value) => {
          return (
            <Typography variant="subtitle2">
              {validateKeyData(value)}
            </Typography>
          );
        },
      },
    },

    {
      name: "Action",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (
            value.driver_status === "assign" &&
            value.vehicle_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                  <IconButton
                  // onClick={() => {
                  //   setOpenDriverDeActive(true)
                  //   setAssignDriv((state) => ({
                  //     ...state,
                  //     "vehicle_id": value.vehicle_id
                  //   }))
                  // }}
                  >
                    <Icon
                      icon="material-symbols:electric-rickshaw"
                      color="#4caf50"
                      width="30"
                      height="30"
                    />
                  </IconButton>
                </Tooltip>

                <IconButton
                  onClick={() => {
                    setOpenEDriverDeActive(true);
                    setEVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);

                    // setAssignEDriv((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id
                    // }))
                    // setEditDriverReAssign((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id,
                    //   "assignment_id": value.assignment_id
                    // }))
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setDelete1(true);
                    setSelectedId1(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="ic:baseline-delete"
                    color="#FF000050"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "assign" &&
            value.vehicle_status === "unassign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:electric-rickshaw"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverDeActive(true);
                    setEVEditArray(value.vehicle_id);
                    setSelectedD(value.vehicle_id);
                    setAssignID(value.assignment_id);

                    // setAssignEDriv((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id
                    // }))
                    // setEditDriverReAssign((state) => ({
                    //   ...state,
                    //   "vehicle_id": value.vehicle_id,
                    //   "assignment_id": value.assignment_id
                    // }))
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setDelete1(true);
                    setSelectedId1(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="ic:baseline-delete"
                    color="#FF000050"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "unassign" &&
            value.vehicle_status === "assign"
          ) {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                  <IconButton>
                    <Icon
                      icon="material-symbols:electric-rickshaw"
                      color="#4caf50"
                      width="30"
                      height="30"
                    />
                  </IconButton>
                </Tooltip>

                <IconButton
                  onClick={() => {
                    setOpenEDriverActive(true);
                    setEVEditArray(value.vehicle_id);
                    setAssignEDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setDelete1(true);
                    setSelectedId1(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="ic:baseline-delete"
                    color="#FF000050"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else {
            return (
              <>
                <IconButton
                  onClick={() => {
                    setOpenEVEdit(true);
                    setEVEditArray(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="bxs:edit-alt"
                    color="#33a6ff"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="material-symbols:electric-rickshaw"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setOpenEDriverActive(true);
                    setEVEditArray(value.vehicle_id);
                    setAssignEDriv((state) => ({
                      ...state,
                      vehicle_id: value.vehicle_id,
                    }));
                  }}
                >
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton
                  onClick={() => {
                    setDelete1(true);
                    setSelectedId1(value.vehicle_id);
                  }}
                >
                  <Icon
                    icon="ic:baseline-delete"
                    color="#FF000050"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          }
        },
      },
    },
    {
      name: "Vehicle Model",
      options: {
        filter: true,
        filterList: clear4,
        display: false,
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_model, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_model);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleModel.filter((item,
              index) => EVehicleModel.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Model Info</InputLabel>
                <Select
                  multiple
                  value={clear4.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear4(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Chassis Number",
      options: {
        filter: true,
        filterList: clear5,
        display: false,
        filterType: 'custom',
        filterOptions: {
          logic: (chassis_number, filters, row) => {
            if (filters.length) return !filters.includes(chassis_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleChassis.filter((item,
              index) => EVehicleChassis.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Chassis Number</InputLabel>
                <Select
                  multiple
                  value={clear5.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear5(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Engine Number",
      options: {
        filter: true,
        filterList: clear6,
        display: false,
        filterType: 'custom',
        filterOptions: {
          logic: (engine_number, filters, row) => {
            if (filters.length) return !filters.includes(engine_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleEngine.filter((item,
              index) => EVehicleEngine.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Engine Number</InputLabel>
                <Select
                  multiple
                  value={clear6.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear6(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Fleet Name",
      options: {
        filter: true,
        display: false,
        filterList: clear7,
        filterType: 'custom',
        filterOptions: {
          logic: (fleet_name, filters, row) => {
            if (filters.length) return !filters.includes(fleet_name);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleFleet.filter((item,
              index) => EVehicleFleet.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Fleet Name</InputLabel>
                <Select
                  multiple
                  value={clear7.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear7(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Operational Manager",
      options: {
        filter: true,
        display: false,
        filterList: clear8,
        filterType: 'custom',
        filterOptions: {
          logic: (operational_manager, filters, row) => {
            if (filters.length) return !filters.includes(operational_manager);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleOperationalManager.filter((item,
              index) => EVehicleOperationalManager.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Operational Manager</InputLabel>
                <Select
                  multiple
                  value={clear8.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear8(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Type",
      options: {
        filter: true,
        display: false,
        filterList: clear9,
        filterType: 'custom',
        filterOptions: {
          logic: (type, filters, row) => {
            if (filters.length) return !filters.includes(type);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleType.filter((item,
              index) => EVehicleType.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Type</InputLabel>
                <Select
                  multiple
                  value={clear9.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear9(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Status",
      options: {
        filter: true,
        filterList: clear10,
        display: false,
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_status, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_status);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleStatus.filter((item,
              index) => EVehicleStatus.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Status</InputLabel>
                <Select
                  multiple
                  value={clear10.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear10(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      name: "Driver Status",
      options: {
        filter: true,
        filterList: clear11,
        display: false,
        filterType: 'custom',
        filterOptions: {
          logic: (driver_status, filters, row) => {
            if (filters.length) return !filters.includes(driver_status);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleDriverStatus.filter((item,
              index) => EVehicleDriverStatus.indexOf(item) === index);
            return (
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Driver Status</InputLabel>
                <Select
                  multiple
                  value={clear11.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear11(filterList[index], index, column);
                  }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
  ];
  const ErickColumn1 = [
    {
      name: "Vehicle Number",
      options: {
        filter: true,
        display: true,
        filterList: clear1,
        filterType: 'custom',
        filterOptions: {
          logic: (vehicle_number, filters, row) => {
            if (filters.length) return !filters.includes(vehicle_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = EVehicleNumber.filter((item,
              index) => EVehicleNumber.indexOf(item) === index);
              return (
                <>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: '-12px' }}><Typography>Filters</Typography>
                  <Button style={{ color: '#9ccc65', width: '100px' }}
                    onClick={() => {
                      setClear1([])
                      setClear2([])
                      setClear3([])
                      setClear4([])
                      setClear5([])
                      setClear6([])
                      setClear7([])
                      setClear8([])
                      setClear9([])
                      setClear10([])
                      setClear11([])
                      dispatch(getEVBulk(enty, pageEV));
                    }}>RESET</Button></div>
              <FormControl>
                <InputLabel htmlFor="select-multiple-chip">Vehicle Number</InputLabel>
                <Select
                  multiple
                  value={clear1.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear1(filterList[index], index, column);
                }}
                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item} onClick={() => {
                      setDataOn(true)
                      dispatch(getErickVBulk(enty));
                    }}>
                      <ListItemText primary={item} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl></>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
        name: "Investor",
        options: {
          filter: true,
          filterList: clear2,
          display: 'true',
          filterType: 'custom',
          filterOptions: {
            logic: (investor, filters, row) => {
              if (filters.length) return !filters.includes(investor);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues1 = EVehicleInvestor.filter((item,
                index) => EVehicleInvestor.indexOf(item) === index);
              const optionValues = optionValues1.filter((str) => str !== '');
              return (
                  <><br/>
                  <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Vehicle Investor</InputLabel>
                  <Select
                    multiple
                    value={clear2.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear2(filterList[index], index, column);
                  }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                  </>
                
              );
            }
          },
          customBodyRender: (value) => (
            <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
          ),
        },
      },
      {
        name: "SOC/Km Left",
        options: {
          filter: true,
          filterList: clear3,
          display: 'true',
          filterType: 'custom',
          filterOptions: {
            logic: (soc, filters, row) => {
              if (filters.length) return !filters.includes(soc);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleSOC.filter((str) => str !== '');
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">SOC</InputLabel>
                  <Select
                    multiple
                    value={clear3.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear3(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
  
          customBodyRender: (value) => {
            return (
              <Typography variant="subtitle2">
                {validateKeyData(value)}
              </Typography>
            );
          },
        },
      },

    {
      name: "Action",
      options: {
        filter: false,
        customBodyRender: (value) => {
          if (
            value.driver_status === "assign" &&
            value.vehicle_status === "assign"
          ) {
            return (
              <>
                <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                  <IconButton>
                    <Icon
                      icon="material-symbols:electric-rickshaw"
                      color="#4caf50"
                      width="30"
                      height="30"
                    />
                  </IconButton>
                </Tooltip>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "assign" &&
            value.vehicle_status === "unassign"
          ) {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="material-symbols:electric-rickshaw"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#4caf50"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else if (
            value.driver_status === "unassign" &&
            value.vehicle_status === "assign"
          ) {
            return (
              <>
                <Tooltip style={{ flex: "left" }} title={"Assigned"}>
                  <IconButton>
                    <Icon
                      icon="material-symbols:electric-rickshaw"
                      color="#4caf50"
                      width="30"
                      height="30"
                    />
                  </IconButton>
                </Tooltip>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          } else {
            return (
              <>
                <IconButton>
                  <Icon
                    icon="material-symbols:electric-rickshaw"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
                <IconButton>
                  <Icon
                    icon="healthicons:truck-driver"
                    color="#C4C4C4"
                    width="30"
                    height="30"
                  />
                </IconButton>
              </>
            );
          }
        },
      },
    },
    {
        name: "Vehicle Model",
        options: {
          filter: true,
          filterList: clear4,
          display: false,
          filterType: 'custom',
          filterOptions: {
            logic: (vehicle_model, filters, row) => {
              if (filters.length) return !filters.includes(vehicle_model);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleModel.filter((item,
                index) => EVehicleModel.indexOf(item) === index);
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Vehicle Model Info</InputLabel>
                  <Select
                    multiple
                    value={clear4.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear4(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
          customBodyRender: (value) => (
            <Typography
              style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
              variant="subtitle2"
            >
              {validateKeyData(value)}
            </Typography>
          ),
        },
      },
      {
        name: "Chassis Number",
        options: {
          filter: true,
          filterList: clear5,
          display: false,
          filterType: 'custom',
          filterOptions: {
            logic: (chassis_number, filters, row) => {
              if (filters.length) return !filters.includes(chassis_number);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleChassis.filter((item,
                index) => EVehicleChassis.indexOf(item) === index);
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Chassis Number</InputLabel>
                  <Select
                    multiple
                    value={clear5.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear5(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
          customBodyRender: (value) => (
            <Typography
              style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
              variant="subtitle2"
            >
              {validateKeyData(value)}
            </Typography>
          ),
        },
      },
      {
        name: "Engine Number",
        options: {
          filter: true,
          filterList: clear6,
          display: false,
          filterType: 'custom',
          filterOptions: {
            logic: (engine_number, filters, row) => {
              if (filters.length) return !filters.includes(engine_number);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleEngine.filter((item,
                index) => EVehicleEngine.indexOf(item) === index);
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Engine Number</InputLabel>
                  <Select
                    multiple
                    value={clear6.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear6(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
          customBodyRender: (value) => (
            <Typography
              style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
              variant="subtitle2"
            >
              {validateKeyData(value)}
            </Typography>
          ),
        },
      },
      {
        name: "Fleet Name",
        options: {
          filter: true,
          display: false,
          filterList: clear7,
          filterType: 'custom',
          filterOptions: {
            logic: (fleet_name, filters, row) => {
              if (filters.length) return !filters.includes(fleet_name);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleFleet.filter((item,
                index) => EVehicleFleet.indexOf(item) === index);
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Fleet Name</InputLabel>
                  <Select
                    multiple
                    value={clear7.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear7(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
          customBodyRender: (value) => (
            <Typography
              style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
              variant="subtitle2"
            >
              {validateKeyData(value)}
            </Typography>
          ),
        },
      },
      {
        name: "Operational Manager",
        options: {
          filter: true,
          display: false,
          filterList: clear8,
          filterType: 'custom',
          filterOptions: {
            logic: (operational_manager, filters, row) => {
              if (filters.length) return !filters.includes(operational_manager);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleOperationalManager.filter((item,
                index) => EVehicleOperationalManager.indexOf(item) === index);
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Operational Manager</InputLabel>
                  <Select
                    multiple
                    value={clear8.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear8(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
          customBodyRender: (value) => (
            <Typography
              style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
              variant="subtitle2"
            >
              {validateKeyData(value)}
            </Typography>
          ),
        },
      },
      {
        name: "Vehicle Type",
        options: {
          filter: true,
          display: false,
          filterList: clear9,
          filterType: 'custom',
          filterOptions: {
            logic: (type, filters, row) => {
              if (filters.length) return !filters.includes(type);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleType.filter((item,
                index) => EVehicleType.indexOf(item) === index);
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Vehicle Type</InputLabel>
                  <Select
                    multiple
                    value={clear9.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear9(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
          customBodyRender: (value) => (
            <Typography
              style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
              variant="subtitle2"
            >
              {validateKeyData(value)}
            </Typography>
          ),
        },
      },
      {
        name: "Vehicle Status",
        options: {
          filter: true,
          filterList: clear10,
          display: false,
          filterType: 'custom',
          filterOptions: {
            logic: (vehicle_status, filters, row) => {
              if (filters.length) return !filters.includes(vehicle_status);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleStatus.filter((item,
                index) => EVehicleStatus.indexOf(item) === index);
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Vehicle Status</InputLabel>
                  <Select
                    multiple
                    value={clear10.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear10(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
          customBodyRender: (value) => (
            <Typography
              style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
              variant="subtitle2"
            >
              {validateKeyData(value)}
            </Typography>
          ),
        },
      },
      {
        name: "Driver Status",
        options: {
          filter: true,
          filterList: clear11,
          display: false,
          filterType: 'custom',
          filterOptions: {
            logic: (driver_status, filters, row) => {
              if (filters.length) return !filters.includes(driver_status);
              return false;
            },
            display: (filterList, onChange, index, column) => {
              const optionValues = EVehicleDriverStatus.filter((item,
                index) => EVehicleDriverStatus.indexOf(item) === index);
              return (
                <FormControl>
                  <InputLabel htmlFor="select-multiple-chip">Driver Status</InputLabel>
                  <Select
                    multiple
                    value={clear11.length === 0 ? [] : filterList[index]}
                    renderValue={selected => selected.join(', ')}
                    onChange={event => {
                      filterList[index] = event.target.value;
                      onChange(filterList[index], index, column);
                      setClear11(filterList[index], index, column);
                    }}
                  >
                    {optionValues.map(item => (
                      <MenuItem key={item} value={item} onClick={() => {
                        setDataOn(true)
                        dispatch(getErickVBulk(enty));
                      }}>
                        <ListItemText primary={item} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              );
            }
          },
          customBodyRender: (value) => (
            <Typography
              style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
              variant="subtitle2"
            >
              {validateKeyData(value)}
            </Typography>
          ),
        },
      },
  ];
  const VehicleModel = [
    {
      name: "Vehicle Model",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography
            style={{ color: "#000000", cursor: "pointer" }}
            variant="subtitle2"
          >
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Seating",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
        ),
      },
    },
    {
      name: "Max Speed (kmph)",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "Vehicle Gross Weight (Kg)",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography variant="subtitle2" color="secondary">
              {value}
            </Typography>
          );
        },
      },
    },
    {
      name: "Range Per Charge (Km)",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography variant="subtitle2" color="secondary">
              {value}
            </Typography>
          );
        },
      },
    },

    {
      name: "Action",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <>
              <IconButton
                onClick={() => {
                  setOpenVMEdit(true);
                  setVMEditArray(value);
                }}
              >
                <Icon
                  icon="bxs:edit-alt"
                  color="#33a6ff"
                  width="30"
                  height="30"
                />
              </IconButton>
              <IconButton
                onClick={() => {
                  setDelete2(true);
                  setSelectedId2(value);
                }}
              >
                <Icon
                  icon="ic:baseline-delete"
                  color="#FF000050"
                  width="30"
                  height="30"
                />
              </IconButton>
            </>
          );
        },
      },
    },
  ];
  const VehicleModel1 = [
    {
      name: "Vehicle Model",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography
            style={{
              color: "#000000",
              cursor: "pointer",
              height: "30px",
              marginTop: "12px",
            }}
            variant="subtitle2"
          >
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Seating",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography
            variant="subtitle2"
            style={{ height: "30px", marginTop: "12px" }}
          >
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Max Speed (kmph)",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography
            variant="subtitle2"
            style={{ height: "30px", marginTop: "12px" }}
          >
            {value}
          </Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "Vehicle Gross Weight (Kg)",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2"
              color="secondary"
              style={{ height: "30px", marginTop: "12px" }}
            >
              {value}
            </Typography>
          );
        },
      },
    },
    {
      name: "Range Per Charge (Km)",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2"
              color="secondary"
              style={{ height: "30px", marginTop: "12px" }}
            >
              {value}
            </Typography>
          );
        },
      },
    },
  ];
  const [selectedD, setSelectedD] = React.useState("");
  React.useEffect(() => {
    setAssignDriv({
      vehicle_id: "",
      driver_id: "",
    }),
      setAssignEDriv({
        vehicle_id: "",
        driver_id: "",
      });
  }, [selectedD]);

  const [assignDriv, setAssignDriv] = React.useState({
    vehicle_id: "",
    driver_id: "",
  });

  const assDriver = () => {
    // let newData = {
    //   vehicle_id: editCArray.vehicle_id,
    //   driver_id: editCArray.driver_id
    // }
    if (assignDriv.driver_id) {
      const postDriv = endpoints.baseUrl + `/vehicle/driver/add`;

      axios.post(postDriv, assignDriv).then((response) => {
        setAddBatteryErrors(true);

        dispatch(getCVBulk(enty, pageCV));
        response.status === 200
          ? setAddResponce("Driver Assigned Successfully")
          : setAddResponce(response.message);
        setOpenDriverActive(false);
        setOpenDriverDeActive(false);
      });
      setOpenDriverActive(false);
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  // const [editDriverReAssign, setEditDriverReAssign] = React.useState(
  //   {

  //   }
  // )
  // const setDriverReAssignEditArray = (assignment_id) => {
  //   console.log("editDriverReAssign", editDriverReAssign)
  //   let allDriverReAssign = VDADataRaw;
  //   let findDriverReAssignArray = allDriverReAssign.find(el => el.assignment_id === assignment_id)
  //   setEditDriverReAssign(findDriverReAssignArray);
  // }
  // const submitDriverReAssign = () => {
  //   if (editDriverReAssign.driver_id) {
  //     const putDriverReAssign = endpoints.baseUrl + `/vehicle/driver/reassign/` + editDriverReAssign.assignment_id;
  //     axios
  //       .put(putDriverReAssign, editDriverReAssign)
  //       .then((response) => {
  //         setAddBatteryErrors(true);
  //         dispatch(getCVBulk(enty, pageCV));
  //         setOpenDriverDeActive(false)
  //         response.status === 200 ? setAddResponce("Reassigned Successfully") : setAddResponce(response.message)
  //         dispatch(getCVBulk(enty, pageCV));

  //       });
  //   } else {
  //     setAddBatteryErrors(true);

  //     setAddResponce("Please fill the required fields")

  //   }

  // }
  // const setDriverReAssignEditFormArray = (e, key, array) => {
  //   setEditDriverReAssign((state) => ({ ...state, [key]: e.target.value }));

  // }
  const DeactiveD = (assignment_id) => {
    const DeactiveDri =
      endpoints.baseUrl + `/vehicle/driver/deactivate/` + assignment_id;
    axios.delete(DeactiveDri).then((response) => {
      response.status === 200
        ? setAddResponce("Driver Deactivated")
        : setAddResponce("Driver Deactivated");
      dispatch(getCVBulk(enty, pageCV));
      setOpenDriverDeActive(false);
    });
  };

  const DeactiveE = (assignment_id) => {
    const DeactiveEDri =
      endpoints.baseUrl + `/vehicle/driver/deactivate/` + assignment_id;
    axios.delete(DeactiveEDri).then((response) => {
      setAddResponce("Driver Deactivated");
      dispatch(getEVBulk(pageCV));
      setOpenEDriverDeActive(false);
    });
  };

  const [assignEDriv, setAssignEDriv] = React.useState({
    vehicle_id: "",
    driver_id: "",
  });

  const assEDriver = () => {
    if (assignEDriv.vehicle_id) {
      const postEDriv = endpoints.baseUrl + `/vehicle/driver/erick/add`;

      axios.post(postEDriv, assignEDriv).then((response) => {
        setAddBatteryErrors(true);

        dispatch(getEVBulk(enty, pageEV));
        response.status === 200
          ? setAddResponce("Driver Assigned Successfully")
          : setAddResponce(response.message);
        setOpenEDriverActive(false);
      });
      setOpenEDriverActive(false);
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  const [assignBattery, setAssignBattery] = React.useState({
    battery_id: "",
    vehicle_id: "",
  });

  const assignBatteryy = () => {
    if (assignBattery.battery_id) {
      const postba = endpoints.baseUrl + `/vehicle/battery/add`;

      axios.post(postba, assignBattery).then((response) => {
        setAddBatteryErrors(true);

        dispatch(getCVBulk(enty, pageCV));
        response.status === 200
          ? setAddResponce("Battery Assigned Successfully")
          : setAddResponce(response.message);
        setOpenBAssign(false);
      });
      setOpenBAssign(false);
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };

  const [editBReAssign, setEditBReAssign] = React.useState({});
  const setBAEditArray = (vehicle_battery_id) => {
    let allBA = BADataRaw;
    let findBArray = allBA.find(
      (el) => el.vehicle_battery_id === vehicle_battery_id
    );
    setEditBReAssign(findBArray);
  };
  const submitBReassign = () => {
    // console.log("editBReAssign", editBReAssign)
    if (editBReAssign.battery_id) {
      const putBA =
        endpoints.baseUrl +
        `/vehicle/battery/reassign/` +
        editBReAssign.vehicle_battery_id;
      axios.put(putBA, editBReAssign).then((response) => {
        setAddBatteryErrors(true);
        dispatch(getCVBulk(enty, pageCV));
        setOpenBReAssign(false);
        response.status === 200
          ? setAddResponce("Reassigned Successfully")
          : setAddResponce(response.message);
        dispatch(getCVBulk(enty, pageCV));
      });
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  const setBAEditFormArray = (e, key, array) => {
    setEditBReAssign((state) => ({ ...state, [key]: e.target.value }));
  };
  const currentDate = new Date().toISOString().split("T")[0];;
  const [cVAddForm, setCVAddForm] = React.useState({
    model_id: "",
    vehicle_number: "",
    chassis_number: "",
    engine_number: "",
    owner_name: "raj",
    upload_rc_book: "",
    upload_insurance: "",
    upload_permit_image: "",
    insurance_expiry_date: "",
    permit_expiry_date: "",
    manufacturing_date: "",
    type: "",
    asset: {
      asset_type: "Vehicle",
      entity_id: "",
    },
    investor: {
      asset_type: "Vehicle",
      entity_id: 100,
      user_id: "",
    },
    user: {
      asset_type: "Vehicle",
      entity_id: 100,
      user_id: "",
    },
    telematics: {
      telematics_data_id: "",
      sim_operator: "",
      mobile_number: "",
      imei: "",
    },
  });
  const submitCV = () => {
    if (cVAddForm.model_id && cVAddForm.vehicle_number && cVAddForm.asset.entity_id) {
      const postCV = endpoints.baseUrl + `/vehicle/add`;
      // const postCV = endpoints.baseUrl + `/vehicle/add`;

      axios.post(postCV, cVAddForm).then((response) => {
        setAddBatteryErrors(true);
        dispatch(getCVBulk(enty, pageCV));
        response.status === 201
          ? setAddResponce("Vehicle Added Successfully")
          : setAddResponce(response.message);
      });
      setOpenCVehicle(false);
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  const setCVAddFormArray = (e, key, array) => {
    if (array) {
      setCVAddForm((state) => ({
        ...state,
        [array]: {
          ...state[array],
          [key]: e.target.value,
        },
      }));
    } else {
      setCVAddForm((state) => ({ ...state, [key]: e.target.value }));
    }
  };

  const handleSubmitAddCV = () => {
    submitCV(true);
    dispatch(getCVBulk(enty, pageCV));
    // setOpenCVehicle(false);
  };

  const [editCArray, setEditCArray] = React.useState({});
  const setCVEditArray = (vehicle_id) => {
    // console.log("editCArray", editCArray)
    let allCV = CVDataRaw;
    let findCArray = allCV.find((el) => el.vehicle_id === vehicle_id);
    setEditCArray(findCArray);
  };
  const submitCVEdit = () => {
    if (editCArray.model_id && editCArray.type) {
      const putCV =
        endpoints.baseUrl + `/vehicle/edit/` + editCArray.vehicle_id;
      axios.put(putCV, editCArray).then((response) => {
        setAddBatteryErrors(true);
        dispatch(getCVBulk(enty, pageCV));
        response.status === 200
          ? setAddResponce("Vehicle Edited Successfully")
          : setAddResponce(response.message);
        dispatch(getCVBulk(enty, pageCV));
      });
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  const setCVEditFormArray = (e, key, array) => {
    if (array) {
      setEditCArray((state) => ({
        ...state,
        [array]: {
          ...state[array],
          [key]: e.target.value,
        },
      }));
    } else {
      setEditCArray((state) => ({ ...state, [key]: e.target.value }));
    }

    // setEditCArray((state) => ({ ...state, [key]: e.target.value }));
  };
  const deleteVehicle = (vehicle_id) => {
    const deleteV = endpoints.baseUrl + `/vehicle/SoftDelete/` + vehicle_id;
    axios
      .delete(deleteV)
      .then((response) => {
        setAddBatteryErrors(true);
        response.status === 200 ? setAddResponce("Vehicle Offboarding") : setAddResponce(response.message)
        setDelete1(false)
        dispatch(getCVBulk(enty, pageCV));
        dispatch(getEVBulk(enty, pageEV));
      });
  }
  //add EV
  const [eVAddForm, setEVAddForm] = React.useState({
    model_id: "",
    vehicle_number: "",
    chassis_number: "",
    engine_number: "",
    owner_name: "raj",
    upload_rc_book: "",
    upload_insurance: "",
    upload_permit_image: "",
    insurance_expiry_date: "",
    permit_expiry_date: "",
    manufacturing_date: "",
    type: "",
    asset: {
      asset_type: "Vehicle",
      entity_id: "",
    },
    investor: {
      asset_type: "Vehicle",
      entity_id: 100,
      user_id: "",
    },
    user: {
      asset_type: "Vehicle",
      entity_id: 100,
      user_id: "",
    },
    telematics: {
      telematics_data_id: "",
      sim_operator: "",
      mobile_number: "",
      imei: "",
    },
  });
  const submitEV = () => {
    if (eVAddForm.model_id && eVAddForm.vehicle_number && eVAddForm.asset.entity_id) {
      const postEV = endpoints.baseUrl + `/vehicle/add`;
      // const postCV = endpoints.baseUrl + `/vehicle/add`;

      axios.post(postEV, eVAddForm).then((response) => {
        setAddBatteryErrors(true);
        dispatch(getEVBulk(enty, pageEV));
        response.status === 201
          ? setAddResponce("Vehicle Added Successfully")
          : setAddResponce(response.message);
        setOpenEVehicle(false);
        //   setCVAddForm({
        //     model_id: "",
        //     vehicle_number: "",
        //     chassis_number: "",
        //     engine_number: "",
        //     owner_name: "raj",
        //     upload_rc_book: "",
        //     upload_insurance: "",
        //     upload_permit_image: "",
        //     insurance_expiry_date: "",
        //     battery_model_related_info: "",
        //     motor_controller_related_info: "",
        //     charger_related_info: "",
        //     permit_expiry_date: "",
        //     manufacturing_date: "",
        //     type: "",
        //     asset: {
        //       asset_type: "vehicle",
        //       entity_id: ""
        //     },
        //     investor: {
        //       asset_type: "vehicle",
        //       entity_id: "100",
        //       user_id: ""
        //     },
        //     user: {
        //       asset_type: "vehicle",
        //       entity_id: "100",
        //       user_id: ""
        //     }
        //   })
      });
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  const setEVAddFormArray = (e, key, array) => {
    if (array) {
      setEVAddForm((state) => ({
        ...state,
        [array]: {
          ...state[array],
          [key]: e.target.value,
        },
      }));
    } else {
      setEVAddForm((state) => ({ ...state, [key]: e.target.value }));
    }
  };


  //edit ev
  const [editEArray, setEditEArray] = React.useState({});
  const setEVEditArray = (vehicle_id) => {
    let allEV = EVDataRaw;
    let findEArray = allEV.find((el) => el.vehicle_id === vehicle_id);
    setEditEArray(findEArray);
  };
  const submitEVEdit = () => {
    if (editEArray.model_id && editEArray.type) {
      const putEV =
        endpoints.baseUrl + `/vehicle/edit/` + editEArray.vehicle_id;
      axios.put(putEV, editEArray).then((response) => {
        setAddBatteryErrors(true);
        dispatch(getCVBulk(enty, pageCV));
        response.status === 200
          ? setAddResponce("Vehicle Edited Successfully")
          : setAddResponce(response.message);
        dispatch(getEVBulk(enty, pageEV));
        setOpenEVEdit(false);
      });
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };

  // const setEVEditFormArray = (e, key) => {
  //   setEditEArray((state) => ({ ...state, [key]: e.target.value }));

  // }
  const setEVEditFormArray = (e, key, array) => {
    if (array) {
      setEditEArray((state) => ({
        ...state,
        [array]: {
          ...state[array],
          [key]: e.target.value,
        },
      }));
    } else {
      setEditEArray((state) => ({ ...state, [key]: e.target.value }));
    }

    // setEditCArray((state) => ({ ...state, [key]: e.target.value }));
  };

  //add Model

  const [addVMForm, setAddVMForm] = React.useState({
    model: "",
    fuel: "Electric",
    unladen_wt: "",
    seating: "",
    width: "",
    length: "",
    height: "",
    gross_vehicle_weight: "",
    payload_weight: "",
    top_speed: "",
    typical_range: "",
    manufacturer: "revx",
    reference_Image: "",
    datasheet: "",
    vehicle_type: "L3N",
    vehicle_class: "3 wheeler",
  });
  const submitVM = () => {
    if (
      addVMForm.model &&
      addVMForm.fuel &&
      addVMForm.unladen_wt &&
      addVMForm.seating &&
      addVMForm.width &&
      addVMForm.length &&
      addVMForm.height &&
      addVMForm.gross_vehicle_weight &&
      addVMForm.payload_weight &&
      addVMForm.top_speed &&
      addVMForm.typical_range
    ) {
      const postVM = endpoints.baseUrl + `/vehiclemodel/add`;

      axios.post(postVM, addVMForm).then((response) => {
        setAddBatteryErrors(true);
        dispatch(getVMBulk(modelPage));
        response.status === 201
          ? setAddResponce("Vehicle Model Onboarded Successfully")
          : setAddResponce(response.message);
        setAddVMForm({
          model: "",
          fuel: "Electric",
          unladen_wt: "",
          seating: "",
          width: "",
          length: "",
          height: "",
          gross_vehicle_weight: "",
          payload_weight: "",
          top_speed: "",
          typical_range: "",
          manufacturer: "revx",
          reference_Image: "",
          datasheet: "",
          vehicle_type: "L3N",
          vehicle_class: "3 wheeler",
        });
      });
      setOpenVM(false);
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  const setVMAddFormArray = (e, key) => {
    setAddVMForm((state) => ({ ...state, [key]: e.target.value }));
  };

  const handleSubmitAddVM = () => {
    submitVM();
    // setOpenVM(false)
  };

  //editModel

  const [editArray, setEditArray] = React.useState({});
  const setVMEditArray = (model_id) => {
    let allModel = VMDataRaw;
    let findArray = allModel.find((el) => el.model_id === model_id);
    setEditArray(findArray);
  };
  const submitVMEdit = () => {
    if (editArray.model) {
      const putVM =
        endpoints.baseUrl + `/vehiclemodel/edit/` + editArray.model_id;
      axios.put(putVM, editArray).then((response) => {
        setAddBatteryErrors(true);
        dispatch(getVMBulk(modelPage));
        response.status === 200
          ? setAddResponce("Model Edited Successfully")
          : setAddResponce(response.message);
        dispatch(getVMBulk(modelPage));
        setOpenVMEdit(false);
      });
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields");
    }
  };
  const setVMEditFormArray = (e, key) => {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));
  };

  const deleteVM = (model_id) => {
    const deleteModel =
      endpoints.baseUrl + `/vehiclemodel/SoftDelete/` + model_id;
    axios.delete(deleteModel).then((response) => {
      setAddBatteryErrors(true);
      response.status === 200
        ? setAddResponce("Model Offboarding")
        : setAddResponce(response.message);
      setDelete2(false)
      dispatch(getVMBulk(modelPage));
    });
  };

  const DeactiveB = (vehicle_battery_id) => {
    const DeactiveBat =
      endpoints.baseUrl + `/battery/vehicle/deactivate/` + vehicle_battery_id;
    axios.delete(DeactiveBat).then((response) => {
      setAddResponce("Vehicle Deactivated");
      dispatch(getCVBulk(enty, pageCV));
      setOpenBReAssign(false);
    });
  };

  const [state, setState] = React.useState({
    checkedA: false,
    checkedB: false,
  });

  const handleChangeC = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
  };
  const [stateb, setStateb] = React.useState({
    checkedB: true,
    checkedC: true,
  });

  const handleChangeB = (event) => {
    setStateb({ ...stateb, [event.target.name]: event.target.checked });
  };
  const getSafe = (fn, defaultVal) => {
    try {
      if (fn().length !== 0) {
        return fn();
      }
    } catch (e) {
      return defaultVal;
    }
  };

  const upload = () => {
    const uploadimg = endpoints.baseUrl + `/uplaod`;

    axios.post(uploadimg).then((response) => {
      setAddBatteryErrors(true);
      response;
      // response.status === 201 ? setAddResponce("Successfully") : setAddResponce(response.message)
    });
  };

  // editCArray.telematics !== null ?  editCArray : null
  // if (CVMetaa && EVMeta && VMMeta) {

  return (
    <div onMouseEnter={() => setFrame(true)} className={classes.table}>
      <SimpleSnackbar
        logInMessage={addResponse}
        notificationTimeOut={notificationTimeOut}
        setLoginSucess={setAddBatteryErrors}
        loginSuccess={addBatteryErrors}
      />

      {/* <div style={{ display: 'flex', justifyContent: 'space-between' }}> */}
      <Tabs
        className={classes.tabsSection}
        value={value}
        onChange={handleChange}
        variant="fullWidth"
        indicatorColor="primary"
        aria-label="icon tabs example"
      >
        <Tab
          label="Commercial"
          icon={<AirportShuttleIcon />}
          aria-label="favorite"
        />
        <Tab
          label="E-Rickshaw"
          icon={
            <Icon
              icon="material-symbols:electric-rickshaw"
              width="30"
              height="30"
            />
          }
          aria-label="phone"
        />
        <Tab label={"VEHICLE Model"} icon={<TabIcon />} aria-label="phone" />
      </Tabs>
      {/* </div> */}

      <Paper square className={classes.root} />
      <>
        {// CVMetaPresent &&
          value === 0 ? (
            <>
              <MUIDataTable
                checkboxSelection={false}
                title={"Commercial"}
                data={CVMeta.data}
                columns={
                  vehicleEditAccess === true ? VehicleColumn : VehicleColumn1
                }
                options={options}
                selectableRows={1}
                selectableRowsHideCheckboxes
              />
              <br />
              <Pagination
                count={MyCVCount}
                page={MyCVPage}
                onChange={changePageCV}
              />
            </>
          ) : null}

        {// EVMetaPresent &&
          value === 1 ? (
            <>
              <MUIDataTable
                checkboxSelection={false}
                title={"E-Rickshaw"}
                data={EVMeta.data}
                columns={vehicleEditAccess === true ? ErickColumn : ErickColumn1}
                options={options1}
                selectableRows={1}
                selectableRowsHideCheckboxes
              />
              <br />
              <Pagination
                count={MyEVCount}
                page={MyEVPage}
                onChange={changePageEV}
              />
            </>
          ) : null}
        {value === 2 ? (
          <>
            <MUIDataTable
              checkboxSelection={false}
              title={"Vehicle Model"}
              data={VMMeta.data}
              columns={
                vehicleEditAccess === true ? VehicleModel : VehicleModel1
              }
              options={options2}
              selectableRows={1}
              selectableRowsHideCheckboxes
            />
            <br />
            <Pagination
              count={MyVMCount}
              page={MyVMPage}
              onChange={changePageBatModel}
            />
          </>
        ) : null}
        <br />
        <Typography align="center" className={classes.copyRight}>
          Copyright© 2023 ReVx Energy Pvt.Ltd.
        </Typography>

        {/* ADD CV */}
        <Dialog
          //fullScreen={fullScreen}
          open={openCVehicle}
          maxWidth={"lg"}
          onClose={() => {
            setState(!state);
            setOpenCVehicle(false);
          }}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogContent>
            <div className={classes.divStyle}>
              <DialogTitle id="responsive-dialog-title">
                Onboarding Vehicle
              </DialogTitle>
              <Grid container spacing={2}>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Model
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setCVAddFormArray(e, "model_id");
                      }}
                      error={addBatteryErrors && cVAddForm.model_id === ""}
                      value={cVAddForm.model_id}
                    >
                      <MenuItem value="">Select your Model</MenuItem>
                      {modelList.length &&
                        modelList.map((modelL) => {
                          return (
                            <MenuItem value={modelL[1]}>{modelL[0]}</MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Type
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setCVAddFormArray(e, "type");
                      }}
                      error={addBatteryErrors && cVAddForm.type === ""}
                      value={cVAddForm.type}
                    >
                      <MenuItem value="">Select your Type</MenuItem>
                      <MenuItem value={"2W"}>2 Wheeler</MenuItem>
                      <MenuItem value={"E-Auto"}>E-Auto</MenuItem>
                      <MenuItem value={"L5"}>L5 Commercial Vehicle</MenuItem>
                      <MenuItem value={"Erickshaw"}>Erickshaw</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Number
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    required
                    onChange={(e) => {
                      setCVAddFormArray(e, "vehicle_number");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && cVAddForm.vehicle_number === ""}
                    value={cVAddForm.vehicle_number}
                    className={classes.styleO}
                    placeholder="eg:  Vehicle Number"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Chassis Number
                  </Typography>
                  <TextField
                    onChange={(e) => {
                      setCVAddFormArray(e, "chassis_number");
                    }}
                    size="small"
                    id="outlined"
                    value={cVAddForm.chassis_number}
                    className={classes.styleO}
                    placeholder="eg:  Chassis Number"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Engine Number
                  </Typography>
                  <TextField
                    onChange={(e) => {
                      setCVAddFormArray(e, "engine_number");
                    }}
                    size="small"
                    id="outlined"
                    value={cVAddForm.engine_number}
                    className={classes.styleO}
                    placeholder="eg:  Engine Number"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>Investor</Typography>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setCVAddFormArray(e, "user_id", "investor");
                      }}
                      // error={addBatteryErrors && cVAddForm.user_id === ""}
                      value={cVAddForm.user_id}
                    >
                      <MenuItem value="">Select your Investor</MenuItem>
                      {IVMeta.data.length &&
                        IVMeta.data.map((iv) => {
                          return <MenuItem value={iv[1]}>{iv[0]}</MenuItem>;
                        })}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Fleet Name
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography> {addBatteryErrors && cVAddForm.asset && cVAddForm.asset.entity_id === "" ? <p style={{ color: 'red' }}> required</p> : null}
                  </div>
                  {enty1 === true ? (
                    <><FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setCVAddFormArray(e, "entity_id", "asset");
                        }}
                        error={addBatteryErrors && cVAddForm.asset && cVAddForm.asset.entity_id === ""}
                        id="demo-simple-select-error" value={cVAddForm.entity_id}
                      >
                        <MenuItem value="">Select your Manager</MenuItem>
                        {FleetMeta.data.length &&
                          FleetMeta.data.map((fleet) => {
                            return (
                              <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>
                            );
                          })}
                      </Select>

                    </FormControl>

                    </>
                  ) : (
                    <TextField
                      size="small"
                      id="outlined"
                      value={uName}
                      className={classes.styleO}
                    />
                  )}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Operation Manager
                  </Typography>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setCVAddFormArray(e, "user_id", "user");
                      }}
                      // error={addBatteryErrors && cVAddForm.user_id === ""}
                      value={cVAddForm.user_id}
                    >
                      <MenuItem value="">Select your Manager</MenuItem>
                      {OMMeta.data.length &&
                        OMMeta.data.map((om) => {
                          return <MenuItem value={om[1]}>{om[0]}</MenuItem>;
                        })}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload RC Book
                  </Typography>
                  <Button
                    sx={{
                      ":hover": { backgroundColor: "#fff" },
                    }}
                  >
                    <input
                      onChange={handleChangeRC}
                      // onChange={(e) => {
                      //   setCVAddFormArray(e, 'upload_rc_book')
                      // }}
                      // error={addBatteryErrors && cVAddForm.upload_rc_book === ""}
                      // value={cVAddForm.upload_rc_book}
                      type="file"
                      style={{ color: "#C1C1C1" }}
                    />
                  </Button>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Manufacturing Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    max={currentDate}
                    onChange={(e) => {
                      setCVAddFormArray(e, "manufacturing_date");
                    }}
                    size="small"
                    id="outlined"
                    value={cVAddForm.manufacturing_date}
                    // className={classes.styleO}
                    placeholder="eg:  manufacturing_date"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload Insurance
                  </Typography>
                  <Button
                    sx={{
                      ":hover": { backgroundColor: "#fff" },
                    }}
                  >
                    <input
                      onChange={handleChangeIns}
                      // onChange={(e) => {
                      //   setCVAddFormArray(e, 'upload_insurance')
                      // }}
                      // error={addBatteryErrors && cVAddForm.upload_insurance === ""}
                      // value={addBatteryErrors.upload_insurance}
                      type="file"
                      style={{ color: "#C1C1C1" }}
                    />
                  </Button>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Insurance Expiry Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    min={currentDate}
                    onChange={(e) => {
                      setCVAddFormArray(e, "insurance_expiry_date");
                    }}
                    size="small"
                    id="outlined"
                    value={cVAddForm.insurance_expiry_date}
                    // className={classes.styleO}
                    placeholder="eg:  insurance_expiry_date"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload Permit Image
                  </Typography>
                  <Button
                    sx={{
                      ":hover": { backgroundColor: "#fff" },
                    }}
                  >
                    <input
                      onChange={handleChangePermit}
                      type="file"
                      style={{ color: "#C1C1C1" }}
                    />
                    {/* onChange={(e) => { 
                          setCVAddFormArray(e, 'upload_permit_image')
                        }}
                        error={addBatteryErrors && cVAddForm.upload_permit_image === ""}
                         value={addBatteryErrors.upload_permit_image}
                         type="file" style={{ color: '#C1C1C1' }} />*/}
                  </Button>
                </Grid>
                {cVAddForm.manufacturing_date === '' ? null : <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Permit Expiry Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    min={cVAddForm.manufacturing_date}
                    onChange={(e) => {
                      setCVAddFormArray(e, "permit_expiry_date");
                    }}
                    size="small"
                    id="outlined"
                    value={cVAddForm.permit_expiry_date}
                    // className={classes.styleO}
                    placeholder="eg:  permit_expiry_date"
                  />
                </Grid>}
              </Grid>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={state.checkedA}
                    onChange={handleChangeC}
                    name="checkedA"
                  />
                }
                label="Is Telematics Attached?"
              />

              {state.checkedA === true ? (
                <Grid container spacing={2}>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>Model</Typography>
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setCVAddFormArray(
                            e,
                            "telematics_data_id",
                            "telematics"
                          );
                        }}
                        error={
                          addBatteryErrors &&
                          cVAddForm.telematics_data_id === ""
                        }
                        value={
                          cVAddForm.telematics &&
                          cVAddForm.telematics.telematics_data_id
                        }
                      >
                        <MenuItem value="">Select your Model</MenuItem>
                        {allTele.length &&
                          allTele.map((tele) => {
                            return (
                              <MenuItem value={tele[5]}>{tele[0]}</MenuItem>
                            );
                          })}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      IMEI Number
                    </Typography>
                    <TextField
                      onChange={(e) => {
                        setCVAddFormArray(e, "imei", "telematics");
                      }}
                      size="small"
                      id="outlined"
                      // error={addBatteryErrors && cVAddForm.imei === ""}
                      value={cVAddForm.telematics && cVAddForm.telematics.imei}
                      className={classes.styleO}
                      placeholder="eg:  imei"
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      SIM Operator
                    </Typography>
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setCVAddFormArray(e, "sim_operator", "telematics");
                        }}
                        // error={addBatteryErrors && cVAddForm.model_id === ""}
                        value={
                          cVAddForm.telematics &&
                          cVAddForm.telematics.sim_operator
                        }
                      >
                        <MenuItem value="">Select your Model</MenuItem>
                        <MenuItem value="Airtel">Airtel</MenuItem>
                        <MenuItem value="Jio">Jio</MenuItem>
                        <MenuItem value="VI">VI</MenuItem>
                        {/* {allVM.length && allVM.map((model) => {
                          return (
                            <MenuItem value={model[5]}>{model[0]}</MenuItem>
  
                          )
                        }
                        )} */}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Mobile Number
                    </Typography>
                    <TextField
                      onChange={(e) => {
                        setCVAddFormArray(e, "mobile_number", "telematics");
                      }}
                      value={
                        cVAddForm.telematics &&
                        cVAddForm.telematics.mobile_number
                      }
                      className={classes.styleO}
                      placeholder="eg:  9876678666"
                    />
                  </Grid>
                  {/* <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>Purchase Date</Typography>
                      <TextField type="date"
                        onChange={(e) => {
                          setCVAddFormArray(e, 'purchase_date', 'telematics')
                        }}
                        value={cVAddForm.telematics && cVAddForm.telematics.purchase_date}
                        size="small" id="outlined"
                        className={classes.styleO}
                        placeholder="eg:  11/11/22"
                      />
                    </Grid> */}
                </Grid>
              ) : null}
            </div>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => {
                setOpenCVehicle(false);
                setState(!state);
              }}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                handleSubmitAddCV(true);
                // setOpenCVehicle(false)
                setState(!state);
              }}
              color="secondary"
              autoFocus
            >
              Submit
            </Button>
          </DialogActions>
        </Dialog>

        {/* Edit CV */}
        <Dialog
          //fullScreen={fullScreen}
          open={openCVEdit}
          maxWidth={"lg"}
          onClose={() => {
            setState(!state);
            setOpenCVEdit(false);
          }}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogContent>
            <div className={classes.divStyle}>
              <DialogTitle id="responsive-dialog-title">
                Edit Vehicle
              </DialogTitle>
              <Grid container spacing={2}>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Model
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  {/* <TextField
                    onChange={(e) => {
                      setCVEditFormArray(e, "vehicle_model");
                    }}
                    size="small"
                    id="outlined"
                    value={editCArray.vehicle_model}
                    className={classes.styleO}
                  /> */}
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setCVEditFormArray(e, "model_id");
                      }}
                      error={addBatteryErrors && editCArray.model_id === ""}
                      value={editCArray.model_id}
                    >
                      <MenuItem value="">Select your Model</MenuItem>
                      {modelList.length &&
                        modelList.map((modelL) => {
                          return (
                            <MenuItem value={modelL[1]}>{modelL[0]}</MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Type
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  {/* <TextField
                      onChange={(e) => { setCVEditFormArray(e, 'type') }}
                      size="small" id="outlined"
                      value={editCArray.type}
                      className={classes.styleO} /> */}
                  <Select
                    onChange={(e) => {
                      setCVEditFormArray(e, "type");
                    }}
                    error={addBatteryErrors && cVAddForm.type === ""}
                    value={editCArray.type}
                    className={classes.styleO}
                  >
                    <MenuItem value={editCArray.type}>
                      {editCArray.type}
                    </MenuItem>
                    <MenuItem value={"2W"}>2 Wheeler</MenuItem>
                    <MenuItem value={"E-Auto"}>E-Auto</MenuItem>
                    <MenuItem value={"L5"}>L5 Commercial Vehicle</MenuItem>
                    <MenuItem value={"Erickshaw"}>Erickshaw</MenuItem>
                  </Select>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Number
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setCVEditFormArray(e, "vehicle_number");
                    }}
                    size="small"
                    id="outlined"
                    value={editCArray.vehicle_number}
                    className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Chassis Number
                  </Typography>
                  <TextField
                    onChange={(e) => {
                      setCVEditFormArray(e, "chassis_number");
                    }}
                    size="small"
                    id="outlined"
                    value={editCArray.chassis_number}
                    className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Engine Number
                  </Typography>
                  <TextField
                    onChange={(e) => {
                      setCVEditFormArray(e, "engine_number");
                    }}
                    size="small"
                    id="outlined"
                    value={editCArray.engine_number}
                    className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>Investor</Typography>
                  <Select
                    className={classes.styleO}
                    onChange={(e) => {
                      setCVEditFormArray(e, "user_id", "investor");
                      // editCArray.user_id
                    }}
                    // error={addBatteryErrors && (editCArray.investor && editCArray.investor.investor === "")}
                    // value={editCArray.investor && editCArray.investor.investor}
                    value={editCArray.investor && editCArray.investor.user_id}
                  >
                    {IVMeta.data.length &&
                      IVMeta.data.map((iv) => {
                        return <MenuItem value={iv[1]}>{iv[0]}</MenuItem>;
                      })}
                  </Select>
                  {/* </FormControl> */}

                  {/* <TextField
                      onChange={(e) => { setCVEditFormArray(e, 'user_id', 'investor') }}
                      size="small" id="outlined"
                      value={editCArray.investor}
                      className={classes.textField} /> */}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Fleet Name
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography> {addBatteryErrors && editCArray.asset && editCArray.asset.entity_id === "" ? <p style={{ color: 'red' }}> required</p> : null}
                  </div>
                  {enty1 === true ? (
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setCVEditFormArray(e, "entity_id", "asset");
                        }}
                        error={addBatteryErrors && (editCArray.asset && editCArray.asset.fleet_name === "")}
                        value={editCArray.asset && editCArray.asset.entity_id}
                      >
                        {FleetMeta.data.length &&
                          FleetMeta.data.map((fleet) => {
                            return (
                              <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>
                            );
                          })}
                      </Select>
                    </FormControl>
                  ) : (
                    <TextField
                      size="small"
                      id="outlined"
                      value={uName}
                      className={classes.styleO}
                    />
                  )}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Operation Manager
                  </Typography>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setCVEditFormArray(e, "user_id", "user");
                      }}
                      // error={addBatteryErrors && (editCArray.user && editCArray.user.operational_manager === "")}
                      value={editCArray.user && editCArray.user.user_id}
                    >
                      {/* <MenuItem value={editCArray.user && editCArray.user.operational_manager}>{editCArray.user && editCArray.user.operational_manager}</MenuItem> */}
                      {OMMeta.data.length &&
                        OMMeta.data.map((om) => {
                          return <MenuItem value={om[1]}>{om[0]}</MenuItem>;
                        })}
                    </Select>
                  </FormControl>

                  {/* <TextField
                      onChange={(e) => { setCVEditFormArray(e, 'entity_id', 'asset') }}
                      size="small" id="outlined"
                      value={editCArray.operational_manager}
                      className={classes.styleO} /> */}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload RC Book
                  </Typography>
                  <Button onClick={() => setOpenRC(true)}>
                    <img src={editCArray.upload_rc_book} />
                  </Button>
                  <Dialog
                    //fullScreen={fullScreen}
                    open={openRC}
                    maxWidth={"lg"}
                    onClose={() => {
                      setOpenRC(false);
                    }}
                    aria-labelledby="responsive-dialog-title"
                    className={classes.dialogPaper}
                  >
                    <div
                      style={{ display: "flex", justifyContent: "flex-end" }}
                    >
                      <></>
                      <IconButton
                        onClick={() => {
                          setOpenRC(false);
                        }}
                      >
                        <Icon
                          icon="akar-icons:circle-x"
                          width="26"
                          height="26"
                          color="#77b93e"
                        />
                      </IconButton>
                    </div>

                    <DialogContent>
                      <img src={editCArray.upload_rc_book} />
                    </DialogContent>
                  </Dialog>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Manufacturing Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    max={currentDate}
                    onChange={(e) => {
                      setCVEditFormArray(e, "manufacturing_date");
                    }}
                    size="small"
                    id="outlined"
                    value={editCArray.manufacturing_date}
                  // className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload Insurance
                  </Typography>
                  <Button onClick={() => setOpenIns(true)}>
                    <img src={editCArray.upload_insurance} />
                  </Button>
                  <Dialog
                    //fullScreen={fullScreen}
                    open={openIns}
                    maxWidth={"lg"}
                    onClose={() => {
                      setOpenIns(false);
                    }}
                    aria-labelledby="responsive-dialog-title"
                    className={classes.dialogPaper}
                  >
                    <div
                      style={{ display: "flex", justifyContent: "flex-end" }}
                    >
                      <></>
                      <IconButton
                        onClick={() => {
                          setOpenIns(false);
                        }}
                      >
                        <Icon
                          icon="akar-icons:circle-x"
                          width="26"
                          height="26"
                          color="#77b93e"
                        />
                      </IconButton>
                    </div>

                    <DialogContent>
                      <img src={editCArray.upload_insurance} />
                    </DialogContent>
                  </Dialog>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Insurance Expiry Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    min={currentDate}
                    onChange={(e) => {
                      setCVEditFormArray(e, "insurance_expiry_date");
                    }}
                    size="small"
                    id="outlined"
                    value={editCArray.insurance_expiry_date}
                  // className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload Permit Image
                  </Typography>
                  <Button onClick={() => setOpenPermit(true)}>
                    <img src={editCArray.upload_permit_image} />
                  </Button>
                  <Dialog
                    //fullScreen={fullScreen}
                    open={openPermit}
                    maxWidth={"lg"}
                    onClose={() => {
                      setOpenPermit(false);
                    }}
                    aria-labelledby="responsive-dialog-title"
                    className={classes.dialogPaper}
                  >
                    <div
                      style={{ display: "flex", justifyContent: "flex-end" }}
                    >
                      <></>
                      <IconButton
                        onClick={() => {
                          setOpenPermit(false);
                        }}
                      >
                        <Icon
                          icon="akar-icons:circle-x"
                          width="26"
                          height="26"
                          color="#77b93e"
                        />
                      </IconButton>
                    </div>

                    <DialogContent>
                      <img src={editCArray.upload_permit_image} />
                    </DialogContent>
                  </Dialog>
                </Grid>
                {editCArray.manufacturing_date === '' ? null : <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Permit Expiry Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    min={editCArray.manufacturing_date}
                    onChange={(e) => {
                      setCVEditFormArray(e, "permit_expiry_date");
                    }}
                    size="small"
                    id="outlined"
                    value={editCArray.permit_expiry_date}
                  // className={classes.styleO}
                  />
                </Grid>}

              </Grid>
              {editCArray.telematics && editCArray.telematics.imei === '' ?
                <><FormControlLabel
                  control={<Checkbox checked={state.checkedB}
                    onChange={handleChangeC}
                    name="checkedB" />}
                  label="Is Telematics Attached?"
                />
                  {state.checkedB === true ? <Grid container spacing={2}>
                    <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>
                        IMEI Number
                      </Typography>
                      <TextField
                        onChange={(e) => {
                          setCVEditFormArray(e, 'imei', 'telematics')
                        }}
                        size="small" id="outlined"
                        value={editCArray.telematics && editCArray.telematics.imei}
                        className={classes.styleO}
                      />
                    </Grid>
                    <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>
                        Model Info
                      </Typography>
                      <Select onChange={(e) => {
                        setCVEditFormArray(e, 'telematics_data_id', 'telematics')
                      }}
                        value={editCArray.telematics && editCArray.telematics.telematics_data_id}
                        className={classes.styleO}>

                        {allTele.length && allTele.map((telem) => {
                          return (
                            <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                          )
                        }
                        )}
                      </Select>
                    </Grid>
                    <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>SIM Operator</Typography>
                      <Select className={classes.styleO}
                        onChange={(e) => { setCVEditFormArray(e, 'sim_operator', 'telematics') }}
                        value={editCArray.telematics && editCArray.telematics.sim_operator}
                      >
                        <MenuItem value="">Select your Model</MenuItem>
                        <MenuItem value="Airtel">Airtel</MenuItem>
                        <MenuItem value="Jio">Jio</MenuItem>
                        <MenuItem value="VI">VI</MenuItem>

                      </Select>
                    </Grid>
                    <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>Mobile Number</Typography>
                      <TextField
                        onChange={(e) => {
                          setCVEditFormArray(e, 'mobile_number', 'telematics')
                        }}
                        value={editCArray.telematics && editCArray.telematics.mobile_number}
                        className={classes.styleO}
                      />
                    </Grid></Grid>
                    : null} </> :
                <><FormControlLabel
                  control={<Checkbox checked={!state.checkedB}
                    onChange={handleChangeC}
                    name="checkedB" />}
                  label="Is Telematics Attached?"
                />
                  <Grid container spacing={2}>
                    <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>
                        IMEI Number
                      </Typography>
                      <TextField
                        onChange={(e) => {
                          setCVEditFormArray(e, 'imei', 'telematics')
                        }}
                        size="small" id="outlined"
                        value={editCArray.telematics && editCArray.telematics.imei}
                        className={classes.styleO}
                      />
                    </Grid>
                    <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>
                        Model Info
                      </Typography>
                      <Select onChange={(e) => {
                        setCVEditFormArray(e, 'telematics_data_id', 'telematics')
                      }}
                        value={editCArray.telematics && editCArray.telematics.telematics_data_id}
                        className={classes.styleO}>

                        {allTele.length && allTele.map((telem) => {
                          return (
                            <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                          )
                        }
                        )}
                      </Select>
                    </Grid>
                    <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>SIM Operator</Typography>
                      <Select className={classes.styleO}
                        onChange={(e) => { setCVEditFormArray(e, 'sim_operator', 'telematics') }}
                        value={editCArray.telematics && editCArray.telematics.sim_operator}
                      >
                        <MenuItem value="">Select your Model</MenuItem>
                        <MenuItem value="Airtel">Airtel</MenuItem>
                        <MenuItem value="Jio">Jio</MenuItem>
                        <MenuItem value="VI">VI</MenuItem>

                      </Select>
                    </Grid>
                    <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>Mobile Number</Typography>
                      <TextField
                        onChange={(e) => {
                          setCVEditFormArray(e, 'mobile_number', 'telematics')
                        }}
                        value={editCArray.telematics && editCArray.telematics.mobile_number}
                        className={classes.styleO}
                      />
                    </Grid></Grid></>}
            </div>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => {
                setOpenCVEdit(false);
                setState(!state);
              }}
              color="secondary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                submitCVEdit();
                setOpenCVEdit(false);
                setState(!state);
              }}
              color="primary"
              autoFocus
            >
              Update
            </Button>
          </DialogActions>
        </Dialog>
        {/* ADD EV */}
        <Dialog
          //fullScreen={fullScreen}
          open={openEVehicle}
          maxWidth={"lg"}
          onClose={() => {
            setState(!state);
            setOpenEVehicle(false);
          }}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogContent>
            <div className={classes.divStyle}>
              <DialogTitle id="responsive-dialog-title">
                Onboarding E-Vehicle
              </DialogTitle>
              <Grid container spacing={2}>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Model
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setEVAddFormArray(e, "model_id");
                      }}
                      error={addBatteryErrors && eVAddForm.model_id === ""}
                      value={eVAddForm.model_id}
                    >
                      <MenuItem value="">Select your Model</MenuItem>
                      {modelList.length &&
                        modelList.map((modelL) => {
                          return (
                            <MenuItem value={modelL[1]}>{modelL[0]}</MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Type
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  {/* <TextField
                    // onChange={(e) => {
                    //   setEVAddFormArray(e, 'type')
                    // }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && eVAddForm.type === ""}
                    value={eVAddForm.type}
                    className={classes.styleO}
                  /> */}
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setEVAddFormArray(e, "type");
                      }}
                      error={addBatteryErrors && eVAddForm.type === ""}
                      value={eVAddForm.type}
                    >
                      <MenuItem value="">Select your Type</MenuItem>
                      <MenuItem value={"2W"}>2 Wheeler</MenuItem>
                      <MenuItem value={"E-Auto"}>E-Auto</MenuItem>
                      <MenuItem value={"L5"}>L5 Commercial Vehicle</MenuItem>
                      <MenuItem value={"Erickshaw"}>Erickshaw</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Number
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setEVAddFormArray(e, "vehicle_number");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && eVAddForm.vehicle_number === ""}
                    value={eVAddForm.vehicle_number}
                    className={classes.styleO}
                    placeholder="eg:  Vehicle Number"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Chassis Number
                  </Typography>
                  <TextField
                    onChange={(e) => {
                      setEVAddFormArray(e, "chassis_number");
                    }}
                    size="small"
                    id="outlined"
                    value={eVAddForm.chassis_number}
                    className={classes.styleO}
                    placeholder="eg:  Chassis Number"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Engine Number
                  </Typography>
                  <TextField
                    onChange={(e) => {
                      setEVAddFormArray(e, "engine_number");
                    }}
                    size="small"
                    id="outlined"
                    value={eVAddForm.engine_number}
                    className={classes.styleO}
                    placeholder="eg:  Engine Number"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>Investor</Typography>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setEVAddFormArray(e, "user_id", "investor");
                      }}
                      error={
                        addBatteryErrors &&
                        (eVAddForm.user_id && eVAddForm.user_id.investor === "")
                      }
                      value={eVAddForm.user_id && eVAddForm.user_id.investor}
                    >
                      <MenuItem value="">Select your Investor</MenuItem>
                      {IVMeta.data.length &&
                        IVMeta.data.map((iv) => {
                          return <MenuItem value={iv[1]}>{iv[0]}</MenuItem>;
                        })}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Fleet Name
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>{addBatteryErrors && eVAddForm.asset && eVAddForm.asset.entity_id === "" ? <p style={{ color: 'red' }}> required</p> : null}
                  </div>
                  {enty1 === true ? (
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setEVAddFormArray(e, "entity_id", "asset");
                        }}
                        error={
                          addBatteryErrors &&
                          (eVAddForm.asset &&
                            eVAddForm.asset.entity_id === "")
                        }
                        value={eVAddForm.entity_id}
                      >
                        <MenuItem value="">Select your Manager</MenuItem>
                        {FleetMeta.data.length &&
                          FleetMeta.data.map((fleet) => {
                            return (
                              <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>
                            );
                          })}
                      </Select>
                    </FormControl>
                  ) : (
                    <TextField
                      size="small"
                      id="outlined"
                      value={uName}
                      className={classes.styleO}
                    />
                  )}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Operation Manager
                  </Typography>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setEVAddFormArray(e, "user_id", "user");
                      }}
                      value={eVAddForm.user_id && eVAddForm.user_id.user}
                    >
                      <MenuItem value="">Select your Manager</MenuItem>
                      {OMMeta.data.length &&
                        OMMeta.data.map((om) => {
                          return <MenuItem value={om[1]}>{om[0]}</MenuItem>;
                        })}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload RC Book
                  </Typography>
                  <Button
                    sx={{
                      ":hover": { backgroundColor: "#fff" },
                    }}
                  >
                    <input
                      onChange={handleChangeERC}
                      // onChange={(e) => {
                      //   setEVAddFormArray(e, 'upload_rc_book')
                      // }}
                      // error={addBatteryErrors && eVAddForm.upload_rc_book === ""}
                      // value={eVAddForm.upload_rc_book}
                      type="file"
                      style={{ color: "#C1C1C1" }}
                    />
                  </Button>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Manufacturing Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    max={currentDate}
                    onChange={(e) => {
                      setEVAddFormArray(e, "manufacturing_date");
                    }}
                    size="small"
                    id="outlined"
                    value={eVAddForm.manufacturing_date}
                    // className={classes.styleO}
                    placeholder="eg:  manufacturing_date"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload Insurance
                  </Typography>
                  <Button
                    sx={{
                      ":hover": { backgroundColor: "#fff" },
                    }}
                  >
                    <input
                      onChange={handleChangeEIns}
                      // onChange={(e) => {
                      //   setEVAddFormArray(e, 'upload_insurance')
                      // }}
                      // error={addBatteryErrors && eVAddForm.upload_insurance === ""}
                      // value={eVAddForm.upload_insurance}
                      type="file"
                      style={{ color: "#C1C1C1" }}
                    />
                  </Button>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Insurance Expiry Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    min={currentDate}
                    onChange={(e) => {
                      setEVAddFormArray(e, "insurance_expiry_date");
                    }}
                    size="small"
                    id="outlined"
                    value={eVAddForm.insurance_expiry_date}
                    // className={classes.styleO}
                    placeholder="eg:  insurance_expiry_date"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Upload Permit Image
                  </Typography>
                  <Button
                    sx={{
                      ":hover": { backgroundColor: "#fff" },
                    }}
                  >
                    <input
                      onChange={handleChangeEPermit}
                      // onChange={(e) => {
                      //   setEVAddFormArray(e, 'upload_permit_image')
                      // }}
                      // error={addBatteryErrors && eVAddForm.upload_permit_image === ""}
                      // value={addBatteryErrors.upload_permit_image}
                      type="file"
                      style={{ color: "#C1C1C1" }}
                    />
                  </Button>
                </Grid>
                {eVAddForm.manufacturing_date === '' ? null : <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Permit Expiry Date
                  </Typography>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    min={eVAddForm.manufacturing_date}
                    onChange={(e) => {
                      setEVAddFormArray(e, "permit_expiry_date");
                    }}
                    size="small"
                    id="outlined"
                    value={eVAddForm.permit_expiry_date}
                    // className={classes.styleO}
                    placeholder="eg:  permit_expiry_date"
                  />
                </Grid>}

              </Grid>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={state.checkedA}
                    onChange={handleChangeC}
                    name="checkedA"
                  />
                }
                label="Is Telematics Attached?"
              />

              {state.checkedA === true ? (
                <Grid container spacing={2}>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>Model</Typography>
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setEVAddFormArray(
                            e,
                            "telematics_data_id",
                            "telematics"
                          );
                        }}
                        // error={addBatteryErrors &&  eVAddForm.telematics_data_id.telematics === ""}
                        value={
                          eVAddForm.telematics &&
                          eVAddForm.telematics.telematics_data_id
                        }
                      >
                        <MenuItem value="">Select your Model</MenuItem>
                        {allTele.length &&
                          allTele.map((tele) => {
                            return (
                              <MenuItem value={tele[5]}>{tele[0]}</MenuItem>
                            );
                          })}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      IMEI Number
                    </Typography>
                    <TextField
                      onChange={(e) => {
                        setEVAddFormArray(e, "imei", "telematics");
                      }}
                      size="small"
                      id="outlined"
                      // error={addBatteryErrors && cVAddForm.imei === ""}
                      value={eVAddForm.imei && eVAddForm.imei.telematics}
                      className={classes.styleO}
                      placeholder="eg:  imei"
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      SIM Operator
                    </Typography>
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setEVAddFormArray(e, "sim_operator", "telematics");
                        }}
                        // error={addBatteryErrors && cVAddForm.model_id === ""}
                        value={
                          eVAddForm.sim_operator &&
                          eVAddForm.sim_operator.telematics
                        }
                      >
                        <MenuItem value="">Select your Model</MenuItem>
                        <MenuItem value="Airtel">Airtel</MenuItem>
                        <MenuItem value="Jio">Jio</MenuItem>
                        <MenuItem value="VI">VI</MenuItem>
                        {/* {allVM.length && allVM.map((model) => {
                      return (
                        <MenuItem value={model[5]}>{model[0]}</MenuItem>

                      )
                    }
                    )} */}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Mobile Number
                    </Typography>
                    <TextField
                      onChange={(e) => {
                        setEVAddFormArray(e, "mobile_number", "telematics");
                      }}
                      size="small"
                      id="outlined"
                      value={
                        eVAddForm.mobile_number &&
                        eVAddForm.mobile_number.telematics
                      }
                      className={classes.styleO}
                      placeholder="eg:  9876678666"
                    />
                  </Grid>
                  {/* <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>Purchase Date</Typography>
                      <TextField type="date"
                        onChange={(e) => {
                          setEVAddFormArray(e, 'purchase_date', 'telematics')
                        }}
                        size="small" id="outlined"
                        value={eVAddForm.purchase_date && eVAddForm.purchase_date.telematics}
                        className={classes.styleO}
                        placeholder="eg:  11/11/22"
                      />
                    </Grid> */}
                </Grid>
              ) : null}
            </div>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => {
                setState(!state);
                setOpenEVehicle(false);
              }}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                submitEV();
                // setOpenEVehicle(false)
                setState(!state);
              }}
              color="secondary"
              autoFocus
            >
              Submit
            </Button>
          </DialogActions>
        </Dialog>
        {/* Edit EV */}
        <Dialog
          //fullScreen={fullScreen}
          open={openEVEdit}
          maxWidth={"lg"}
          onClose={() => {
            setState(!state);
            setOpenEVEdit(false);
          }}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogContent>
            <div className={classes.divStyle}>
              <DialogTitle id="responsive-dialog-title">
                Edit Vehicle
              </DialogTitle>
              <Grid container spacing={2}>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Model
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  {/* <TextField
                    onChange={(e) => {
                      setEVEditFormArray(e, "vehicle_model");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && editEArray.vehicle_model === ""}
                    value={editEArray.vehicle_model}
                    className={classes.styleO}
                  /> */}
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setEVEditFormArray(e, "model_id");
                      }}
                      error={addBatteryErrors && editEArray.model_id === ""}
                      value={editEArray.model_id}
                    >
                      <MenuItem value="">Select your Model</MenuItem>
                      {modelList.length &&
                        modelList.map((modelL) => {
                          return (
                            <MenuItem value={modelL[1]}>{modelL[0]}</MenuItem>
                          );
                        })}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Type
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  {/* <TextField
                      onChange={(e) => { setEVEditFormArray(e, 'type') }}
                      size="small" id="outlined"
                      error={addBatteryErrors && editEArray.type === ""}
                      value={editEArray.type}
                      className={classes.styleO} /> */}
                  <Select
                    onChange={(e) => {
                      setEVEditFormArray(e, "type");
                    }}
                    error={addBatteryErrors && editEArray.type === ""}
                    value={editEArray.type}
                    className={classes.styleO}
                  >
                    <MenuItem value={editEArray.type}>
                      {editEArray.type}
                    </MenuItem>
                    <MenuItem value={"2W"}>2 Wheeler</MenuItem>
                    <MenuItem value={"E-Auto"}>E-Auto</MenuItem>
                    <MenuItem value={"L5"}>L5 Commercial Vehicle</MenuItem>
                  </Select>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Number
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setEVEditFormArray(e, "vehicle_number");
                    }}
                    size="small"
                    id="outlined"
                    value={editEArray.vehicle_number}
                    error={addBatteryErrors && editEArray.vehicle_number === ""}
                    className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Chassis Number
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setEVEditFormArray(e, "chassis_number");
                    }}
                    size="small"
                    id="outlined"
                    value={editEArray.chassis_number}
                    error={addBatteryErrors && editEArray.chassis_number === ""}
                    className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Engine Number
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setEVEditFormArray(e, "engine_number");
                    }}
                    size="small"
                    id="outlined"
                    value={editEArray.engine_number}
                    error={addBatteryErrors && editEArray.engine_number === ""}
                    className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>Investor</Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>

                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setEVEditFormArray(e, "user_id", "investor");
                      }}
                      // error={addBatteryErrors && editEArray.user_id === ""}
                      defaultValue={
                        editEArray.investor && editEArray.investor.user_id
                      }
                    >
                      <MenuItem value="">Select Investor</MenuItem>
                      {IVMeta.data.length &&
                        IVMeta.data.map((iv) => {
                          return <MenuItem value={iv[1]}>{iv[0]}</MenuItem>;
                        })}
                    </Select>
                  </FormControl>

                  {/* <TextField
                      onChange={(e) => { setEVEditFormArray(e, 'user_id', 'investor') }}
                      size="small" id="outlined"
                      value={editEArray.investor}
                      className={classes.textField} /> */}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Fleet Name
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>{addBatteryErrors && editEArray.asset && editEArray.asset.entity_id === "" ? <p style={{ color: 'red' }}> required</p> : null}
                  </div>
                  {enty1 === true ? (
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setEVEditFormArray(e, "entity_id", "asset");
                        }}
                        defaultValue={
                          editEArray.asset && editEArray.asset.entity_id
                        }
                      >
                        {FleetMeta.data.length &&
                          FleetMeta.data.map((fleet) => {
                            return (
                              <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>
                            );
                          })}
                      </Select>
                    </FormControl>
                  ) : (
                    <TextField
                      size="small"
                      id="outlined"
                      value={uName}
                      className={classes.styleO}
                    />
                  )}
                  {/* <TextField
                      onChange={(e) => { setEVEditFormArray(e, 'user_id', 'user') }}
                      size="small" id="outlined"
                      value={editEArray.user}
                      className={classes.styleO} /> */}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Operation Manager
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <FormControl className={classes.styleO}>
                    <Select
                      onChange={(e) => {
                        setEVEditFormArray(e, "user_id", "user");
                      }}
                      error={
                        addBatteryErrors &&
                        (editEArray.user && editEArray.user.user_id === "")
                      }
                      defaultValue={editEArray.user && editEArray.user.user_id}
                    >
                      <MenuItem value="">Select your Manager</MenuItem>
                      {OMMeta.data.length &&
                        OMMeta.data.map((om) => {
                          return <MenuItem value={om[1]}>{om[0]}</MenuItem>;
                        })}
                    </Select>
                  </FormControl>

                  {/* <TextField
                      onChange={(e) => { setEVEditFormArray(e, 'entity_id', 'asset') }}
                      size="small" id="outlined"
                      value={editEArray.entity_id}
                      className={classes.styleO} /> */}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Upload RC Book
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <Button onClick={() => setOpenERC(true)}>
                    <img src={editEArray.upload_rc_book} />
                  </Button>
                  <Dialog
                    //fullScreen={fullScreen}
                    open={openERC}
                    maxWidth={"lg"}
                    onClose={() => {
                      setOpenERC(false);
                    }}
                    aria-labelledby="responsive-dialog-title"
                    className={classes.dialogPaper}
                  >
                    <div
                      style={{ display: "flex", justifyContent: "flex-end" }}
                    >
                      <></>
                      <IconButton
                        onClick={() => {
                          setOpenERC(false);
                        }}
                      >
                        <Icon
                          icon="akar-icons:circle-x"
                          width="26"
                          height="26"
                          color="#77b93e"
                        />
                      </IconButton>
                    </div>

                    <DialogContent>
                      <img src={editEArray.upload_rc_book} />
                    </DialogContent>
                  </Dialog>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Manufacturing Date
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    max={currentDate}
                    onChange={(e) => {
                      setEVEditFormArray(e, "manufacturing_date");
                    }}
                    size="small"
                    id="outlined"
                    value={editEArray.manufacturing_date}
                  // className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Upload Insurance
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>

                  <Button onClick={() => setOpenEIns(true)}>
                    <img src={editEArray.upload_insurance} />
                  </Button>
                  <Dialog
                    //fullScreen={fullScreen}
                    open={openEIns}
                    maxWidth={"lg"}
                    onClose={() => {
                      setOpenEIns(false);
                    }}
                    aria-labelledby="responsive-dialog-title"
                    className={classes.dialogPaper}
                  >
                    <div
                      style={{ display: "flex", justifyContent: "flex-end" }}
                    >
                      <></>
                      <IconButton
                        onClick={() => {
                          setOpenEIns(false);
                        }}
                      >
                        <Icon
                          icon="akar-icons:circle-x"
                          width="26"
                          height="26"
                          color="#77b93e"
                        />
                      </IconButton>
                    </div>

                    <DialogContent>
                      <img src={editEArray.upload_insurance} />
                    </DialogContent>
                  </Dialog>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Insurance Expiry Date
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    min={currentDate}
                    onChange={(e) => {
                      setEVEditFormArray(e, "insurance_expiry_date");
                    }}
                    size="small"
                    id="outlined"
                    value={editEArray.insurance_expiry_date}
                  // className={classes.styleO}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Upload Permit Image
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <Button onClick={() => setOpenEPermit(true)}>
                    <img src={editEArray.upload_permit_image} />
                  </Button>
                  <Dialog
                    //fullScreen={fullScreen}
                    open={openEPermit}
                    maxWidth={"lg"}
                    onClose={() => {
                      setOpenEPermit(false);
                    }}
                    aria-labelledby="responsive-dialog-title"
                    className={classes.dialogPaper}
                  >
                    <div
                      style={{ display: "flex", justifyContent: "flex-end" }}
                    >
                      <></>
                      <IconButton
                        onClick={() => {
                          setOpenEPermit(false);
                        }}
                      >
                        <Icon
                          icon="akar-icons:circle-x"
                          width="26"
                          height="26"
                          color="#77b93e"
                        />
                      </IconButton>
                    </div>

                    <DialogContent>
                      <img src={editEArray.upload_permit_image} />
                    </DialogContent>
                  </Dialog>
                </Grid>
                {editEArray.manufacturing_date === '' ? null : <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Permit Expiry Date
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <input
                    style={{
                      width: "90%",
                      color: "#7A7A7D",
                      borderRadius: "9px",
                      height: '40px',
                      border: '1px solid #000',
                      ".Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#C4C4C4  !important",
                      },
                      "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" }
                    }}
                    type="date"
                    min={editEArray.manufacturing_date}
                    onChange={(e) => {
                      setEVEditFormArray(e, "permit_expiry_date");
                    }}
                    size="small"
                    id="outlined"
                    value={editEArray.permit_expiry_date}
                  // className={classes.styleO}
                  />
                </Grid>}

              </Grid>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={stateb.checkedB}
                    onChange={handleChangeB}
                    name="checkedB"
                  />
                }
                label="Is Telematics Attached?"
              />

              {stateb.checkedB === true ? (
                <Grid container spacing={2}>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>Model</Typography>
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setEVEditFormArray(
                            e,
                            "telematics_data_id",
                            "telematics"
                          );
                        }}
                        value={
                          editEArray.telematics &&
                          editEArray.telematics.telematics_data_id
                        }
                      >
                        <MenuItem value="">Select your Model</MenuItem>
                        {allTele.length &&
                          allTele.map((tele) => {
                            return (
                              <MenuItem value={tele[5]}>{tele[0]}</MenuItem>
                            );
                          })}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      IMEI Number
                    </Typography>
                    <TextField
                      onChange={(e) => {
                        setEVEditFormArray(e, "imei", "telematics");
                      }}
                      size="small"
                      id="outlined"
                      value={
                        editEArray.telematics && editEArray.telematics.imei
                      }
                      className={classes.styleO}
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      SIM Operator
                    </Typography>
                    <FormControl className={classes.styleO}>
                      <Select
                        onChange={(e) => {
                          setEVEditFormArray(e, "sim_operator", "telematics");
                        }}
                        value={
                          editEArray.telematics &&
                          editEArray.telematics.sim_operator
                        }
                      >
                        <MenuItem value="">Select your Model</MenuItem>
                        <MenuItem value="Airtel">Airtel</MenuItem>
                        <MenuItem value="Jio">Jio</MenuItem>
                        <MenuItem value="VI">VI</MenuItem>
                        {/* {allVM.length && allVM.map((model) => {
                      return (
                        <MenuItem value={model[5]}>{model[0]}</MenuItem>

                      )
                    }
                    )} */}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Mobile Number
                    </Typography>
                    <TextField
                      onChange={(e) => {
                        setEVEditFormArray(e, "mobile_number", "telematics");
                      }}
                      size="small"
                      id="outlined"
                      value={
                        editEArray.telematics &&
                        editEArray.telematics.mobile_number
                      }
                      className={classes.styleO}
                    />
                  </Grid>
                  {/* <Grid item lg={6} xs={12}>
                      <Typography className={classes.styleL}>Purchase Date</Typography>
                      <TextField type="date"
                        onChange={(e) => {
                          setEVEditFormArray(e, 'purchase_date', 'telematics')
                        }}
                        size="small" id="outlined"
                        value={editEArray.telematics && editEArray.telematics.purchase_date}
                        className={classes.styleO}
                      />
                    </Grid> */}
                </Grid>
              ) : // <Grid container spacing={2}>
                //   <Grid item lg={6} xs={12}>
                //     <Typography className={classes.styleL}>
                //       IMEI Number
                //     </Typography>
                //     <TextField
                //       // onChange={(e) => { setEVEditFormArray(e, 'imei', 'telematics') }}
                //       size="small" id="outlined"
                //       value={editEArray.tele_imei}
                //       className={classes.styleO}
                //     />
                //   </Grid>
                //   <Grid item lg={6} xs={12}>
                //     <Typography className={classes.styleL}>
                //       Model Info
                //     </Typography>
                //     <TextField
                //       // onChange={(e) => { setEVEditFormArray(e, 'model_info', 'telematics') }}
                //       size="small" id="outlined"
                //       value={editEArray.tele_model_info}
                //       className={classes.styleO}
                //     />
                //   </Grid>
                //   <Grid item lg={6} xs={12}>
                //     <Typography className={classes.styleL}>
                //       Hardware Version
                //     </Typography>
                //     <TextField
                //       // onChange={(e) => { setEVEditFormArray(e, 'hw_version', 'telematics') }}
                //       size="small" id="outlined"
                //       value={editEArray.tele_hw_version}
                //       className={classes.styleO}
                //     />
                //   </Grid>
                //   <Grid item lg={6} xs={12}>
                //     <Typography className={classes.styleL}>
                //       Software Version
                //     </Typography>
                //     <TextField
                //       // onChange={(e) => { setEVEditFormArray(e, 'sw_version', 'telematics') }}
                //       size="small" id="outlined"
                //       value={editEArray.tele_sw_version}
                //       className={classes.styleO}
                //     />
                //   </Grid>
                //   <Grid item lg={6} xs={12}>
                //     <Typography className={classes.styleL}>
                //       OEM
                //     </Typography>
                //     <TextField
                //       // onChange={(e) => { setEVEditFormArray(e, 'oem', 'telematics') }}
                //       size="small" id="outlined"
                //       value={editEArray.tele_oem}
                //       className={classes.styleO}
                //     />
                //   </Grid></Grid>
                null}
            </div>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => {
                setState(!state);
                setOpenEVEdit(false);
              }}
              color="secondary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                setState(!state);
                submitEVEdit();
                // setOpenEVEdit(false)
              }}
              color="primary"
              autoFocus
            >
              Update
            </Button>
          </DialogActions>
        </Dialog>

        {/* Add Model */}
        <Dialog
          open={openVM}
          maxWidth={"lg"}
          onClose={() => setOpenVM(false)}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogContent>
            <div className={classes.divStyle}>
              <DialogTitle id="responsive-dialog-title">
                Onboarding Model
              </DialogTitle>
              <Grid container spacing={2}>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Model
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setVMAddFormArray(e, "model");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.model === ""}
                    value={addVMForm.model}
                    className={classes.styleO}
                    placeholder="eg:  Vehicle Model"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Catagory
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    // onChange={(e) => {
                    //   setVMAddFormArray(e, 'fuel')
                    // }}
                    size="small"
                    id="outlined"
                    // error={addBatteryErrors && addVMForm.fuel === ""}
                    value={addVMForm.fuel}
                    className={classes.styleO}
                    placeholder="eg:  Vehicle Catagory"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Payload(Kg)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMAddFormArray(e, "unladen_wt");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.unladen_wt === ""}
                    value={addVMForm.unladen_wt}
                    className={classes.styleO}
                    placeholder="eg:  Payload(Kg)"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}> Seating</Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setVMAddFormArray(e, "seating");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.seating === ""}
                    value={addVMForm.seating}
                    className={classes.styleO}
                    placeholder="eg:  seating"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Width (mm)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>

                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMAddFormArray(e, "width");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.width === ""}
                    value={addVMForm.width}
                    className={classes.styleO}
                    placeholder="eg:Vehicle Width (mm)"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Length (mm)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMAddFormArray(e, "length");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.length === ""}
                    value={addVMForm.length}
                    className={classes.styleO}
                    placeholder="eg: Vehicle Length (mm)"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Height (mm)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMAddFormArray(e, "height");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.height === ""}
                    value={addVMForm.height}
                    className={classes.styleO}
                    placeholder="eg: Vehicle Height (mm)"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Kerb Weight (Kg)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMAddFormArray(e, "gross_vehicle_weight");
                    }}
                    size="small"
                    id="outlined"
                    error={
                      addBatteryErrors && addVMForm.gross_vehicle_weight === ""
                    }
                    value={addVMForm.gross_vehicle_weight}
                    className={classes.styleO}
                    placeholder="eg: Vehicle Kerb Weight (Kg)"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Gross Weight (Kg)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMAddFormArray(e, "payload_weight");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.payload_weight === ""}
                    value={addVMForm.payload_weight}
                    className={classes.styleO}
                    placeholder="eg: Vehicle Gross Weight (Kg)"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Max Speed (kmph)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMAddFormArray(e, "top_speed");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.top_speed === ""}
                    value={addVMForm.top_speed}
                    className={classes.styleO}
                    placeholder="eg: Max Speed (kmph)"
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Range Per Charge (Km)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setVMAddFormArray(e, "typical_range");
                    }}
                    size="small"
                    id="outlined"
                    error={addBatteryErrors && addVMForm.typical_range === ""}
                    value={addVMForm.typical_range}
                    className={classes.styleO}
                    placeholder="eg: Range Per Charge (Km)"
                  />
                </Grid>

                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Reference Image
                  </Typography>
                  <Button
                    sx={{
                      ":hover": { backgroundColor: "#fff" },
                    }}
                  >
                    <input
                      onChange={handleChangeRef}
                      // onChange={(e) => {
                      //   setVMAddFormArray(e, 'reference_Image')
                      // }}
                      // error={addBatteryErrors && cVAddForm.reference_Image === ""}
                      // value={addBatteryErrors.reference_Image}
                      type="file"
                      style={{ color: "#C1C1C1" }}
                    />
                  </Button>
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Online link/Datasheet
                  </Typography>
                  <Button
                    sx={{
                      ":hover": { backgroundColor: "#fff" },
                    }}
                  >
                    <input
                      onChange={handleChangeDataSheet}
                      // onChange={(e) => {
                      //   setVMAddFormArray(e, 'datasheet')
                      // }}
                      // error={addBatteryErrors && cVAddForm.datasheet === ""}
                      // value={addBatteryErrors.datasheet}
                      type="file"
                      style={{ color: "#C1C1C1" }}
                    />
                  </Button>
                </Grid>
              </Grid>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenVM(false)} color="primary">
              Cancel
            </Button>
            <Button
              onClick={() => {
                handleSubmitAddVM();
                // setOpenVM(false)
              }}
              color="secondary"
            >
              Submit
            </Button>
          </DialogActions>
        </Dialog>

        {/* editModel */}
        <Dialog
          open={openVMEdit}
          maxWidth={"lg"}
          onClose={() => setOpenVMEdit(false)}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogContent>
            <div className={classes.divStyle}>
              <DialogTitle id="responsive-dialog-title">Edit Model</DialogTitle>
              <Grid container spacing={2}>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Model
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setVMEditFormArray(e, "model");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.model}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Catagory
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setVMEditFormArray(e, "fuel");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.fuel}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Unladen_weight
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setVMEditFormArray(e, "unladen_wt");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.unladen_wt}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}> Seating</Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    onChange={(e) => {
                      setVMEditFormArray(e, "seating");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.seating}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Width (mm)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMEditFormArray(e, "width");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.width}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Length (mm)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMEditFormArray(e, "length");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.length}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Height (mm)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMEditFormArray(e, "height");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.height}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Kerb Weight (Kg)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMEditFormArray(e, "gross_vehicle_weight");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.gross_vehicle_weight}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Vehicle Gross Weight (Kg)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMEditFormArray(e, "payload_weight");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.payload_weight}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Max Speed (kmph)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMEditFormArray(e, "top_speed");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.top_speed}
                    className={classes.textField}
                  />
                </Grid>
                <Grid item lg={6} xs={12}>
                  <div style={{ display: "flex" }}>
                    <Typography className={classes.styleL}>
                      Range Per Charge (Km)
                    </Typography>
                    &nbsp;
                    <Typography style={{ color: "red", fontSize: "18px" }}>
                      *
                    </Typography>
                  </div>
                  <TextField
                    type="number"
                    onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                    onChange={(e) => {
                      setVMEditFormArray(e, "typical_range");
                    }}
                    size="small"
                    id="outlined"
                    value={editArray.typical_range}
                    className={classes.textField}
                  />
                </Grid>

                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Reference Image
                  </Typography>
                  <Button onClick={() => setOpenRef(true)}>
                    <img src={editArray.reference_Image} />
                  </Button>
                  <Dialog
                    //fullScreen={fullScreen}
                    open={openRef}
                    maxWidth={"lg"}
                    onClose={() => {
                      setOpenRef(false);
                    }}
                    aria-labelledby="responsive-dialog-title"
                    className={classes.dialogPaper}
                  >
                    <div
                      style={{ display: "flex", justifyContent: "flex-end" }}
                    >
                      <></>
                      <IconButton
                        onClick={() => {
                          setOpenRef(false);
                        }}
                      >
                        <Icon
                          icon="akar-icons:circle-x"
                          width="26"
                          height="26"
                          color="#77b93e"
                        />
                      </IconButton>
                    </div>

                    <DialogContent>
                      <img src={editArray.reference_Image} />
                    </DialogContent>
                  </Dialog>
                  {/* <Button
                      sx={{
                        ":hover": { backgroundColor: "#fff" },
                      }}
                    >
                      <img src={editArray.reference_Image}
                        //  onChange={(e) => { setVMEditFormArray(e, 'reference_Image') }}
                        // value={editArray.reference_Image}
  
                        // type="file" style={{ color: '#C1C1C1' }} 
                        />
                    </Button> */}
                </Grid>
                <Grid item lg={6} xs={12}>
                  <Typography className={classes.styleL}>
                    Online link/Datasheet
                  </Typography>
                  <Button onClick={() => setOpenData(true)}>
                    <img src={editArray.datasheet} />
                  </Button>
                  <Dialog
                    //fullScreen={fullScreen}
                    open={openData}
                    maxWidth={"lg"}
                    onClose={() => {
                      setOpenData(false);
                    }}
                    aria-labelledby="responsive-dialog-title"
                    className={classes.dialogPaper}
                  >
                    <div
                      style={{ display: "flex", justifyContent: "flex-end" }}
                    >
                      <></>
                      <IconButton
                        onClick={() => {
                          setOpenData(false);
                        }}
                      >
                        <Icon
                          icon="akar-icons:circle-x"
                          width="26"
                          height="26"
                          color="#77b93e"
                        />
                      </IconButton>
                    </div>

                    <DialogContent>
                      <img src={editArray.datasheet} />
                    </DialogContent>
                  </Dialog>
                </Grid>
              </Grid>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenVMEdit(false)} color="primary">
              Cancel
            </Button>
            <Button
              onClick={() => {
                submitVMEdit(true);
                // setOpenVMEdit(false)
              }}
              color="secondary"
            >
              Submit
            </Button>
          </DialogActions>
        </Dialog>

        {/* Driver Active */}
        <Dialog
          open={openDriverActive}
          maxWidth={"lg"}
          onClose={() => setOpenDriverActive(false)}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Driver Assignment"}
          </DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <Grid item lg={12} xs={12}>
                  <Typography className={classes.secondaryTextG}>
                    <b style={{ color: "#00000080" }}>Driver Name:</b>
                  </Typography>
                  <Select
                    onChange={(e) => {
                      setAssignDriv((state) => ({
                        ...state,
                        driver_id: e.target.value,
                      }));
                    }}
                    className={classes.styleO}
                  // value={assignDriv.driver_id}
                  >
                    <MenuItem value="">Driver Vehicle</MenuItem>
                    {/* (VDAMetaPresent === true ? */}
                    {VDAMeta.data.length &&
                      VDAMeta.data.map((driver) => {
                        return (
                          <MenuItem value={driver[1]}>{driver[0]}</MenuItem>
                        );
                      })}
                    {/* : <MenuItem>No Driver to Assign</MenuItem>) */}
                  </Select>
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenDriverActive(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                assDriver();
              }}
              color="secondary"
              autoFocus
            >
              Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* Driver De-Active */}
        <Dialog
          open={openDriverDeActive}
          maxWidth={"lg"}
          onClose={() => setOpenDriverDeActive(false)}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Driver Reassignment"}
          </DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <Grid item lg={12} xs={12}>
                  <Typography className={classes.secondaryTextG}>
                    <b style={{ color: "#00000080" }}>Driver Name:</b>&nbsp;
                    {editCArray.driver_name}
                  </Typography>
                  {/* <Select onChange={(e) => {
                      setEditDriverReAssign((state) => ({
                        ...state,
                        "driver_id": e.target.value
                      }))
                      // setEditCArray((state) => ({
                      //   ...state,
                      //   "driver_id": e.target.value
                      // }))
                    }}
                      className={classes.styleO}
                    // value={selectedD ? assignDriv && assignDriv.driver_id : null}
                    // value={setEditDriverReAssign.driver_id}
                    >
                      <MenuItem value={editCArray.driver_id}>{editCArray.driver_name}</MenuItem>
                      {VDAMeta.data.length && VDAMeta.data.map((driver) => {
                        return (
                          <MenuItem value={driver[1]}>{driver[0]}</MenuItem>

                        )
                      }
                      )}

                    </Select> */}
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenDriverDeActive(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                DeactiveD(assignID);
              }}
              color="secondary"
              autoFocus
            >
              Re-Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* E-Driver Active */}
        <Dialog
          open={openEDriverActive}
          maxWidth={"lg"}
          onClose={() => setOpenEDriverActive(false)}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Driver Assignment"}
          </DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <Grid item lg={12} xs={12}>
                  <Typography className={classes.secondaryTextG}>
                    <b style={{ color: "#00000080" }}>Driver Name:</b>
                  </Typography>
                  <Select
                    onChange={(e) => {
                      setAssignEDriv((state) => ({
                        ...state,
                        driver_id: e.target.value,
                      }));
                    }}
                    className={classes.styleO}
                  >
                    <MenuItem value="">Driver Vehicle</MenuItem>
                    {/* (VDAMetaPresent === true ? */}
                    {VDAMeta.data.length &&
                      VDAMeta.data.map((driver) => {
                        return (
                          <MenuItem value={driver[1]}>{driver[0]}</MenuItem>
                        );
                      })}
                    {/* : <MenuItem>No Driver to Assign</MenuItem>) */}
                  </Select>
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenEDriverActive(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                assEDriver();
              }}
              color="secondary"
              autoFocus
            >
              Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* E-Driver De-Active */}
        <Dialog
          open={openEDriverDeActive}
          maxWidth={"lg"}
          onClose={() => setOpenEDriverDeActive(false)}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Driver Reassignment"}
          </DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <Grid item lg={12} xs={12}>
                  <Typography className={classes.secondaryTextG}>
                    <b style={{ color: "#00000080" }}>Driver Name:</b>&nbsp;
                    {editEArray.driver_name}
                  </Typography>
                  {/* <Select onChange={(e) => {
                      setEditDriverReAssign((state) => ({
                        ...state,
                        "driver_id": e.target.value
                      }))
                      // setEditCArray((state) => ({
                      //   ...state,
                      //   "driver_id": e.target.value
                      // }))
                    }}
                      className={classes.styleO}
                    // value={selectedD ? assignDriv && assignDriv.driver_id : null}
                    // value={editCArray.driver_id}
                    >

                      <MenuItem value={editEArray.driver_id}>{editEArray.driver_name}</MenuItem>
                      {VDAMeta.data.length && VDAMeta.data.map((driver) => {
                        return (
                          <MenuItem value={driver[1]}>{driver[0]}</MenuItem>

                        )
                      }
                      )}
                    </Select> */}
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenEDriverDeActive(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                DeactiveE(assignID);
              }}
              color="secondary"
              autoFocus
            >
              Re-Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* Battery Active */}
        <Dialog
          open={openBAssign}
          maxWidth={"lg"}
          onClose={() => setOpenBAssign(false)}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Battery Assignment"}
          </DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <Grid item lg={12} xs={12}>
                  <Typography className={classes.secondaryTextG}>
                    <b style={{ color: "#00000080" }}>Battery:</b>
                  </Typography>
                  <Select
                    onChange={(e) => {
                      setAssignBattery((state) => ({
                        ...state,
                        battery_id: e.target.value,
                      }));
                    }}
                    className={classes.styleO}
                  >
                    <MenuItem value="">Select</MenuItem>
                    {BAMeta.data.length &&
                      BAMeta.data.map((battt) => {
                        return <MenuItem value={battt[1]}>{battt[0]}</MenuItem>;
                      })}
                  </Select>
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenBAssign(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                assignBatteryy();
              }}
              color="secondary"
              autoFocus
            >
              Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* Battery De-Active */}
        <Dialog
          open={openBReAssign}
          maxWidth={"lg"}
          onClose={() => setOpenBReAssign(false)}
          aria-labelledby="responsive-dialog-title"
          className={classes.dialogPaper}
        >
          <DialogTitle id="responsive-dialog-title">
            {"Battery Reassignment"}
          </DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <Grid item lg={12} xs={12}>
                  <Typography className={classes.secondaryTextG}>
                    <b style={{ color: "#00000080" }}>Battery:</b>&nbsp;
                    {editCArray.serial_number}
                  </Typography>
                  {/* <Select
                      onChange={(e) => {
                        setEditBReAssign((state) => ({
                          ...state,
                          "battery_id": e.target.value
                        }))
                      }}
                      // onChange={(e) => { setBAEditFormArray(e, 'battery_id') }}
                      size="small" id="outlined"
                      value={editBReAssign.battery_id}
                      className={classes.styleO}
                    // value={editCArray.battery_id }
                    >

                      <MenuItem value={editCArray.battery_id}>{editCArray.serial_number}</MenuItem>
                      {BAMeta.data.length && BAMeta.data.map((battt) => {
                        return (
                          <MenuItem value={battt[1]}>{battt[0]}</MenuItem>

                        )
                      }
                      )}
                    </Select> */}
                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              autoFocus
              onClick={() => setOpenBReAssign(false)}
              color="primary"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                DeactiveB(vehBatID);
              }}
              color="secondary"
              autoFocus
            >
              Re-Assign
            </Button>
          </DialogActions>
        </Dialog>

        {/* Delete Vehicle */}
        <Dialog
          fullScreen={fullScreen}
          open={delete1}
          maxWidth={"lg"}
          onClose={() => setDelete1(false)}
          aria-labelledby="responsive-dialog-title"
          className={!fullScreen ? classes.dialog : null}
        >
          <DialogTitle id="responsive-dialog-title">{"Offboarding Vehicle"}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                <Grid item lg={12} xs={12}>
                  <TextField style={{
                    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
                    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
                  }}
                    onChange={(e) => { setPassword1(e.target.value) }}
                  />

                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setDelete1(false)}
              color="primary">
              Cancel
            </Button>
            <Button
              disabled={password1 !== pWord}
              onClick={() => {
                deleteVehicle(selectedId1);
              }}
              color="secondary">
              Offboarding
            </Button>
          </DialogActions>
        </Dialog>

        {/* Delete Model */}
        <Dialog
          fullScreen={fullScreen}
          open={delete2}
          maxWidth={"lg"}
          onClose={() => setDelete2(false)}
          aria-labelledby="responsive-dialog-title"
          className={!fullScreen ? classes.dialog : null}
        >
          <DialogTitle id="responsive-dialog-title">{"Offboarding Vehicle Model"}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              <Grid container spacing={2}>
                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                <Grid item lg={12} xs={12}>
                  <TextField style={{
                    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
                    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
                  }}
                    onChange={(e) => { setPassword2(e.target.value) }}
                  />

                </Grid>
              </Grid>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setDelete2(false)}
              color="primary">
              Cancel
            </Button>
            <Button
              disabled={password2 !== pWord}
              onClick={() => {
                deleteVM(selectedId2);
              }}
              color="secondary">
              Offboarding
            </Button>
          </DialogActions>
        </Dialog>
      </>
    </div>
  );

  // } else {
  //   return (<Loading
  //   />)
  // }
}
