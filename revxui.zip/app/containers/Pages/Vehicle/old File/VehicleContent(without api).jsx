import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "@material-ui/core/Button";
import Chart1 from "./Chart1";
import Chart2 from "./Chart2";
import Chart3 from "./Chart3";
import Chart4 from "./Chart4";
import Select from "@material-ui/core/Select";
import Tooltip from "@material-ui/core/Tooltip";


import Grid from "@material-ui/core/Grid";
import IconButton from "@material-ui/core/IconButton";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
// import makeAPICall from "../../reducers/batteryActions";
// import { getAllEBatteries } from '../../../actions/asyncActions';
// import getCBattery from "../../../api/batteryPage/getCBattery"
import { Icon } from '@iconify/react';
import endpoints from "../../../endpoints/endpoints";
import CustomToolbar from "./CustomToobar";
import TabIcon from '@material-ui/icons/Tab';
import AirportShuttleIcon from '@material-ui/icons/AirportShuttle';

import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";

import TextField from "@material-ui/core/TextField";
import { useState } from "react";
import DateFnsUtils from "@date-io/date-fns";
const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  graphText: {
    fontSize: 12,
    position: "absolute",
    transform: "rotate(270deg)",
    left: "-40px",
    top: 370,
    color: "primary",
    fontWeight: 600,
  },
  graphSelect: {
    minWidth: 150,
    left: "20em",
    marginBottom: 20,
  },
  tabsSection: {
    [theme.breakpoints.up("lg")]: {
      // borderRadius:0,position:'sticky',top:0 ,width:500
      borderRadius: 0,
      position: "sticky",
      top: 0,
      width: 500,
    },
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },

  margin: {
    margin: theme.spacing(3),
  },
  withoutLabel: {
    marginTop: theme.spacing(3),
    "& > div": {
      alignItems: "center",
    },
  },
  textField: {
    flexBasis: 200,
  },
  dialogPaper: {
    height: "100%",
    width: "150%",
  },
  divStyle: {
    width: "500px",
  },
  screensize: {},
  modelIcon: {
    "&:hover": {
      color: "#9ccc65",
    },
    transform: "translateX(-10em)",
  },
  vehicleIcon: {
    "&:hover": {
      color: "#9ccc65",
    },
    transform: "translateX(-10em)",
  },
  styleL: {
    fontSize: "15px",
    fontFamily: " Maven Pro",
    fontWeight: 400,
    color: "#A7A7A7",
  },
  styleM: {
    //width: "100%",
    borderRadius: "9px",
    marginBottom: "10px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#7A7A7D  !important",
    },
  },
  styleN: {
    ".MuiPaper-root": { width: "80% !important", marginLeft: "60px" },
  },
  styleO: {
    width: "90%",
    color: "#7A7A7D",
    borderRadius: "9px",
    //paddingBottom: "10px",
    ".Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#C4C4C4  !important",
    },
    "input.MuiOutlinedInput-input": { fontSize: "15px", marginLeft: "60px" },
  },
  styleE: {
    padding: "8px",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  "& input": {
    color: theme.palette.text.primary,
    background: "transparent",
    width: "100%",
    height: "100%",
    margin: 0,
    padding: "2px 20px 2px 2px",
    boxSizing: "border-box",
    border: "none",
    boxShadow: "none",
    outline: "none",
    fontSize: "15px",
  },

  //CSS For Textfield

  dialogPaper: {
    height: "100%",
    width: "150%",
  },
  divStyle: {
    width: "500px",
  },
  screensize: {},
  modelIcon: {
    "&:hover": {
      color: "#9ccc65",
    },
    transform: "translateX(-10em)",
  },
}));

/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function VehicleContent() { 
  const theme = useTheme();
  const classes = useStyles();
  const [screen, setScreen] = React.useState(false); 
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const [tableMode, setTableMode] = React.useState("ericksaw");
 
  const LightTooltip = styled(Tooltip)(({ theme }) => ({
    tooltip: {
      backgroundColor: theme.palette.common.white,
      color: "rgba(0, 0, 0, 0.87)",
      boxShadow: theme.shadows[1],
      fontSize: 20,
    },
    arrow: {
      arrow: {
        color: "#fff",
      },
    },
  }));

  const options = {
    filterType: "dropdown",
    responsive: "vertical",
    print: false,
    rowsPerPage: 10,
    page: 0,
    downloadCsv: false,
    selectableRows: "none",
    customToolbar: () => {
      return <CustomToolbar val={value} />;
    },
  };
  const [chartOneVal, setChartOneVal] = React.useState("day");
  const handleChartOneVal = (e) => {
    setChartOneVal(e.target.value);
  };
  const Header = () => {};

  /**
   *
   * @param {Field Variables} val
   * @returns
   */

  const [insuExpDate, setInsuExpDate] = React.useState(
    new Date("2022-08-18T21:11:54")
  );
  const [permitExpDate, setPermitExpDate] = React.useState(
    new Date("2022-08-18T21:11:54")
  );
  const [manufaDate, setManufaDate] = React.useState(
    new Date("2022-08-18T21:11:54")
  );

  const handleDateChange1 = (date) => {
    setInsuExpDate(date);
  };

  const handleDateChange2 = (date) => {
    setPermitExpDate(date);
  };
  const handleDateChange3 = (date) => {
    setManufaDate(date);
  };
  const vechList = [
    {
      vehiNumber: "TN 12 C1234",
      vehiNumberLabel: "Vehicle Number",
      ownerName: "Pukazhini",
      ownerNameLabel: "Owner Name",
      typeVechi: "3W",
      typeVechiLabel: "Type of Vehicle",
      socLeft: "56km Left",
      socLabel: "SOC/Km Left",
      actionButton: "Deactive",
      actionLabel: "Action Button",
      status: "healthy",
      statusLabel: "Status",
      vechiModel: "Honda",
      vechimodelLabel: "Vehicle Model",
      chassiNum: 12345,
      chassiLabel: "Chassis Number",
      engineNum: "ABDG765TYS",
      engineLabel: "Engine Label",
      batteryModelInfo: "This is Battery",
      batteryModelLabel: "Battery Model Related Info",
      motorInfo: "This is Motor",
      motorInfoLabel: "Motor Controller Related Info",
      telematicsInfo: "This is Telematics",
      telematicLabel: "Telematics Related Info",
      chargerInfo: "This is Charger",
      chagerInfoLabel: "Charger related info",
      insuExpDate: "06/11/2025",
      permitExpDate: "02/12/2024",
      manufacDate: "12/12/2009",
    },
    {
      vehiNumber: "TN 12 u4234",
      vehiNumberLabel: "Vehicle Number",
      ownerName: "Dhanalakshmi",
      ownerNameLabel: "Owner Name",
      typeVechi: "2W",
      typeVechiLabel: "Type of Vehicle",
      socLeft: "56km Left",
      socLabel: "SOC/Km Left",
      actionButton: "Deactive",
      actionLabel: "Action Button",
      status: "healthy",
      statusLabel: "Status",
      vechiModel: "Honda",
      vechimodelLabel: "Vehicle Model",
      chassiNum: 12345,
      chassiLabel: "Chassis Number",
      engineNum: "ABDG765TYS",
      engineLabel: "Engine Label",
      batteryModelInfo: "This is Battery",
      batteryModelLabel: "Battery Model Related Info",
      motorInfo: "This is Motor",
      motorInfoLabel: "Motor Controller Related Info",
      telematicsInfo: "This is Telematics",
      telematicLabel: "Telematics Related Info",
      chargerInfo: "This is Charger",
      chagerInfoLabel: "Charger related info",
      insuExpDate: "06/11/2025",
      permitExpDate: "02/12/2024",
      manufacDate: "12/12/2009",
    },
    {
      vehiNumber: "TN 12 I1489",
      vehiNumberLabel: "Vehicle Number",
      ownerName: "Kamalakannan",
      ownerNameLabel: "Owner Name",
      typeVechi: "3W",
      typeVechiLabel: "Type of Vehicle",
      socLeft: "56km Left",
      socLabel: "SOC/Km Left",
      actionButton: "Deactive",
      actionLabel: "Action Button",
      status: "healthy",
      statusLabel: "Status",
      vechiModel: "Honda",
      vechimodelLabel: "Vehicle Model",
      chassiNum: 12345,
      chassiLabel: "Chassis Number",
      engineNum: "ABDG765TYS",
      engineLabel: "Engine Label",
      batteryModelInfo: "This is Battery",
      batteryModelLabel: "Battery Model Related Info",
      motorInfo: "This is Motor",
      motorInfoLabel: "Motor Controller Related Info",
      telematicsInfo: "This is Telematics",
      telematicLabel: "Telematics Related Info",
      chargerInfo: "This is Charger",
      chagerInfoLabel: "Charger related info",
      insuExpDate: "06/11/2025",
      permitExpDate: "02/12/2024",
      manufacDate: "12/12/2009",
    },
    {
      vehiNumber: "TN 12 M1598",
      vehiNumberLabel: "Vehicle Number",
      ownerName: "Pukazhini",
      ownerNameLabel: "Owner Name",
      typeVechi: "2W",
      typeVechiLabel: "Type of Vehicle",
      socLeft: "56km Left",
      socLabel: "SOC/Km Left",
      actionButton: "Deactive",
      actionLabel: "Action Button",
      status: "healthy",
      statusLabel: "Status",
      vechiModel: "Honda",
      vechimodelLabel: "Vehicle Model",
      chassiNum: 12345,
      chassiLabel: "Chassis Number",
      engineNum: "ABDG765TYS",
      engineLabel: "Engine Label",
      batteryModelInfo: "This is Battery",
      batteryModelLabel: "Battery Model Related Info",
      motorInfo: "This is Motor",
      motorInfoLabel: "Motor Controller Related Info",
      telematicsInfo: "This is Telematics",
      telematicLabel: "Telematics Related Info",
      chargerInfo: "This is Charger",
      chagerInfoLabel: "Charger related info",
      insuExpDate: "06/11/2025",
      permitExpDate: "02/12/2024",
      manufacDate: "12/12/2009",
    },
    {
      vehiNumber: "TN 12 V3698",
      vehiNumberLabel: "Vehicle Number",
      ownerName: "Dhanalakshmi",
      ownerNameLabel: "Owner Name",
      typeVechi: "2W",
      typeVechiLabel: "Type of Vehicle",
      socLeft: "56km Left",
      socLabel: "SOC/Km Left",
      actionButton: "Deactive",
      actionLabel: "Action Button",
      status: "healthy",
      statusLabel: "Status",
      vechiModel: "Honda",
      vechimodelLabel: "Vehicle Model",
      chassiNum: 12345,
      chassiLabel: "Chassis Number",
      engineNum: "ABDG765TYS",
      engineLabel: "Engine Label",
      batteryModelInfo: "This is Battery",
      batteryModelLabel: "Battery Model Related Info",
      motorInfo: "This is Motor",
      motorInfoLabel: "Motor Controller Related Info",
      telematicsInfo: "This is Telematics",
      telematicLabel: "Telematics Related Info",
      chargerInfo: "This is Charger",
      chagerInfoLabel: "Charger related info",
      insuExpDate: "06/11/2025",
      permitExpDate: "02/12/2024",
      manufacDate: "12/12/2009",
    },
  ];

  const [dataState, setDataState] = useState({
    vechiModel: "",
    vechiSeats: "",
    status: "",
    weight: "",
  });
  // const classes = useStyles();

  const getTitle = (val) => {
    if (val === 0) {
      return "COMMERCIAL";
    }
    if (val === 1) {
      return "E-RICKSHAW";
    }
    return "MODEL";
  };

  const getColumns = (value) => {
    if (value === 0) {
      return VehicleColumn;
    }
    if (value === 1) {
      return ErickColumn;
    }
    return VehicleModel;
  };

  const getData = (value) => {
    if (value === 0) {
      return VehiData;
    }
    if (value === 1) {
      return erickData;
    }
    return ModelData;
  };

  const [frame, setFrame] = React.useState(false);
  const [openEdit, setOpenEdit] = React.useState(false);
  const [rowIndex, setRowIndex] = React.useState(0);

  const VehicleColumn = [
    {
      name: "Vehicle Number",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography
            onClick={() => setScreen(true)}
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Type",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography>
            <Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" />
          </Typography>
        ),
      },
    },
    {
      name: "Vehicle Owner",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
        ),
      },
    },
    {
      name: "Investor",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "Driver Name",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2" 
              style={{ color: "#33a6ff",textAlign: "center" }}
            >
              {value}
            </Typography>
          );
        },
      },
    },
    {
      name: "Battrey",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2" 
              style={{ color: "#33a6ff",textAlign: "center" }}
            >
              {value}
            </Typography>
          );
        },
      },
    },
    {
      name: "Distance to Empty",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2" 
              style={{ textAlign: "center" }}
            >
              {value}
            </Typography>
          );
        },
      },
    },
    {
      name: 'Assignment States',
      options: {
          filter: true,
          customBodyRender: (value) => {
              if (value) {
                  return (
                      <>
                      <IconButton><Icon icon="bxs:edit-alt" color="#33a6ff" width="30" height="30" /></IconButton>
                      <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                      <IconButton><Icon icon="healthicons:truck-driver" color="#82E219" width="30" height="30" /></IconButton>
                      <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>
                      </>)
                  } else {
                  return (
                    <>
                    <IconButton><Icon icon="bxs:edit-alt" color="#33a6ff" width="30" height="30" /></IconButton>
                    <IconButton><Icon icon="mdi:motorbike" color="#82E219" width="30" height="30" /></IconButton>
                    <IconButton><Icon icon="healthicons:truck-driver" color="#82E219" width="30" height="30" /></IconButton>
                    <IconButton><Icon icon="mdi:car-battery" color="#82E219" width="30" height="30" /> </IconButton>
                    </> )
              }


          },
          
      },
      
  }, 
  ];
  const ErickColumn = [
    {
      name: "Vehicle Number",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography
            onClick={() => setScreen(true)}
            style={{ color: "#33a6ff", cursor: "pointer", textAlign: "center" }}
            variant="subtitle2"
          >
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Owner Name",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
        ),
      },
    },
    {
      name: "SOC/Km Left",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography
              variant="subtitle2"
              color="secondary"
              style={{ textAlign: "center" }}
            >
              {value}
            </Typography>
          );
        },
      },
    },

    {
      name: "Action Button",
      options: {
        filter: true,
        customBodyRender: (value, MUIDataTableMeta) => {
          return (
            <Select style={{ minWidth: 150, color: "#FFC130" }} value="deactive">
              <MenuItem style={{ color: "red !important" }} value="deactive">
                Deactivate
              </MenuItem>
              <MenuItem style={{ color: "#FFC130 !important" }} value="assign">
                Assign
              </MenuItem>
              <MenuItem
                style={{ color: "#FFC130 !important" }}
                value="edit"
                onClick={() => {
                  setOpenEdit(true);
                  setRowIndex(MUIDataTableMeta.rowIndex);
                }}
              >
                Edit
              </MenuItem>
            </Select>
          );
        },
      },
    },
    {
      name: "Status",
      options: {
        filter: true,
        customBodyRender: (value) => {
          if (value === "unhealthy") {
            return (
              <Button
                variant="contained"
                style={{
                  minWidth: 130,
                  background: "#FFC130",
                  color: "white",
                  fontSize: "13px",
                }}
                //onClick={()=>getRow("5")}
              >
                {value}
              </Button>
            );
          } else {
            return (
              <Button
                variant="contained"
                style={{ minWidth: 130, background: "#68A724", color: "white" }}
              >
                {value}
              </Button>
            );
          }
        },
      },
    },
  ];
  const VehicleModel = [
    {
      name: "Vehicle Model",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography
            //onClick={() => setScreen(true)}
            style={{ color: "#000000", cursor: "pointer" }}
            variant="subtitle2"
          >
            {value}
          </Typography>
        ),
      },
    },
    {
      name: "Seating",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
        ),
      },
    },
    {
      name: "Top Speed",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <Typography variant="subtitle2">{value}</Typography>
          //   <LinearProgress variant="determinate" color="secondary" value={value} />
        ),
      },
    },
    {
      name: "Payload Weight",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography variant="subtitle2" color="secondary">
              {value}
            </Typography>
          );
        },
      },
    },
    {
      name: "Typical Range",
      options: {
        filter: true,

        customBodyRender: (value) => {
          return (
            <Typography variant="subtitle2" color="secondary">
              {value}
            </Typography>
          );
        },
      },
    },

    {
      name: "Action Button",
      options: {
        filter: true,
        customBodyRender: (value, MUIDataTableMeta) => {
          return (
            <Select style={{ minWidth: 150, color: "#FFC130" }} value="action">
              <MenuItem style={{ color: "red !important" }} value="action">
                Action
              </MenuItem>
             
              <MenuItem
                style={{ color: "#FFC130 !important" }}
                value="edit"
                onClick={() => {
                  setOpenEdit(true);
                  setRowIndex(MUIDataTableMeta.rowIndex);
                }}
              >
                Edit
              </MenuItem>
              <MenuItem style={{ color: "#FFC130 !important" }} value="delete">
                Delete
              </MenuItem>
            </Select>
          );
        },
      },
    },
  ];

  const VehiData = [
    [
      "TN 12 C1234","",
      "Pukazhini", 
      "Evify",
      "Hari",
      "ER2500T12",
      "4.25"
    ],
    ["TN 12 u4234","", " Dhanalakashmi", "Shell", "Krishnan", "INV48V100Ah", "8.25"],
     
  ];
  const erickData = [
    [
      "TN 12 C1234",
      "Pukazhini",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    ["TN 12 u4234", " Dhanalakashmi", "56 KM Left", "deactive", "healthy"],
    [
      "TN 12 I1489",
      " kamalakkannan ",
      "56 KM Left",
      "deactive",
      "healthy",
    ],
    ["TN 12 M1598", "Pukazhini",  "56 KM Left", "Assign", "unhealthy"],
    ["TN 12 V3698", "Dhanalakshmi", "56 KM Left", "deactive", "healthy"],
  ];
  const ModelData = [
    ["TVS ", " 4 Seating", "80km", "105", "40-50", "edit"],
    ["Honda ", " 3 Seating", "280km", "105", "40-50", "edit"],
    ["TVS ", " 4 Seating", "80km", "105", "40-50", "edit"],
    ["Honda ", " 4 Seating", "50km", "105", "40-50", "edit"],
    ["Honda ", " 3 Seating", "80km", "105", "40-50", "edit"],
    ["TVS ", " 4 Seating", "80km", "105", "40-50", "edit"],
    ["TVS ", " 3 Seating", "40km", "105", "40-50", "edit"],
    ["Honda ", " 4 Seating", "80km", "105", "40-50", "edit"],
  ];

  return (
    <div onMouseEnter={() => setFrame(true)} className={classes.table}>
      <Tabs
        // value={tableMode}
        className={classes.tabsSection}
        value={value}
        // onChange={handleTableChange}
        onChange={handleChange}
        variant="fullWidth"
        indicatorColor="primary"
        // textColor="primary"
        aria-label="icon tabs example"
      >
        <Tab
          label="Commercial"
          onClick={() => setScreen(false)}
          icon={<AirportShuttleIcon/>}
          aria-label="favorite"
        />
        <Tab
          label="E-Rickshaw"
          onClick={() => setScreen(false)}
          icon={<Icon icon="material-symbols:electric-rickshaw" width="30" height="30"/>}
          aria-label="phone"
        />
        <Tab
          label={"Model"}
          onClick={() => setScreen(false)}
          icon={<TabIcon/>}
          aria-label="phone"
        /> 
      </Tabs>

      <Paper square className={classes.root} />

      {screen !== true ? (
        <>
          <MUIDataTable
            checkboxSelection={false}
            title={getTitle(value)}
            data={getData(value)}
            columns={getColumns(value)}
            options={options}
            selectableRows={1}
            selectableRowsHideCheckboxes
            //toolbar={toolbar}
            // onRowClick={window.alert('hi')}
            // onCellClick={window.alert('hi')}
          />

          <Dialog
            //fullScreen={fullScreen}
            open={openEdit}
            maxWidth={"lg"}
            onClose={() => setOpenEdit(false)}
            aria-labelledby="responsive-dialog-title"
            className={classes.dialogPaper}
          >
            <DialogContent>
              <div className={classes.divStyle}>
                <DialogTitle id="responsive-dialog-title">
                 Vehicle
                </DialogTitle>
                <Grid container spacing={2}>
                  {/* <Grid item lg={6} xs={12}>
                <Typography className={classes.styleL}>
                  Vehicle Model
                </Typography>
                <FormControl className={classes.styleO}>
                  <Select
                    value={dataState.vechiModel}
                    onChange={handleChange}
                    
                  >
                    <MenuItem value="1">Vehicle Model</MenuItem>
                    <MenuItem value={2}>Hero</MenuItem>
                    <MenuItem value={3}>Honda</MenuItem>
                    <MenuItem value={4}>TVS</MenuItem>
                  </Select>
                </FormControl>
              </Grid> */}

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Vehicle Number
                    </Typography>
                    <TextField
                      size="small"
                      id="outlined"
                      className={classes.styleO}
                      placeholder="eg:  Vehicle Number"
                      defaultValue={vechList[rowIndex].vehiNumber}
                    />
                  </Grid>

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Chassis Number
                    </Typography>
                    <TextField
                      size="small"
                      id="outlined"
                      className={classes.styleO}
                      placeholder="eg:  Chassis Number"
                      defaultValue={vechList[rowIndex].chassiNum}
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Engine Number
                    </Typography>
                    <TextField
                      size="small"
                      id="outlined"
                      className={classes.styleO}
                      placeholder="eg:  Engine Number"
                      defaultValue={vechList[rowIndex].engineNum}
                    />
                  </Grid>

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Owner Name
                    </Typography>
                    <TextField
                      size="small"
                      id="outlined"
                      className={classes.styleO}
                      placeholder="eg: Owner Name"
                      defaultValue={vechList[rowIndex].ownerName}
                    />
                  </Grid>

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Battery Model Related Info
                    </Typography>
                    <TextField
                      size="small"
                      id="outlined"
                      className={classes.styleO}
                      placeholder="eg: Battery Model Info"
                      defaultValue={vechList[rowIndex].batteryModelInfo}
                    />
                  </Grid>

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      
                      Motor Controller Related Info
                    </Typography>
                    <TextField
                      size="small"
                      id="outlined"
                      className={classes.styleO}
                      placeholder="eg: Motor Controller Info"
                      defaultValue={vechList[rowIndex].motorInfo}
                    />
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Telematics Related Info
                    </Typography>
                    <TextField
                      size="small"
                      id="outlined"
                      className={classes.styleO}
                      placeholder="eg: Telematics Related Info"
                      defaultValue={vechList[rowIndex].telematicsInfo}
                    />
                  </Grid>

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Charger related info
                    </Typography>
                    <TextField
                      size="small"
                      id="outlined"
                      className={classes.styleO}
                      placeholder="eg: Charger related info"
                      defaultValue={vechList[rowIndex].chargerInfo}
                    />
                  </Grid>

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Insurance Expiry Date
                    </Typography>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="MM/dd/yyyy"
                        margin="normal"
                        id="date-picker-inline"
                        value={insuExpDate}
                        onChange={handleDateChange1}
                        className={classes.styleO}
                        KeyboardButtonProps={{
                          "aria-label": "change date",
                        }}
                      />
                    </MuiPickersUtilsProvider>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Permit Expiry Date
                    </Typography>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="MM/dd/yyyy"
                        margin="normal"
                        id="date-picker-inline"
                        value={permitExpDate}
                        onChange={handleDateChange2}
                        className={classes.styleO}
                        KeyboardButtonProps={{
                          "aria-label": "change date",
                        }}
                      />
                    </MuiPickersUtilsProvider>
                  </Grid>

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Manufacturing Date
                    </Typography>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="MM/dd/yyyy"
                        margin="normal"
                        id="date-picker-inline"
                        value={manufaDate}
                        onChange={handleDateChange3}
                        className={classes.styleO}
                        KeyboardButtonProps={{
                          "aria-label": "change date",
                        }}
                      />
                    </MuiPickersUtilsProvider>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Upload RC Book
                    </Typography>
                    <Button
                      sx={{
                        ":hover": { backgroundColor: "#fff" },
                      }}
                    >
                      <input type="file" style={{ color: "#C1C1C1" }} />
                    </Button>
                  </Grid>

                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Upload Insurance
                    </Typography>

                    <Button
                      sx={{
                        ":hover": { backgroundColor: "#fff" },
                      }}
                    >
                      <input type="file" style={{ color: "#C1C1C1" }} />
                    </Button>
                  </Grid>
                  <Grid item lg={6} xs={12}>
                    <Typography className={classes.styleL}>
                      Upload Permit Image
                    </Typography>
                    <Button
                      sx={{
                        ":hover": { backgroundColor: "#fff" },
                      }}
                    >
                      <input type="file" style={{ color: "#C1C1C1" }} />
                    </Button>
                  </Grid>
                </Grid>
              </div>
            </DialogContent>
            <DialogActions>
              <Button
                autoFocus
                onClick={() => setOpenEdit(false)}
                color="secondary"
              >
                Cancel
              </Button>
              <Button
                onClick={() => setOpenEdit(false)}
                color="primary"
                autoFocus
              >
                Update
              </Button>
            </DialogActions>
          </Dialog>
        </>
      ) : (
        <Grid container style={{ marginTop: 40 }}>
          <Grid item xs>
            <Grid item xs>
              {/* <Typography className={classes.graphText} >Battery Voltage, Current</Typography> */}
              <Select
                className={classes.graphSelect}
                value={chartOneVal}
                onChange={handleChartOneVal}
              >
                {dayDropdown.map((m) => {
                  return <MenuItem value={m.val}>{m.name}</MenuItem>;
                })}
              </Select>
              <Chart1 dataIndex={chartOneVal} />
            </Grid>
            <Grid item xs>
              {/* <Typography className={classes.graphText} >Battery Voltage, Current</Typography> */}

              <Select className={classes.graphSelect} value="day">
                {dayDropdown.map((m) => {
                  return <MenuItem value={m.val}>{m.name}</MenuItem>;
                })}
              </Select>
              <Chart3 />
            </Grid>
          </Grid>
          <Grid xs item>
            <Grid item xs>
              <Select className={classes.graphSelect} value="day">
                {dayDropdown.map((m) => {
                  return <MenuItem value={m.val}>{m.name}</MenuItem>;
                })}
              </Select>
              <Chart4 />
            </Grid>
            <Grid item xs>
              <Select className={classes.graphSelect} value="day">
                {dayDropdown.map((m) => {
                  return <MenuItem value={m.val}>{m.name}</MenuItem>;
                })}
              </Select>
              <Chart2 />
            </Grid>
          </Grid>
        </Grid>
      )}

      <br />
      <Typography align="center" className={classes.copyRight}>
        Copyright© 2023 ReVx Energy Pvt.Ltd.
      </Typography>
    </div>
  );
}
