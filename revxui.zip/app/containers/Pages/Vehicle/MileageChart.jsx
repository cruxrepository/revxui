import React from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import { createTheme, withStyles } from '@material-ui/core/styles';
import ThemePallete from 'enl-api/palette/themePalette';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  CartesianAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { data1 , data1year, data1month } from './sampleData';
// import styles from './fluidChart-jss';
import { Typography } from '@material-ui/core';
import endpoints from '../../../endpoints/endpoints';
const theme = createTheme(ThemePallete.magentaTheme);
const color = ({
  primary: "#68A724",
  secondary: theme.palette.secondary.main,
});

const CustomizedLabel = props => {
  const {
    x,
    y,
    stroke,
    value
  } = props;
  return (
    <text x={x} y={y} dy={-4} fill={stroke} fillOpacity="0.8" fontSize={10} textAnchor="middle">
      { value }
    </text>
  );
};

CustomizedLabel.propTypes = {
  x: PropTypes.number,
  y: PropTypes.number,
  value: PropTypes.number,
  stroke: PropTypes.string,
};

CustomizedLabel.defaultProps = {
  x: 0,
  y: 0,
  value: 0,
  stroke: '#000'
};
const CustomizedLabelnew = (props) => {
  const {text}=props;
  return(
    <Typography>{text} </Typography>
  )
}

function Chart1(props) {
  const { vid } = props;
  const [ graphData , setGraphData ] = React.useState([]);

  React.useEffect(() => {
    let Url = endpoints.baseUrl + `/vehicle/dashboard/`+vid;
    axios.get(Url).then((response) => {
      setGraphData(response.data.data[0].c_mileage)
    }).catch((error) => { })  
    
    },[])
    console.log("graphData",graphData)
  return (
    <div >
      <ResponsiveContainer width="100%" height={250}>
        <LineChart
          width="100%"
          height={250}
          data={graphData}
          // margin={{
          //   top: 5,
          //   right: 30,
          //   left: 15,
          //   bottom: 5
          // }}
        >
          <XAxis dataKey="time" tickLine={false} stroke="#106dcf"/>
          <YAxis dataKey="mileage" stroke="#106dcf"
          // label={{className:'yaxix-value', value: 'Battery Current', angle: -90, position: 'insideLeft', marginLeft:'-10px' }}
            // axisLine={false} 
            tickSize={3} tickLine={false} tickFormatter={tick => `  ${tick}` } tick={{ stroke: 'none' }} />
          {/* <CartesianGrid vertical={false} strokeDasharray="3 3" />
          <CartesianAxis vertical={false} /> */}
          <Tooltip />
 
          <Line dot={false} type="monotone" dataKey="mileage" strokeWidth={3} stroke={color.primary} 
          // label={<CustomizedLabel stroke={color.primary} />} 
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// Chart1.propTypes = {
//   classes: PropTypes.object.isRequired,
// };

export default Chart1;