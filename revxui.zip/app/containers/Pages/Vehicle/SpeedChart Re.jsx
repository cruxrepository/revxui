import React from "react";
import { render } from "react-dom";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";

export default function Chart() {
    const options = {
        chart: {
            type: "spline"
        },
        title: {
            align: "left",text: "Speed"
        },
        legend: false,
        series: [
            {
                data: [1, 2, 1, 4, 3, 6]
            }
        ]
    };

    return (
        <HighchartsReact highcharts={Highcharts} options={options} />
    );
}
// render(<App />, document.getElementById("root"));
