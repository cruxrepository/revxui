export const data1 = [
  {
    name: "9 AM",

    percentage: 30,
  },
  {
    name: "10 AM",

    percentage: 50,
  },
  {
    name: "11 AM",

    percentage: 10,
  },
  {
    name: "12 AM",

    percentage: 60,
  },
  {
    name: "1 PM",

    percentage: 50,
  },
  {
    name: "2 PM",

    percentage: 70,
  },
  {
    name: "3 PM",

    percentage: 80,
  },
  {
    name: "4 PM",

    percentage: 50,
  },
  {
    name: "5 AM",

    percentage: 60,
  },
  {
    name: "6 PM",

    percentage: 50,
  },
  {
    name: "7 PM",

    percentage: 70,
  },
  {
    name: "8 PM",

    percentage: 90,
  },
  {
    name: "9 PM",

    percentage: 40,
  },
];
export const data2 = [
  {
    name: "9 AM",

    percentage: 40,
  },
  {
    name: "10 AM",

    percentage: 60,
  },
  {
    name: "11 AM",

    percentage: 55,
  },
  {
    name: "12 AM",

    percentage: 80,
  },
  {
    name: "1 PM",

    percentage: 57,
  },
  {
    name: "2 PM",

    percentage: 70,
  },
  {
    name: "3 PM",

    percentage: 80,
  },
  {
    name: "4 PM",

    percentage: 100,
  },
  {
    name: "5 PM",

    percentage: 57,
  },
  {
    name: "6 PM",

    percentage: 70,
  },
  {
    name: "7 PM",

    percentage: 80,
  },
  {
    name: "8 PM",

    percentage: 100,
  },
];
