import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";

import Paper from "@material-ui/core/Paper";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import './style.css';
import { useDispatch, useSelector } from 'react-redux';
import { getTelematicsBulk, getTeleListBulk, getTeleModelBulk, getTeleListTotalBulk, getTMBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import endpoints from "../../../endpoints/endpoints";
import ErrorWrap from '../../../components/Error/ErrorWrap';
import SimpleSnackbar from '../Users/SimpleSnackbar';
import Pagination from '@material-ui/lab/Pagination';
import { InputLabel, ListItemText, Tab, Tabs, Tooltip } from "@material-ui/core";
import { StepButton } from "@material-ui/core";
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import { CloudDownload } from "@material-ui/icons";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  gst: {
    color: '#4CAF50'
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  tabHelp: {
    fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
  },
  formControl: {
    width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
  },
  textField: {
    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
  },
  autoComplete: {
    '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
  },
  dialog: {
    position: 'relative', marginLeft: '630px'
  },

  dialogPaper: {
    height: "85%",
    width: "50%",
    marginLeft: '700px'
  },
  BNsecondaryTextG: { color: '#00FF00' },
  tabsSection: {
    [theme.breakpoints.up('lg')]: {
      // borderRadius:0,position:'sticky',top:0 ,width:500
      borderRadius: 0, top: 0, width: 400

    },
  },
  tabsSectionrr: {
      [theme.breakpoints.up('lg')]: {
          // borderRadius:0,position:'sticky',top:0 ,width:500
          borderRadius: 0, top: 0, width: 150

      },
  },
}));



/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function Telematics() {
  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const [value, setValue] = React.useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const classes = useStyles();
  const validateKeyData = (key) => {
    return key ? key : "-";
  };
  const [openAdd, setOpenAdd] = React.useState(false);
  const [openEdit, setOpenEdit] = React.useState(false);
  const [openTeleList, setOpenTeleList] = React.useState(false);
  const [openTeleListEdit, setOpenTeleListEdit] = React.useState(false);
  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(3000)
  const [addResponse, setAddResponce] = React.useState("")
  const [page, setPage] = React.useState(1);

  const changePage = (event, newValue) => {
    setPage(newValue);
  };
  const [pagee, setPagee] = React.useState(1);

  const changePagee = (event, newValue) => {
    setPagee(newValue);
  };
  const logged_user = useSelector((store) => store.login.result);
  let telematicsEditAccess = logged_user.telematics === "edit"
  let pWord = logged_user.password
  const ppp = useSelector((store) => store.login.result.password);
  let urId = logged_user.user_id 
  let roid = logged_user.role_id
  let enty = logged_user.entity_id
  const UserName = useSelector((store) => store.login.result.username);

  const TelematicsData = useSelector((store) => store.telematicsAll)
  const TelematicsDataRaw = useSelector((store) => store.telematicsAll.rawData)
  let TelematicsMeta = {};
  TelematicsMeta.data = [];
  let TelematicsMetaa = useSelector((store) => store.telematicsAll)
  if (TelematicsMetaa.data.length >= 1) {
    TelematicsMeta.data = TelematicsMetaa.data;
  }
  const MyTelematicsPage = useSelector((store) => store.telematicsAll.page_number)
  const MyTelematicsCount = Math.ceil(useSelector((store) => store.telematicsAll.total_records) / 10)
  let TelematicsFetching = useSelector((store) => store.telematicsAll.fetching)
  let TelematicsResponsecode = useSelector((store) => store.telematicsAll.responseStatus)
  let TelematicsMetaPresent = useSelector((store) => store.telematicsAll.dataPresent)


  const TeleListData = useSelector((store) => store.tList)
  const TeleListDataRaw = useSelector((store) => store.tList.rawData)
  let TeleListMeta = {};
  TeleListMeta.data = [];
  let TeleListMetaa = useSelector((store) => store.tList)
  if (TeleListMetaa.data.length >= 1) {
    TeleListMeta.data = TeleListMetaa.data;
  }
  const MyTeleListPage = useSelector((store) => store.tList.page_number)
  const MyTeleListCount = Math.ceil(useSelector((store) => store.tList.total_records) / 10)
  let TeleListFetching = useSelector((store) => store.tList.fetching)
  let TeleListResponsecode = useSelector((store) => store.tList.responseStatus)
  let TeleListMetaPresent = useSelector((store) => store.tList.dataPresent)

  const TeleListTotalData = useSelector((store) => store.teleAll)
  const TeleListTotalDataRaw = useSelector((store) => store.teleAll.rawData)
  let TeleListTotalMeta = {};
  TeleListTotalMeta.data = [];
  let TeleListTotalMetaa = useSelector((store) => store.teleAll)
  if (TeleListTotalMetaa.data.length >= 1) {
    TeleListTotalMeta.data = TeleListTotalMetaa.data;
  }
  let TeleListTotalFetching = useSelector((store) => store.teleAll.fetching)
  let TeleListTotalResponsecode = useSelector((store) => store.teleAll.responseStatus)
  let TeleListTotalMetaPresent = useSelector((store) => store.teleAll.dataPresent)

  let TDBC = TeleListTotalMeta.data.map(function (el) { return el[0]; });
  let TModel_info = TeleListTotalMeta.data.map(function (el) { return el[1]; });
  let TIMEI = TeleListTotalMeta.data.map(function (el) { return el[2]; });
  let TMobile = TeleListTotalMeta.data.map(function (el) { return el[3]; });
  let TSim = TeleListTotalMeta.data.map(function (el) { return el[4]; });

  //Telematics Model
  const TeleModelData = useSelector((store) => store.teleModelAll)
  const TeleModelDataRaw = useSelector((store) => store.teleModelAll.rawData)
  let TeleModelMeta = useSelector((store) => store.teleModelAll)
  let TeleModelFetching = useSelector((store) => store.teleModelAll.fetching)
  let TeleModelResponsecode = useSelector((store) => store.teleModelAll.responseStatus)
  let TeleModelMetaPresent = useSelector((store) => store.teleModelAll.dataPresent)

  const TMData = useSelector((store) => store.tmAll)
  const TMDataRaw = useSelector((store) => store.tmAll.rawData)
  let TMMeta = {};
  TMMeta.data = [];
  let TMMetaa = useSelector((store) => store.tmAll)
  if (TMMetaa.data.length >= 1) {
    TMMeta.data = TMMetaa.data;
  }
  let TMFetching = useSelector((store) => store.tmAll.fetching)
  let TMResponsecode = useSelector((store) => store.tmAll.responseStatus)
  let TMMetaPresent = useSelector((store) => store.tmAll.dataPresent)

  let TMModel_info = TMMeta.data.map(function (el) { return el[0]; });
  let TMOEM = TMMeta.data.map(function (el) { return el[1]; });
  let TMSim_Type = TMMeta.data.map(function (el) { return el[2]; });
  let TMProtocal = TMMeta.data.map(function (el) { return el[3]; });

  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getTeleModelBulk());
    dispatch(getTeleListTotalBulk(enty,urId,roid));
    dispatch(getTMBulk());
    dispatch(getTelematicsBulk(page));
    dispatch(getTeleListBulk(enty,urId,roid,pagee));
  }, [TeleModelMetaPresent, TeleListMetaPresent, TelematicsMetaPresent, page, pagee, TeleListTotalMetaPresent, TMMetaPresent]);


  const [open, setOpen] = React.useState(false);
  const [ddd, setDdd] = React.useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };
  const [open1, setOpen1] = React.useState(false);
  const [ddd1, setDdd1] = React.useState(false);

  const handleClick1 = () => {
    setOpen1(true);
  };

  const handleClose1 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen1(false);
  };
  const [open2, setOpen2] = React.useState(false);
  const [ddd2, setDdd2] = React.useState(false);

  const handleClick2 = () => {
    setOpen2(true);
  };

  const handleClose2 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen2(false);
  };
  const [open3, setOpen3] = React.useState(false);
  const [ddd3, setDdd3] = React.useState(false);

  const handleClick3 = () => {
    setOpen3(true);
  };

  const handleClose3 = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen3(false);
  };

  // Add Telematics
  const [addForm, setAddForm] = React.useState(
    {
      model_info: "",
      oem: "",
      sim_type: "",
      protocal: "",
      datasheet_attachment: "",
      created_by: UserName,
      updated_by: ""
    }
  )
  const submit = () => {
    if (addForm.model_info && addForm.oem && addForm.sim_type && addForm.protocal && addForm.datasheet_attachment) {
      const post = endpoints.baseUrl + `/telematics/add`;

      axios
        .post(post, addForm)
        .then((response) => {
          handleClick2(true);
          response.status === 201 ? setDdd2("Telematics onboarded successfully!") : setDdd2(response.message)
        });
      dispatch(getTelematicsBulk(page));
      setAddForm({})
      setOpenAdd(false);
    } else {
      handleClick3(true);
      setDdd3("Please fill the required fields")

    }

  }
  const setAddFormArray = (e, key, array) => {
    setAddForm((state) => ({ ...state, [key]: e.target.value }));

  }

  const handleSubmitAdd = () => {
    submit(true)
  }

  //Edit Telematics
  const [editLArray, setEditLArray] = React.useState({})
  const setEditLFormArray = (e, key) => {
    setEditLArray((state) => ({ ...state, [key]: e.target.value }));

  }

  const submitLEdit = () => {

    if ((editLArray.updated_by = UserName) && editLArray.telematics_model_id && editLArray.imei && editLArray.mobile_number && editLArray.sim_operator) {
      const putL = endpoints.baseUrl + `/telematicsnew/update/` + editLArray.telematics_id;
      let newEditLArray = editLArray;
      axios
        .put(putL, newEditLArray)
        .then((response) => {
          handleClick2(true);
          response.status === 200 ? setDdd2("Telematics details edited successfully!") : setDdd2(response.message)
          setOpenTeleListEdit(false)
          dispatch(getTeleListBulk(enty,urId,roid,pagee));
        });
      setOpenTeleListEdit(false)

    } else {
      handleClick3(true);
      setDdd3("Please fill the required fields")

    }
  }
  const setLEditArray = (telematics_id) => {
    let allList = TeleListDataRaw;
    let findLArray = allList.find(el => el.telematics_id === telematics_id)
    setEditLArray(findLArray);
  }
  //Edit Telematics model
  const [editArray, setEditArray] = React.useState(
    {
    }
  )
  const setEditFormArray = (e, key) => {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));

  }

  const submitEdit = () => {

    if ((editArray.updated_by = UserName) && editArray.model_info && editArray.oem && editArray.sim_type && editArray.protocal && editArray.datasheet_attachment) {
      const put = endpoints.baseUrl + `/telematics/edit/` + editArray.telematics_model_id;
      let newEditArray = editArray;
      axios
        .put(put, newEditArray)
        .then((response) => {
          handleClick2(true);
          response.status === 200 ? setDdd2("Telematics details edited successfully!") : setDdd2(response.message)
          dispatch(getTelematicsBulk(page));
          setOpenEdit(false)
          setEditArray({

          })
        });
      setOpenEdit(false)

    } else {
      handleClick3(true);
      setDdd3("Please fill the required fields")

    }
  }
  const setTelematicsEditArray = (telematics_model_id) => {
    let allTelematics = TelematicsDataRaw;
    let findArray = allTelematics.find(el => el.telematics_model_id === telematics_model_id)
    setEditArray(findArray);
  }

  // Delete Telematics
  const deleteTelematics = (telematics_model_id) => {
    const deleteT = endpoints.baseUrl + `/telematics/SoftDelete/` + telematics_model_id;
    axios
      .delete(deleteT)
      .then((response) => {
        handleClick2(true);
        response.status === 200 ? setDdd2("Telematics model offboarded successfully!") : setDdd2(response.message)
        setDelete1(false)
        setPassword1()
        dispatch(getTelematicsBulk(page));
      });
  }

  const [openD, setOpenD] = React.useState(false);
  const [openD1, setOpenD1] = React.useState(false);
  const [file, setFile] = React.useState()
  function handleChangeDataSheet(event) {
    setFile(event.target.files[0])


    event.preventDefault()
    const url = endpoints.baseUrl + '/upload';
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('fileName', event.target.files[0].name);
    const config = {
      headers: {
        'content-type': 'multipart/form-data',
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setAddForm((state) => ({ ...state, datasheet_attachment: response.data }));

    });

  }
  function handleChangeDataSheetEdit(event) {
    setFile(event.target.files[0])


    event.preventDefault()
    const url = endpoints.baseUrl + '/upload';
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('fileName', event.target.files[0].name);
    const config = {
      headers: {
        'content-type': 'multipart/form-data',
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setEditArray((state) => ({ ...state, datasheet_attachment: response.data }));

    });

  }

  const [password1, setPassword1] = React.useState("");
  const [password2, setPassword2] = React.useState("");
  const [delete1, setDelete1] = React.useState("");
  const [delete2, setDelete2] = React.useState("");
  const [selectedId1, setSelectedId1] = React.useState("");
  const [selectedId2, setSelectedId2] = React.useState("");

  const [dataOn, setDataOn] = React.useState(false);
  const [dataOnM, setDataOnM] = React.useState(false);

  const [clear1, setClear1] = React.useState("");
  const [clear2, setClear2] = React.useState("");
  const [clear3, setClear3] = React.useState("");
  const [clear4, setClear4] = React.useState("");
  const [clear5, setClear5] = React.useState("");

  const [clear6, setClear6] = React.useState("");
  const [clear7, setClear7] = React.useState("");
  const [clear8, setClear8] = React.useState("");
  const [clear9, setClear9] = React.useState("");


  const TelematicsColumn = [
    {
      label: "Model Info", name: "model",
      options: {
        filter: true,
        filterList: clear6,
        filterType: 'custom',
        filterOptions: {
          logic: (model_info, filters, row) => {
            if (filters.length) return !filters.includes(model_info);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMModel_info.filter((item,
              index) => TMModel_info.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Model Info</InputLabel>
                <Select

                  multiple
                  value={clear6.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear6(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOnM(true)
                        dispatch(getTMBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "OEM", name: "oem",
      options: {
        filter: true,
        filterList: clear7,
        filterType: 'custom',
        filterOptions: {
          logic: (oem, filters, row) => {
            if (filters.length) return !filters.includes(oem);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMOEM.filter((item,
              index) => TMOEM.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">OEM</InputLabel>
                <Select

                  multiple
                  value={clear7.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear7(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOnM(true)
                        dispatch(getTMBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "SIM Type", name: "sim",
      options: {
        filter: true,
        filterList: clear8,
        filterType: 'custom',
        filterOptions: {
          logic: (sim_type, filters, row) => {
            if (filters.length) return !filters.includes(sim_type);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMSim_Type.filter((item,
              index) => TMSim_Type.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">SIM Type</InputLabel>
                <Select

                  multiple
                  value={clear8.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear8(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOnM(true)
                        dispatch(getTMBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Protocol", name: "protocol",
      options: {
        filter: true,
        filterList: clear9,
        filterType: 'custom',
        filterOptions: {
          logic: (protocal, filters, row) => {
            if (filters.length) return !filters.includes(protocal);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMProtocal.filter((item,
              index) => TMProtocal.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Protocol</InputLabel>
                <Select

                  multiple
                  value={clear9.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear9(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOnM(true)
                        dispatch(getTMBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Datasheet Attachment", name: "datasheet",
      options: {
        filter: true,
        customBodyRender: (value) => (
          // <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
          <img src={value} width="80" height="60" />

        ),
      },
    },
    {
      label: "Action", name: "action",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <><IconButton onClick={() => {
            setTelematicsEditArray(value)
            setOpenEdit(true)
          }} ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
            <IconButton
              onClick={() => {
                setDelete1(true);
                setSelectedId1(value);
                // deleteTelematics(value) 
              }}
            ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /> </IconButton></>
        ),
      },
    },


  ];
  const TelematicsColumn1 = [
    {
      label: "Model Info", name: "model",
      options: {
        filter: true,
        filterList: clear6,
        filterType: 'custom',
        filterOptions: {
          logic: (model_info, filters, row) => {
            if (filters.length) return !filters.includes(model_info);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMModel_info.filter((item,
              index) => TMModel_info.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Model Info</InputLabel>
                <Select

                  multiple
                  value={clear6.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear6(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOnM(true)
                        dispatch(getTMBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "OEM", name: "oem",
      options: {
        filter: true,
        filterList: clear7,
        filterType: 'custom',
        filterOptions: {
          logic: (oem, filters, row) => {
            if (filters.length) return !filters.includes(oem);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMOEM.filter((item,
              index) => TMOEM.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">OEM</InputLabel>
                <Select

                  multiple
                  value={clear7.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear7(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOnM(true)
                        dispatch(getTMBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "SIM Type", name: "sim",
      options: {
        filter: true,
        filterList: clear8,
        filterType: 'custom',
        filterOptions: {
          logic: (sim_type, filters, row) => {
            if (filters.length) return !filters.includes(sim_type);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMSim_Type.filter((item,
              index) => TMSim_Type.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">SIM Type</InputLabel>
                <Select

                  multiple
                  value={clear8.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear8(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOnM(true)
                        dispatch(getTMBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Protocol", name: "protocol",
      options: {
        filter: true,
        filterList: clear9,
        filterType: 'custom',
        filterOptions: {
          logic: (protocal, filters, row) => {
            if (filters.length) return !filters.includes(protocal);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMProtocal.filter((item,
              index) => TMProtocal.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Protocol</InputLabel>
                <Select

                  multiple
                  value={clear9.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear9(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOnM(true)
                        dispatch(getTMBulk());
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Datasheet Attachment", name: "datasheet",
      options: {
        filter: true,
        customBodyRender: (value) => (
          // <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
          <img src={value} width="100" height="60" />

        ),
      },
    },


  ];

  const TeleListColumn = [
    {
      label: "DBC", name: "dbc",
      options: {
        filter: true,
        filterList: clear1,
        filterType: 'custom',
        filterOptions: {
          logic: (dbc_file_type, filters, row) => {
            if (filters.length) return !filters.includes(dbc_file_type);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TDBC.filter((item,
              index) => TDBC.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">DBC</InputLabel>
                <Select

                  multiple
                  value={clear1.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear1(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer",marginLeft:'-10px', align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Model", name: "model",
      options: {
        filter: true,
        filterList: clear2,
        filterType: 'custom',
        filterOptions: {
          logic: (model_info, filters, row) => {
            if (filters.length) return !filters.includes(model_info);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TModel_info.filter((item,
              index) => TModel_info.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Model</InputLabel>
                <Select

                  multiple
                  value={clear2.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear2(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "IMEI", name: "imei",
      options: {
        filter: true,
        filterList: clear3,
        filterType: 'custom',
        filterOptions: {
          logic: (imei, filters, row) => {
            if (filters.length) return !filters.includes(imei);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TIMEI.filter((item,
              index) => TIMEI.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">IMEI</InputLabel>
                <Select

                  multiple
                  value={clear3.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear3(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer",marginLeft:'-6px', align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Mobile", name: "mobile",
      options: {
        filter: true,
        filterList: clear4,
        filterType: 'custom',
        filterOptions: {
          logic: (mobile_number, filters, row) => {
            if (filters.length) return !filters.includes(mobile_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMobile.filter((item,
              index) => TMobile.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Mobile</InputLabel>
                <Select

                  multiple
                  value={clear4.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear4(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "SIM Operator", name: "sim",
      options: {
        filter: true,
        filterList: clear5,
        filterType: 'custom',
        filterOptions: {
          logic: (sim_operator, filters, row) => {
            if (filters.length) return !filters.includes(sim_operator);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TSim.filter((item,
              index) => TSim.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">SIM Operator</InputLabel>
                <Select

                  multiple
                  value={clear5.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear5(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Action", name: "action",
      options: {
        filter: false,
        customBodyRender: (value) => (
          <><IconButton onClick={() => {
            setLEditArray(value.telematics_id)
            setOpenTeleListEdit(true)
          }} ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
            <IconButton
              onClick={() => {
                if (value.telematassign_status === "assign" && value.vehicle_number != "") {
                  handleClick(true);
                  setDdd(value.vehicle_number)
                }
                else if (value.telematassign_status === "assign" && value.serial_number != "") {
                  handleClick1(true);
                  setDdd1(value.serial_number)
                }
                else {
                  setDelete2(true);
                  setSelectedId2(value.telematics_id);
                }
              }}
            ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" />
            </IconButton>
          </>
        ),
      },
    },


  ];
  const TeleListColumn1 = [
    {
      label: "DBC", name: "dbc",
      options: {
        filter: true,
        filterList: clear1,
        filterType: 'custom',
        filterOptions: {
          logic: (dbc_file_type, filters, row) => {
            if (filters.length) return !filters.includes(dbc_file_type);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TDBC.filter((item,
              index) => TDBC.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">DBC</InputLabel>
                <Select

                  multiple
                  value={clear1.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear1(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Model", name: "model",
      options: {
        filter: true,
        filterList: clear2,
        filterType: 'custom',
        filterOptions: {
          logic: (model_info, filters, row) => {
            if (filters.length) return !filters.includes(model_info);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TModel_info.filter((item,
              index) => TModel_info.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Model</InputLabel>
                <Select

                  multiple
                  value={clear2.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear2(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "IMEI", name: "imei",
      options: {
        filter: true,
        filterList: clear3,
        filterType: 'custom',
        filterOptions: {
          logic: (imei, filters, row) => {
            if (filters.length) return !filters.includes(imei);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TIMEI.filter((item,
              index) => TIMEI.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">IMEI</InputLabel>
                <Select

                  multiple
                  value={clear3.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear3(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "Mobile", name: "mobile",
      options: {
        filter: true,
        filterList: clear4,
        filterType: 'custom',
        filterOptions: {
          logic: (mobile_number, filters, row) => {
            if (filters.length) return !filters.includes(mobile_number);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TMobile.filter((item,
              index) => TMobile.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">Mobile</InputLabel>
                <Select

                  multiple
                  value={clear4.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear4(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },
    {
      label: "SIM Operator", name: "sim",
      options: {
        filter: true,
        filterList: clear5,
        filterType: 'custom',
        filterOptions: {
          logic: (sim_operator, filters, row) => {
            if (filters.length) return !filters.includes(sim_operator);
            return false;
          },
          display: (filterList, onChange, index, column) => {
            const optionValues = TSim.filter((item,
              index) => TSim.indexOf(item) === index);
            return (
              <FormControl >
                <InputLabel htmlFor="select-multiple-chip">SIM Operator</InputLabel>
                <Select

                  multiple
                  value={clear5.length === 0 ? [] : filterList[index]}
                  renderValue={selected => selected.join(', ')}
                  onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                    setClear5(filterList[index], index, column);
                  }}

                >
                  {optionValues.map(item => (
                    <MenuItem key={item} value={item}
                      onClick={() => {
                        setDataOn(true)
                        dispatch(getTeleListTotalBulk(enty,urId,roid));
                      }}
                    >
                      <ListItemText primary={item}

                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          }
        },
        customBodyRender: (value) => (
          <Typography onClick={() => {
          }}
            style={{ cursor: "pointer", align: "center", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, whiteSpace: 'nowrap' }} variant='subtitle2'>
            {validateKeyData(value)}
          </Typography>

        )
      },
    },


  ];
  const onDownload = () => {
    const headerRow = ["DBC", "Model", "IMEI", "Mobile Number", "Sim Operator"];
    const bodyRows = TeleListTotalMeta.data.length && TeleListTotalMeta.data.map((col) => {
      return [
        col[0],
        col[1],
        col[2],
        col[3],
        col[4]
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }
  const onDownloadTL = () => {
    const headerRow = ["Model Info", "OEM", "Sim Type", "Protocol"];
    const bodyRows = TMMeta.data.length && TMMeta.data.map((col) => {
      return [
        col[0],
        col[1],
        col[2],
        col[3]
      ];
    });

    const csvRows = [headerRow, ...bodyRows];
    const csvContent = "\uFEFF" + csvRows.map(row => row.join(";")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "data.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

  }
  const options = {
    filter: true,
    download: false,
    print: false,
    viewColumns: false,
    search: false,
    selectableRows: "none",
    customToolbar: () => {
      if (telematicsEditAccess === true) {
        return (
          value === 1 ?
            <><IconButton style={{ transform: "translateX(-6em)" }} onClick={() => setOpenAdd(true)}>
              <Icon icon="ic:baseline-electric-car" width="22" height="22" /></IconButton>
              <Tooltip style={{ flex: 'left' }} title={"Download CSV"}>
                <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                  onDownloadTL()
                }}>
                  <CloudDownload />
                </IconButton></Tooltip>
              {clear6 != '' || clear7 != '' || clear8 != '' || clear9 != '' ?
                <Button style={{ width: '100px' }}
                  onClick={() => {
                    setDataOnM(false)
                    setClear6([])
                    setClear7([])
                    setClear8([])
                    setClear9([])
                    dispatch(getTelematicsBulk(page));
                  }}>RESET</Button> : null}</>
            : <>
              <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => setOpenTeleList(true)}><Icon icon="ic:baseline-settings-remote" width="22" height="22" /></IconButton>
              <Tooltip style={{ flex: 'left' }} title={"Download CSV"}>
                <IconButton style={{ transform: "translateX(-6em)" }} onClick={() => {
                  onDownload()
                }}>
                  <CloudDownload />
                </IconButton></Tooltip>
              {clear1 != '' || clear2 != '' || clear3 != '' || clear4 != '' || clear5 != '' ?
                <Button style={{ width: '100px' }}
                  onClick={() => {
                    setDataOn(false)
                    setClear1([])
                    setClear2([])
                    setClear3([])
                    setClear4([])
                    setClear5([])
                    dispatch(getTeleListBulk(enty,urId,roid,pagee));
                  }}>RESET</Button> : null}</>
        );
      }
      else {
        return (
          value === 1 ?
            <>
              {clear6 != '' || clear7 != '' || clear8 != '' || clear9 != '' ?
                <Button style={{ width: '100px' }}
                  onClick={() => {
                    setDataOnM(false)
                    setClear6([])
                    setClear7([])
                    setClear8([])
                    setClear9([])
                    dispatch(getTelematicsBulk(page));
                  }}>RESET</Button> : null}</>
            : <>
              {clear1 != '' || clear2 != '' || clear3 != '' || clear4 != '' || clear5 != '' ?
                <Button style={{ width: '100px' }}
                  onClick={() => {
                    setDataOn(false)
                    setClear1([])
                    setClear2([])
                    setClear3([])
                    setClear4([])
                    setClear5([])
                    dispatch(getTeleListBulk(enty,urId,roid,pagee));
                  }}>RESET</Button> : null}</>
        );
      }
    },
  };

  // Add Telematics List
  const [addList, setAddList] = React.useState(
    {
      telematics_model_id: "",
      imei: "",
      sim_operator: "",
      mobile_number: "",
      created_by: UserName,
      updated_by: "",
      dbc_file_type: ""
    }
  )
  const submitL = () => {
    if (addList.telematics_model_id && /^(\d{15})$/.test(addList.imei) && addList.sim_operator && /^[0-9]{10}$/.test(addList.mobile_number)) {
      const post = endpoints.baseUrl + `/telematicsnew/add`;

      axios
        .post(post, addList)
        .then((response) => {
          handleClick2(true);
          response.status === 201 ? setDdd2("Telematics onboarded successfully!") : setDdd2(response.message)
        });
      dispatch(getTeleListBulk(enty,urId,roid,pagee));
      setAddList({})
      setOpenTeleList(false);
    } else if (!/^(\d{15})$/.test(addList.imei)) {
      handleClick3(true);
      setDdd3("Enter valid IMEI number")
    } else if (!/^[0-9]{10}$/.test(addList.mobile_number)) {
      handleClick3(true);
      setDdd3("Enter valid mobile number")
    }
    else {
      handleClick3(true);
      setDdd3("Please fill the required fields")

    }

  }
  const setAddListArray = (e, key, array) => {
    setAddList((state) => ({ ...state, [key]: e.target.value }));

  }

  const deleteTeleList = (telematics_id) => {
    const deleteTele = endpoints.baseUrl + `/telematicsnew/Softdelete/` + telematics_id;
    axios
      .delete(deleteTele)
      .then((response) => {
        handleClick2(true);
        response.status === 200 ? setDdd2("Telematics offboarded successfully!") : setDdd2(response.message)
        setDelete2(false)
        setPassword2();
        dispatch(getTeleListBulk(enty,urId,roid,pagee));
      });
  }

  // Add Telematics List
  function getSteps() {
    return ['Identifiction'];
  }

  function getStepContent(step) {
    switch (step) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              IMEI Number
            </Typography>
            <TextField
              onChange={(e) => {
                setAddListArray(e, 'imei')
              }}
              size="small" id="outlined"
              value={addList.imei && addList.imei.trim()}
              error={addBatteryErrors && addList.imei === ''}
              helperText={addList.imei != '' &&
                !/^(\d{15})$/.test(addList.imei) ? 'Enter valid IMEI' : null}
              className={classes.textField}
              placeholder="eg:  imei"
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Model Info
            </Typography>
            <Select
              onChange={(e) => {
                setAddListArray(e, 'telematics_model_id')
              }}
              size="small" id="outlined"
              value={addList.telematics_model_id}
              error={addBatteryErrors && addList.telematics_model_id === ''}
              className={classes.textField}>

              <MenuItem value="">Select Telematics Model</MenuItem>
              {TeleModelMeta.data.length && TeleModelMeta.data.map((telem) => {
                return (
                  <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                )
              }
              )}
            </Select>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Mobile Number</Typography>
            <TextField
              onChange={(e) => {
                setAddListArray(e, 'mobile_number')
              }}
              size="small" id="outlined" type="number"
              value={addList.mobile_number && addList.mobile_number.trim()}
              error={addBatteryErrors && addList.mobile_number === ''}
              helperText={addList.mobile_number != '' &&
                !/^[0-9]{10}$/.test(addList.mobile_number) ? 'Mobile number must be 10 digits' : null}
              onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
              className={classes.textField}
              placeholder="eg:  9876678666"
            />
          </Grid><Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>SIM Operator</Typography>
            <Select className={classes.textField}
              onChange={(e) => {
                setAddListArray(e, 'sim_operator')
              }}
              size="small" id="outlined"
              value={addList.sim_operator}
              error={addBatteryErrors && addList.sim_operator === ''}
            >
              <MenuItem value="">Select your Model</MenuItem>
              <MenuItem value="Airtel">Airtel</MenuItem>
              <MenuItem value="Jio">Jio</MenuItem>
              <MenuItem value="VI">VI</MenuItem>
            </Select>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>DBC File Type</Typography>
            <Select className={classes.textField}
              onChange={(e) => {
                setAddListArray(e, 'dbc_file_type')
              }}
              size="small" id="outlined"
              value={addList.dbc_file_type}
              error={addBatteryErrors && addList.dbc_file_type === ''}
            >
              <MenuItem value="">Select your File Type</MenuItem>
              <MenuItem value="ReVx">ReVx</MenuItem>
              <MenuItem value="Grevol">Grevol</MenuItem>
            </Select>
          </Grid>


        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep, setActiveStep] = React.useState(0);
  const [completed, setCompleted] = React.useState({});
  const steps = getSteps();

  const totalSteps = () => steps.length;

  const completedSteps = () => Object.keys(completed).length;

  const isLastStep = () => activeStep === totalSteps() - 1;

  const allStepsCompleted = () => completedSteps() === totalSteps();

  const handleNext = () => {
    const newActiveStep = isLastStep() && !allStepsCompleted() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps.findIndex((step, i) => !(i in completed))
      : activeStep + 1;
    setActiveStep(newActiveStep);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStep = (step) => () => {
    setActiveStep(step);
  };

  const handleComplete = () => {
    const newCompleted = completed;
    newCompleted[activeStep] = true;
    setCompleted(newCompleted);
    handleNext();
  };

  const handleReset = () => {
    setActiveStep(0);
    setCompleted({});
  };

  // edit Telematics List

  function getSteps1() {
    return ['Identifiction'];
  }

  function getStepContent1(step1) {
    switch (step1) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              IMEI Number
            </Typography>
            <TextField
              onChange={(e) => {
                setEditLFormArray(e, 'imei')
              }}
              size="small" id="outlined" value={editLArray.imei && editLArray.imei.trim()}
              error={addBatteryErrors && editLArray.imei === ""}
              helperText={editLArray.imei != '' &&
                !/^(\d{15})$/.test(editLArray.imei) ? 'Enter valid IMEI' : null}
              className={classes.textField}
            />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>
              Model Info
            </Typography>
            <Select
              onChange={(e) => {
                setEditLFormArray(e, 'telematics_model_id')
              }}
              size="small" id="outlined" value={editLArray.telematics_model_id}
              error={addBatteryErrors && editLArray.telematics_model_id === ""}
              className={classes.textField}>

              <MenuItem value="">Select Telematics Model</MenuItem>
              {TeleModelMeta.data.length && TeleModelMeta.data.map((telem) => {
                return (
                  <MenuItem value={telem[0]}>{telem[1]}</MenuItem>

                )
              }
              )}
            </Select>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>Mobile Number</Typography>
            <TextField
              onChange={(e) => {
                setEditLFormArray(e, 'mobile_number')
              }}
              size="small" id="outlined" value={editLArray.mobile_number && editLArray.mobile_number.trim()}
              error={addBatteryErrors && editLArray.mobile_number === ""}
              helperText={editLArray.mobile_number != '' &&
                !/^[0-9]{10}$/.test(editLArray.mobile_number) ? 'Enter valid mobile number' : null}
              className={classes.textField}
              placeholder="eg:  9876678666"
            />
          </Grid><Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>SIM Operator</Typography>
            <Select className={classes.textField}
              onChange={(e) => {
                setEditLFormArray(e, 'sim_operator')
              }}
              size="small" id="outlined" value={editLArray.sim_operator}
              error={addBatteryErrors && editLArray.sim_operator === ""}
            >
              <MenuItem value="">Select your Model</MenuItem>
              <MenuItem value="Airtel">Airtel</MenuItem>
              <MenuItem value="Jio">Jio</MenuItem>
              <MenuItem value="VI">VI</MenuItem>
            </Select>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <Typography className={classes.styleL}>DBC File Type</Typography>
            <Select className={classes.textField}
              onChange={(e) => {
                setEditLFormArray(e, 'dbc_file_type')
              }}
              size="small" id="outlined"
              value={editLArray.dbc_file_type}
              error={addBatteryErrors && editLArray.dbc_file_type === ''}
            >
              <MenuItem value="">Select your File Type</MenuItem>
              <MenuItem value="ReVx">ReVx</MenuItem>
              <MenuItem value="Grevol">Grevol</MenuItem>
            </Select>
          </Grid>

          <Grid item lg={4.5} />

        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep1, setActiveStep1] = React.useState(0);
  const [completed1, setCompleted1] = React.useState({});
  const steps1 = getSteps1();

  const totalSteps1 = () => steps1.length;

  const completedSteps1 = () => Object.keys(completed1).length;

  const isLastStep1 = () => activeStep1 === totalSteps1() - 1;

  const allStepsCompleted1 = () => completedSteps1() === totalSteps1();

  const handleNext1 = () => {
    const newActiveStep1 = isLastStep1() && !allStepsCompleted1() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps1.findIndex((step1, i) => !(i in completed1))
      : activeStep1 + 1;
    setActiveStep1(newActiveStep1);
  };

  const handleBack1 = () => {
    setActiveStep1((prevActiveStep1) => prevActiveStep1 - 1);
  };

  const handleStep1 = (step1) => () => {
    setActiveStep1(step1);
  };

  const handleComplete1 = () => {
    const newCompleted1 = completed1;
    newCompleted1[activeStep1] = true;
    setCompleted1(newCompleted1);
    handleNext1();
  };

  const handleReset1 = () => {
    setActiveStep1(0);
    setCompleted1({});
  };

  //Add Telematics Model

  function getSteps2() {
    return ['Identifiction'];
  }

  function getStepContent2(step2) {
    switch (step2) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Model Info</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            <TextField
              onChange={(e) => {
                setAddFormArray(e, 'model_info')
              }}
              size="small" id="outlined"
              error={addBatteryErrors && addForm.model_info === ""}
              value={addForm.model_info}
              className={classes.textField} />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>OEM</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            <TextField
              onChange={(e) => {
                setAddFormArray(e, 'oem')
              }}
              size="small" id="outlined"
              error={addBatteryErrors && addForm.oem === ""}
              value={addForm.oem}
              className={classes.textField} />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>SIM Type</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            <FormControl className={classes.textField}>
              <Select
                onChange={(e) => {
                  setAddFormArray(e, 'sim_type')
                }}
                size="small" id="outlined"
                error={addBatteryErrors && addForm.sim_type === ""}
                value={addForm.sim_type} >
                <MenuItem value="">Select your SIM</MenuItem>
                <MenuItem value="Airtel">Airtel</MenuItem>
                <MenuItem value="Jio">Jio</MenuItem>
                <MenuItem value="VI">VI</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Protocol</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            <FormControl className={classes.textField}>
              <Select
                onChange={(e) => {
                  setAddFormArray(e, 'protocal')
                }}
                size="small" id="outlined"
                error={addBatteryErrors && addForm.protocal === ""}
                value={addForm.protocal}>
                <MenuItem value="">Select your Protocol</MenuItem>
                <MenuItem value="TCP">TCP</MenuItem>
                <MenuItem value="UDP">UDP</MenuItem>
                <MenuItem value="HTTP">HTTP</MenuItem>
                <MenuItem value="HTTPS">HTTPS</MenuItem>
                <MenuItem value="MQTT">MQTT</MenuItem>

              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Datasheet Attachment</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography>
            </div>
            <Button sx={{ ":hover": { backgroundColor: "#fff" } }} >
              <input onChange={handleChangeDataSheet}
                type="file" style={{ color: '#C1C1C1' }} /></Button>
          </Grid>

          <Grid item lg={4.5} />

        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep2, setActiveStep2] = React.useState(0);
  const [completed2, setCompleted2] = React.useState({});
  const steps2 = getSteps2();

  const totalSteps2 = () => steps2.length;

  const completedSteps2 = () => Object.keys(completed2).length;

  const isLastStep2 = () => activeStep2 === totalSteps2() - 1;

  const allStepsCompleted2 = () => completedSteps2() === totalSteps2();

  const handleNext2 = () => {
    const newActiveStep2 = isLastStep2() && !allStepsCompleted2() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps2.findIndex((step2, i) => !(i in completed2))
      : activeStep2 + 1;
    setActiveStep2(newActiveStep2);
  };

  const handleBack2 = () => {
    setActiveStep2((prevActiveStep2) => prevActiveStep2 - 1);
  };

  const handleStep2 = (step2) => () => {
    setActiveStep2(step2);
  };

  const handleComplete2 = () => {
    const newCompleted2 = completed2;
    newCompleted2[activeStep2] = true;
    setCompleted2(newCompleted2);
    handleNext2();
  };

  const handleReset2 = () => {
    setActiveStep2(0);
    setCompleted2({});
  };

  //edit telematics model
  function getSteps3() {
    return ['Identifiction'];
  }

  function getStepContent3(step3) {
    switch (step3) {
      case 0:
        return <Grid container spacing={2}>
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Model Info</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            <TextField onChange={(e) => {
              setEditFormArray(e, 'model_info')
            }}
              size="small" id="outlined" value={editArray.model_info}
              error={addBatteryErrors && editArray.model_info === ""}
              className={classes.textField} />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>OEM</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            <TextField onChange={(e) => {
              setEditFormArray(e, 'oem')
            }}
              size="small" id="outlined" value={editArray.oem}
              error={addBatteryErrors && editArray.oem === ""}
              className={classes.textField} />
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>SIM Type</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            <FormControl className={classes.textField}>
              <Select onChange={(e) => {
                setEditFormArray(e, 'sim_type')
              }}
                size="small" id="outlined" value={editArray.sim_type}
                error={addBatteryErrors && editArray.sim_type === ""}>
                <MenuItem value="Airtel">Airtel</MenuItem>
                <MenuItem value="Jio">Jio</MenuItem>
                <MenuItem value="VI">VI</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={1} />
          <Grid item lg={1} />
          <Grid item lg={3} xs={12}>
            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Protocol</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            <FormControl className={classes.textField}>
              <Select onChange={(e) => {
                setEditFormArray(e, 'protocal')
              }}
                size="small" id="outlined" value={editArray.protocal}
                error={addBatteryErrors && editArray.protocal === ""}>
                {/* <MenuItem value={editArray.protocal}>{editArray.protocal}</MenuItem> */}
                <MenuItem value="TCP">TCP</MenuItem>
                <MenuItem value="UDP">UDP</MenuItem>
                <MenuItem value="HTTP">HTTP</MenuItem>
                <MenuItem value="HTTPS">HTTPS</MenuItem>
                <MenuItem value="MQTT">MQTT</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item lg={0.5} />
          <Grid item lg={3} xs={12}>

            <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Datasheet Attachment</Typography>&nbsp;
              <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
            {editArray.datasheet_attachment === '' ?
              <Button sx={{ ":hover": { backgroundColor: "#fff" } }} >
                <input onChange={handleChangeDataSheetEdit}
                  type="file" style={{ color: '#C1C1C1' }} /></Button>
              : <Button onClick={() => setOpenD(true)}>
                <img src={editArray.datasheet_attachment} /></Button>
            }
            <Dialog
              //fullScreen={fullScreen}
              open={openD}
              maxWidth={"lg"}
              onClose={() => {
                setOpenD(false)
              }}
              aria-labelledby="responsive-dialog-title"
              className={classes.dialogPaper}
            >
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}><></><IconButton onClick={() => {
                setOpenD(false)
              }}  >
                <Icon icon="akar-icons:circle-x" width="26" height="26" color="#77b93e" />
              </IconButton></div>

              <DialogContent>
                <img src={editArray.datasheet_attachment} />
              </DialogContent>
            </Dialog>
          </Grid>

          <Grid item lg={4.5} />

        </Grid>;
      default:
        return 'Unknown step';
    }
  }

  const [activeStep3, setActiveStep3] = React.useState(0);
  const [completed3, setCompleted3] = React.useState({});
  const steps3 = getSteps3();

  const totalSteps3 = () => steps3.length;

  const completedSteps3 = () => Object.keys(completed3).length;

  const isLastStep3 = () => activeStep3 === totalSteps3() - 1;

  const allStepsCompleted3 = () => completedSteps3() === totalSteps3();

  const handleNext3 = () => {
    const newActiveStep3 = isLastStep3() && !allStepsCompleted3() // It's the last step, but not all steps have been completed,
      // find the first step that has been completed
      ? steps3.findIndex((step3, i) => !(i in completed3))
      : activeStep3 + 1;
    setActiveStep3(newActiveStep3);
  };

  const handleBack3 = () => {
    setActiveStep3((prevActiveStep3) => prevActiveStep3 - 1);
  };

  const handleStep3 = (step3) => () => {
    setActiveStep3(step3);
  };

  const handleComplete3 = () => {
    const newCompleted3 = completed3;
    newCompleted3[activeStep3] = true;
    setCompleted3(newCompleted3);
    handleNext3();
  };

  const handleReset3 = () => {
    setActiveStep3(0);
    setCompleted3({});
  };
  return (
    <div className={classes.table}>
      <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />
      <Snackbar open={open} autoHideDuration={3000} onClose={handleClose}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        style={{ marginTop: '300px', marginLeft: '450px' }}
      >
        <Alert onClose={handleClose} severity="warning">
          This Telematics assigned to&nbsp;{ddd}
        </Alert>
      </Snackbar>
      <Snackbar open={open1} autoHideDuration={3000} onClose={handleClose1}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        style={{ marginTop: '350px', marginLeft: '450px' }}
      >
        <Alert onClose={handleClose1} severity="warning">
          This Telematics assigned to&nbsp;{ddd1}
        </Alert>
      </Snackbar>
      <Snackbar open={open2} autoHideDuration={3000} onClose={handleClose2}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        style={{ marginTop: '350px', marginLeft: '450px' }}
      >
        <Alert onClose={handleClose2} severity="success">
          {ddd2}
        </Alert>
      </Snackbar>
      <Snackbar open={open3} autoHideDuration={3000} onClose={handleClose3}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        style={{ marginTop: '350px', marginLeft: '450px' }}
      >
        <Alert onClose={handleClose3} severity="warning">
          {ddd3}
        </Alert>
      </Snackbar>

      <Tabs
        className={roid === "38" ? classes.tabsSection : classes.tabsSectionrr}
        value={value}
        onChange={handleChange}
        variant="fullWidth"
        indicatorColor="primary"
        aria-label="icon tabs example"
      >
        <Tab label="Telematics" icon={<Icon icon="ic:baseline-settings-remote" height="22" width="22" />} aria-label="favorite" />
        {roid === "38" ? <Tab label="Telematics Model" icon={<Icon icon="ic:baseline-electric-car" height="22" width="22" />} aria-label="phone" /> : null}

      </Tabs>

      <Paper square className={classes.root} />

      <>
        {value === 0 ?
          <>
            {openTeleList === true ?
              <div style={{
                width: '100%', overflow: 'hidden'
              }}><br />
                <h3>Onboarding Telematics</h3><br />
                <Stepper nonLinear activeStep={activeStep}>
                  {steps.map((label, index) => (
                    <Step key={label}>
                      <StepButton onClick={handleStep(index)} completed={completed[index]}>
                        {label}
                      </StepButton>
                    </Step>
                  ))}
                </Stepper>
                <div>
                  {allStepsCompleted() ? (
                    <div>
                      <Typography style={{
                        marginTop: theme.spacing(1),
                        marginBottom: theme.spacing(1)
                      }}>
                        All steps completed - you&apos;re finished
                      </Typography>
                      <Button onClick={handleReset}>Reset</Button>
                    </div>
                  ) : (
                    <div><br />
                      <Typography style={{
                        marginTop: theme.spacing(1),
                        marginBottom: theme.spacing(1)
                      }}>{getStepContent(activeStep)}</Typography>
                      <br /><br /><br /><br />
                      <div>
                        <Button
                          onClick={() => {
                            setOpenTeleList(false);
                            handleReset()
                          }}
                          style={{
                            marginRight: theme.spacing(1)
                          }}>
                          Cancel
                        </Button>
                        {addList.telematics_model_id != '' && addList.imei != '' && addList.sim_operator != '' &&
                          addList.mobile_number != '' ?
                          <Button variant="contained" color="primary"
                            onClick={() => {
                              submitL();
                            }}
                          >Finish
                          </Button>
                          : <Button disabled variant="contained">Finish
                          </Button>}


                      </div>
                    </div>
                  )}
                </div><br /><br /><br />
              </div> :
              openTeleListEdit === true ?
                <div style={{
                  width: '100%', overflow: 'hidden'
                }}><br />
                  <h3>Telematics Profile</h3><br />
                  <Stepper nonLinear activeStep={activeStep1}>
                    {steps1.map((label1, index) => (
                      <Step key={label1}>
                        <StepButton onClick={handleStep1(index)} completed={completed1[index]}>
                          {label1}
                        </StepButton>
                      </Step>
                    ))}
                  </Stepper>
                  <div>
                    {allStepsCompleted1() ? (
                      <div>
                        <Typography style={{
                          marginTop: theme.spacing(1),
                          marginBottom: theme.spacing(1)
                        }}>
                          All steps completed - you&apos;re finished
                        </Typography>
                        <Button onClick={handleReset1}>Reset</Button>
                      </div>
                    ) : (
                      <div><br />
                        <Typography style={{
                          marginTop: theme.spacing(1),
                          marginBottom: theme.spacing(1)
                        }}>{getStepContent1(activeStep1)}</Typography>
                        <br /><br /><br /><br />
                        <div>
                          <Button
                            onClick={() => {
                              setOpenTeleListEdit(false);
                              handleReset1()
                            }}
                            style={{
                              marginRight: theme.spacing(1)
                            }}>
                            Cancel
                          </Button>
                          {/^(\d{15})$/.test(editLArray.imei) && editLArray.telematics_model_id &&
                            /^[0-9]{10}$/.test(editLArray.mobile_number) && editLArray.sim_operator ?
                            <Button variant="contained" color="primary"
                              onClick={() => {
                                submitLEdit();
                              }}
                            >Finish
                            </Button>
                            : <Button disabled variant="contained">Finish
                            </Button>}


                        </div>
                      </div>
                    )}
                  </div><br /><br /><br />
                </div>
                : <><MUIDataTable
                  checkboxSelection={false}
                  title="Telematics"
                  data={dataOn === true ? TeleListTotalMeta.data : TeleListMeta.data}
                  columns={telematicsEditAccess === true ? TeleListColumn : TeleListColumn1}
                  options={options}
                  selectableRows={1}
                  selectableRowsHideCheckboxes
                /><br />
                  <Pagination color="secondary" count={MyTeleListCount} page={pagee} onChange={changePagee} /><br />
                  <Typography align="center" className={classes.copyRight}>
                    Copyright© 2023 ReVx Energy Pvt.Ltd.
                  </Typography></>}
          </>

          : <> {openAdd === true ?
            <div style={{
              width: '100%', overflow: 'hidden'
            }}><br />
              <h3>Onboarding Telematics Model</h3><br />
              <Stepper nonLinear activeStep={activeStep2}>
                {steps2.map((label2, index) => (
                  <Step key={label2}>
                    <StepButton onClick={handleStep2(index)} completed={completed2[index]}>
                      {label2}
                    </StepButton>
                  </Step>
                ))}
              </Stepper>
              <div>
                {allStepsCompleted2() ? (
                  <div>
                    <Typography style={{
                      marginTop: theme.spacing(1),
                      marginBottom: theme.spacing(1)
                    }}>
                      All steps completed - you&apos;re finished
                    </Typography>
                    <Button onClick={handleReset2}>Reset</Button>
                  </div>
                ) : (
                  <div><br />
                    <Typography style={{
                      marginTop: theme.spacing(1),
                      marginBottom: theme.spacing(1)
                    }}>{getStepContent2(activeStep2)}</Typography>
                    <br /><br /><br /><br />
                    <div>
                      <Button
                        onClick={() => {
                          setOpenAdd(false);
                          handleReset2()
                        }}
                        style={{
                          marginRight: theme.spacing(1)
                        }}>
                        Cancel
                      </Button>
                      {addForm.model_info !== '' && addForm.oem !== '' && addForm.sim_type !== '' && addForm.protocal !== '' &&
                        addForm.datasheet_attachment !== '' ?
                        <Button variant="contained" color="primary"
                          onClick={() => {
                            handleSubmitAdd(true);
                          }}
                        >Finish
                        </Button>
                        : <Button disabled variant="contained">Finish
                        </Button>}
                    </div>
                  </div>
                )}
              </div><br /><br /><br />
            </div> : openEdit === true ?
              <div style={{
                width: '100%', overflow: 'hidden'
              }}><br />
                <h3>Telematics Model Profile</h3><br />
                <Stepper nonLinear activeStep={activeStep3}>
                  {steps3.map((label3, index) => (
                    <Step key={label3}>
                      <StepButton onClick={handleStep3(index)} completed={completed3[index]}>
                        {label3}
                      </StepButton>
                    </Step>
                  ))}
                </Stepper>
                <div>
                  {allStepsCompleted3() ? (
                    <div>
                      <Typography style={{
                        marginTop: theme.spacing(1),
                        marginBottom: theme.spacing(1)
                      }}>
                        All steps completed - you&apos;re finished
                      </Typography>
                      <Button onClick={handleReset3}>Reset</Button>
                    </div>
                  ) : (
                    <div><br />
                      <Typography style={{
                        marginTop: theme.spacing(1),
                        marginBottom: theme.spacing(1)
                      }}>{getStepContent3(activeStep3)}</Typography>
                      <br /><br /><br /><br />
                      <div>
                        <Button
                          onClick={() => {
                            setOpenEdit(false);
                            handleReset3()
                          }}
                          style={{
                            marginRight: theme.spacing(1)
                          }}>
                          Cancel
                        </Button>
                        {editArray.model_info !== '' && editArray.oem !== '' && editArray.sim_type !== '' && editArray.protocal !== '' &&
                          editArray.datasheet_attachment !== '' ?
                          <Button variant="contained" color="primary"
                            onClick={() => {
                              submitEdit(true);
                            }}
                          >Finish
                          </Button>
                          : <Button disabled variant="contained">Finish
                          </Button>}
                      </div>
                    </div>
                  )}
                </div><br /><br /><br />
              </div>
              : <><MUIDataTable
                checkboxSelection={false}
                title="Telematics Model"
                data={dataOnM === true ? TMMeta.data : TelematicsMeta.data}
                columns={telematicsEditAccess === true ? TelematicsColumn : TelematicsColumn1}
                options={options}
                selectableRows={1}
                selectableRowsHideCheckboxes
              /><br />
                <Pagination color="secondary" count={MyTelematicsCount} page={page} onChange={changePage} /><br />
                <Typography align="center" className={classes.copyRight}>
                  Copyright© 2023 ReVx Energy Pvt.Ltd.
                </Typography></>}</>}</>




      <Dialog
        //fullScreen={fullScreen}
        open={openD1}
        maxWidth={"lg"}
        onClose={() => {
          setOpenD1(false)
        }}
        aria-labelledby="responsive-dialog-title"
        className={classes.dialogPaper}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><><DialogTitle>Datasheet</DialogTitle></><IconButton onClick={() => {
          setOpenD1(false)
        }}  >
          <Icon icon="akar-icons:circle-x" width="26" height="26" color="#77b93e" />
        </IconButton></div>

        <DialogContent>
          <img src={editArray.datasheet_attachment} />
        </DialogContent>
      </Dialog>
      {/* //Delete Telematics Model */}
      <Dialog
        fullScreen={fullScreen}
        open={delete1}
        maxWidth={"lg"}
        onClose={() => setDelete1(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Offboarding Telematics Model"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item lg={12} xs={12}>
                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                <TextField className={classes.textField}
                  onChange={(e) => { setPassword1(e.target.value) }}
                />

              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setDelete1(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            disabled={password1 !== pWord}
            onClick={() => {
              deleteTelematics(selectedId1);
            }}
            color="secondary">
            Offboarding
          </Button>
        </DialogActions>
      </Dialog>
      {/* //Delete Telematics */}
      <Dialog
        fullScreen={fullScreen}
        open={delete2}
        maxWidth={"lg"}
        onClose={() => setDelete2(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Offboarding Telematics"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item lg={12} xs={12}>
                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                <TextField className={classes.textField}
                  onChange={(e) => { setPassword2(e.target.value) }}
                />

              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setDelete2(false)}
            color="primary">
            Cancel
          </Button>
          <Button
            disabled={password2 !== pWord}
            onClick={() => {
              deleteTeleList(selectedId2);
            }}
            color="secondary">
            Offboarding
          </Button>
        </DialogActions>
      </Dialog>


    </div>
  );
}
