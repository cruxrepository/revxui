import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';
import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";

import Paper from "@material-ui/core/Paper";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import './style.css';
import { useDispatch, useSelector } from 'react-redux';
import { getTelematicsBulk } from '../../../redux/actions/asyncActions';
import Loading from '../../../components/Loading';
import endpoints from "../../../endpoints/endpoints";
import ErrorWrap from '../../../components/Error/ErrorWrap';
import SimpleSnackbar from '../Users/SimpleSnackbar';
import Pagination from '@material-ui/lab/Pagination';


const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  gst: {
    color: '#4CAF50'
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  tabHelp: {
    fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
  },
  formControl: {
    width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
  },
  textField: {
    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
  },
  autoComplete: {
    '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
  },
  dialog: {
    position: 'relative', marginLeft: '630px'
  },

  dialogPaper: {
    height: "85%",
    width: "50%",
    marginLeft: '700px'
  },
  BNsecondaryTextG: { color: '#00FF00' },

}));



/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function Telematics() {

  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const classes = useStyles();
  const validateKeyData = (key) => {
    return key ? key : "-";
  };
  const [openAdd, setOpenAdd] = React.useState(false);
  const [openEdit, setOpenEdit] = React.useState(false);
  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)
  const [addResponse, setAddResponce] = React.useState("")
  const [page, setPage] = React.useState(1);

  const changePage = (event, newValue) => {
    setPage(newValue);
  };
  const logged_user = useSelector((store) => store.login.result);
  let telematicsEditAccess = logged_user.telematics === "edit"
  let pWord = logged_user.password
  const ppp = useSelector((store) => store.login.result.password);
  const TelematicsData = useSelector((store) => store.telematicsAll)
  const TelematicsDataRaw = useSelector((store) => store.telematicsAll.rawData)
  let TelematicsMeta = {};
  TelematicsMeta.data = [];
  let TelematicsMetaa = useSelector((store) => store.telematicsAll)
  if (TelematicsMetaa.data.length >= 1) {
    TelematicsMeta.data = TelematicsMetaa.data;
  }
  const MyTelematicsPage = useSelector((store) => store.telematicsAll.page_number)
  const MyTelematicsCount = Math.ceil(useSelector((store) => store.telematicsAll.total_records) / 10)
  let TelematicsFetching = useSelector((store) => store.telematicsAll.fetching)
  let TelematicsResponsecode = useSelector((store) => store.telematicsAll.responseStatus)
  let TelematicsMetaPresent = useSelector((store) => store.telematicsAll.dataPresent)

  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(getTelematicsBulk(page));
  }, [TelematicsMetaPresent, page]);

  // Add Telematics
  const [addForm, setAddForm] = React.useState(
    {
      model_info: "",
      oem: "",
      sim_type: "",
      protocal: "",
      datasheet_attachment: ""
    }
  )
  const submit = () => {
    if (addForm.model_info && addForm.oem && addForm.sim_type && addForm.protocal && addForm.datasheet_attachment) {
      const post = endpoints.baseUrl + `/telematics/add`;

      axios
        .post(post, addForm)
        .then((response) => {
          setAddBatteryErrors(true);
          response.status === 201 ? setAddResponce("Telematics onboarding successfully") : setAddResponce(response.message)
        });
        dispatch(getTelematicsBulk(page));
        setAddForm({})
      setOpenAdd(false);
    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields")

    }

  }
  const setAddFormArray = (e, key, array) => {
    setAddForm((state) => ({ ...state, [key]: e.target.value }));

  }

  const handleSubmitAdd = () => {
    submit(true)
    dispatch(getTelematicsBulk(page));
  }


  //Edit Telematics
  const [editArray, setEditArray] = React.useState(
    {
    }
  )
  const setEditFormArray = (e, key) => {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));

  }

  const submitEdit = () => {

    if (editArray.model_info && editArray.oem && editArray.sim_type && editArray.protocal && editArray.datasheet_attachment) {
      const put = endpoints.baseUrl + `/telematics/edit/` + editArray.telematics_data_id;
      let newEditArray = editArray;
      axios
        .put(put, newEditArray)
        .then((response) => {
          setAddBatteryErrors(true);
          setOpenEdit(false)

          dispatch(getTelematicsBulk(page));
          response.status === 200 ? setAddResponce("Telematics details edited successfully") : setAddResponce(response.message)
          setEditArray({

          })
        });
      setOpenEdit(false)

    } else {
      setAddBatteryErrors(true);

      setAddResponce("Please fill the required fields")

    }
  }
  console.log("TelematicsDataRaw",TelematicsDataRaw)
  const setTelematicsEditArray = (telematics_data_id) => {
    let allTelematics = TelematicsDataRaw;
    let findArray = allTelematics.find(el => el.telematics_data_id === telematics_data_id)
    setEditArray(findArray);
  }

  // Delete Telematics
  const deleteTelematics = (telematics_data_id) => {
    const deleteT = endpoints.baseUrl + `/telematics/SoftDelete/` + telematics_data_id;
    axios
      .delete(deleteT)
      .then((response) => {
        setAddBatteryErrors(true);
        response.status === 200 ? setAddResponce("Telematics offboarded") : setAddResponce(response.message)
        setDelete1(false)
        setPassword1()
        dispatch(getTelematicsBulk(page));
      });
  }

  const [openD, setOpenD] = React.useState(false);
  const [openD1, setOpenD1] = React.useState(false);
  const [file, setFile] = React.useState()
  function handleChangeDataSheet(event) {
    setFile(event.target.files[0])


    event.preventDefault()
    const url = endpoints.baseUrl + '/upload';
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('fileName', event.target.files[0].name);
    const config = {
      headers: {
        'content-type': 'multipart/form-data',
      },
    };
    axios.post(url, formData, config).then((response) => {
      // console.log(response.data);
      setAddForm((state) => ({ ...state, datasheet_attachment: response.data }));

    });

  }

  const [password1, setPassword1] = React.useState("");
  const [delete1, setDelete1] = React.useState("");
  const [selectedId1, setSelectedId1] = React.useState("");


  const TelematicsColumn = [
    {
      label: "Model Info", name: "model",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" >{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "OEM", name: "oem",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" >{validateKeyData(value)}</Typography>
        ),
      },
    },

    {
      label: "SIM Type", name: "sim",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <div style={{display:'flex',justifyContent: 'space-between'}}>
          <Typography/>
          <Typography variant="subtitle2" >{validateKeyData(value)}</Typography>
          <Typography/>
          </div>
           ),
      },
    },
    {
      label: "Protocol", name: "protocol",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <div style={{display:'flex',justifyContent: 'space-between'}}>
          <Typography variant="subtitle2"/>
          <Typography variant="subtitle2" >{validateKeyData(value)}</Typography>
          <Typography variant="subtitle2"/>
          </div>
        ),
      },
    },
    {
      label: "Datasheet Attachment", name: "datasheet",
      options: {
        filter: true,
        customBodyRender: (value) => (
          // <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
          <img src={value}  width="80" height="60"/>
          
        ),
      },
    },
    {
      label: "Action", name: "action",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <><IconButton onClick={() => {
            setTelematicsEditArray(value)
            setOpenEdit(true)
          }} ><Icon icon="bxs:edit-alt" color="#33a6ff" width="30" height="30" /></IconButton>
            <IconButton
              onClick={() => { 
                setDelete1(true);
                setSelectedId1(value);
                  // deleteTelematics(value) 
                }} 
            ><Icon icon="ic:baseline-delete" color="#C7292C" width="30" height="30" /> </IconButton></>
        ),
      },
    },


  ];
  const TelematicsColumn1 = [
    {
      label: "Model Info", name: "model",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" >{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "OEM", name: "oem",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" >{validateKeyData(value)}</Typography>
        ),
      },
    },

    {
      label: "SIM Type", name: "sim",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" >{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Protocol", name: "protocol",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography variant="subtitle2" >{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Datasheet Attachment", name: "datasheet",
      options: {
        filter: true,
        customBodyRender: (value) => (
          // <Typography variant="subtitle2">{validateKeyData(value)}</Typography>
          <img src={value}  width="100" height="60"  />
          
        ),
      },
    },


  ];

  const options = {
    filter: true,
    download: true,
    print: false,
    viewColumns: true,
    search: true,
    selectableRows: "none",
    customToolbar: () => {
      if(telematicsEditAccess === true){
      return (<IconButton style={{ transform: "translateX(-10em)" }} onClick={() => setOpenAdd(true)}><Icon icon="ic:baseline-electric-car" width="24" height="24" /></IconButton>)
    }
    else {
      null
    }
    },
  };




  return (
    <div className={classes.table}>
      <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />

      <Paper square className={classes.root} />

      <><MUIDataTable
        checkboxSelection={false}
        title="Telematics Model"
        data={TelematicsMeta.data}
        columns={telematicsEditAccess === true ? TelematicsColumn : TelematicsColumn1}
        options={options}
        selectableRows={1}
        selectableRowsHideCheckboxes
      /><br />
        <Pagination count={MyTelematicsCount} page={MyTelematicsPage} onChange={changePage} /><br />
          <Typography align="center" className={classes.copyRight}>
            Copyright© 2023 ReVx Energy Pvt.Ltd.
          </Typography></>

      {/* Add Telematics */}
      <Dialog
        fullScreen={fullScreen}
        open={openAdd}
        maxWidth={"lg"}
        onClose={() => setOpenAdd(false)}
        aria-labelledby="responsive-dialog-title"
        className={classes.dialogPaper}
      >
        <DialogTitle id="responsive-dialog-title">{"Onboarding Telematics"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Model Info</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setAddFormArray(e, 'model_info')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && addForm.model_info === ""}
                  value={addForm.model_info}
                  className={classes.textField} /></Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>OEM</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <TextField
                  onChange={(e) => {
                    setAddFormArray(e, 'oem')
                  }}
                  size="small" id="outlined"
                  error={addBatteryErrors && addForm.oem === ""}
                  value={addForm.oem}
                  className={classes.textField} />
              </Grid>

              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>SIM Type</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <FormControl className={classes.textField}>
                  <Select
                    onChange={(e) => {
                      setAddFormArray(e, 'sim_type')
                    }}
                    size="small" id="outlined"
                    error={addBatteryErrors && addForm.sim_type === ""}
                    value={addForm.sim_type} >
                    <MenuItem value="">Select your SIM</MenuItem>
                    <MenuItem value="Airtel">Airtel</MenuItem>
                    <MenuItem value="Jio">Jio</MenuItem>
                    <MenuItem value="VI">VI</MenuItem>
                    {/* {allVM.length && allVM.map((model) => {
                          return (
                            <MenuItem value={model[5]}>{model[0]}</MenuItem>
  
                          )
                        }
                        )} */}

                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Protocol</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <FormControl className={classes.textField}>
                  <Select
                    onChange={(e) => {
                      setAddFormArray(e, 'protocal')
                    }}
                    size="small" id="outlined"
                    error={addBatteryErrors && addForm.protocal === ""}
                    value={addForm.protocal}>
                    <MenuItem value="">Select your Protocol</MenuItem>
                    <MenuItem value="TCP">TCP</MenuItem>
                    <MenuItem value="UDP">UDP</MenuItem>
                    <MenuItem value="HTTP">HTTP</MenuItem>
                    <MenuItem value="HTTPS">HTTPS</MenuItem>
                    <MenuItem value="MQTT">MQTT</MenuItem>
                    {/* {allVM.length && allVM.map((model) => {
                          return (
                            <MenuItem value={model[5]}>{model[0]}</MenuItem>
  
                          )
                        }
                        )} */}

                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Datasheet Attachment</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography>
                  </div>
                <Button sx={{ ":hover": { backgroundColor: "#fff" } }} >
                  <input onChange={handleChangeDataSheet}
                    //  onChange={(e) => {
                    //   setAddFormArray(e, 'datasheet_attachment')
                    // }}
                    // size="small" id="outlined"
                    // value={addForm.datasheet_attachment}
                    type="file" style={{ color: '#C1C1C1' }} /></Button>
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenAdd(false)}
            color="primary">
            Cancel
          </Button>
          <Button autoFocus
            onClick={() => handleSubmitAdd(true)}
            color="secondary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Telematics */}
      <Dialog
        fullScreen={fullScreen}
        open={openEdit}
        maxWidth={"lg"}
        onClose={() => setOpenEdit(false)}
        aria-labelledby="responsive-dialog-title"
        className={classes.dialogPaper}
      >
        <DialogTitle id="responsive-dialog-title">{"Edit Telematics"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Model Info</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setEditFormArray(e, 'model_info')
                }}
                  size="small" id="outlined" value={editArray.model_info}
                  error={addBatteryErrors && editArray.model_info === ""}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>OEM</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <TextField onChange={(e) => {
                  setEditFormArray(e, 'oem')
                }}
                  size="small" id="outlined" value={editArray.oem}
                  error={addBatteryErrors && editArray.oem === ""}
                  className={classes.textField} />
              </Grid>

              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>SIM Type</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <FormControl className={classes.textField}>
                  <Select onChange={(e) => {
                    setEditFormArray(e, 'sim_type')
                  }}
                    size="small" id="outlined" value={editArray.sim_type}
                    error={addBatteryErrors && editArray.sim_type === ""}>
                    {/* <MenuItem value={editArray.sim_type}>{editArray.sim_type}</MenuItem> */}
                    <MenuItem value="Airtel">Airtel</MenuItem>
                    <MenuItem value="Jio">Jio</MenuItem>
                    <MenuItem value="VI">VI</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Protocol</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <FormControl className={classes.textField}>
                  <Select onChange={(e) => {
                    setEditFormArray(e, 'protocal')
                  }}
                    size="small" id="outlined" value={editArray.protocal}
                    error={addBatteryErrors && editArray.protocal === ""}>
                    {/* <MenuItem value={editArray.protocal}>{editArray.protocal}</MenuItem> */}
                    <MenuItem value="TCP">TCP</MenuItem>
                    <MenuItem value="UDP">UDP</MenuItem>
                    <MenuItem value="HTTP">HTTP</MenuItem>
                    <MenuItem value="HTTPS">HTTPS</MenuItem>
                    <MenuItem value="MQTT">MQTT</MenuItem>
                    {/* {allVM.length && allVM.map((model) => {
                          return (
                            <MenuItem value={model[5]}>{model[0]}</MenuItem>
  
                          )
                        }
                        )} */}

                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{ display: 'flex' }}><Typography className={classes.tabHelp}>Datasheet Attachment</Typography>&nbsp;
                  <Typography style={{ fontSize: '18px', color: 'red' }}>*</Typography></div>
                <Button onClick={() => setOpenD(true)}>
                  <img src={editArray.datasheet_attachment} /></Button>
                <Dialog
                  //fullScreen={fullScreen}
                  open={openD}
                  maxWidth={"lg"}
                  onClose={() => {
                    setOpenD(false)
                  }}
                  aria-labelledby="responsive-dialog-title"
                  className={classes.dialogPaper}
                >
                  <div style={{ display: 'flex', justifyContent: 'flex-end' }}><></><IconButton onClick={() => {
                    setOpenD(false)
                  }}  >
                    <Icon icon="akar-icons:circle-x" width="26" height="26" color="#77b93e" />
                  </IconButton></div>

                  <DialogContent>
                    <img src={editArray.datasheet_attachment} />
                  </DialogContent>
                </Dialog>
              </Grid>
            </Grid>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenEdit(false)}
            color="primary">
            Cancel
          </Button>
          <Button autoFocus
            onClick={() => submitEdit(true)}
            color="secondary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
            //fullScreen={fullScreen}
            open={openD1}
            maxWidth={"lg"}
            onClose={() => {
              setOpenD1(false)
            }}
            aria-labelledby="responsive-dialog-title"
            className={classes.dialogPaper}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><><DialogTitle>Datasheet</DialogTitle></><IconButton onClick={() => {
              setOpenD1(false)
            }}  >
              <Icon icon="akar-icons:circle-x" width="26" height="26" color="#77b93e" />
            </IconButton></div>
            
            <DialogContent>
            <img src={editArray.datasheet_attachment} />
            </DialogContent>
          </Dialog>

          <Dialog
fullScreen={fullScreen}
open={delete1}
maxWidth={"lg"}
onClose={() => setDelete1(false)}
aria-labelledby="responsive-dialog-title"
className={!fullScreen ? classes.dialog : null}
>
<DialogTitle id="responsive-dialog-title">{"Delete Telematics"}</DialogTitle>
<DialogContent>
    <DialogContentText>
        <Grid container spacing={2}>
            <Grid item lg={12} xs={12}>
                <b style={{ fontSize: '14px', color: '#00000070' }}>Password</b>
                <TextField className={classes.textField}
                    onChange={(e) => { setPassword1(e.target.value) }}
                />

            </Grid>
        </Grid>
    </DialogContentText>
</DialogContent>
<DialogActions>
    <Button
        onClick={() => setDelete1(false)}
        color="primary">
        Cancel
    </Button>
    <Button
        disabled={password1 !== pWord}
        onClick={() => {
            deleteTelematics(selectedId1);
        }}
        color="secondary">
        Delete
    </Button>
</DialogActions>
</Dialog>


    </div>
  );
}
