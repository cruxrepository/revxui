import React from "react";
import PropTypes from "prop-types";
import { Helmet } from "react-helmet";
import brand from "enl-api/dummy/brand";
import { PapperBlock } from "enl-components";
import { injectIntl, FormattedMessage } from "react-intl";
// import messages from "./messages";
import Paper from "@material-ui/core/Paper";
import TelematicsPage from './Telematics';
import PageTitle from '../../../components/Utils/PageTitle';

function Telematics(props) {
  const title = brand.name + " - Telematics";
  const description = brand.desc;
  const { intl } = props;
  return (
    <div>
      <Helmet>
        <title> {title} </title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="twitter:title" content={title} />
        <meta property="twitter:description" content={description} />
      </Helmet>
      <div  style={{marginTop:'-25px'}}><PageTitle />
    <TelematicsPage /></div>
    </div>
  );
}

Telematics.propTypes = {
  intl: PropTypes.object.isRequired,
};

export default injectIntl(Telematics);
