import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import brand from 'enl-api/dummy/brand';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Hidden from '@material-ui/core/Hidden';
import { NavLink, useNavigate, Navigate, Redirect, useHistory } from 'react-router-dom';

import { withStyles } from '@material-ui/core/styles';
import { LoginForm, SelectLanguage } from 'enl-components';
import logoFull from "enl-images/logoFull.svg";
import ArrowBack from '@material-ui/icons/ArrowBack';
import styles from 'enl-components/Forms/user-jss';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import SimpleSnackbar from './SimpleSnackbar';
import { allUsers } from './listUsers';
import { useDispatch, useSelector } from "react-redux";
import { getUserLBulk, userLogin } from "../../../redux/actions/asyncActions";
import { saveLoggeduser, clearLoggeduser } from '../../../redux/actions/normalActions';
function Login(props) {
  const history = useHistory();
  const [loginSuccess, setLoginSucess] = useState(false);
  const logged_user = useSelector((store) => store.login.result);
  const validUser = useSelector((store) => store.login.valid_user);
  const validUser1 = useSelector((store) => store.login.result);
  const validUser2 = useSelector((store) => store.login);
  // console.log("validUser", validUser)
  // console.log("validUser1", validUser1)
  // console.log("validUser2", validUser2)


  const dispatch = useDispatch();

  const { classes } = props;
  const title = brand.name + ' - Login';
  const description = brand.desc;
  const [valueForm, setValueForm] = useState(null);


  const submitForm = (values) => {
    setValueForm(values);
    // dispatch(userLogin(values));

    // console.log(values, 'values');
    if (values) {
      dispatch(userLogin(values));
      if (validUser === true) {
        setLoginSucess(true);
        // console.log(values, "valueForm")
        // dispatch(saveLoggeduser(values));
        setLogInMessage("Success....");
        // dispatch(userLogin(values));
        setTimeout(() => {
          setLogInMessage("Success, Redirecting to Battery");
        }, 2000)
        // history.push('/app');
        // setTimeout(() => {


        //   window.location.href = '/app';
        // }, 1000)
      } else if (validUser === false) {
        // console.log("hi")
        setLoginSucess(true);
        setLogInMessage("Loading....");
        setTimeout(() => {
          setLogInMessage("Failed, Check Credentials")
        }, 2000)
      }
      else {
        setLoginSucess(true);
        setLogInMessage("Success....");
        setLoginSucess(true);
      }
    }
  };

  // const navigate = useNavigate();

  // useEffect(() => {
  //   dispatch(userLogin(loginStates));
  // }, [dispatch]);
  const UserDataRaw = useSelector((store) => store.userLAll.rawData)
  const [logInMessage, setLogInMessage] = useState('');

  useEffect(() => {
    // if (valueForm) {
    // const [loginStates, setLoginStates] = React.useState({
    //   password: valueForm.password,
    //   email: valueForm.email
    // });

    // }
  }
    , [valueForm, validUser]);

  return (
    <div className={classes.rootFull}>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="twitter:title" content={title} />
        <meta property="twitter:description" content={description} />
      </Helmet>
      <div className={classes.containerSide} style={{ backgroundColor: '#E9F2DF' }}>
        <Hidden smDown>
          <div className={classes.opening}>
            <div className={classes.openingWrap}>
              <div className={classes.openingHead}>

                <NavLink to="/" className={classes.brand}>

                  {/* {brand.name} */}
                </NavLink>
              </div>
              <Typography variant="h3" component="h1" gutterBottom>
                {/* <FormattedMessage {...messages.welcomeTitle} /> */}
                <img src={logoFull} alt={brand.name} style={{ height: '100px', width: '400px', marginLeft:'-40px' }} />
                &nbsp;
                <Grid container spacing={2}>
                <Grid xs={4}/>
                <Grid xs={8}>
                <Typography component="p" className={classes.subpening} style={{ fontFamily:'"Gill Sans MT Condensed", Arial, sans-serif',whiteSpace:'nowrap',fontSize: '18px', fontWeight: 600, color: '#777777' }}>
                EV Lifecycle Management Platform
                <br />
                By ReVx Energy
              </Typography>
                </Grid>
              </Grid>
              </Typography>
              
              
            </div>
            {/* <div className={classes.openingFooter}>
              <NavLink to="/" className={classes.back}>
                <ArrowBack />
                &nbsp;back to site
              </NavLink>
              <div className={classes.lang}>
                <SelectLanguage />
              </div>
            </div> */}
          </div>
        </Hidden>
        <div className={classes.sideFormWrap}>
          <SimpleSnackbar logInMessage={logInMessage} setLoginSucess={setLoginSucess} loginSuccess={loginSuccess} />
          <LoginForm onSubmit={(values) => submitForm(values)} />

        </div>
      </div>
    </div>
  );
}

Login.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(Login);
