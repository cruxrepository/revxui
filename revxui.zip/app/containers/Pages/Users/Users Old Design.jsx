import React from "react";
import axios from "axios";
import {
  withStyles,
  makeStyles,
  useTheme,
  styled,
} from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import Tooltip from "@material-ui/core/Tooltip";
import Paper from "@material-ui/core/Paper";
import './style.css';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import IconButton from '@material-ui/core/IconButton';
import { Icon } from '@iconify/react';

import SimpleSnackbar from './SimpleSnackbar';

import { useDispatch, useSelector, useState } from 'react-redux';
import Loading from '../../../components/Loading';
import ErrorWrap from '../../../components/Error/ErrorWrap';
import { getUserBulk, getRoleBulk, getRoleLBulk, getFleetBulk } from "../../../redux/actions/asyncActions";
import endpoints from '../../../endpoints/endpoints';
import Pagination from '@material-ui/lab/Pagination';

const useStyles = makeStyles((theme) => ({
  root: {
    margin: 10,
  },
  table: {
    "& > div": {
      "& > .MuiToolbar-regular": {
        backgroundColor: "#68A72480  !important",
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      },
      overflow: "auto",
      // textAlign:'center'
    },

    "& table": {
      "& td": {
        wordBreak: "keep-all",
        textAlign: "center",
      },
      [theme.breakpoints.down("md")]: {
        "& td": {
          height: 60,
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
      },
    },
  },
  gst: {
    color: '#4CAF50'
  },
  copyRight: {
    fontSize: "16px",
    color: "#68A724",
    fontWeight: 700,
    fontStyle: "Bold",
    whiteSpace: "nowrap",
  },
  tabHelp: {
    fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
  },
  formControl: {
    width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
  },
  textField: {
    width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
    'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
  },
  autoComplete: {
    '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
  },
  dialog: {
    position: 'relative', marginLeft: '630px'
  }
}));



/*
  It uses npm mui-datatables. It's easy to use, you just describe columns and data collection.
  Checkout full documentation here :
  https://github.com/gregnb/mui-datatables/blob/master/README.md
*/
export default function Users() {


  const UserData = useSelector((store) => store.userAll)
  const UserDataRaw = useSelector((store) => store.userAll.rawData)

  let UserMeta = useSelector((store) => store.userAll)

  const MyUserPage = useSelector((store) => store.userAll.page_number)
  const MyUserCount = Math.ceil(useSelector((store) => store.userAll.total_records) / 10 )
  
  let UserFetching = useSelector((store) => store.userAll.fetching)
  let UserResponsecode = useSelector((store) => store.userAll.responseStatus)
  let UserMetaPresent = useSelector((store) => store.userAll.dataPresent)
  const dispatch = useDispatch();



  let RoleFetching = useSelector((store) => store.roleAll.fetching)
  let RoleResponsecode = useSelector((store) => store.roleAll.responseStatus)
  let RoleMetaPresent = useSelector((store) => store.roleAll.dataPresent)
  const RoleData = useSelector((store) => store.roleAll)
  let RoleMeta = useSelector((store) => store.roleAll)
 
  let RoleLFetching = useSelector((store) => store.roleLAll.fetching)
  let RoleLResponsecode = useSelector((store) => store.roleLAll.responseStatus)
  let RoleLMetaPresent = useSelector((store) => store.roleLAll.dataPresent)
  const RoleLData = useSelector((store) => store.roleLAll)
  let RoleLMeta = useSelector((store) => store.roleLAll)
 let allRoles = RoleLMeta.data
  
  const FleetData = useSelector((store) => store.fleetAll)
  const FleetDataRaw = useSelector((store) => store.fleetAll.rawData)
  let FleetMeta = useSelector((store) => store.fleetAll)
  let FleetFetching = useSelector((store) => store.fleetAll.fetching)
  let FleetResponsecode = useSelector((store) => store.fleetAll.responseStatus)
  let FleetMetaPresent = useSelector((store) => store.fleetAll.dataPresent)

  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const [openEditUsers, setOpenEditUsers] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)
  const [addResponse, setAddResponce] = React.useState("")
  const changePage = (event, newValue) => {
    setPage(newValue);
  };
  const logged_user = useSelector((store) => store.login.result);
  let usersEditAccess = logged_user.users === "edit"
  let enty = logged_user.entity_id
  const [openAddUsers, setOpenAddUsers] = React.useState(false);


  React.useEffect(() => {
    dispatch(getUserBulk(enty, page));
  }, [dispatch, UserMetaPresent, page]);
  React.useEffect(() => {
    dispatch(getRoleBulk());
    dispatch(getRoleLBulk());
    dispatch(getFleetBulk());
  }, [dispatch, RoleMetaPresent, FleetMetaPresent]);

  const validateKeyData = (key) => {
    return key ? key : "-";
  };

  
  const [userAddForm, setUserAddForm] = React.useState(
  {
    username: "",
    password: "",
    role_id: "",        
    mobile_number: "",
    email: "",
    address: "",
    role_name: " ",
    entity_id:" ",
    entity:{
      asset_type:""
  }
  }
)


 const submitUser = () =>{
   if (userAddForm.username && userAddForm.password && userAddForm.role_id && userAddForm.entity_id && userAddForm.entity.asset_type) {

 const postUser = endpoints.baseUrl + `/bo/add`;
 axios
 .post(postUser, userAddForm)
 .then((response) => {
   setAddBatteryErrors(true);
   response.status === 201 ? setAddResponce("User Added Successfully") : setAddResponce(response.message)
     setOpenAddUsers(false)
     dispatch(getUserBulk(enty, page));
     // setUserAddForm({
     //   username: "",
     //   password: "",
     //   role_id: "",        
     //   mobile_number: "",
     //   email: "",
     //   address: "",
     //   role_name: " "
     // })
 });

} else {
setAddBatteryErrors(true);

setAddResponce("Please fill the required fields")

}

}

const setUserAddFormArray = (e, key, array) => {
 // setUserAddForm((state) => ({ ...state, [key]: e.target.value }));
 if (array) {
   setUserAddForm((state) => ({
       ...state, [array]: {
           ...state[array],
           [key]: e.target.value
       }
   }));
} else {
 setUserAddForm((state) => ({ ...state, [key]: e.target.value }));

}
 }
 const handleSubmiAddUser = () => {
   submitUser()
}

  const UsersColumn = [

    {
      label: "Users Name", name: "name",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Email", name: "email",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Mobile Number", name: "mobile",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Role Name", name: "role",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{value}</Typography>
        ),
      },
    },
    {
      label: "Fleet Company", name: "fleet",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      label: "Asset", name: "entity",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      label: "Action Button", name: "action",
      options: {
        filter: true,
        customBodyRender: (value) => {
          return (
            <><IconButton
              onClick={() => {
                setOpenEditUsers(true)
                setUserEditArray(value)
              }}
            ><Icon icon="bxs:edit-alt" color="#33a6ff" width="22" height="22" /></IconButton>
              <IconButton 
              onClick={() => { 
                deleteUser(value) 
              }}
              ><Icon icon="ic:baseline-delete" color="#fa5d41" width="22" height="22" /> </IconButton>
            </>
          );
        },
      },
    },


  ];
  const UsersColumn1 = [

    {
      label: "Users Name", name: "name",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }} >{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Email", name: "email",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }} >{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Mobile Number", name: "mobile",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{validateKeyData(value)}</Typography>
        ),
      },
    },
    {
      label: "Role Name", name: "role",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }}>{value}</Typography>
        ),
      },
    },
    {
      label: "Fleet Company", name: "fleet",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }} >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    {
      label: "Asset", name: "entity",
      options: {
        filter: true,
        customBodyRender: (value) => (
          <Typography style={{ cursor: "pointer", color: "#4caf50", fontSize: '0.875rem', fontWeight: 400, marginLeft: '-20px' }} >
            {validateKeyData(value)}
          </Typography>
        ),
      },
    },
    


  ];


  const [editArray, setEditArray] = React.useState({})
  const setUserEditArray = (user_id) => {
    let allUsers = UserDataRaw;
    let findArray = allUsers.find(el => el.user_id === user_id)
    setEditArray(findArray);
  }
  const submitUserEdit = () => {
    if(editArray.username && editArray.password && editArray.role_id && editArray.entity_id && editArray.entity.asset_type){
      const putUser = endpoints.baseUrl + `/bo/useredit/` + editArray.user_id;
      axios
        .put(putUser, editArray)
        .then((response) => {
          setAddBatteryErrors(true)
          response.status === 200 ? setAddResponce("User Edit Successfully") : setAddResponce(response.message)
          dispatch(getUserBulk(enty, page));
          setOpenEditUsers(false)
  
  
        });
  
    }
    else {
      setAddBatteryErrors(true);
      
      setAddResponce("Please fill the required fields")
      
      }
   
  }

  const deleteUser = (user_id) => {
    const deleteUser1 = endpoints.baseUrl + `/bo/usersoftdelete/` + user_id;
    axios
      .delete(deleteUser1)
      .then((response) => {
        setAddBatteryErrors(true)
        response.status === 200 ? setAddResponce("User Offboarding") : setAddResponce(response.message)
        dispatch(getUserBulk(enty, page));
      });
  }

  const setUserEditFormArray = (e, key, array) => {
    // setEditArray((state) => ({ ...state, [key]: e.target.value }));
    if (array) {
      setEditArray((state) => ({
          ...state, [array]: {
              ...state[array],
              [key]: e.target.value
          }
      }));
  } else {
    setEditArray((state) => ({ ...state, [key]: e.target.value }));
  
  }
  }



  const options = {
    filter: true,
    download: true,
    print: false,
    viewColumns: true,
    search: true,
    selectableRows: "none",
    customToolbar: () => {
      if(usersEditAccess === true){
      return (
        <Tooltip style={{ flex: 'left',transform: "translateX(-10em)" }} title={"Onboard Users"}>
        <IconButton
          className={classes.IconButton}
          onClick={() => setOpenAddUsers(true)}
        >
          <Icon icon="mdi:account-plus" width="22" height="22" hFlip={true} />
        </IconButton>
      </Tooltip>
      );}
      else {
        null
      }
    }
  };




  // const refreshPage = () => {
  //   window.location.reload(false);
  // }
  return (
    <div className={classes.table}>
<SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />
      <Paper square className={classes.root} />
      {(UserMetaPresent) ?
        (
          <>

            <MUIDataTable
              checkboxSelection={false}
              title="Users"
              data={UserMeta.data}
              columns={usersEditAccess === true ? UsersColumn : UsersColumn1}
              options={options}
              selectableRows={1}
              selectableRowsHideCheckboxes
            /><br />
            <Pagination count={MyUserCount} page={MyUserPage} onChange={changePage} />
          </>
        )
        :
        UserFetching ?
          <Loading /> :
          UserResponsecode === 500 ?

            <ErrorWrap />
            : null
      }
{/* //Add users */}
<Dialog
        fullScreen={fullScreen}
        open={openAddUsers}
        maxWidth={"lg"}
        onClose={() => setOpenAddUsers(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Users"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
             <Grid container spacing={2}>
             <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}>
                <Typography className={classes.tabHelp}>Users Name</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <TextField
                onChange={(e) => {
                  setUserAddFormArray(e, 'username')
                }}
                size="small" id="outlined" 
                error={addBatteryErrors && userAddForm.username === ""}
                value={userAddForm.username} placeholder="eg: John" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Mobile Number</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography>
                {!userAddForm.mobile_number.match(/^\d{10}$/) ? <p style={{ color: 'red', fontSize: '14px' }}>Must contains 10 digits</p> : null}</div>
                <TextField onChange={(e) => {
                  setUserAddFormArray(e, 'mobile_number')
                }}
                error={addBatteryErrors && userAddForm.mobile_number === ""} type="number"
                value={userAddForm.mobile_number} size="small" id="outlined" placeholder="eg: 9876543210" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Password</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <TextField
                onChange={(e) => { 
                  setUserAddFormArray(e, 'password')
                }} 
                size="small" id="outlined" 
                error={addBatteryErrors && userAddForm.password === ""}
                value={userAddForm.password}  className={classes.textField} />
              </Grid>
              
              <Grid item xs={12} lg={6}>
                <Typography className={classes.tabHelp}>Email ID</Typography>
                <TextField onChange={(e) => {
                  setUserAddFormArray(e, 'email')
                }}
                type="email" value={userAddForm.email_id} size="small" id="outlined" placeholder="eg: john@example.com" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <Typography className={classes.tabHelp}>Address</Typography>
                <TextField onChange={(e) => {
                  setUserAddFormArray(e,'address')
                }}
                value={userAddForm.address}  size="small" id="outlined" placeholder="eg: 123 Main St" className={classes.textField} />
              </Grid>
              
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Role Name</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select   onChange={(e) => {setUserAddFormArray(e,'role_id')}}
                error={addBatteryErrors && userAddForm.role_id === ""}
                value={userAddForm.role_id} className={classes.textField}>
                      <MenuItem value="">Select your Role</MenuItem>
                      {allRoles.length && allRoles.map((roleL) =>{
                  return(
                    <MenuItem value={roleL[1]}>{roleL[0]}</MenuItem>

                  )
                }
              )}

                      </Select>
              </Grid>

              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Fleet Company</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select   
                onChange={(e) => {setUserAddFormArray(e,'entity_id')}}
                error={addBatteryErrors && userAddForm.entity_id === ""}
                value={userAddForm.entity_id} 
                className={classes.textField}>
                      <MenuItem value="">Select your Fleet</MenuItem>
                      {FleetMeta.data.length && FleetMeta.data.map((fleet) => {
                          return (
                            <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>

                          )
                        }
                        )}

                      </Select>
              </Grid>

              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Entity Type</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select   
                onChange={(e) => {setUserAddFormArray(e,'asset_type', 'entity')}}
                // error={addBatteryErrors && userAddForm.role_id === ""}
                value={userAddForm.entity && userAddForm.entity.asset_type} 
                className={classes.textField}>
                      <MenuItem value="">Select your Entity</MenuItem>
                      <MenuItem value="Vehicle">Vehicle</MenuItem>
                      <MenuItem value="Battery">Battery</MenuItem>
                      <MenuItem value="Both">Both</MenuItem>


                      {/* {allRoles.map((role) =>{
                  return(
                    <MenuItem value={role[1]}>{role[0]}</MenuItem>

                  )
                }
              )} */}

                      </Select>
              </Grid>
            </Grid>  
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenAddUsers(false)}
            color="secondary">
            Cancel
          </Button>
          <Button
          onClick={() => {
            handleSubmiAddUser(true)
            //  refreshPage(true)
          }}
            color="primary" >
            Submit
          </Button>
        </DialogActions>
      </Dialog>  

      {/* edit User */}
      <Dialog
        fullScreen={fullScreen}
        open={openEditUsers}
        maxWidth={"lg"}
        data={UserDataRaw}
        onClose={() => setOpenEditUsers(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{" Users"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}>
                <Typography className={classes.tabHelp}>Users Name</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <TextField
                  onChange={(e) => { setUserEditFormArray(e, 'username') }}
                  size="small" id="outlined"
                  value={editArray.username}
                  className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Mobile Number</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <TextField
                  value={editArray.mobile_number} type="number"
                  onChange={(e) => { setUserEditFormArray(e, 'mobile_number') }}
                  size="small" id="outlined" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Password</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <TextField
                  value={editArray.password}
                  onChange={(e) => { setUserEditFormArray(e, 'password') }}
                  size="small" id="outlined" className={classes.textField} />
              </Grid>


              <Grid item xs={12} lg={6}>
                <Typography className={classes.tabHelp}>Email ID</Typography>
                <TextField
                  value={editArray.email}
                  type="email"
                  onChange={(e) => { setUserEditFormArray(e, 'email') }}
                  size="small" id="outlined" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <Typography className={classes.tabHelp}>Address</Typography>
                <TextField
                  value={editArray.address}

                  onChange={(e) => { setUserEditFormArray(e, 'address') }}
                  size="small" id="outlined" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Role Name</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select
                  onChange={(e) => { setUserEditFormArray(e, 'role_id') }}
                  value={editArray.role_id}
                  className={classes.textField}>

                  <MenuItem value="">Select your Role</MenuItem>
                  {allRoles.length && allRoles.map((role) => {
                    return (
                      <MenuItem value={role[1]}>{role[0]}</MenuItem>

                    )
                  }
                  )}
                </Select>

              </Grid>
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Fleet Company</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select
                  onChange={(e) => { setUserEditFormArray(e, 'entity_id') }}
                  value={editArray.entity_id} 
                  className={classes.textField}>

                  <MenuItem value="">Select your Fleet</MenuItem>
                  {FleetMeta.data.length && FleetMeta.data.map((fleet) => {
                          return (
                            <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>

                          )
                        }
                        )}
                </Select>

              </Grid>
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Asset Type</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select
                  onChange={(e) => { setUserEditFormArray(e,'asset_type', 'entity') }}
                  value={editArray.entity && editArray.entity.asset_type} 
                  className={classes.textField}>

                  {/* <MenuItem value="">{editArray.entity && editArray.entity.asset_type}</MenuItem> */}
                  <MenuItem value="Vehicle">Vehicle</MenuItem>
                  <MenuItem value="Battery">Battery</MenuItem>
                  <MenuItem value="Both">Both</MenuItem>
                </Select>

              </Grid>
            </Grid>




          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenEditUsers(false)}
            color="secondary">
            Cancel
          </Button>
          <Button
            onClick={() => {
              submitUserEdit(true)
              // refreshPage(true)
            }}
            color="primary"  >
            Submit
          </Button>
        </DialogActions>
      </Dialog>

      <br />
      <Typography align="center" className={classes.copyRight}>
        
        Copyright© 2023 ReVx Energy Pvt.Ltd.
      </Typography>
    </div>
  );
}
