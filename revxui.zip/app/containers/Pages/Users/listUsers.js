export const allUsers = [
    {
        email: 'admin@revx.com',
        username:'Admin',
        password: '1234',
        allowedFields: []
    },
    {
        email: 'opmanager@revx.com',
        username:'Operational Manager',
        password: '1234',
        allowedFields: ["live_Tracker","battery","settings"]
    },
]