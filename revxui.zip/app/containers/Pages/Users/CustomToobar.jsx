import React from "react";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import { withStyles, makeStyles, useTheme, styled, useStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Grid from '@material-ui/core/Grid';
import { Icon } from '@iconify/react';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import classNames from 'classnames';
import './style.css';
import axios from 'axios';
import endpoints from '../../../endpoints/endpoints';
import { getUserBulk , getRoleBulk, getRoleLBulk, getFleetBulk  } from "../../../redux/actions/asyncActions";
import { useDispatch, useSelector, useState } from 'react-redux';
import SimpleSnackbar from './SimpleSnackbar';


export default function CustomToolbar(props) {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const [openAddUsers, setOpenAddUsers] = React.useState(false);

  const handleClick = () => {
  }
  const useStyles = makeStyles((theme) => ({
    Box: {
      border: '1px solid #000000'
    },
    IconButton: {
      '&:hover': {
        color: '#9ccc65'
      },
      
    },
    tabHelp: {
      fontSize: '17px', fontFamily: ' Maven Pro', fontWeight: 400, color: '#A7A7A7'
    },
    formControl: {
      width: '100%', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#7A7A7D  !important' }
    },
    textField: {
      width: '100%', color: '#7A7A7D', borderRadius: '9px', '.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#C4C4C4  !important' },
      'input.MuiOutlinedInput-input': { fontSize: '15px', marginLeft: '60px' }
    },
    autoComplete: {
      '.MuiPaper-root': { width: '80% !important', marginLeft: '60px' }
  },
  dialog: {
    position:'relative', marginLeft:'630px'
  }
  }));

  //   const theme = useTheme();
  const classes = useStyles();
  const [status, setStatus] = React.useState('');
  const [action, setAction] = React.useState('');
  const [addrole, setAddRole] = React.useState('');


  const [addBatteryErrors, setAddBatteryErrors] = React.useState(false)
  const [notificationTimeOut, setNotificationTimeOut] = React.useState(6000)

  const [addResponse, setAddResponce] = React.useState("")
    const [userAddForm, setUserAddForm] = React.useState(
    {
      username: "",
      password: "",
      role_id: "",        
      mobile_number: "",
      email: "",
      address: "",
      role_name: " ",
      entity_id:" ",
      entity:{
        asset_type:""
    }
    }
  )

  const UserData = useSelector((store) => store.userAll)
  const UserDataRaw = useSelector((store) => store.userAll.rawData)
  const MyUserPage = useSelector((store) => store.userAll.page_number)
  const MyUserCount = Math.ceil(useSelector((store) => store.userAll.total_records) / 10 )
  let UserMeta = useSelector((store) => store.userAll)
  let UserFetching = useSelector((store) => store.userAll.fetching)
  let UserResponsecode = useSelector((store) => store.userAll.responseStatus)
  let UserMetaPresent = useSelector((store) => store.userAll.dataPresent)
  const dispatch = useDispatch();



  let RoleFetching = useSelector((store) => store.roleAll.fetching)
  let RoleResponsecode = useSelector((store) => store.roleAll.responseStatus)
  let RoleMetaPresent = useSelector((store) => store.roleAll.dataPresent)
  
  
  const FleetData = useSelector((store) => store.fleetAll)
  const FleetDataRaw = useSelector((store) => store.fleetAll.rawData)
  let FleetMeta = useSelector((store) => store.fleetAll)
  let FleetFetching = useSelector((store) => store.fleetAll.fetching)
  let FleetResponsecode = useSelector((store) => store.fleetAll.responseStatus)
  let FleetMetaPresent = useSelector((store) => store.fleetAll.dataPresent)

  const logged_user = useSelector((store) => store.login.result);
  let usersEditAccess = logged_user.users === "edit"
  let enty = logged_user.entity_id

  React.useEffect(() => {
    dispatch(getUserBulk(enty, page));
  }, [dispatch, UserMetaPresent, page]);
  React.useEffect(() => {
    dispatch(getRoleBulk());
    dispatch(getRoleLBulk());
    dispatch(getFleetBulk());
  }, [dispatch, RoleMetaPresent, FleetMetaPresent]);

  const RoleData = useSelector((store) => store.roleAll)
  let RoleMeta = useSelector((store) => store.roleAll)

  let RoleLFetching = useSelector((store) => store.roleLAll.fetching)
  let RoleLResponsecode = useSelector((store) => store.roleLAll.responseStatus)
  let RoleLMetaPresent = useSelector((store) => store.roleLAll.dataPresent)
  const RoleLData = useSelector((store) => store.roleLAll)
  let RoleLMeta = useSelector((store) => store.roleLAll)
 let allRoles = RoleLMeta.data
 const [page, setPage] = React.useState(1);
 const changePage = (event, newValue) => {
  setPage(newValue);
};

  const submitUser = () =>{
    if (userAddForm.username && userAddForm.password && userAddForm.role_id && userAddForm.entity_id && userAddForm.entity.asset_type) {

  const postUser = endpoints.baseUrl + `/bo/add`;
  axios
  .post(postUser, userAddForm)
  .then((response) => {
    setAddBatteryErrors(true);
    response.status === 201 ? setAddResponce("User Added Successfully") : setAddResponce(response.message)
      setOpenAddUsers(false)
      dispatch(getUserBulk(enty, page));
      // setUserAddForm({
      //   username: "",
      //   password: "",
      //   role_id: "",        
      //   mobile_number: "",
      //   email: "",
      //   address: "",
      //   role_name: " "
      // })
  });

} else {
setAddBatteryErrors(true);

setAddResponce("Please fill the required fields")

}

}

 const setUserAddFormArray = (e, key, array) => {
  // setUserAddForm((state) => ({ ...state, [key]: e.target.value }));
  if (array) {
    setUserAddForm((state) => ({
        ...state, [array]: {
            ...state[array],
            [key]: e.target.value
        }
    }));
} else {
  setUserAddForm((state) => ({ ...state, [key]: e.target.value }));

}
  }
  const handleSubmiAddUser = () => {
    submitUser()
}
  const handleChange1 = (event) => {
    setStatus(event.target.value);
};
const handleChange2 = (event) => {
  setAction(event.target.value);
};
// const refreshPage = () => {
//   window.location.reload(false);
// }
  return (
    <React.Fragment>
      <Tooltip style={{ flex: 'left' }} title={"Onboard Users"}>
        <IconButton
          className={classes.IconButton}
          onClick={() => setOpenAddUsers(true)}
        >
          <Icon icon="mdi:account-plus" width="30" height="30" hFlip={true} />
        </IconButton>
      </Tooltip>
      <SimpleSnackbar logInMessage={addResponse} notificationTimeOut={notificationTimeOut} setLoginSucess={setAddBatteryErrors} loginSuccess={addBatteryErrors} />

      <Dialog
        fullScreen={fullScreen}
        open={openAddUsers}
        maxWidth={"lg"}
        onClose={() => setOpenAddUsers(false)}
        aria-labelledby="responsive-dialog-title"
        className={!fullScreen ? classes.dialog : null}
      >
        <DialogTitle id="responsive-dialog-title">{"Users"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
             <Grid container spacing={2}>
             <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}>
                <Typography className={classes.tabHelp}>Users Name</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <TextField
                onChange={(e) => {
                  setUserAddFormArray(e, 'username')
                }}
                size="small" id="outlined" 
                error={addBatteryErrors && userAddForm.username === ""}
                value={userAddForm.username} placeholder="eg: John" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Mobile Number</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography>
                {!userAddForm.mobile_number.match(/^\d{10}$/) ? <p style={{ color: 'red', fontSize: '14px' }}>Must contains 10 digits</p> : null}</div>
                <TextField onChange={(e) => {
                  setUserAddFormArray(e, 'mobile_number')
                }}
                error={addBatteryErrors && userAddForm.mobile_number === ""} type="number"
                value={userAddForm.mobile_number} size="small" id="outlined" placeholder="eg: 9876543210" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Password</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <TextField
                onChange={(e) => { 
                  setUserAddFormArray(e, 'password')
                }} 
                size="small" id="outlined" 
                error={addBatteryErrors && userAddForm.password === ""}
                value={userAddForm.password}  className={classes.textField} />
              </Grid>
              
              <Grid item xs={12} lg={6}>
                <Typography className={classes.tabHelp}>Email ID</Typography>
                <TextField onChange={(e) => {
                  setUserAddFormArray(e, 'email')
                }}
                type="email" value={userAddForm.email_id} size="small" id="outlined" placeholder="eg: john@example.com" className={classes.textField} />
              </Grid>
              <Grid item xs={12} lg={6}>
                <Typography className={classes.tabHelp}>Address</Typography>
                <TextField onChange={(e) => {
                  setUserAddFormArray(e,'address')
                }}
                value={userAddForm.address}  size="small" id="outlined" placeholder="eg: 123 Main St" className={classes.textField} />
              </Grid>
              
              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Role Name</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select   onChange={(e) => {setUserAddFormArray(e,'role_id')}}
                error={addBatteryErrors && userAddForm.role_id === ""}
                value={userAddForm.role_id} className={classes.textField}>
                      <MenuItem value="">Select your Role</MenuItem>
                      {allRoles.length && allRoles.map((roleL) =>{
                  return(
                    <MenuItem value={roleL[1]}>{roleL[0]}</MenuItem>

                  )
                }
              )}

                      </Select>
              </Grid>

              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Fleet Company</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select   
                onChange={(e) => {setUserAddFormArray(e,'entity_id')}}
                error={addBatteryErrors && userAddForm.entity_id === ""}
                value={userAddForm.entity_id} 
                className={classes.textField}>
                      <MenuItem value="">Select your Fleet</MenuItem>
                      {FleetMeta.data.length && FleetMeta.data.map((fleet) => {
                          return (
                            <MenuItem value={fleet[1]}>{fleet[0]}</MenuItem>

                          )
                        }
                        )}

                      </Select>
              </Grid>

              <Grid item xs={12} lg={6}>
              <div style={{display:'flex'}}><Typography className={classes.tabHelp}>Entity Type</Typography>&nbsp;
                <Typography style={{color:'red', fontSize: '20px'}}>*</Typography></div>
                <Select   
                onChange={(e) => {setUserAddFormArray(e,'asset_type', 'entity')}}
                // error={addBatteryErrors && userAddForm.role_id === ""}
                value={userAddForm.entity && userAddForm.entity.asset_type} 
                className={classes.textField}>
                      <MenuItem value="">Select your Entity</MenuItem>
                      <MenuItem value="Vehicle">Vehicle</MenuItem>
                      <MenuItem value="Battery">Battery</MenuItem>
                      <MenuItem value="Both">Both</MenuItem>


                      {/* {allRoles.map((role) =>{
                  return(
                    <MenuItem value={role[1]}>{role[0]}</MenuItem>

                  )
                }
              )} */}

                      </Select>
              </Grid>
            </Grid>  
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus
            onClick={() => setOpenAddUsers(false)}
            color="secondary">
            Cancel
          </Button>
          <Button
          onClick={() => {
            handleSubmiAddUser(true)
            //  refreshPage(true)
          }}
            color="primary" >
            Submit
          </Button>
        </DialogActions>
      </Dialog>  

    </React.Fragment>

  );


}

// export default withStyles(CustomToolbar, defaultToolbarStyles, { name: "CustomToolbar" });
