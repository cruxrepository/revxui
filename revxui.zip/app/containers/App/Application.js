import React, { useContext } from "react";
import { PropTypes } from "prop-types";
import { Switch, Route , useLocation, Navigate,Redirect} from "react-router-dom";
 
import Dashboard from "../Templates/Dashboard";
import LiveTracker from "../Pages/LiveTracker";
import VehicleDashboard from "../Pages/VehicleDashboard";
import BatteryDashboard from "../Pages/BatteryDashboard";
import BatteryPage from "../Pages/Battery";
import AssignmentPage from "../Pages/Assignment";
import ddd from "../Pages/Dashboardd";
import Drivers from "../Pages/Drivers";
import FleetManager from "../Pages/FleetManager";
import OperationsManager from "../Pages/OperationsManager";
import VehicleInvestor from "../Pages/VehicleInvestor";
import BatteryInvestor from "../Pages/BatteryInvestor";
import Vehicle from "../Pages/Vehicle";
import Association from "../Pages/Association";
// import Analytic from "../Pages/Analytic";
import Users from "../Pages/Users";
import Report from "../Pages/Report";
import Telematics from "../Pages/Telematics";
import Role from "../Pages/Role";
import { AppContext } from "./ThemeWrapper";
import { useSelector } from "react-redux";
 import {
  DashboardPage,
  ComingSoon,
  BlankPage,
  Error,
  NotFound,
  Form,
  Table,
  Parent,
  // Battery
} from "../pageListAsync";

function Application(props) {
  const location = useLocation();
  const LUser = useSelector((store) => store.login.result)
  let roleID= LUser.role_id;
  const admin = useSelector((store) => store.login.result.entity_id);
  // console.log("admin",admin)
  // const admin = useSelector((store) => store.user.loggeduser.entity_id);
  const isAdmin =( admin === 1  )
  React.useEffect(() => {
    if (isAdmin && location.pathname === '/app' ) {      // if (location.pathname.toLowerCase() === "login") {
      // <Redirect to="/logout" /> 
    }
  }, [isAdmin, location]);
  const { history } = props;
  const changeMode = useContext(AppContext);

  return (
    <Dashboard history={history} changeMode={changeMode}>
      <Switch>
        Home
        <Route exact path="/app" component={BatteryPage} />
        <Route path="/app/pages/dashboard" component={ddd} />
        <Route path="/app/pages/fleetmanager" component={FleetManager} />
        <Route path="/app/pages/operationsmanager" component={OperationsManager} />
        <Route path="/app/pages/vehicleinvestor" component={VehicleInvestor}/>
        <Route path="/app/pages/batteryinvestor" component={BatteryInvestor}/>
        <Route path="/app/pages/form" component={Form} />
        <Route path="/app/pages/association" component={Association} />
        {/* <Route path="/app/pages/analytics" component={Analytic} /> */}
        <Route path="/app/pages/drivers" component={Drivers} />
        <Route path="/app/pages/vehicle" component={isAdmin ? Vehicle: Vehicle} />
        <Route path="/app/pages/users" component={Users} />
        <Route path="/app/pages/report" component={Report} />
        <Route path="/app/pages/telematics" component={Telematics} />
        <Route path="/app/pages/role" component={Role} />
        <Route path="/app/pages/battery" component={BatteryPage} />
        <Route path="/app/pages/assignment" component={AssignmentPage} />
        <Route path="/app/pages/livetracker" component={LiveTracker} />
        <Route path="/app/pages/vehicle-dashboard" component={VehicleDashboard} />
        <Route path="/app/pages/battery-dashboard" component={BatteryDashboard} />
        <Route path="/app/pages/table" component={Table} />
        <Route path="/app/pages/page-list" component={Parent} />
        <Route path="/app/pages/pages/not-found" component={NotFound} />
        <Route path="/app/pages/pages/error" component={Error} />
        <Route component={NotFound} />
      </Switch>
    </Dashboard>
  );
}

Application.propTypes = {
  history: PropTypes.object.isRequired,
};

export default Application;
