import React from 'react';
import { Switch, Route , useLocation, Navigate,Redirect} from "react-router-dom";
import NotFound from '../Pages/Standalone/NotFoundDedicated';
import LoginDedicated from '../Pages/Standalone/LoginDedicated';
import LogoutAndClear from './LogoutAndClear';
import Auth from './Auth';
import Application from './Application';
import ThemeWrapper from './ThemeWrapper';
window.__MUI_USE_NEXT_TYPOGRAPHY_VARIANTS__ = true;
import { useDispatch, useSelector } from "react-redux";

// import ErrorBoundry from "../../utils/ErrorBoundary";
 function App() {
  // const dispatch = useDispatch();
  // console.log("starta");
   const loggedUser = useSelector((store) => store.login.result);
  //  dispatch(loggedUser(JSON.parse(localStorage.getItem('logged_user'))));
  // let loggedUser = localStorage.getItem('logged_user');
  // loggedUser =JSON.parse(loggedUser);
  const location = useLocation();
  // React.useEffect(() => {
    // const authToken = localStorage.getItem('authToken');
    // console.log("call22",loggedUser);
    // console.log("call22",loggedUser,loggedUser.username,location.pathname);
    if ((loggedUser  && loggedUser.username !== 'undefined') && location.pathname === '/logout' || location.pathname === '/' ) {      // if (location.pathname.toLowerCase() === "login") {
      // console.log("call23",loggedUser);
      // return  <Navigate to="/app"    replace />
      // return <Redirect to="/app" />;
    //   console.log("call223",loggedUser);
    // setTimeout(() => {
      window.location.href = '/app';
    // }, 3000)
      // }
    }
  // }, [loggedUser, location]);
 
 
   return (
    <ThemeWrapper>
      {/* <ErrorBoundry> */}
      <Switch>
{/* <Route path="/logout" component={LogoutAndClear} /> */}
    
{ loggedUser  && loggedUser.username

 ?
 <>
{/* <Route path="/" component={Application} /> */}

<Route path="/app" component={Application} />
{/* <Route component={Auth} />
<Route component={NotFound} /> */}
</>
:   
  
<Route path="*" exact component={LoginDedicated} />

}
       
      </Switch>
      {/* </ErrorBoundry> */}
    </ThemeWrapper>
  );
}
export default App;

 
