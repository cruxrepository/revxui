import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { clearMyBattery, clearLoggeduser, clearBattProfile, clearBattView, clearDrivers, clearUsersList,
    clearCV, clearEV, clearVM, clearIV, clearOM, clearEntity, clearClient, clearBVA, clearVDA, clearFleet, clearTelematics,
    clearReport } from '../../redux/actions/normalActions';
import { Switch, Route, useLocation, Navigate } from "react-router-dom";
import LoginDedicated from '../Pages/Standalone/LoginDedicated';

export default function LogoutAndClear() {
    const dispatch = useDispatch()
    React.useEffect(() => {
    dispatch(clearMyBattery())
    dispatch(clearLoggeduser())
    dispatch(clearBattProfile())
    dispatch(clearBattView())
    dispatch(clearDrivers())
    dispatch(clearUsersList())
    dispatch(clearCV())
    dispatch(clearEV())
    dispatch(clearVM())
    dispatch(clearIV())
    dispatch(clearOM())
    dispatch(clearEntity())
    dispatch(clearClient())
    dispatch(clearBVA())
    dispatch(clearVDA())
    dispatch(clearFleet())
    dispatch(clearTelematics())
    dispatch(clearReport())
    },[])

    
    return (
        <LoginDedicated   />
    )

}