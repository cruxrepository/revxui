import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import classNames from 'classnames';
import CardGiftcard from '@material-ui/icons/CardGiftcard';
import LocalLibrary from '@material-ui/icons/LocalLibrary';
import Computer from '@material-ui/icons/Computer';
import Toys from '@material-ui/icons/Toys';
import Avatar from '@material-ui/core/Avatar';
import Divider from '@material-ui/core/Divider';
import Style from '@material-ui/icons/Style';
import Typography from '@material-ui/core/Typography';
import purple from '@material-ui/core/colors/purple';
import blue from '@material-ui/core/colors/blue';
import cyan from '@material-ui/core/colors/cyan';
import pink from '@material-ui/core/colors/pink';
import colorfull from 'enl-api/palette/colorfull';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  CartesianAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart, Pie, Cell,
  Legend
} from 'recharts';
import { dataSales } from 'enl-api/chart/chartData';
import { data2 } from 'enl-api/chart/chartMiniData';
import { injectIntl, FormattedMessage } from 'react-intl';
import messages from './messages';
import styles from './widget-jss';
import PapperBlock from '../PapperBlock/PapperBlock';

const color = ({
  primary: colorfull[0],
  secondary: colorfull[1],
  third: colorfull[2],
  fourth: colorfull[3],
});

const colorsPie = [purple[500], blue[500], cyan[500], pink[500]];

function SalesChartWidget(props) {
  const { classes, intl } = props;
  return (
    <PapperBlock whiteBg noMargin title={intl.formatMessage(messages.product_title)} icon="bar_chart" desc="">
      <Grid container spacing={2}>
        <Grid item md={8} xs={12}>
          <ul className={classes.bigResume}>
            <li>
              <Avatar className={classNames(classes.avatar, classes.pinkAvatar)}>
                <LocalLibrary />
              </Avatar>
              <Typography variant="h6">
                <span className={classes.pinkText}>4321</span>
                <Typography>
                  <FormattedMessage {...messages.fashions} />
                </Typography>
              </Typography>
            </li>
            <li>
              <Avatar className={classNames(classes.avatar, classes.purpleAvatar)}>
                <Computer />
              </Avatar>
              <Typography variant="h6">
                <span className={classes.purpleText}>9876</span>
                <Typography>
                  <FormattedMessage {...messages.electronics} />
                </Typography>
              </Typography>
            </li>
            <li>
              <Avatar className={classNames(classes.avatar, classes.blueAvatar)}>
                <Toys />
              </Avatar>
              <Typography variant="h6">
                <span className={classes.blueText}>345</span>
                <Typography>
                  <FormattedMessage {...messages.toys} />
                </Typography>
              </Typography>
            </li>
            <li>
              <Avatar className={classNames(classes.avatar, classes.tealAvatar)}>
                <Style />
              </Avatar>
              <Typography variant="h6">
                <span className={classes.tealText}>1021</span>
                <Typography>
                  <FormattedMessage {...messages.vouchers} />
                </Typography>
              </Typography>
            </li>
          </ul>
          <div className={classes.chartWrap}>
            <div className={classes.chartFluid}>
              <ResponsiveContainer width={800} height="80%">
                <BarChart
                  data={dataSales}
                >
                  <XAxis dataKey="name" tickLine={false} />
                  <YAxis axisLine={false} tickSize={3} tickLine={false} tick={{ stroke: 'none' }} />
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <CartesianAxis />
                  <Tooltip />
                  <Bar dataKey="Fashions" fill={color.primary} />
                  <Bar dataKey="Electronics" fill={color.secondary} />
                  <Bar dataKey="Toys" fill={color.third} />
                  <Bar dataKey="Vouchers" fill={color.fourth} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Grid>
        <Grid item md={4} xs={12}>
          <Typography className={classes.smallTitle} variant="button">
            <CardGiftcard className={classes.leftIcon} />
            <FormattedMessage {...messages.today_sales} />
          </Typography>
          <Divider className={classes.divider} />
          <Grid container className={classes.secondaryWrap}>
            <PieChart width={300} height={300}>
              <Pie
                data={data2}
                cx={150}
                cy={100}
                dataKey="value"
                innerRadius={40}
                outerRadius={80}
                fill="#FFFFFF"
                paddingAngle={5}
                label
              >
                {
                  data2.map((entry, index) => <Cell key={index.toString()} fill={colorsPie[index % colorsPie.length]} />)
                }
              </Pie>
              <Legend iconType="circle" verticalALign="bottom" iconSize={10} />
            </PieChart>
          </Grid>
        </Grid>
      </Grid>
    </PapperBlock>
  );
}

SalesChartWidget.propTypes = {
  classes: PropTypes.object.isRequired,
  intl: PropTypes.object.isRequired
};

export default withStyles(styles)(injectIntl(SalesChartWidget));
