import { Tooltip } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';

const ArrowTooltip = withStyles((theme) => ({
  arrow: {
    color: theme.palette.common.white,
    zIndex: 4,
    boxShadow:'2px 4px 4px #cfcfcf'
  },
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: '#fff',
    boxShadow: theme.shadows[1],
    fontSize: 12,
    zIndex: 2,
  },
}))(Tooltip);

export default ArrowTooltip;