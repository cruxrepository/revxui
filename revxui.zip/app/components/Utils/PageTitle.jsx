import React from "react";
import Typography from '@material-ui/core/Typography';
export default function PageTitle(){
  return(
    <Typography
    style={{textTransform:'Capitalize' ,color:'#68A724',margin:5, fontFamily:'Maven Pro', fontWeight:600}}
    component="h4" variant="h4">{location.pathname.toString().split('/')[3]}</Typography>
  )
}