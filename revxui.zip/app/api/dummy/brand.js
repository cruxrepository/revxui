module.exports = {
  name: 'TuringX',
  desc: 'TuringX - Home',
  prefix: 'turingx',
  footerText: 'TuringX - All Rights Reserved 2020',
  logoText: 'TuringX',
};
