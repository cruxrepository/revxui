module.exports = [
//   {
//   key: 'dashboard',
//   name: 'Dashboard',
//   icon: 'home',
//   link: '/app/pages/dashboard',
//   child: [
//     // {
//     //   key: 'dashboard',
//     //   name: 'Sttaic Auth Page',
//     //   title: true,
//     // },
//     // {
//     //   key: 'login',
//     //   name: 'Login',
//     //   icon: 'account_box',
//     //   link: '/login'
//     // },
//     // {
//     //   key: 'register',
//     //   name: 'Register',
//     //   icon: 'border_color',
//     //   link: '/register'
//     // },
//     // {
//     //   key: 'reset',
//     //   name: 'Reset Password',
//     //   icon: 'undo',
//     //   link: '/reset-password'
//     // },
//     // {
//     //   key: 'dashboard_firebase',
//     //   name: 'Firebase Auth Page',
//     //   title: true,
//     // },
//     // {
//     //   key: 'login',
//     //   name: 'Login',
//     //   icon: 'account_box',
//     //   link: '/login-firebase'
//     // },
//     // {
//     //   key: 'register',
//     //   name: 'Register',
//     //   icon: 'border_color',
//     //   link: '/register-firebase'
//     // },
//     // {
//     //   key: 'reset',
//     //   name: 'Reset Password',
//     //   icon: 'undo',
//     //   link: '/reset-password-firebase'
//     // },
//   ],
// },
{
  key: 'live_tracker',
  name: 'Live Tracker',
  icon: 'roomout',
  link: '/app/pages/livetracker',
  child: [
    // {
    //   key: 'other_page',
    //   name: 'Welcome Page',
    //   title: true,
    // },
    // {
    //   key: 'blank',
    //   name: 'Blank Page',
    //   icon: 'video_label',
    //   link: '/app'
    // },
    // {
    //   key: 'generic_page',
    //   name: 'Generic',
    //   title: true,
    // },
    // {
    //   key: 'dashboard',
    //   name: 'Dashboard',
    //   icon: 'settings_brightness',
    //   link: '/app/pages/dashboard'
    // },
    // {
    //   key: 'forms',
    //   name: 'Form',
    //   link: '/app/pages/form',
    //   icon: 'ballot',
    // },
    // {
    //   key: 'tables',
    //   name: 'Table',
    //   icon: 'grid_on',
    //   link: '/app/pages/table'
    // },
    // {
    //   key: 'maintenance',
    //   name: 'Maintenance',
    //   icon: 'settings',
    //   link: '/maintenance'
    // },
    // {
    //   key: 'coming_soon',
    //   name: 'Coming Soon',
    //   icon: 'polymer',
    //   link: '/coming-soon'
    // },
  ],
},
{
  key: 'drivers',
  name: 'Drivers',
  link: '/app/pages/drivers',
  // multilevel: true,
  icon: 'contacts',
  child: [],
},
{
  key: 'vehicle',
  name: 'Vehicle',
  icon: 'airport_shuttle',
  link: '/app/pages/vehicle',
  child: [
    //   {
    //     key: 'errors',
    //     name: 'Errors',
    //     title: true,
    //   },
    //   {
    //     key: 'not_found_page',
    //     name: 'Not Found Page',
    //     icon: 'pets',
    //     link: '/app/pages/not-found'
    //   },
    //   {
    //     key: 'error_page',
    //     name: 'Error Page',
    //     icon: 'flash_on',
    //     link: '/app/pages/error'
    //   },
  ],
},
{
  key: 'battery',
  name: 'Battery',
  link: '/app/pages/battery',
  // multilevel: true,
  icon: 'battery_0_bar',
  child: [
    //   {
    //     key: 'level_1',
    //     name: 'Level 1',
    //     link: '/#'
    //   },
    //   {
    //     key: 'level_2',
    //     keyParent: 'menu_levels',
    //     name: 'Level 2',
    //     child: [
    //       {
    //         key: 'sub_menu_1',
    //         name: 'Sub Menu 1',
    //         link: '/#'
    //       },
    //       {
    //         key: 'sub_menu_2',
    //         name: 'Sub Menu 2',
    //         link: '/#'
    //       },
    //     ]
    //   },
  ],
},
{
  key: 'telematics',
  name: 'Telematics',
  link: '/app/pages/telematics',
  // multilevel: true,
  icon: 'electric_car',
  child: [],
},
{
  key: 'assignment',
  name: 'Assignment',
  link: '/app/pages/assignment',
  // multilevel: true,
  icon: 'assignment',
  child: [],
},
// {
//     key: "analytic",
//     name: "Analytics",
//     link: '/app/pages/analytics',
//     // multilevel: true,
//     icon: "analytics",
//     child: [],
// },
// {
//     key: "charging",
//     name: "Charging",
//     link: '/app/pages/',
//     // multilevel: true,
//     icon: "battery_charging_full",
//     child: [],
// },
// {
//     key: "telematics",
//     name: "Telematics",
//     link: '/app/pages/',
//     // multilevel: true,
//     icon: "electric_car",
//     child: [],
// },
{
  key: 'client',
  name: 'Association',
  link: '/app/pages/association',
  // multilevel: true,
  icon: 'person',
  child: [],
},

// {
//     key: "accounts",
//     name: "Accounts",
//     link: '/app/pages/',
//     // multilevel: true,
//     icon: "account_circle",
//     child: [],
// },

{
  key: 'reports',
  name: 'Reports',
  link: '/app/pages/report',
  // multilevel: true,
  icon: 'comment',
  child: [],
},
{
  key: 'users',
  name: 'Users',
  link: '/app/pages/users',
  // multilevel: true,
  icon: 'people',
  child: [],
},
{
  key: 'role',
  name: 'Role',
  link: '/app/pages/role',
  // multilevel: true,
  icon: 'supervised_user_circle',
  child: [],
},
{
  key: 'settings',
  name: 'Settings',
  link: '/app/pages/',
  // multilevel: true,
  icon: 'settings',
  child: [],
},
];
